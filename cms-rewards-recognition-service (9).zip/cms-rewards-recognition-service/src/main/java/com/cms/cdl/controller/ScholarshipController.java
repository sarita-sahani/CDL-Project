package com.cms.cdl.controller;

import com.cms.cdl.dto.honorClub.ScholarshipDto;
import com.cms.cdl.Enum.ScholarshipType;
import com.cms.cdl.service.ScholarshipService;
import com.cms.cdl.utils.ApiResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;

@RestController
@RequestMapping("/api/scholarship")
@RequiredArgsConstructor
@CrossOrigin("*")
public class ScholarshipController {

    private final ScholarshipService scholarshipService;

    @PostMapping("/saveScholarshipdata")
    public ResponseEntity<ScholarshipDto.Response> saveScholarship(
            @RequestBody ScholarshipDto.Request request) throws IOException { // ← @RequestBody
        return ResponseEntity.ok(scholarshipService.saveScholarship(request));
    }

    @GetMapping("/year/{awardYear}")
    public ApiResponse getByYear(
            @PathVariable String awardYear) {

        return ApiResponse.success(
                scholarshipService
                        .getByYear(awardYear));
    }

    @GetMapping("/type/{scholarshipType}")
    public ApiResponse getByType(
            @PathVariable ScholarshipType scholarshipType) {

        return ApiResponse.success(
                scholarshipService
                        .getByType(
                                scholarshipType.name()));
    }

    @GetMapping("/filter")
    public ApiResponse getByYearAndType(
            @RequestParam String awardYear,
            @RequestParam ScholarshipType scholarshipType) {

        return ApiResponse.success(
                scholarshipService
                        .getByYearAndType(
                                awardYear,
                                scholarshipType.name()));
    }
}