package com.cms.cdl.service;

import com.cms.cdl.dto.honorClub.HonorClubDto;
import com.cms.cdl.Enum.HonorClubType;

import java.io.IOException;
import java.util.List;

public interface HonorClubService {

    HonorClubDto.Response saveHonorClubData(HonorClubDto.Request request) throws IOException;

    List<HonorClubDto.Response> getHonorClubDataByYear(
            String awardYear);

    List<HonorClubDto.Response> getHonorClubDataByType(
            HonorClubType honorClubType);

    List<HonorClubDto.Response>
    getHonorClubDataByYearAndType(
            String awardYear,
            HonorClubType honorClubType);
}