package com.cms.cdl.dto.executiveCircleDto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class HRMailAwardGroup {
    private String awardTitle;
    private String awardCategory;
    private List<NominationDetailDTO> nominees;

}
