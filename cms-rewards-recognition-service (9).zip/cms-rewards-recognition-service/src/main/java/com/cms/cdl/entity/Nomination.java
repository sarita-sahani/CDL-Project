package com.cms.cdl.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "nominations")
@Data
@RequiredArgsConstructor
@NoArgsConstructor(force = true)
@AllArgsConstructor
@Builder
public class Nomination {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NonNull
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "award_id", nullable = false)
    private Award award;

    @NonNull
    @Column(name = "financial_year", nullable = false)
    private String financialYear;

    @Column(name = "submitted_by_employee_code")
    private String submittedByEmployeeCode;

    @Column(name = "submitted_by_name")
    private String submittedByName;

    @Column(name = "submitted_by_emailId")
    private String submittedByEmailId;

    @Column(name = "is_nominating")
    private boolean isNominating;

    // @Enumerated(EnumType.STRING)
    @Convert(converter = NominationStatusConverter.class)
    @Column(name = "status")
    private NominationStatus status;

    @Column(name = "hr_remarks", columnDefinition = "TEXT")
    private String hrRemarks;

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @UpdateTimestamp
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @OneToMany(mappedBy = "nomination", cascade = CascadeType.ALL, orphanRemoval = true)
    @Builder.Default
    private List<NominationDetail> nominationDetails = new ArrayList<>();

    public enum NominationStatus {
        DRAFT("Draft"),
        SUBMITTED_TO_HR("Submitted to HR"),
        APPROVED("Approved"),
        REJECTED("Rejected");

        private final String displayValue;

        NominationStatus(String displayValue) {
            this.displayValue = displayValue;
        }

        public String getDisplayValue() {
            return displayValue;
        }
    }
}
