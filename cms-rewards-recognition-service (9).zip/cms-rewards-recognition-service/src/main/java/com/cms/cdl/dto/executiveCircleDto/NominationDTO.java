package com.cms.cdl.dto.executiveCircleDto;

import com.cms.cdl.entity.Nomination;
import lombok.*;

import java.time.LocalDateTime;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class NominationDTO {
    private Long id;
    private Long awardId;
    private String category;
    private String financialYear;
    private String submittedByEmployeeCode;
    private String submittedByName;
    private String submittedByEmailId;
    private boolean isNominating;
    private String status;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    private List<NominationDetailDTO> nominationDetails;

    // ── NEW fields — populated by mapper for preview ─────────────────────────
    private String awardTitle;
    private String awardCategory;
}
