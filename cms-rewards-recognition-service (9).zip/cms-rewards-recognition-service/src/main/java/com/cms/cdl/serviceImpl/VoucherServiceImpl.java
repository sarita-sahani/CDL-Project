package com.cms.cdl.serviceImpl;

import com.cms.cdl.dto.VoucherDto;
import com.cms.cdl.entity.RnRMappingTable;
import com.cms.cdl.entity.Voucher;
import com.cms.cdl.mapper.VoucherMapper;
import com.cms.cdl.repository.RnRMappingRepo;
import com.cms.cdl.repository.VoucherRepository;
import com.cms.cdl.service.MailService;
import com.cms.cdl.service.VoucherService;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class VoucherServiceImpl implements VoucherService {

    @Autowired
    private VoucherRepository voucherRepository;

    @Autowired
    private VoucherMapper voucherMapper;

    @Autowired
    private MailService mailService;

    @Autowired
    private RnRMappingRepo rnRMappingRepo;

    // threshold constant
    private static final int LOW_VOUCHER_THRESHOLD = 5;


//    @Override
//    public List<VoucherDto> getAllVouchers() {
//        return voucherRepository.findAll().stream()
//                .map(voucherMapper::toDto)
//                .collect(Collectors.toList());
//    }

    @Override
    public List<VoucherDto> getAllVouchers() {
        List<Voucher> vouchers = voucherRepository.findAll();
        LocalDate today = LocalDate.now();

        List<VoucherDto> result = vouchers.stream()
                .map(v -> {
                    // ✅ Auto-update status based on expiry
                    if (v.getExpiryDate() != null && !v.getExpiryDate().isAfter(today)) {
                        v.setVoucherStatus("Expired");
                    } else {
                        v.setVoucherStatus("Active");
                    }
                    return voucherMapper.toDto(v);
                })
                .collect(Collectors.toList());

        // ✅ Count Active + Unused vouchers
        long activeUnusedCount = result.stream()
                .filter(v -> "Active".equalsIgnoreCase(v.getVoucherStatus())
                        && "Unused".equalsIgnoreCase(v.getUsageStatus()))
                .count();

        List<RnRMappingTable> emailListNotificationforAddVoucher=rnRMappingRepo.findAll();
        List<String> emailIds = emailListNotificationforAddVoucher.stream()
                .map(RnRMappingTable::getEmailId)
                .collect(Collectors.toList());
        System.out.println("emailIds list==="+emailIds);
        // ✅ Send alert if count is exactly at or below threshold
        if (activeUnusedCount <= LOW_VOUCHER_THRESHOLD) {
            try {
                mailService.sendLowVoucherAlert(emailIds,activeUnusedCount);
            } catch (Exception e) {
                // log but don't break the API response
                System.err.println("Failed to send voucher alert email: " + e.getMessage());
            }
        }

        return result;
    }

    @Override
    public VoucherDto addVoucher(VoucherDto dto) {
        Voucher voucher = voucherMapper.toEntity(dto);

        // ✅ Generate unique voucher number safely
        if (voucher.getVoucherNumber() == null || voucher.getVoucherNumber().isEmpty()) {

            String lastVoucher = voucherRepository.findLastVoucherNumber();

            int nextNumber = 1001;

            if (lastVoucher != null && lastVoucher.startsWith("VCH")) {
                int lastNum = Integer.parseInt(lastVoucher.substring(3));
                nextNumber = lastNum + 1;
            }

            voucher.setVoucherNumber("VCH" + nextNumber);
        }

        // defaults
        if (voucher.getVoucherStatus() == null) voucher.setVoucherStatus("Active");
        if (voucher.getUsageStatus() == null) voucher.setUsageStatus("Unused");

        voucher.setCreatedAt(LocalDateTime.now());

        return voucherMapper.toDto(voucherRepository.save(voucher));
    }
    @Override
    public List<VoucherDto> addBulkVouchers(List<VoucherDto> dtos) {

        String lastVoucher = voucherRepository.findLastVoucherNumber();
        int nextNumber = 1001;

        if (lastVoucher != null && lastVoucher.startsWith("VCH")) {
            nextNumber = Integer.parseInt(lastVoucher.substring(3)) + 1;
        }

        List<Voucher> vouchers = new ArrayList<>();

        for (VoucherDto dto : dtos) {
            Voucher voucher = voucherMapper.toEntity(dto);

            if (voucher.getVoucherNumber() == null || voucher.getVoucherNumber().isEmpty()) {
                voucher.setVoucherNumber("VCH" + nextNumber++);
            }

            if (voucher.getVoucherStatus() == null) voucher.setVoucherStatus("Active");
            if (voucher.getUsageStatus() == null) voucher.setUsageStatus("Unused");

            voucher.setCreatedAt(LocalDateTime.now());

            vouchers.add(voucher);
        }

        return voucherRepository.saveAll(vouchers)
                .stream()
                .map(voucherMapper::toDto)
                .toList();
    }

    // Returns a map like: { 500.0: 12, 1000.0: 5, 1500.0: 2 }
    @Override
    public Map<Double, Long> getActiveVoucherCounts() {
        List<Object[]> results = voucherRepository.countActiveVouchersByValue();
        Map<Double, Long> counts = new HashMap<>();
        for (Object[] result : results) {
            counts.put((Double) result[0], (Long) result[1]);
        }
        return counts;
    }

    // ✅ UPDATE
    @Override
    public VoucherDto updateVoucher(Long id, VoucherDto dto) {

        Voucher existing = voucherRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Voucher not found with id: " + id));

        // ✅ Update only editable fields
        existing.setVoucherCompany(dto.getVoucherCompany());
        existing.setVoucherCode(dto.getVoucherCode());
        existing.setVoucherValue(dto.getVoucherValue());
        existing.setVoucherId(dto.getVoucherId());
        existing.setExpiryDate(dto.getExpiryDate());

        // Optional fields
//        existing.setManagerName(dto.getManagerName());
//        existing.setDepartment(dto.getDepartment());
        // voucherNumber (keep constant)


        // ✅ Set timestamps
        LocalDateTime now = LocalDateTime.now();
        existing.setUpdatedAt(now);

        Voucher updated = voucherRepository.save(existing);

        return voucherMapper.toDto(updated);
    }

    // ✅ DELETE
    @Override
    public void deleteVoucher(Long id) {

        Voucher existing = voucherRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Voucher not found with id: " + id));

        voucherRepository.delete(existing);
    }

    // Call this method from your RecognitionService when saving a Bravo recognition
    @Override
    @Transactional
    public Voucher assignVoucher(Double value, String usedBy, String managerName, String department) {
        // Automatically picks the one closest to expiry date
        Voucher voucher = voucherRepository.findFirstByVoucherValueAndVoucherStatusAndUsageStatusOrderByExpiryDateAsc(value, "Active", "Unused")
                .orElseThrow(() -> new RuntimeException("No active vouchers available for value: " + value));

        voucher.setUsageStatus("Used");
        voucher.setUsedBy(usedBy);
        voucher.setManagerName(managerName);
        voucher.setDepartment(department);

        return voucherRepository.save(voucher);
    }

@Override
    public Voucher getNextAvailableVoucherPreview(Double value) {
        return voucherRepository
                .findFirstByVoucherValueAndVoucherStatusAndUsageStatusOrderByExpiryDateAsc(
                        value,
                        "Active",
                        "Unused"
                )
                .orElse(null);
    }


}
