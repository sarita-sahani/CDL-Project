package com.cms.cdl.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "nomination_details")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class NominationDetail {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "nomination_id", nullable = false)
    @JsonIgnore
    private Nomination nomination;

    @Column(name = "sequence_no")
    private int sequenceNo; // 1, 2, 3, 4


    @Column(name = "financial_year")
    private String financialYear;

    @Column(name = "nominee_employee_code")
    private String nomineeEmployeeCode;

    @Column(name = "nominee_name")
    private String nomineeName;

    @Column(name = "department")
    private String department;

    @Column(name = "nominee_emailId")
    private String nomineeEmailId;

    @Column(name = "nominee_designation")
    private String nomineeDesignation;


    @Column(name = "reason_for_nomination", columnDefinition = "TEXT")
    private String reasonForNomination;
}
