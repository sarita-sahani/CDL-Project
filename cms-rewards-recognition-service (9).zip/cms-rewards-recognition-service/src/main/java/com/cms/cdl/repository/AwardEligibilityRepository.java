package com.cms.cdl.repository;

import com.cms.cdl.entity.AwardEligibility;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public interface AwardEligibilityRepository
        extends JpaRepository<AwardEligibility, Long> {

    // main query — join on role matching whoCanNominate
    @Query(value = """
    SELECT a.id
    FROM awards a
    INNER JOIN award_eligibility ae ON
        LOWER(TRIM(a.who_can_nominate)) LIKE CONCAT('%', LOWER(TRIM(ae.role)), '%')
    WHERE ae.emp_code = :empCode
      AND ae.is_active = true
      AND a.is_open_for_nomination = true
    """, nativeQuery = true)
    List<Long> findEligibleAwardIdsByRole(@Param("empCode") String empCode);

    boolean existsByEmpCode(String empCode);

    List<AwardEligibility> findByEmpCode(String empCode);


}

