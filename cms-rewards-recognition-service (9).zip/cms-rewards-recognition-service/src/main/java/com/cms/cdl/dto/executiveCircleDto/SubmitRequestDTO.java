package com.cms.cdl.dto.executiveCircleDto;

import lombok.Data;

@Data
public class SubmitRequestDTO {
    private String employeeCode;
    private String financialYear;
}
