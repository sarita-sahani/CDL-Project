package com.cms.cdl.config;

import com.cms.cdl.entity.Award;
import com.cms.cdl.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@RequiredArgsConstructor
public class DataInitializer implements CommandLineRunner {

    private final AwardRepository awardRepository;

    @Override
    public void run(String... args) {
        if (awardRepository.count() == 0) {
            initAwards();
        }
    }

    private void initAwards() {
        List<Award> awards = List.of(
                Award.builder()
                        .awardTitle("Team Awesome Award")
                        .noOfAwards("1")
                        .category("Business Unit / Function for")
                        .criteria("Profitable growth, Balanced growth (Regions, Mix of business, portfolio churn), People development, etc.")
                        .whoCanNominate("Executive Management. Not open for nomination")
                        .isOpenForNomination(false)
                        .maxNominations(0)
                        .build(),

                Award.builder()
                        .awardTitle("Tip your Hat Award")
                        .noOfAwards("1")
                        .category("Business Support Department")
                        .criteria("Business value, TAT, Responsive, Collaborative.")
                        .whoCanNominate("All Business Support Functions")
                        .isOpenForNomination(true)
                        .maxNominations(1)
                        .build(),

                Award.builder()
                        .awardTitle("Ace Initiative Award")
                        .noOfAwards("3-4")
                        .category("Incremental contribution beyond core job responsibility")
                        .criteria("Business value, Incremental work, Going beyond the call of duty")
                        .whoCanNominate("All BU and Functions of the company")
                        .isOpenForNomination(true)
                        .maxNominations(4)
                        .build(),

                Award.builder()
                        .awardTitle("Kudos Award for Excellence")
                        .noOfAwards("4")
                        .category("Execution Excellence")
                        .criteria("Reflects CMS Values, Strong business orientation, focus on TAT, Collaborative, Relies on the process to accelerate tasks, and achieves things fast.")
                        .whoCanNominate("All BU and Functions of the company")
                        .isOpenForNomination(true)
                        .maxNominations(4)
                        .build(),

                Award.builder()
                        .awardTitle("Calmer of Storms Award")
                        .noOfAwards("3-4")
                        .category("Delivery and Support(s) of the Year")
                        .criteria("Client satisfaction, Customer delight, Client retention.")
                        .whoCanNominate("All BU and Functions of the company")
                        .isOpenForNomination(true)
                        .maxNominations(4)
                        .build(),

                Award.builder()
                        .awardTitle("Behind the Scenes Wonder")
                        .noOfAwards("3-4")
                        .category("Strong Contributor to Business")
                        .criteria("Business Value, Agility, Differentiating work, Incremental Revenue")
                        .whoCanNominate("All Business Support functions")
                        .isOpenForNomination(true)
                        .maxNominations(4)
                        .build(),

                Award.builder()
                        .awardTitle("RockStar Rookie Award")
                        .noOfAwards("3-4")
                        .category("New Joinees in CMS")
                        .criteria("The early initiative, Collaboration, Team player, and Participation in activities – above all fit the role well.")
                        .whoCanNominate("All BU and Functions of the company")
                        .isOpenForNomination(true)
                        .maxNominations(4)
                        .build(),

                Award.builder()
                        .awardTitle("Chairperson's Award")
                        .noOfAwards("2-4")
                        .category("Salesperson of the Year")
                        .criteria("Revenue, Meeting targets, Balanced numbers")
                        .whoCanNominate("GSD, BSD, and Traffic")
                        .isOpenForNomination(true)
                        .maxNominations(4)
                        .build(),

                Award.builder()
                        .awardTitle("Circle of Joy Award")
                        .noOfAwards("2-4")
                        .category("Project of the Year")
                        .criteria("Revenue growth, Enabled & Collected AR, Cost optimization, Client satisfaction, Profitability, Timely completion, and Strategic importance.")
                        .whoCanNominate("GSD, BSD-D & Traffic")
                        .isOpenForNomination(true)
                        .maxNominations(4)
                        .build(),

                Award.builder()
                        .awardTitle("Executive Choice Award")
                        .noOfAwards("2")
                        .category("Transformational Deal of the Year (1 per year)")
                        .criteria("Identified growth area: Software, FMS, CMS Asset-based business, Areas that accelerate CMS transformation")
                        .whoCanNominate("GSD, BSD, and Traffic")
                        .isOpenForNomination(true)
                        .maxNominations(2)
                        .build(),

                Award.builder()
                        .awardTitle("Star Service Award")
                        .noOfAwards("3-4")
                        .category("Project Manager of the Year")
                        .criteria("Client satisfaction, Attention to TAT, Cost optimization, Timely completion, Enabled AR, and Revenue growth.")
                        .whoCanNominate("GSD, Traffic & BSD-D")
                        .isOpenForNomination(true)
                        .maxNominations(4)
                        .build(),

                Award.builder()
                        .awardTitle("Limelight Award")
                        .noOfAwards("2-4")
                        .category("Software Development, Product Development And Testing")
                        .criteria("Innovation, error-free Software/Hardware, Product/Process/POC innovation, Client sat, Accelerated development")
                        .whoCanNominate("GSD, Product Development, SSD (Primarily for CMS assets)")
                        .isOpenForNomination(true)
                        .maxNominations(4)
                        .build(),

                Award.builder()
                        .awardTitle("Circle of Excellence Award")
                        .noOfAwards("1")
                        .category("Overall Excellence")
                        .criteria("All-round excellence across business metrics and team contributions")
                        .whoCanNominate("Executive Management")
                        .isOpenForNomination(false)
                        .maxNominations(0)
                        .build()
        );

        awardRepository.saveAll(awards);
    }

}