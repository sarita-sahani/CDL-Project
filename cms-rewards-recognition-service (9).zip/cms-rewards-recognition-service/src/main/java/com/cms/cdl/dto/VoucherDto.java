package com.cms.cdl.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
public class VoucherDto {
    private Long id;
    private String voucherNumber;
    private String voucherCode;
    private String voucherId;
    private Double voucherValue;
    private String voucherCompany;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
    private LocalDate expiryDate;
    private String usedBy;
    private String managerName;
    private String department;
    private String voucherStatus;
    private String usageStatus;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}