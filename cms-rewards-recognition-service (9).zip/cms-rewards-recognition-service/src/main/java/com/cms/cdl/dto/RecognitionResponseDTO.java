package com.cms.cdl.dto;

import com.cms.cdl.entity.Recognition;
import lombok.*;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Getter
@Setter
@Data
@AllArgsConstructor
@NoArgsConstructor
public class RecognitionResponseDTO {

    private Long id;
    private String empCode;
    private String employeeName;
    private String comment;
    private String createdDate;
    private Long categoryId;
    private String categoryName;
    private Long templateId;
    private String recognitionType;
    private String recognitionMode;
    private String certificateType;
    private Double voucherValue;
    private String voucherCode;
    private String voucherNumber;
    private LocalDate voucherExpiryDate;
    private Long voucherSerialNum;

    private long likes;
    private long comments;
    private Long docId;

    // Constructor to map Recognition entity + counts
    public RecognitionResponseDTO(Recognition rec, long likes, long comments) {
        this.id = rec.getId();
        this.empCode = rec.getEmpCode();
        this.employeeName = rec.getEmployeeName();
        this.comment = rec.getComment();
        this.createdDate = String.valueOf(rec.getCreatedDate());
        this.categoryId = rec.getCategoryId();
        this.categoryName = rec.getCategoryName();
        this.templateId = rec.getTemplateId();
        this.recognitionType = rec.getRecognitionType();
        this.recognitionMode = rec.getRecognitionMode();
        this.certificateType = rec.getCertificateType();
        this.voucherValue = rec.getVoucherValue();
        this.likes = likes;
        this.comments = comments;
    }

}