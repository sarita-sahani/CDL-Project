package com.cms.cdl.dto.user_dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class UserResDTO {
    private long userId;
    private String firstName;
    private String middleName;
    private String lastName;
    private String personalEmail;
    private String primaryContactNo;
    private String secondaryContactNo;
    private String gender;
    private LocalDate dateOfBirth;
    private String oldCompaniesExperience;
    @JsonProperty("addressResDTOS")
    private List<AddressResDTO> addressDTOS;
    @JsonProperty("educationResDTOS")
    private List<EducationResDTO> educationDTOS;
    @JsonProperty("experienceResDTOS")
    private List<ExperienceResDTO> experienceDTOS;
    @JsonProperty("locationResDTO")
    private LocationResDTO locationDTO;
    @JsonProperty("skillResDTOS")
    private List<SkillResDTO> skillDTOS;
    @JsonProperty("statutoryDetailsResDTO")
    private StatutoryDetailsResDTO statutoryDetailsDTO;
    @JsonProperty("userRoleResDTOS")
    private List<UserRoleResDTO> userRoleDTOS;

}
