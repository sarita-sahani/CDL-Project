package com.cms.cdl.dto.executiveCircleDto;

public record NomineeRow(

    String awardTitle,
    String awardCategory,
    String nomineeName,
    String nomineeCode,
    String department,
    String designation,
    String reason) {}

