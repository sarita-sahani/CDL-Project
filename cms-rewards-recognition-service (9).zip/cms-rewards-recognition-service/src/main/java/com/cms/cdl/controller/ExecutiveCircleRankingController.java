package com.cms.cdl.controller;

import com.cms.cdl.dto.executiveCircleDto.*;
import com.cms.cdl.service.ExecutiveCircleRankingService;
import com.cms.cdl.utils.ApiResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/rankings")
@CrossOrigin("*")
@RequiredArgsConstructor
public class ExecutiveCircleRankingController {

    private final ExecutiveCircleRankingService service;

    @PostMapping("/saveExecutiveCircleRank")
    public ApiResponse saveExecutiveCircleRank(
            @RequestBody ExecutiveRankingRequest request) {

        service.saveRank(request);

        return ApiResponse.success(
                "Rank saved successfully");
    }

    @GetMapping("/getExecutiveCircleRanking")
    public ApiResponse getExecutiveCircleRanking(
            @RequestParam String financialYear,
            @RequestParam String awardTitle) {

        return ApiResponse.success(
                service.getRankings(
                        financialYear,
                        awardTitle));
    }

    @GetMapping("/ExecutiveCircleWinners")
    public ApiResponse getWinnersByAward(@RequestParam String financialYear) {
        return ApiResponse.success(service.getWinnersByAward(financialYear));
    }
}
