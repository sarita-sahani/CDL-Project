package com.cms.cdl.controller;

import com.cms.cdl.dto.executiveCircleDto.AwardDTO;
import com.cms.cdl.dto.executiveCircleDto.AwardEligibilityRequestDTO;
import com.cms.cdl.service.AwardService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/awards")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class AwardController {

    private final AwardService awardService;

    @GetMapping
    public ResponseEntity<List<AwardDTO>> getAllAwards() {
        return ResponseEntity.ok(awardService.getAllAwards());
    }

    @GetMapping("/user")
    public ResponseEntity<List<AwardDTO>> getAwardsForUser(
            @RequestParam String empCode,
            @RequestParam(required = false) List<String> roles) {

        return ResponseEntity.ok(
                awardService.getAwardsForUser(empCode, roles));
    }

    @GetMapping("/open")
    public ResponseEntity<List<AwardDTO>> getOpenNominationAwards() {
        return ResponseEntity.ok(
                awardService.getOpenNominationAwards());
    }

    @GetMapping("/{id}")
    public ResponseEntity<AwardDTO> getAwardById(
            @PathVariable Long id) {

        return ResponseEntity.ok(
                awardService.getAwardById(id));
    }

    @PostMapping
    public ResponseEntity<AwardDTO> createAward(
            @RequestBody AwardDTO awardDTO) {

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(awardService.createAward(awardDTO));
    }

    @PutMapping("/{id}")
    public ResponseEntity<AwardDTO> updateAward(
            @PathVariable Long id,
            @RequestBody AwardDTO awardDTO) {

        return ResponseEntity.ok(
                awardService.updateAward(id, awardDTO));
    }

    // ─────────────────────────────────────────────
    // ASSIGN ELIGIBILITY
    // ─────────────────────────────────────────────
    @PostMapping("/award-eligibility")
    public ResponseEntity<Map<String, String>> assignEligibility(
            @RequestBody AwardEligibilityRequestDTO request) {

        awardService.assignEligibility(request);

        return ResponseEntity.ok(
                Map.of("message", "Permission Assigned Successfully"));
    }

    @GetMapping("/check-eligibility")
    public ResponseEntity<Boolean> checkEligibility(@RequestParam String empCode) {
        boolean eligible = awardService.isEmployeeEligibleForAnyAward(empCode);
        return ResponseEntity.ok(eligible);
    }
    // ─────────────────────────────────────────────
    // GET ELIGIBILITY BY AWARD
    // ─────────────────────────────────────────────
    @GetMapping("/eligibility/{awardId}")
    public ResponseEntity<List<AwardEligibilityRequestDTO>>
    getEligibilityByAward(
            @PathVariable Long awardId) {

        return ResponseEntity.ok(
                awardService.getEligibilityByAward(awardId));
    }

    // ─────────────────────────────────────────────
    // REMOVE ELIGIBILITY
    // ─────────────────────────────────────────────
    @DeleteMapping("/remove-eligibility/{id}")
    public ResponseEntity<Void> removeEligibility(
            @PathVariable Long id) {

        awardService.removeEligibility(id);

        return ResponseEntity.noContent().build();
    }
}