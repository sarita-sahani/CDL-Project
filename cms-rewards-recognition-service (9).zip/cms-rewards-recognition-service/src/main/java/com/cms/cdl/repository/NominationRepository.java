package com.cms.cdl.repository;

import com.cms.cdl.entity.Nomination;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface NominationRepository extends JpaRepository<Nomination, Long> {

    List<Nomination> findByFinancialYear(String financialYear);

    List<Nomination> findBySubmittedByEmployeeCodeAndFinancialYear(String employeeCode, String financialYear);

    Optional<Nomination> findByAwardIdAndSubmittedByEmployeeCodeAndFinancialYear(
            Long awardId, String employeeCode, String financialYear);

    @Query("""
    SELECT nd.nomineeEmployeeCode
    FROM   Nomination n
    JOIN   n.nominationDetails nd
    WHERE  n.award.id = :awardId
    AND    n.financialYear = :financialYear
    AND    n.submittedByEmployeeCode <> :excludeCode
    AND    n.isNominating = true
""")
    List<String> findNomineeCodesByAwardAndFY(
            @Param("awardId")      Long   awardId,
            @Param("financialYear") String financialYear,
            @Param("excludeCode")  String excludeCode);

    @Query("SELECT n FROM Nomination n JOIN FETCH n.award JOIN FETCH n.nominationDetails WHERE n.financialYear = :fy")
    List<Nomination> findAllWithDetailsByFinancialYear(@Param("fy") String financialYear);

    @Query("SELECT n FROM Nomination n JOIN FETCH n.award WHERE n.submittedByEmployeeCode = :empCode AND n.financialYear = :fy")
    List<Nomination> findByEmployeeAndFinancialYear(@Param("empCode") String employeeCode, @Param("fy") String financialYear);


    // ── NEW: all DRAFT + nominating rows for bulk submit ─────────────────────
    List<Nomination> findBySubmittedByEmployeeCodeAndFinancialYearAndIsNominatingTrueAndStatus(
            String employeeCode, String financialYear, Nomination.NominationStatus status);



}
