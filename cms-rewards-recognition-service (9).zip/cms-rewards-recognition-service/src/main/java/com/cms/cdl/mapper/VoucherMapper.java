package com.cms.cdl.mapper;

import com.cms.cdl.dto.*;
import com.cms.cdl.entity.Voucher;
import org.springframework.stereotype.Component;

@Component
public class VoucherMapper {

    public VoucherDto toDto(Voucher entity) {
        if (entity == null) {
            return null;
        }

        VoucherDto dto = new VoucherDto();
        dto.setId(entity.getId());
        dto.setVoucherNumber(entity.getVoucherNumber());
        dto.setVoucherCode(entity.getVoucherCode());
        dto.setVoucherValue(entity.getVoucherValue());
        dto.setVoucherId(entity.getVoucherId());
        dto.setExpiryDate(entity.getExpiryDate());
        dto.setUsedBy(entity.getUsedBy());
        dto.setManagerName(entity.getManagerName());
        dto.setDepartment(entity.getDepartment());
        dto.setVoucherStatus(entity.getVoucherStatus());
        dto.setUsageStatus(entity.getUsageStatus());
        dto.setVoucherCompany(entity.getVoucherCompany());
        dto.setCreatedAt(entity.getCreatedAt());
        dto.setUpdatedAt(entity.getUpdatedAt());

        return dto;
    }

    public Voucher toEntity(VoucherDto dto) {
        if (dto == null) {
            return null;
        }

        Voucher entity = new Voucher();
        // We do not set ID, createdAt, or updatedAt here as the DB handles them
        entity.setVoucherNumber(dto.getVoucherNumber());
        entity.setVoucherCode(dto.getVoucherCode());
        entity.setVoucherValue(dto.getVoucherValue());
        entity.setVoucherId(dto.getVoucherId());
        entity.setVoucherCompany(dto.getVoucherCompany());
        entity.setExpiryDate(dto.getExpiryDate());
        entity.setUsedBy(dto.getUsedBy());
        entity.setManagerName(dto.getManagerName());
        entity.setDepartment(dto.getDepartment());
        entity.setVoucherStatus(dto.getVoucherStatus());
        entity.setUsageStatus(dto.getUsageStatus());

        return entity;
    }
}
