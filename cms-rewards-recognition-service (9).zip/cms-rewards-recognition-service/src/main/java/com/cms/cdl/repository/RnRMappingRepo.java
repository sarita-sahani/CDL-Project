package com.cms.cdl.repository;

import com.cms.cdl.entity.RnRMappingTable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface RnRMappingRepo extends JpaRepository<RnRMappingTable, Long> {
}
