package com.cms.cdl.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name="category")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Category {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name="category_name")
    private String categoryName;

    @Column(name = "certificate_url")
    private String certificateUrl;

    @Column(name="recognition_type_id")
    private Long recognitionTypeId;
}