package com.cms.cdl.controller;

import com.cms.cdl.dto.executiveCircleDto.HrExecutiveReviewRequest;
import com.cms.cdl.dto.executiveCircleDto.NominationDTO;
import com.cms.cdl.dto.executiveCircleDto.NominationSummaryDTO;
import com.cms.cdl.dto.executiveCircleDto.SubmitRequestDTO;
import com.cms.cdl.entity.Nomination;
import com.cms.cdl.service.NominationService;
import com.cms.cdl.serviceImpl.ExcelExportService;
import com.cms.cdl.utils.FinancialYearUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/nominations")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class NominationController {

    private final NominationService nominationService;
    private final ExcelExportService excelExportService;

    // ── Save / Update ──────────────────────────────────────────────────────────

    /**
     * POST /api/nominations
     * If the client omits financialYear, the server fills it from FinancialYearUtil.
     */
    // ── Existing: save / update ───────────────────────────────────────────────
    @PostMapping("/saveNominationsDetails")
    public ResponseEntity<?> saveNomination(@RequestBody NominationDTO dto) {
        if (dto.getFinancialYear() == null || dto.getFinancialYear().isBlank()) {
            dto.setFinancialYear(FinancialYearUtil.getCurrentFinancialYearFull());
        }
        try {
            return ResponseEntity.status(HttpStatus.CREATED)
                    .body(nominationService.saveOrUpdateNomination(dto));
        } catch (IllegalArgumentException ex) {
            return ResponseEntity.badRequest().body(ex.getMessage());
        }
    }

    // ── NEW: fetch all nominations for preview ────────────────────────────────
    /**
     * GET /api/executive-circle/nominations/preview
     *   ?employeeCode=EMP001&financialYear=26-27
     *
     * Returns every Nomination row for this employee + FY, joined with
     * award title, category, and all nomination details — used by the
     * PreviewAndSubmit React component.
     */
    @GetMapping("/preview")
    public ResponseEntity<List<NominationDTO>> getPreview(
            @RequestParam String employeeCode,
            @RequestParam String financialYear) {

        List<NominationDTO> preview =
                nominationService.getNominationsForPreview(employeeCode, financialYear);
        return ResponseEntity.ok(preview);
    }

    // ── NEW: submit all DRAFT nominations to HR ───────────────────────────────
    /**
     * POST /api/executive-circle/nominations/submit
     * Body: { "employeeCode": "EMP001", "financialYear": "26-27" }
     *
     * 1. Finds all DRAFT + isNominating=true rows for this employee + FY.
     * 2. Sets status → SUBMITTED.
     * 3. Sends one consolidated HR mail listing all awards + nominees.
     * 4. Returns the updated list of NominationDTOs.
     */
    @PostMapping("/submit")
    public ResponseEntity<?> submitToHR(@RequestBody SubmitRequestDTO request) {
        try {
            List<NominationDTO> updated =
                    nominationService.submitNominationsToHR(
                            request.getEmployeeCode(),
                            request.getFinancialYear());
            return ResponseEntity.ok(updated);
        } catch (IllegalStateException ex) {
            return ResponseEntity.badRequest().body(ex.getMessage());
        }
    }



    // ── Read ───────────────────────────────────────────────────────────────────

    @GetMapping("/{id}")
    public ResponseEntity<NominationDTO> getNominationById(@PathVariable Long id) {
        return ResponseEntity.ok(nominationService.getNominationById(id));
    }

    /**
     * GET /api/nominations/award/{awardId}/employee/{employeeCode}?financialYear=26-27
     * financialYear is optional; defaults to current FY when omitted.
     */
    //http:localhost:9035//api/nominations
    @GetMapping("/award/{awardId}/employee/{employeeCode}")
    public ResponseEntity<NominationDTO> getNominationByAwardAndEmployee(
            @PathVariable Long awardId,
            @PathVariable String employeeCode,
            @RequestParam(required = false) String financialYear) {

        String fy = (financialYear == null || financialYear.isBlank())
                ? FinancialYearUtil.getCurrentFinancialYear()
                : financialYear;

        NominationDTO dto = nominationService.getNominationByAwardAndEmployee(
                awardId, employeeCode, fy);

        return ResponseEntity.ok(dto); // ✅ always 200
    }

    /**
     * GET /api/nominations/employee/{employeeCode}?financialYear=26-27
     */
    @GetMapping("/employee/{employeeCode}")
    public ResponseEntity<List<NominationDTO>> getNominationsByEmployee(
            @PathVariable String employeeCode,
            @RequestParam(required = false) String financialYear) {

        return ResponseEntity.ok(
                nominationService.getNominationsByEmployee(employeeCode, resolve(financialYear)));
    }

    /**
     * GET /api/nominations/summary?financialYear=26-27
     * Used by Nomination Details screen (Preview table).
     */
    @GetMapping("/executiveCircleDetails")
    public ResponseEntity<List<NominationSummaryDTO>> getExecutiveCircleDetails(
            @RequestParam(required = false) String financialYear,
            @RequestParam(required = false) List<String> status,
            @RequestParam(required = false) String managerEmpCode) {

        return ResponseEntity.ok(
                nominationService.getExecutiveCircleDetails(
                        resolve(financialYear), status, managerEmpCode));
    }



    // ── Submit ─────────────────────────────────────────────────────────────────

    /**
     * POST /api/nominations/submit-all?employeeCode=9085119&financialYear=26-27
     *
     * Validates every open-for-nomination award has been answered,
     * then marks all DRAFT nominations as SUBMITTED.
     *
     * 200 → { message, count }
     * 400 → { error: "Error! You have not filled required field in one or more category: XYZ Award" }
     */
    @PostMapping("/submit-all")
    public ResponseEntity<?> submitAll(
            @RequestParam String employeeCode,
            @RequestParam(required = false) String financialYear) {

        try {
            List<NominationDTO> submitted =
                    nominationService.submitAllNominations(employeeCode, resolve(financialYear));
            return ResponseEntity.ok(Map.of(
                    "message", "Nominations submitted successfully to HR.",
                    "count",   submitted.size()));
        } catch (IllegalStateException ex) {
            // User-facing validation message — matches the browser alert in the screenshots
            return ResponseEntity.badRequest().body(Map.of("error", ex.getMessage()));
        }
    }

    /** Submit a single nomination (individual award). */
    @PostMapping("/{id}/submit")
    public ResponseEntity<NominationDTO> submitNomination(@PathVariable Long id) {
        return ResponseEntity.ok(nominationService.submitNomination(id));
    }

    // ── Delete ─────────────────────────────────────────────────────────────────

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteNomination(@PathVariable Long id) {
        nominationService.deleteNomination(id);
        return ResponseEntity.noContent().build();
    }

    @PutMapping("/{nominationId}/review")
    public ResponseEntity<Nomination> reviewNomination(
            @PathVariable Long nominationId,
            @RequestBody HrExecutiveReviewRequest request) {

        Nomination updated = nominationService.reviewNomination(
                nominationId,
                request.getStatus(),
                request.getHrRemarks()
        );
        return ResponseEntity.ok(updated);
    }

    // ── Excel Export ───────────────────────────────────────────────────────────

    /**
     * GET /api/nominations/export/excel?financialYear=26-27
     */
    @GetMapping("/export/excel")
    public ResponseEntity<byte[]> exportToExcel(
            @RequestParam(required = false) String financialYear) throws IOException {

        String fy = resolve(financialYear);
        List<NominationSummaryDTO> summaries = nominationService.getExecutiveCircleDetails(
                fy, List.of("Submitted to HR", "Approved","Draft"), null);
        byte[] bytes = excelExportService.exportNominationSummaries(summaries, fy);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
        headers.setContentDispositionFormData("attachment",
                "NominationDetails_FY" + fy + ".xlsx");
        return ResponseEntity.ok().headers(headers).body(bytes);
    }

    // ── Helper ─────────────────────────────────────────────────────────────────

    /** Falls back to the server-computed current FY if the caller omits it. */
    private static String resolve(String fy) {
        return (fy == null || fy.isBlank()) ? FinancialYearUtil.getCurrentFinancialYear() : fy;
    }

//    @GetMapping("/executive-circle-report")
//    public List<ExecutiveCircleReportDTO> getExecutiveCircleReport(
//            @RequestParam String financialYear
//    ) {
//
//        return nominationService.getExecutiveCircleReport(financialYear);
//    }
}
