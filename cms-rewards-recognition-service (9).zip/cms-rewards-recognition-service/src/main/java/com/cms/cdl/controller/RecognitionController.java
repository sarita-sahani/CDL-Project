package com.cms.cdl.controller;

import com.cms.cdl.beans.emp_bean.FileAndObjectTypeBean;
import com.cms.cdl.beans.emp_user_bean.EmpAndUserResponse;
import com.cms.cdl.dto.RecognitionRequestDTO;
import com.cms.cdl.dto.RecognitionResponseDTO;
import com.cms.cdl.dto.VoucherEligibilityDTO;
import com.cms.cdl.entity.*;
import com.cms.cdl.service.RecognitionService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;

@RestController
@RequestMapping("/api/recognition")
@RequiredArgsConstructor
@CrossOrigin("*")
public class RecognitionController {

    private final RecognitionService recognitionService;

    @GetMapping("/getEmployeeInfo/{empCode}")
    public ResponseEntity<?> getByempCode(@PathVariable("empCode") String empCode) throws ExecutionException, InterruptedException {
        EmpAndUserResponse employeeDetails = recognitionService.getEmpInfoByEmpCode(empCode);
        if (employeeDetails != null) {
            return ResponseEntity.ok(employeeDetails);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("empId not exist");
        }
    }

    // 🔍 API 1: Search Employee
    @GetMapping("/searchEmployee")
    public List<FileAndObjectTypeBean> searchEmployee(
            @RequestParam String searchValue) {

        return recognitionService.searchEmployee(searchValue);
    }
    //http://localhost:9035/api/recognition/getEmployeeteamdata
    // 👥 API 2: Get Team Data
//    @GetMapping("/getEmployeeteamdata")
//    public Map<String, Object> fetchEmployeeTeamData(
//            @RequestParam String empCode) {
//
//        return recognitionService.fetchEmployeeTeamData(empCode);
//    }

//    @GetMapping("/getEmployeeteamdata")
//    public List<Map<String, Object>> fetchEmployeeTeamData(
//            @RequestParam String empCode) {
//        return recognitionService.fetchEmployeeTeamData(empCode);
//    }

    @GetMapping("/getEmployeeteamdata")
    public Map<String, Object> fetchEmployeeTeamData(
            @RequestParam String empCode) {
        return recognitionService.fetchEmployeeTeamData(empCode);
    }

    //http://localhost:9035/api/recognition/getcategoriesname
    //1️⃣ Get Categories based on RecognitionType
    @GetMapping("/categories/{recognitionTypeId}")
    public List<Category> getCategories(@PathVariable Long recognitionTypeId){
        return recognitionService.getCategoriesByRecognitionType(recognitionTypeId);
    }

    @GetMapping("/getcategoriesname/{categoryId}")
    public Category getcategoriesname(@PathVariable Long categoryId){
        return recognitionService.getcategoriesname(categoryId);
    }


    //2️⃣ Get Templates based on Category
    @GetMapping("/templates/{categoryId}")
    public List<Template> getTemplates(@PathVariable Long categoryId){
        return recognitionService.getTemplatesByCategory(categoryId);
    }

    //3️⃣ Get Description based on Template
    @GetMapping("/template-description/{templateId}")
    public Template getTemplateDescription(@PathVariable Long templateId){
        return recognitionService.getTemplateDescription(templateId);
    }

    @GetMapping("/template-images/{templateId}")
    public ResponseEntity<List<TemplateImage>> getTemplateImages(@PathVariable Long templateId) {
        return ResponseEntity.ok(recognitionService.getImagesByTemplate(templateId));
    }

    //to save Hats oFF and Bravo data in tables
//    @PostMapping("/saveRecognitionsData")
//    public ResponseEntity<?> saveRecognitionsData(@RequestBody Recognition request, @RequestPart(value = "certificate", required = false) MultipartFile multipartFile) throws Exception {
//        Recognition saved = recognitionService.saveRecognitionsData(request, multipartFile);
//        return ResponseEntity.ok(saved);
//    }

    @PostMapping(value = "/saveRecognitionsData", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<?> saveRecognitionsData(
            @RequestPart("request") Recognition request,
            @RequestPart(value = "certificate", required = false) MultipartFile certificate
    ) throws Exception {

        Recognition saved = recognitionService.saveRecognitionsData(request, certificate);
        return ResponseEntity.ok(saved);
    }

    @PostMapping("/previewCertificate")
    public ResponseEntity<Map<String, String>> previewCertificate(@RequestBody Recognition request) throws Exception {
        Map<String, String> preview = recognitionService.previewCertificate(request);
        return ResponseEntity.ok(preview);
    }
    //http://localhost:9035/api/recognition/getAllDataByRecognitionType
    // ✅ GET BY TYPE (HATSOFF / BRAVO)


//    @GetMapping("/getAllDataByRecognitionType/{type}")
//    public ResponseEntity<Page<RecognitionResponseDTO>> getAllRecognitions(
//            @PathVariable String type,
//            @RequestParam(defaultValue = "0") int page,
//            @RequestParam(defaultValue = "10") int size) {
//
//        Page<RecognitionResponseDTO> data = recognitionService.getAllDataByRecognitionType(type, page, size);
//        return ResponseEntity.ok(data);
//    }

    @GetMapping("/getAllDataByRecognitionType/{type}")
    public ResponseEntity<Page<RecognitionResponseDTO>> getAllRecognitions(
            @PathVariable String type,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {

        Page<RecognitionResponseDTO> data = recognitionService.getAllDataByRecognitionType(type, page, size);
        return ResponseEntity.ok(data);
    }
    //http://localhost:9035/api/recognition/getAllRecognitions
    @GetMapping("/getAllRecognitions")
    public ResponseEntity<Map<String, Object>> getAllRecognitions(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {

        Map<String, Object> response = recognitionService.getAllRecognitions(page, size);
        return ResponseEntity.ok(response);
    }

    //for voucher///
    @GetMapping("/voucher/eligibility/{managerCode}")
    public VoucherEligibilityDTO getVoucherEligibility(
            @PathVariable String managerCode
    ) throws ExecutionException, InterruptedException {
        return recognitionService.getVoucherEligibility(managerCode);
    }
}