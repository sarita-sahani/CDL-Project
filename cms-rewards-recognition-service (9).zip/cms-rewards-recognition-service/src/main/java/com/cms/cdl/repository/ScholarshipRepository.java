package com.cms.cdl.repository;

import com.cms.cdl.entity.Scholarship;
import com.cms.cdl.Enum.ScholarshipType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ScholarshipRepository
        extends JpaRepository<Scholarship, Long> {

    List<Scholarship> findByAwardYear(String awardYear);

    List<Scholarship> findByScholarshipType(
            ScholarshipType scholarshipType);

    List<Scholarship> findByAwardYearAndScholarshipType(
            String awardYear,
            ScholarshipType scholarshipType);

}
