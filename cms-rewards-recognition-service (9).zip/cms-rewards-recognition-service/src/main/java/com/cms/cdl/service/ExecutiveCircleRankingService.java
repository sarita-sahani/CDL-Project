package com.cms.cdl.service;

import com.cms.cdl.dto.executiveCircleDto.ExecutiveRankingRequest;
import com.cms.cdl.dto.executiveCircleDto.ExecutiveRankingResponse;
import com.cms.cdl.dto.honorClub.AwardWinnersResponse;
import jakarta.transaction.Transactional;

import java.util.List;

public interface ExecutiveCircleRankingService {


    @Transactional
    void saveRank(ExecutiveRankingRequest request);

    List<ExecutiveRankingResponse> getRankings(
            String financialYear,
            String awardTitle);

    List<AwardWinnersResponse> getWinnersByAward(String financialYear);
}