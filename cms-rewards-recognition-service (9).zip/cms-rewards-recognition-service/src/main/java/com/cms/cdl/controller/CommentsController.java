package com.cms.cdl.controller;

import com.cms.cdl.entity.RnRCommentsTable;
import com.cms.cdl.Enum.InteractionType;
import com.cms.cdl.service.CommentsService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.concurrent.ExecutionException;

@RestController
@RequestMapping("/api/recognition")
@RequiredArgsConstructor
@CrossOrigin("*")
public class CommentsController {

    @Autowired
    private CommentsService commentsService;

    // Bravo / World of Thanks — existing endpoint, pass isNomination = false
    @PostMapping("/addComments/{id}/{empCode}")
    public ResponseEntity<String> addRecognitionComment(
            @PathVariable Long id,
            @PathVariable String empCode,
            @RequestBody String newComment) {
        try {
            commentsService.addComment(empCode, id, newComment, InteractionType.RECOGNITION);  // ← false
            return new ResponseEntity<>("Comment added successfully for Claim #" + id, HttpStatus.OK);
        } catch (IllegalArgumentException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        } catch (Exception e) {
            return new ResponseEntity<>("Failed to add comment", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // Executive Circle — same method, isNomination = true
    @PostMapping("/addNominationComments/{id}/{empCode}")
    public ResponseEntity<String> addNominationComment(@PathVariable Long id,
                                                       @PathVariable String empCode,
                                                       @RequestBody String comment)
            throws ExecutionException, InterruptedException {
        commentsService.addComment(empCode, id, comment, InteractionType.NOMINATION);
        return ResponseEntity.ok("Comment added for nominee detail #" + id);
    }

    @PostMapping("/addHonorClubComments/{id}/{empCode}")
    public ResponseEntity<String> addHonorClubComment(
            @PathVariable Long id,
            @PathVariable String empCode,
            @RequestBody String comment)
            throws ExecutionException, InterruptedException {

        commentsService.addComment(
                empCode,
                id,
                comment,
                InteractionType.HONOR_CLUB);

        return ResponseEntity.ok("Comment added");
    }


    @PostMapping("/addScholarshipComments/{id}/{empCode}")
    public ResponseEntity<String> addScholarshipComment(
            @PathVariable Long id,
            @PathVariable String empCode,
            @RequestBody String comment)
            throws ExecutionException, InterruptedException {

        commentsService.addComment(
                empCode,
                id,
                comment,
                InteractionType.SCHOLARSHIP);

        return ResponseEntity.ok("Comment added");
    }
    // Bravo / World of Thanks — existing endpoint
    @GetMapping("/getAllRecognitionComments/{recognitionId}")
    public ResponseEntity<List<RnRCommentsTable>> getAllComments(@PathVariable Long recognitionId) {
        try {
            List<RnRCommentsTable> comments = commentsService.getAllRnRComments(recognitionId, InteractionType.RECOGNITION);  // ← false
            if (comments.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }
            return new ResponseEntity<>(comments, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // Executive Circle — same method, isNomination = true
    @GetMapping("/getAllNominationComments/{id}")
    public ResponseEntity<List<RnRCommentsTable>> getNominationComments(@PathVariable Long id) {
        List<RnRCommentsTable> comments = commentsService.getAllRnRComments(id, InteractionType.NOMINATION);
        if (comments.isEmpty()) return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        return ResponseEntity.ok(comments);
    }

    //honorclub
    @GetMapping("/getAllHonorClubComments/{id}")
    public ResponseEntity<List<RnRCommentsTable>> getAllHonorClubComments(@PathVariable Long id) {
        List<RnRCommentsTable> comments = commentsService.getAllRnRComments(id, InteractionType.HONOR_CLUB);
        if (comments.isEmpty()) return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        return ResponseEntity.ok(comments);
    }

    @GetMapping("/getAllScholarshipsComments/{id}")
    public ResponseEntity<List<RnRCommentsTable>> getAllScholarshipsComments(@PathVariable Long id) {
        List<RnRCommentsTable> comments = commentsService.getAllRnRComments(id, InteractionType.SCHOLARSHIP);
        if (comments.isEmpty()) return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        return ResponseEntity.ok(comments);
    }


}
