package com.cms.cdl.dto.response_dto.emp_full_response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class SalaryAccDetailsResDTO {
    private long salaryAccDetailsId;
    private String bankName;
    private long accountNumber;
    private String nameOnAccount;
    private String ifsc;
}
