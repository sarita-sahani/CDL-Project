package com.cms.cdl.entity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "vouchers")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Voucher {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false)
    private String voucherNumber; // e.g., VCH1001

    @Column(nullable = false)
    private String voucherCode;

    @Column
    private String voucherId;

    @Column(nullable = false)
    private Double voucherValue;

    @Column(nullable = false)
    private String voucherCompany;

    private LocalDate expiryDate;

    private String usedBy;
    private String managerName;
    private String department;

    private String voucherStatus="Active";
    private String usageStatus = "Unused";

    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}