package com.cms.cdl.repository;

import com.cms.cdl.entity.ExecutiveCircleRanking;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface ExecutiveCircleRankingRepository
        extends JpaRepository<ExecutiveCircleRanking, Long> {

    List<ExecutiveCircleRanking>
    findByFinancialYearAndAwardTitle(
            String financialYear,
            String awardTitle);

    Optional<ExecutiveCircleRanking>
    findByFinancialYearAndAwardTitleAndRankPosition(
            String financialYear,
            String awardTitle,
            Integer rankPosition);

    Optional<ExecutiveCircleRanking>
    findByNominationDetailId(
            Long nominationDetailId);

    @Query("SELECT r, d " +
            "FROM ExecutiveCircleRanking r " +
            "JOIN NominationDetail d ON r.nominationDetailId = d.id " +
            "WHERE r.financialYear = :fy AND r.rankPosition <= 3 " +
            "ORDER BY r.awardTitle, r.rankPosition")
    List<Object[]> findTopRankingsByFinancialYear(@Param("fy") String financialYear);
}