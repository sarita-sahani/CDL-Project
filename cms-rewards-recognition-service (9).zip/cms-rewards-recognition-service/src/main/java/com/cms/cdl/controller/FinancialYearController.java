package com.cms.cdl.controller;

import com.cms.cdl.utils.FinancialYearUtil;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * Exposes the current Indian Financial Year to the frontend.
 *
 * GET /api/financial-year/current
 * Response: { "code": "26-27", "label": "2026-27" }
 *
 * The frontend MUST call this on startup and pass the code
 * to all nomination/award API calls. No hardcoding allowed.
 */
@RestController
@RequestMapping("/api/financial-year")
@CrossOrigin(origins = "*")
public class FinancialYearController {

    @GetMapping("/currentYear")
    public ResponseEntity<Map<String, String>> getCurrentFinancialYear() {
        return ResponseEntity.ok(Map.of(
                "code",  FinancialYearUtil.getCurrentFinancialYear(),    // "26-27"
                "label", FinancialYearUtil.getCurrentFinancialYearFull() // "2026-27"
        ));
    }
}
