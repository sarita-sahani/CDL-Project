package com.cms.cdl.mapper;

import com.cms.cdl.dto.honorClub.HonorClubDto;
import com.cms.cdl.entity.HonorClub;
import org.springframework.stereotype.Component;


@Component
public class HonorClubMapper {

    public HonorClubDto.Response toResponse(HonorClub entity) {

        if (entity == null) {
            return null;
        }

        return HonorClubDto.Response.builder()
                .id(entity.getId())
                .awardYear(entity.getAwardYear())
                .honorClubType(entity.getHonorClubType())
                .empCode(entity.getEmpCode())
                .employeeName(entity.getEmployeeName())
                .department(entity.getDepartment())
                .docId(entity.getDocId())
                .selected(entity.getSelected())
                .build();
    }

    public HonorClub toEntity(HonorClubDto.Request dto) {

        if (dto == null) {
            return null;
        }

        return HonorClub.builder()
                .awardYear(dto.getAwardYear())

                .honorClubType(dto.getHonorClubType())
                .empCode(dto.getEmpCode())
                .employeeName(dto.getEmployeeName())
                .department(dto.getDepartment())
                .build();
    }
}