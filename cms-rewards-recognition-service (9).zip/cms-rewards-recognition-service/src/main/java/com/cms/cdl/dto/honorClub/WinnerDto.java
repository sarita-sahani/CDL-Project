package com.cms.cdl.dto.honorClub;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class WinnerDto {
    private Integer rank;
    private String nomineeName;
    private String employeeCode;
    private String department;
    private String rankReason;
    private String reasonForNomination;
}