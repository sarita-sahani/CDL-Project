package com.cms.cdl.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name="recognition")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Recognition {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // 👤 Receiver(nominee details)
    private String empCode;
    private String employeeName;
    private String employeeEmail;
    private String nomineeDepartment;

    // 👤 nominator details (sender)
    private String recognizedByCode;
    private String recognizedByName;
    private String recognizedByEmail;
    private String voucherCompany;

    private String comment;

    private LocalDateTime createdDate;

    private Long categoryId;
    private String categoryName;
    private Long templateId;
//    // ✅ NEW selected image fields
//    private Long templateImageId;
    @Transient
    private String templateImageUrl;

    //extra fields for Bravo
    private String recognitionType;
    private String recognitionMode ="ecard";
    private String certificateType;
    private Double voucherValue;

    private String voucherCode;
    private String voucherNumber;
    private LocalDate voucherExpiryDate;
    private Long voucherSerialNum;

    private String quarter;
    private Integer financialYear;

    private Long docId;

}