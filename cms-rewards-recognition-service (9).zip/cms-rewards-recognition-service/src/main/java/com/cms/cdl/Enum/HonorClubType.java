package com.cms.cdl.Enum;

public enum HonorClubType {
    TEN_YEARS,
    TWENTY_YEARS,
    TWENTY_FIVE_YEARS
}
