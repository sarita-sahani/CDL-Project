package com.cms.cdl.utils;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.graphics.image.LosslessFactory;
import org.apache.pdfbox.pdmodel.graphics.image.PDImageXObject;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

import com.cms.cdl.entity.Voucher;

@Component
public class CertificateGenerator {

    /**
     * Generates both JPG and PDF versions of the certificate.
     * Returns a Map containing the generated Files with keys "JPG" and "PDF".
     */

    public Map<String, File> generateCertificateFiles(
            String templateImageUrl,
            String employeeName,
            String managerName,
            Voucher voucher,
            Long serialNumber
    ) throws Exception {

        // Load template
        String formattedPath = templateImageUrl.startsWith("/") ? templateImageUrl : "/" + templateImageUrl;
        ClassPathResource resource = new ClassPathResource("static" + formattedPath);
        BufferedImage image = ImageIO.read(resource.getInputStream());

        // Convert to RGB so JPEG export works cleanly
        BufferedImage rgb = new BufferedImage(image.getWidth(), image.getHeight(), BufferedImage.TYPE_INT_RGB);
        Graphics2D g = rgb.createGraphics();
        g.drawImage(image, 0, 0, Color.WHITE, null);
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_LCD_HRGB);
        g.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS, RenderingHints.VALUE_FRACTIONALMETRICS_ON);
        g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);

        int W = rgb.getWidth();
        int H = rgb.getHeight();

        boolean isECard = (serialNumber == null && voucher == null);

        if (isECard) {
            // ═══════════════════════════════════════════════════════════════════════
            // E-CARD LAYOUT
            // ═══════════════════════════════════════════════════════════════════════

            g.setColor(Color.BLACK);
            g.setFont(new Font("Arial", Font.BOLD, 14));

            String empUpper =formatName(employeeName);
            int empX = (int) (W * 0.05);
            int empY = (int) (H * 0.10);
            g.drawString(empUpper, empX, empY);

            g.setColor(Color.BLACK);
            g.setFont(new Font("Arial", Font.BOLD, 12));
            FontMetrics mgrFm = g.getFontMetrics();

            String mgrUpper =formatName(managerName);
            int mgrW = mgrFm.stringWidth(mgrUpper);
            int mgrX = (int) (W * 0.95) - mgrW;
            int mgrY = (int) (H * 0.92);
            g.drawString(mgrUpper, mgrX, mgrY);

        } else {
            // ═══════════════════════════════════════════════════════════════════════
            // E-CERTIFICATE LAYOUT (Matching Target Reference)
            // ═══════════════════════════════════════════════════════════════════════

            // ── 1. S. No + Date (Top Left) ──────────────────────────────────────
            g.setColor(new Color(15, 15, 15));
            g.setFont(new Font("Arial", Font.BOLD, (int) (H * 0.025))); // Responsive size

            // Draw values next to template labels
            g.drawString(String.valueOf(serialNumber), (int) (W * 0.115), (int) (H * 0.065));

            String dtValue = LocalDate.now().format(DateTimeFormatter.ofPattern("dd.MM.yyyy"));
            g.drawString(dtValue, (int) (W * 0.115), (int) (H * 0.115));

            // ── 2. Employee (Nominee) Name ───────────────────────────────────────
            g.setFont(new Font("Serif", Font.BOLD, (int) (H * 0.045))); // Elegant Serif font
            String empUpper = formatName(employeeName);
            FontMetrics empFm = g.getFontMetrics();
            int empTextW = empFm.stringWidth(empUpper);

            // Center relative to the printable white space (left of the blue ribbon)
            int textCenterX = (int) (W * 0.41);
            int empX = textCenterX - (empTextW / 2);
            int empY = (int) (H * 0.51); // Positioned nicely beneath "presented to"

            g.drawString(empUpper, empX, empY);

            // ── 3. Manager Name & Designation ───────────────────────────────
            g.setFont(new Font("Serif", Font.BOLD, (int) (H * 0.035)));
            String mgrUpper = formatName(managerName);
            FontMetrics mgrFm = g.getFontMetrics();
            int mgrW = mgrFm.stringWidth(mgrUpper);

            // Pivot point for the right-side alignment
            int mgrPivotX = (int) (W * 0.58);
            int mgrX = mgrPivotX - (mgrW / 2);
            int mgrY = (int) (H * 0.72);
            g.drawString(mgrUpper, mgrX, mgrY);

            // Designation
            g.setFont(new Font("Serif", Font.PLAIN, (int) (H * 0.030)));
            // Note: You can pass designation as a parameter, hardcoded for now based on target
            String mgrTitle = "Manager";
            FontMetrics lblFm = g.getFontMetrics();
            int lblW = lblFm.stringWidth(mgrTitle);
            int lblX = mgrPivotX - (lblW / 2);
            int lblY = (int) (H * 0.77);
            g.drawString(mgrTitle, lblX, lblY);

            // ── 4. Voucher Section ───────────────────────────────────────────────
            g.setColor(new Color(15, 15, 15));
            g.setFont(new Font("Arial", Font.BOLD, Math.max(10, (int) (H * 0.03))));
            String voucherCodeDisplay = (voucher != null && voucher.getVoucherCode() != null)
                    ? voucher.getVoucherCode()
                    : "null";
            g.drawString(voucherCodeDisplay, (int) (W * 0.41), (int) (H * 0.94));

            g.setColor(new Color(220, 38, 38));
            g.setFont(new Font("Arial", Font.BOLD, Math.max(12, (int) (H * 0.05))));
            String valStr = (voucher != null && voucher.getVoucherValue() != null)
                    ? String.valueOf(voucher.getVoucherValue().intValue())
                    : "0";
            g.drawString(valStr, (int) (W * 0.72), (int) (H * 0.945));
        }

        g.dispose();

        // ── Save JPG ─────────────────────────────────────────────────────────────
        File jpgFile = File.createTempFile("certificate-", ".jpg");
        ImageIO.write(rgb, "jpg", jpgFile);

        // ── Save PDF ─────────────────────────────────────────────────────────────
        File pdfFile = File.createTempFile("certificate-", ".pdf");
        try (PDDocument doc = new PDDocument()) {
            PDPage page = new PDPage(new PDRectangle(rgb.getWidth(), rgb.getHeight()));
            doc.addPage(page);
            PDImageXObject pdImage = LosslessFactory.createFromImage(doc, rgb);
            try (PDPageContentStream cs = new PDPageContentStream(doc, page)) {
                cs.drawImage(pdImage, 0, 0, rgb.getWidth(), rgb.getHeight());
            }
            doc.save(pdfFile);
        }

        Map<String, File> out = new HashMap<>();
        out.put("JPG", jpgFile);
        out.put("PDF", pdfFile);
        return out;
    }

    private String formatName(String name) {
        if (name == null || name.trim().isEmpty()) {
            return "";
        }

        return Arrays.stream(name.trim().toLowerCase().split("\\s+"))
                .map(word -> Character.toUpperCase(word.charAt(0)) + word.substring(1))
                .collect(Collectors.joining(" "));
    }
}