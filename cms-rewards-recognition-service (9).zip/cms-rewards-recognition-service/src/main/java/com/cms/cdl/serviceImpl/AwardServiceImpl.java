package com.cms.cdl.serviceImpl;


import com.cms.cdl.dto.executiveCircleDto.AwardDTO;
import com.cms.cdl.dto.executiveCircleDto.AwardEligibilityRequestDTO;
import com.cms.cdl.entity.Award;
import com.cms.cdl.entity.AwardEligibility;
import com.cms.cdl.mapper.AwardMapper;
import com.cms.cdl.repository.AwardEligibilityRepository;
import com.cms.cdl.repository.AwardRepository;
import com.cms.cdl.service.AwardService;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Transactional
public class AwardServiceImpl implements AwardService {

    private final AwardRepository awardRepository;
    private final AwardMapper awardMapper;
    private final AwardEligibilityRepository awardEligibilityRepository;


    @Override
    @Transactional(readOnly = true)
    public List<AwardDTO> getAllAwards() {
        return awardRepository.findAll()
                .stream()
                .map(awardMapper::toDTO)
                .collect(Collectors.toList());
    }

//    @Override
//    @Transactional(readOnly = true)
//    public List<AwardDTO> getAwardsForUser(String empCode, List<String> roles) {
//
//        List<Long> eligibleIds = awardEligibilityRepository.findEligibleAwardIds(empCode);
//
//        if (eligibleIds.isEmpty()) return List.of();
//
//        return awardRepository.findAllById(eligibleIds)
//                .stream()
//                .map(awardMapper::toDTO)
//                .collect(Collectors.toList());
//    }

    @Override
    @Transactional(readOnly = true)
    public List<AwardDTO> getAwardsForUser(String empCode, List<String> roles) {

        List<Long> eligibleIds =
                awardEligibilityRepository.findEligibleAwardIdsByRole(empCode);

        System.out.println(">>> empCode: " + empCode);
        System.out.println(">>> eligibleIds: " + eligibleIds);

        if (eligibleIds.isEmpty()) return List.of();

        return awardRepository.findAllById(eligibleIds)
                .stream()
                .map(awardMapper::toDTO)
                .collect(Collectors.toList());
    }
    @Override
    @Transactional(readOnly = true)
    public AwardDTO getAwardById(Long id) {
        Award award = awardRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Award not found with id: " + id));
        return awardMapper.toDTO(award);
    }

    @Override
    public AwardDTO createAward(AwardDTO awardDTO) {
        Award award = awardMapper.toEntity(awardDTO);
        return awardMapper.toDTO(awardRepository.save(award));
    }

    @Override
    public AwardDTO updateAward(Long id, AwardDTO awardDTO) {
        Award existing = awardRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Award not found with id: " + id));
        existing.setAwardTitle(awardDTO.getAwardTitle());
        existing.setNoOfAwards(awardDTO.getNoOfAwards());
        existing.setCategory(awardDTO.getCategory());
        existing.setCriteria(awardDTO.getCriteria());
        existing.setWhoCanNominate(awardDTO.getWhoCanNominate());
        existing.setOpenForNomination(awardDTO.isOpenForNomination());
        existing.setMaxNominations(awardDTO.getMaxNominations());
        return awardMapper.toDTO(awardRepository.save(existing));
    }

    @Override
    @Transactional
    public void removeEligibility(Long id) {

        AwardEligibility eligibility =
                awardEligibilityRepository.findById(id)
                        .orElseThrow(() ->
                                new RuntimeException(
                                        "Eligibility not found"));

        awardEligibilityRepository.delete(eligibility);
    }

    @Override
    @Transactional(readOnly = true)
    public List<AwardDTO> getOpenNominationAwards() {
        return awardRepository.findByIsOpenForNominationTrue()
                .stream()
                .map(awardMapper::toDTO)
                .collect(Collectors.toList());
    }

//    @Override
//    @Transactional
//    public void assignEligibility(AwardEligibilityRequestDTO request) {
//
//        Award award = awardRepository.findById(request.getAwardId())
//                .orElseThrow(() -> new RuntimeException("Award not found"));
//
//        // prevent duplicate mapping
//        boolean exists = awardEligibilityRepository
//                .existsByAwardIdAndEmpCode(
//                        request.getAwardId(),
//                        request.getEmpCode());
//
//        if (exists) {
//            throw new RuntimeException(
//                    "Permission already assigned");
//        }
//
//        AwardEligibility eligibility = AwardEligibility.builder()
//                .award(award)
//                .empCode(request.getEmpCode())
//                .empName(request.getEmpName())
//                .email(request.getEmail())
//                .isActive(true)
//                .build();
//
//        awardEligibilityRepository.save(eligibility);
//    }
//
//    @Override
//    @Transactional(readOnly = true)
//    public List<AwardEligibilityRequestDTO>
//    getEligibilityByAward(Long awardId) {
//
//        List<AwardEligibility> list =
//                awardEligibilityRepository.findByAwardId(awardId);
//
//        return list.stream()
//                .map(item -> AwardEligibilityRequestDTO.builder()
//                        .id(item.getId())
//                        .awardId(item.getAward().getId())
//                        .awardTitle(item.getAward().getAwardTitle())
//                        .empCode(item.getEmpCode())
//                        .empName(item.getEmpName())
//                        .email(item.getEmail())
//                        .isActive(item.getIsActive())
//                        .build())
//                .collect(Collectors.toList());
//    }

    @Override
    @Transactional
    public void assignEligibility(AwardEligibilityRequestDTO request) {
        // no award lookup needed — just save empCode + role
        boolean exists = awardEligibilityRepository
                .existsByEmpCode(request.getEmpCode());

        if (exists) throw new RuntimeException("Permission already assigned");

        AwardEligibility eligibility = AwardEligibility.builder()
                .empCode(request.getEmpCode())
                .empName(request.getEmpName())
                .email(request.getEmail())
                .role(request.getRole())
                .isActive(true)
                .build();

        awardEligibilityRepository.save(eligibility);
    }

    @Override
    public boolean isEmployeeEligibleForAnyAward(String empCode) {
        return awardEligibilityRepository.existsByEmpCode(empCode);
    }

    @Override
    @Transactional(readOnly = true)
    public List<AwardEligibilityRequestDTO> getEligibilityByAward(Long awardId) {
        // now returns all eligibility records (filtered by awardId not applicable)
        return awardEligibilityRepository.findAll()
                .stream()
                .map(item -> AwardEligibilityRequestDTO.builder()
                        .id(item.getId())
                        .empCode(item.getEmpCode())
                        .empName(item.getEmpName())
                        .email(item.getEmail())
                        .role(item.getRole())
                        .isActive(item.getIsActive())
                        .build())
                .collect(Collectors.toList());
    }
}
