package com.cms.cdl.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "executive_circle_ranking",
        uniqueConstraints = {
                @UniqueConstraint(
                        columnNames = {
                                "financial_year",
                                "award_title",
                                "rank_position"
                        }
                )
        })
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ExecutiveCircleRanking {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String financialYear;

    private String awardTitle;

    private Long nominationDetailId;

    private Integer rankPosition;

    private String rankedBy;

    private LocalDateTime rankedAt;
    private String rankReason;
}