package com.cms.cdl;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;

@SpringBootApplication
@EnableAsync(proxyTargetClass = true)
public class CmsRewardsRecognitionServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(CmsRewardsRecognitionServiceApplication.class, args);
	}

}
