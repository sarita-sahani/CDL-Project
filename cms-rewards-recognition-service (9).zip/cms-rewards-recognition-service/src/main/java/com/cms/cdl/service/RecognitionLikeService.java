package com.cms.cdl.service;

import com.cms.cdl.Enum.InteractionType;
import com.cms.cdl.entity.RnRLikesTable;

import java.util.List;
import java.util.concurrent.ExecutionException;

public interface RecognitionLikeService {
    String likeRecognition(Long id, String empCode, InteractionType type)
            throws ExecutionException, InterruptedException;

    List<RnRLikesTable> getRecognitionLikes(Long id, InteractionType type);
}
