package com.cms.cdl.dto.response_dto.emp_full_response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class BuHeadResDTO {
    private Long id;
    private String buHeadName;
    private String buHeadEmpCode;
    private String buHeadEmailId;
}
