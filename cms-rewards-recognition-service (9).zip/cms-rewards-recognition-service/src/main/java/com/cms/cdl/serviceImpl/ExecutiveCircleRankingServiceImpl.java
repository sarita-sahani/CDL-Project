package com.cms.cdl.serviceImpl;

import com.cms.cdl.dto.executiveCircleDto.ExecutiveRankingRequest;
import com.cms.cdl.dto.executiveCircleDto.ExecutiveRankingResponse;
import com.cms.cdl.dto.honorClub.AwardWinnersResponse;
import com.cms.cdl.dto.honorClub.WinnerDto;
import com.cms.cdl.entity.ExecutiveCircleRanking;
import com.cms.cdl.entity.NominationDetail;
import com.cms.cdl.repository.ExecutiveCircleRankingRepository;
import com.cms.cdl.service.ExecutiveCircleRankingService;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ExecutiveCircleRankingServiceImpl
        implements ExecutiveCircleRankingService {

    private final ExecutiveCircleRankingRepository rankingRepository;

    @Override
    @Transactional
    public void saveRank(ExecutiveRankingRequest request) {

        // If rank already exists for this position, clear it (including reason)
        Optional<ExecutiveCircleRanking> existingRank =
                rankingRepository.findByFinancialYearAndAwardTitleAndRankPosition(
                        request.getFinancialYear(),
                        request.getAwardTitle(),
                        request.getRankPosition());

        if (existingRank.isPresent()) {
            ExecutiveCircleRanking old = existingRank.get();
            old.setRankPosition(null);
            old.setRankReason(null);       // clear reason as well
            rankingRepository.save(old);
        }

        ExecutiveCircleRanking ranking =
                rankingRepository.findByNominationDetailId(request.getNominationDetailId())
                        .orElse(ExecutiveCircleRanking.builder()
                                .nominationDetailId(request.getNominationDetailId())
                                .build());

        ranking.setFinancialYear(request.getFinancialYear());
        ranking.setAwardTitle(request.getAwardTitle());
        ranking.setRankPosition(request.getRankPosition());
        ranking.setRankReason(request.getReason());   // store reason
        ranking.setRankedAt(LocalDateTime.now());

        rankingRepository.save(ranking);
    }
    @Override
    public List<ExecutiveRankingResponse> getRankings(
            String financialYear,
            String awardTitle) {

        return rankingRepository
                .findByFinancialYearAndAwardTitle(
                        financialYear,
                        awardTitle)
                .stream()
                .map(r ->
                        ExecutiveRankingResponse.builder()
                                .nominationDetailId(
                                        r.getNominationDetailId())
                                .rankPosition(
                                        r.getRankPosition())
                                .rankReason(r.getRankReason())
                                .build()
                )
                .toList();
    }

    @Override
    public List<AwardWinnersResponse> getWinnersByAward(String financialYear) {
        List<Object[]> results = rankingRepository.findTopRankingsByFinancialYear(financialYear);
        Map<String, List<WinnerDto>> awardMap = new LinkedHashMap<>();

        for (Object[] row : results) {
            ExecutiveCircleRanking ranking = (ExecutiveCircleRanking) row[0];
            NominationDetail detail = (NominationDetail) row[1];

            WinnerDto winner = WinnerDto.builder()
                    .rank(ranking.getRankPosition())
                    .nomineeName(detail.getNomineeName())
                    .employeeCode(detail.getNomineeEmployeeCode())
                    .department(detail.getDepartment())
                    .rankReason(ranking.getRankReason())
                    .reasonForNomination(detail.getReasonForNomination())
                    .build();

            awardMap.computeIfAbsent(ranking.getAwardTitle(), k -> new ArrayList<>()).add(winner);
        }

        return awardMap.entrySet().stream()
                .map(entry -> AwardWinnersResponse.builder()
                        .awardTitle(entry.getKey())
                        .winners(entry.getValue())
                        .build())
                .collect(Collectors.toList());
    }
}