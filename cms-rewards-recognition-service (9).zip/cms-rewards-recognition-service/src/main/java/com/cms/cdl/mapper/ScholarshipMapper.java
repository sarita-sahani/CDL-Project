package com.cms.cdl.mapper;

import com.cms.cdl.dto.honorClub.ScholarshipDto;
import com.cms.cdl.entity.Scholarship;
import com.cms.cdl.entity.ScholarshipChild;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.List;

@Component
public class ScholarshipMapper {

    public Scholarship toEntity(
            ScholarshipDto.Request dto) {

        if (dto == null) {
            return null;
        }

        return Scholarship.builder()
                .awardYear(dto.getAwardYear())
                .scholarshipType(dto.getScholarshipType())
                .empCode(dto.getEmpCode())
                .employeeName(dto.getEmployeeName())
                .department(dto.getDepartment())
                .subDepartment(dto.getSubDepartment())
                .location(dto.getLocation())
                .project(dto.getProject())
                .r1ECode(dto.getR1ECode())
                .r1Name(dto.getR1Name())
                .buHeadName(dto.getBuHeadName())
                .build();
    }

    public ScholarshipDto.Response toResponse(
            Scholarship entity) {

        if (entity == null) {
            return null;
        }

        return ScholarshipDto.Response.builder()
                .id(entity.getId())
                .awardYear(entity.getAwardYear())
                .scholarshipType(entity.getScholarshipType())
                .empCode(entity.getEmpCode())
                .employeeName(entity.getEmployeeName())
                .department(entity.getDepartment())
                .subDepartment(entity.getSubDepartment())
                .location(entity.getLocation())
                .project(entity.getProject())
                .r1ECode(entity.getR1ECode())
                .r1Name(entity.getR1Name())
                .buHeadName(entity.getBuHeadName())
                .selected(entity.getSelected())
                .published(entity.getPublished())
                .children(
                        entity.getChildren() == null
                                ? Collections.emptyList()
                                : entity.getChildren()
                                .stream()
                                .map(this::toChildResponse)
                                .toList()
                )
                .build();
    }

    private ScholarshipDto.ChildResponse toChildResponse(
            ScholarshipChild child) {

        return ScholarshipDto.ChildResponse.builder()
                .id(child.getId())
                .title(child.getTitle())
                .studentName(child.getStudentName())
                .academicYear(child.getAcademicYear())
                .marksPercentage(child.getMarksPercentage())
                .percentile(child.getPercentile())
                .rankObtained(child.getRankObtained())
                .schoolName(child.getSchoolName())
                .photoDocId(child.getPhotoDocId())
                .certificateDocId(child.getCertificateDocId())
                .build();
    }

    public List<ScholarshipDto.Response> toResponseList(
            List<Scholarship> entities) {

        return entities.stream()
                .map(this::toResponse)
                .toList();
    }
}