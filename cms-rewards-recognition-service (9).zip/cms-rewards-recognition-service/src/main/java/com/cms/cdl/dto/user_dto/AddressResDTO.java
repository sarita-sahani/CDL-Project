package com.cms.cdl.dto.user_dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class AddressResDTO {
    private long addressId;
    private String houseNo;
    private String street1;
    private String street2;
    private String landmark;
    private String country;
    private String state;
    private String district;
    private String city;
    private Integer pinCode;
}
