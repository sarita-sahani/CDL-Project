package com.cms.cdl.dto.executiveCircleDto;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class NominationDetailDTO {
    private Long id;
    private int sequenceNo;
    private String nomineeEmployeeCode;
    private String nomineeName;
    private String department;
    private String nomineeEmailId;
    private String nomineeDesignation;
    private String reasonForNomination;
}
