package com.cms.cdl.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import lombok.*;

import java.util.List;

@Entity
@Table(name = "awards")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class Award {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "award_title", nullable = false, unique = true)
    private String awardTitle;

    @Column(name = "no_of_awards")
    private String noOfAwards; // e.g., "1", "2-4", "3-4"

    @Column(name = "category", nullable = false)
    private String category;

    @Column(name = "criteria", columnDefinition = "TEXT")
    private String criteria;

    @Column(name = "who_can_nominate")
    private String whoCanNominate;

    @Column(name = "is_open_for_nomination")
    private boolean isOpenForNomination;

    @Column(name = "max_nominations")
    private int maxNominations; // max number of nominations allowed

    @OneToMany(mappedBy = "award",
            cascade = CascadeType.ALL,
            orphanRemoval = true)
    private List<AwardEligibility> eligibilities;
}
