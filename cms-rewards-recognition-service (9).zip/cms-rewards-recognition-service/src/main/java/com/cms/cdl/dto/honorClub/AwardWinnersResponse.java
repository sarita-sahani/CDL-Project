package com.cms.cdl.dto.honorClub;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AwardWinnersResponse {
    private String awardTitle;
    private List<WinnerDto> winners; // sorted by rank (1,2,3)
}