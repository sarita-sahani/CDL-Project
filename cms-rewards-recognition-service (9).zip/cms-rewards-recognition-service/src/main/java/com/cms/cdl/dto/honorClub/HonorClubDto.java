package com.cms.cdl.dto.honorClub;

import com.cms.cdl.Enum.HonorClubType;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.*;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDate;

public class HonorClubDto {

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class Request {

        @NotBlank
        private String awardYear;

        @NotNull
        private HonorClubType honorClubType;

        @NotBlank
        private String empCode;

        private String employeeName;

        private String department;

        private MultipartFile file;
        private LocalDate createdDate;
    }

    @Getter
    @Setter
    @Builder
    public static class Response {

        private Long id;

        private String awardYear;

        private HonorClubType honorClubType;

        private String empCode;

        private String employeeName;

        private String department;

        private Long docId;

        private Boolean published;
        private Boolean selected;
        private LocalDate createdDate;
    }
}
