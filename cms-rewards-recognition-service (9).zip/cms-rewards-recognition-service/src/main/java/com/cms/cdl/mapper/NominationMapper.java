package com.cms.cdl.mapper;

import com.cms.cdl.dto.executiveCircleDto.*;
import com.cms.cdl.entity.*;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.Mapping;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

@Component
public class NominationMapper {

    public NominationDetailDTO toDetailDTO(NominationDetail detail) {
        if (detail == null) return null;
        return NominationDetailDTO.builder()
                .id(detail.getId())
                .sequenceNo(detail.getSequenceNo())
                .nomineeEmployeeCode(detail.getNomineeEmployeeCode())
                .nomineeName(detail.getNomineeName())
                .department(detail.getDepartment())
                .nomineeEmailId(detail.getNomineeEmailId())
                .nomineeDesignation(detail.getNomineeDesignation())
                .reasonForNomination(detail.getReasonForNomination())
                .build();
    }

    public NominationDetail toDetailEntity(NominationDetailDTO dto, Nomination nomination) {
        if (dto == null) return null;
        return NominationDetail.builder()
                .id(dto.getId())
                .nomination(nomination)
                .sequenceNo(dto.getSequenceNo())
                .nomineeEmployeeCode(dto.getNomineeEmployeeCode())
                .nomineeName(dto.getNomineeName())
                .department(dto.getDepartment())
                .nomineeEmailId(dto.getNomineeEmailId())
                .nomineeDesignation(dto.getNomineeDesignation())
                .reasonForNomination(dto.getReasonForNomination())
                .build();
    }

    public NominationDTO toDTO(Nomination nomination) {
        if (nomination == null) return null;
        List<NominationDetailDTO> details = nomination.getNominationDetails().stream()
                .sorted(Comparator.comparingInt(NominationDetail::getSequenceNo))
                .map(this::toDetailDTO)
                .collect(Collectors.toList());

        return NominationDTO.builder()
                .id(nomination.getId())
                .awardId(nomination.getAward().getId())
                .awardTitle(nomination.getAward().getAwardTitle())
                .category(nomination.getAward().getCategory())
                .financialYear(nomination.getFinancialYear())
                .submittedByEmployeeCode(nomination.getSubmittedByEmployeeCode())
                .submittedByEmailId(nomination.getSubmittedByEmailId())
                .submittedByName(nomination.getSubmittedByName())
                .isNominating(nomination.isNominating())
                //.status(nomination.getStatus())
                .status(nomination.getStatus() != null ? nomination.getStatus().getDisplayValue() : null)
                .createdAt(nomination.getCreatedAt())
                .updatedAt(nomination.getUpdatedAt())
                .nominationDetails(details)
                .build();
    }

    public NominationSummaryDTO toSummaryDTO(Nomination nomination) {

        NominationSummaryDTO dto = new NominationSummaryDTO();

        dto.setNominationId(nomination.getId());

        dto.setAwardTitle(
                nomination.getAward() != null
                        ? nomination.getAward().getAwardTitle()
                        : null
        );

        dto.setCategory(
                nomination.getAward() != null
                        ? nomination.getAward().getCategory()
                        : null
        );

        dto.setFinancialYear(
                nomination.getFinancialYear()
        );

        // ── Nominator Details ─────────────────────

        dto.setSubmittedByEmployeeCode(
                nomination.getSubmittedByEmployeeCode()
        );

        dto.setSubmittedByName(
                nomination.getSubmittedByName()
        );

        dto.setSubmittedByEmailId(
                nomination.getSubmittedByEmailId()
        );

        dto.setIsNominating(
                nomination.isNominating()
        );

//        dto.setStatus(
//                nomination.getStatus()
//        );

        dto.setStatus(nomination.getStatus() != null ? nomination.getStatus().getDisplayValue() : null);
        dto.setHrRemarks(nomination.getHrRemarks() != null ? nomination.getHrRemarks() : null);


        dto.setCreatedAt(
                nomination.getCreatedAt()
        );

        // ── Nominee Summary Fields ────────────────

        List<NominationDetail> details =
                nomination.getNominationDetails();

        for (NominationDetail detail : details) {

            int seq = detail.getSequenceNo();

            switch (seq) {

                case 1 -> {
                    dto.setNomination1(detail.getNomineeName());
                    dto.setDepartment1(detail.getDepartment());
                    dto.setReason1(detail.getReasonForNomination());
                }

                case 2 -> {
                    dto.setNomination2(detail.getNomineeName());
                    dto.setDepartment2(detail.getDepartment());
                    dto.setReason2(detail.getReasonForNomination());
                }

                case 3 -> {
                    dto.setNomination3(detail.getNomineeName());
                    dto.setDepartment3(detail.getDepartment());
                    dto.setReason3(detail.getReasonForNomination());
                }

                case 4 -> {
                    dto.setNomination4(detail.getNomineeName());
                    dto.setDepartment4(detail.getDepartment());
                    dto.setReason4(detail.getReasonForNomination());
                }
            }
        }

        // ── Full Nominee Detail List ──────────────

        dto.setNominationDetails(

                details.stream()
                        .map(detail -> NominationDetailDTO.builder()

                                .id(detail.getId())

                                .sequenceNo(
                                        detail.getSequenceNo()
                                )

                                .nomineeEmployeeCode(
                                        detail.getNomineeEmployeeCode()
                                )

                                .nomineeName(
                                        detail.getNomineeName()
                                )

                                .department(
                                        detail.getDepartment()
                                )

                                .nomineeEmailId(
                                        detail.getNomineeEmailId()
                                )

                                .nomineeDesignation(
                                        detail.getNomineeDesignation()
                                )

                                .reasonForNomination(
                                        detail.getReasonForNomination()
                                )

                                .build())

                        .toList()
        );

        return dto;
    }
}
