package com.cms.cdl.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class RnRLikesTable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long recognitionId;

    private Long nominationDetailId;

    private Long honorClubId;

    private Long scholarshipChildId;

    private String empCode;

    private String employeeName;
    private String department;
    private String emailId;

    private String likedAt;
}
