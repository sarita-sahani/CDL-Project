package com.cms.cdl.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name="RnR_Mapping_table")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class RnRMappingTable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String empCode;
    private String emailId;
    private String empName;
}
