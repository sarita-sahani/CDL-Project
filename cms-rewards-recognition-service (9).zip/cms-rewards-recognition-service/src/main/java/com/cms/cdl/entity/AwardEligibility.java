package com.cms.cdl.entity;

import jakarta.persistence.*;
import lombok.*;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "award_eligibility")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AwardEligibility {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // MANY eligibility records can belong to ONE award
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "award_id", nullable = false)
    private Award award;

    @Column(name = "emp_code", nullable = false)
    private String empCode;

    @Column(name = "email", nullable = false)
    private String email;

    @Column(name = "emp_name")
    private String empName;

    private String role;

    // optional
    @Column(name = "is_active")
    private Boolean isActive = true;
}