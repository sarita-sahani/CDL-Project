package com.cms.cdl.service;

import com.cms.cdl.dto.executiveCircleDto.NominationDTO;
import com.cms.cdl.dto.executiveCircleDto.NominationSummaryDTO;
import com.cms.cdl.entity.Nomination;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public interface NominationService {

    NominationDTO saveOrUpdateNomination(NominationDTO dto);

    // ── NEW: preview ──────────────────────────────────────────────────────────
    @Transactional(readOnly = true)
    List<NominationDTO> getNominationsForPreview(String employeeCode,
                                                 String financialYear);

    // ── NEW: submit all drafts to HR ──────────────────────────────────────────
    @Transactional
    List<NominationDTO> submitNominationsToHR(String employeeCode,
                                              String financialYear);

    NominationDTO getNominationById(Long id);

    NominationDTO getNominationByAwardAndEmployee(Long awardId, String employeeCode, String financialYear);

    List<NominationDTO> getNominationsByEmployee(String employeeCode, String financialYear);

//    List<NominationSummaryDTO> getAllNominationSummaries(String financialYear, String status);

    @Transactional(readOnly = true)
    List<NominationSummaryDTO> getExecutiveCircleDetails(
            String financialYear, List<String> status, String managerEmpCode);



    NominationDTO submitNomination(Long id);

    void deleteNomination(Long id);

    /**
     * Validates & submits ALL nominations for an employee in a given FY.
     *
     * Rules enforced:
     *  - Every award that is open for nomination must have a saved record
     *    (either isNominating=false  OR  at least 1 detail with name+reason).
     *  - Throws IllegalStateException listing the award(s) with missing data.
     *  - On success, sets every DRAFT nomination to SUBMITTED.
     */
    List<NominationDTO> submitAllNominations(String employeeCode, String financialYear);

    @Transactional
    Nomination reviewNomination(Long nominationId, String status, String hrRemarks);
}
