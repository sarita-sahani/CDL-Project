package com.cms.cdl.serviceImpl;

import com.cms.cdl.beans.emp_user_bean.EmpAndUserResponse;
import com.cms.cdl.entity.RnRCommentsTable;
import com.cms.cdl.Enum.InteractionType;
import com.cms.cdl.repository.CommentsRepository;
import com.cms.cdl.service.CommentsService;
import com.cms.cdl.utils.EmployeeOperations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.concurrent.ExecutionException;

@Service
public class CommentsServiceImpl implements CommentsService {

    @Autowired
    private EmployeeOperations employeeOperations;

    @Autowired
    private CommentsRepository commentsRepository;
    @Autowired
    private MailServiceImpl mailService;


    @Override
    public RnRCommentsTable addComment(
            String empCode,
            Long id,
            String comments,
            InteractionType type)
            throws ExecutionException, InterruptedException {

        EmpAndUserResponse emp =
                employeeOperations.getEmpByEmpCode(empCode);

        if (emp == null) {
            throw new IllegalArgumentException(
                    "Employee not found: " + empCode);
        }

        RnRCommentsTable commentsObj = new RnRCommentsTable();

        switch (type) {

            case RECOGNITION ->
                    commentsObj.setRecognitionId(id);

            case NOMINATION ->
                    commentsObj.setNominationDetailId(id);

            case HONOR_CLUB ->
                    commentsObj.setHonorClubId(id);

            case SCHOLARSHIP ->
                    commentsObj.setScholarshipChildId(id);
        }

        commentsObj.setEmpCode(empCode);

        commentsObj.setEmployeeName(
                emp.getFileAndObjectTypeBean()
                        .getEmpResDTO()
                        .getFirstName());

        commentsObj.setEmailId(
                emp.getFileAndObjectTypeBean()
                        .getEmpResDTO()
                        .getEmailId());

        commentsObj.setDepartment(
                emp.getFileAndObjectTypeBean()
                        .getEmpResDTO()
                        .getMainDeptResDTO()
                        .getMainDepartment());

        commentsObj.setComments(comments);

        DateTimeFormatter fmt =
                DateTimeFormatter.ofPattern(
                        "dd MMMM yyyy hh:mm a");

        commentsObj.setCommentDateTime(
                LocalDateTime.now(
                                ZoneId.of("Asia/Kolkata"))
                        .format(fmt));

        return commentsRepository.save(commentsObj);
    }

    @Override
    public List<RnRCommentsTable> getAllRnRComments(
            Long id,
            InteractionType type) {

        return switch (type) {

            case RECOGNITION ->
                    commentsRepository.findByRecognitionId(id);

            case NOMINATION ->
                    commentsRepository.findByNominationDetailId(id);

            case HONOR_CLUB ->
                    commentsRepository.findByHonorClubId(id);

            case SCHOLARSHIP ->
                    commentsRepository.findByScholarshipChildId(id);
        };
    }



}