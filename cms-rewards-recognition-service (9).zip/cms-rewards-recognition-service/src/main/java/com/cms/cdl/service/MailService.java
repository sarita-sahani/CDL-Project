package com.cms.cdl.service;

import com.cms.cdl.dto.executiveCircleDto.HRMailAwardGroup;
import com.cms.cdl.dto.executiveCircleDto.NomineeRow;
import com.cms.cdl.entity.Recognition;
import com.cms.cdl.entity.Voucher;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.util.List;
import java.util.Map;

public interface MailService {

    void sendRecognitionMail(
            String toEmail,
            String nomineeName,
            String nominatorName,
            String recognitionType,
            String messageText,
            MultipartFile certificateFile,
            Voucher voucher
    );

    void sendLowVoucherAlert(List<String> emailIds, long remainingCount);

    void sendNominationNotificationMail(String toEmail,
                                        String nomineeName,
                                        String nominatorName,
                                        String awardTitle,
                                        String awardCategory,
                                        String awardCriteria,
                                        String financialYear);

    void sendHRSubmissionMail(String nominatorName,
                              String nominatorCode,
                              String nominatorEmail,
                              String financialYear,
                              List<NomineeRow> awardGroups);
//public void sendRecognitionMail(Recognition recognition);
}
