package com.cms.cdl.serviceImpl;

import com.cms.cdl.dto.executiveCircleDto.NominationSummaryDTO;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;

@Service
public class ExcelExportService {

    public byte[] exportNominationSummaries(List<NominationSummaryDTO> summaries,
                                            String financialYear) throws IOException {
        try (Workbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("Nominations FY " + financialYear);

            // ── Styles ────────────────────────────────────────────────────────
            CellStyle headerStyle = workbook.createCellStyle();
            headerStyle.setFillForegroundColor(IndexedColors.DARK_RED.getIndex());
            headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            Font headerFont = workbook.createFont();
            headerFont.setColor(IndexedColors.WHITE.getIndex());
            headerFont.setBold(true);
            headerStyle.setFont(headerFont);
            applyBorder(headerStyle);
            headerStyle.setAlignment(HorizontalAlignment.CENTER);

            CellStyle titleStyle = workbook.createCellStyle();
            Font titleFont = workbook.createFont();
            titleFont.setBold(true);
            titleFont.setFontHeightInPoints((short) 14);
            titleStyle.setFont(titleFont);

            CellStyle dataStyle = workbook.createCellStyle();
            applyBorder(dataStyle);
            dataStyle.setWrapText(true);
            dataStyle.setVerticalAlignment(VerticalAlignment.TOP);

            // Reason style — same as dataStyle (plain, no italic, no muted colour)
            CellStyle reasonStyle = dataStyle;

            // ── Title row ─────────────────────────────────────────────────────
            // Now spans 10 columns (0–9): Award Title, Category, then 4×(Nominee, Reason)
            Row titleRow = sheet.createRow(0);
            titleRow.setHeightInPoints(24);
            Cell titleCell = titleRow.createCell(0);
            titleCell.setCellValue("Executive Circle Award Nominations – FY " + financialYear);
            titleCell.setCellStyle(titleStyle);
            sheet.addMergedRegion(new CellRangeAddress(0, 0, 0, 9));

            // ── Header row ────────────────────────────────────────────────────
            // Layout: Award Title | Category | Nomination 1 | Reason 1 | Nomination 2 | Reason 2 | ...
            String[] headers = {
                    "Award Title", "Category",
                    "Nomination 1", "Reason for Nomination 1",
                    "Nomination 2", "Reason for Nomination 2",
                    "Nomination 3", "Reason for Nomination 3",
                    "Nomination 4", "Reason for Nomination 4"
            };
            int[] colWidths = {
                    8000, 6000,          // Award Title, Category
                    7000, 12000,         // Nom 1, Reason 1
                    7000, 12000,         // Nom 2, Reason 2
                    7000, 12000,         // Nom 3, Reason 3
                    7000, 12000          // Nom 4, Reason 4
            };

            Row headerRow = sheet.createRow(1);
            headerRow.setHeightInPoints(18);
            for (int i = 0; i < headers.length; i++) {
                Cell cell = headerRow.createCell(i);
                cell.setCellValue(headers[i]);
                cell.setCellStyle(headerStyle);
                sheet.setColumnWidth(i, colWidths[i]);
            }

            // ── Data rows ─────────────────────────────────────────────────────
            int rowNum = 2;
            for (NominationSummaryDTO s : summaries) {
                Row row = sheet.createRow(rowNum++);
                row.setHeightInPoints(60);

                createCell(row, 0, s.getAwardTitle(),                                     dataStyle);
                createCell(row, 1, s.getCategory(),                                       dataStyle);

                createCell(row, 2, formatNominee(s.getNomination1(), s.getDepartment1()), dataStyle);
                createCell(row, 3, s.getReason1(),                                        reasonStyle);

                createCell(row, 4, formatNominee(s.getNomination2(), s.getDepartment2()), dataStyle);
                createCell(row, 5, s.getReason2(),                                        reasonStyle);

                createCell(row, 6, formatNominee(s.getNomination3(), s.getDepartment3()), dataStyle);
                createCell(row, 7, s.getReason3(),                                        reasonStyle);

                createCell(row, 8, formatNominee(s.getNomination4(), s.getDepartment4()), dataStyle);
                createCell(row, 9, s.getReason4(),                                        reasonStyle);
            }

            ByteArrayOutputStream out = new ByteArrayOutputStream();
            workbook.write(out);
            return out.toByteArray();
        }
    }

    // ── Private helpers ───────────────────────────────────────────────────────

    private void createCell(Row row, int col, String value, CellStyle style) {
        Cell cell = row.createCell(col);
        cell.setCellValue(value != null ? value : "");
        cell.setCellStyle(style);
    }

    private String formatNominee(String name, String dept) {
        if (name == null || name.isBlank()) return "";
        return dept != null && !dept.isBlank()
                ? name + "\n(" + dept + ")"
                : name;
    }

    private void applyBorder(CellStyle style) {
        style.setBorderTop(BorderStyle.THIN);
        style.setBorderBottom(BorderStyle.THIN);
        style.setBorderLeft(BorderStyle.THIN);
        style.setBorderRight(BorderStyle.THIN);
    }
}