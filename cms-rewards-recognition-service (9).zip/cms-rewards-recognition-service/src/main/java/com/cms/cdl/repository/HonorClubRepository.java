package com.cms.cdl.repository;

import com.cms.cdl.entity.HonorClub;
import com.cms.cdl.Enum.HonorClubType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface HonorClubRepository
        extends JpaRepository<HonorClub, Long> {

    List<HonorClub> findByAwardYear(String awardYear);

    List<HonorClub> findBySelectedTrue();


    List<HonorClub> findByHonorClubType(HonorClubType honorClubType);

    List<HonorClub> findByAwardYearAndHonorClubType(
            String awardYear,
            HonorClubType honorClubType);

}