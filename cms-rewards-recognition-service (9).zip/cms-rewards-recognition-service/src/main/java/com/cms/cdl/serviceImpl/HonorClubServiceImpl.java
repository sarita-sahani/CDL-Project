package com.cms.cdl.serviceImpl;

import com.cms.cdl.common_dtos.dto.document_dto.DocumentDTO;
import com.cms.cdl.common_dtos.util.dms.DocumentOperations;
import com.cms.cdl.dto.honorClub.HonorClubDto;
import com.cms.cdl.entity.HonorClub;
import com.cms.cdl.Enum.HonorClubType;
import com.cms.cdl.mapper.HonorClubMapper;
import com.cms.cdl.repository.HonorClubRepository;
import com.cms.cdl.service.HonorClubService;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.time.LocalDate;
import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class HonorClubServiceImpl implements HonorClubService {

    private final HonorClubRepository honorClubRepository;
    private final HonorClubMapper honorClubMapper;

    @Autowired
    DocumentOperations documentOperations;

    @Override
    @Transactional
    public HonorClubDto.Response saveHonorClubData(
            HonorClubDto.Request request) throws IOException {

        Long docId = null;

        if (request.getFile() != null
                && !request.getFile().isEmpty()) {

            DocumentDTO documentDTO = new DocumentDTO();
            documentDTO.setEmpCode(request.getEmpCode());

            docId = documentOperations
                    .uploadDocument(documentDTO, request.getFile())
                    .get(0)
                    .getDocId();
        }

        HonorClub entity = honorClubMapper.toEntity(request);

        entity.setDocId(docId);
        entity.setCreatedDate(LocalDate.now());
        entity.setSelected(Boolean.FALSE);
        entity.setPublished(Boolean.FALSE);

        HonorClub savedEntity =
                honorClubRepository.save(entity);

        return honorClubMapper.toResponse(savedEntity);
    }

    @Override
    public List<HonorClubDto.Response> getHonorClubDataByYear(
            String awardYear) {

        return honorClubRepository.findByAwardYear(awardYear)
                .stream()
                .map(honorClubMapper::toResponse)
                .toList();
    }

    @Override
    public List<HonorClubDto.Response> getHonorClubDataByType(
            HonorClubType honorClubType) {

        return honorClubRepository.findByHonorClubType(
                        honorClubType)
                .stream()
                .map(honorClubMapper::toResponse)
                .toList();
    }

    @Override
    public List<HonorClubDto.Response>
    getHonorClubDataByYearAndType(
            String awardYear,
            HonorClubType honorClubType) {

        return honorClubRepository
                .findByAwardYearAndHonorClubType(
                        awardYear,
                        honorClubType)
                .stream()
                .map(honorClubMapper::toResponse)
                .toList();
    }
}