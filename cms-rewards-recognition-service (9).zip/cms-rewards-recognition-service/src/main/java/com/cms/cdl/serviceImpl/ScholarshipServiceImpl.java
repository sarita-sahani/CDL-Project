package com.cms.cdl.serviceImpl;

import com.cms.cdl.common_dtos.dto.document_dto.DocumentDTO;
import com.cms.cdl.common_dtos.util.dms.DocumentOperations;
import com.cms.cdl.dto.honorClub.ScholarshipDto;
import com.cms.cdl.entity.Scholarship;
import com.cms.cdl.entity.ScholarshipChild;
import com.cms.cdl.Enum.ScholarshipType;
import com.cms.cdl.mapper.ScholarshipMapper;
import com.cms.cdl.repository.ScholarshipRepository;
import com.cms.cdl.service.ScholarshipService;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional
public class ScholarshipServiceImpl
        implements ScholarshipService {

    private final ScholarshipRepository scholarshipRepository;
    private final ScholarshipMapper scholarshipMapper;
    private final DocumentOperations documentOperations;

    private MultipartFile base64ToMultipartFile(String base64, String fileName) {
        byte[] bytes = Base64.getDecoder().decode(base64);
        return new MockMultipartFile(
                fileName,                                    // name
                fileName,                                    // originalFilename
                MediaType.APPLICATION_OCTET_STREAM_VALUE,   // contentType
                bytes                                        // content
        );
    }

    @Override
    public ScholarshipDto.Response saveScholarship(ScholarshipDto.Request request)
            throws IOException {

        Scholarship scholarship = scholarshipMapper.toEntity(request);
        scholarship.setCreatedDate(LocalDate.now());
        scholarship.setPublished(false);
        scholarship.setSelected(false);

        List<ScholarshipChild> children = new ArrayList<>();

        if (request.getChildren() != null) {
            for (ScholarshipDto.ChildRequest childReq : request.getChildren()) {

                Long photoDocId = null;
                Long certificateDocId = null;

                // Handle photo base64
                if (childReq.getPhotoFile() != null
                        && !childReq.getPhotoFile().isEmpty()) {

                    MultipartFile photoFile = base64ToMultipartFile(
                            childReq.getPhotoFile(),
                            childReq.getPhotoFileName()
                    );

                    DocumentDTO dto = new DocumentDTO();
                    dto.setEmpCode(request.getEmpCode());

                    photoDocId = documentOperations
                            .uploadDocument(dto, photoFile)
                            .get(0)
                            .getDocId();
                }

                // Handle certificate base64
                if (childReq.getCertificateFile() != null
                        && !childReq.getCertificateFile().isEmpty()) {

                    MultipartFile certificateFile = base64ToMultipartFile(
                            childReq.getCertificateFile(),
                            childReq.getCertificateFileName()
                    );

                    DocumentDTO dto = new DocumentDTO();
                    dto.setEmpCode(request.getEmpCode());

                    certificateDocId = documentOperations
                            .uploadDocument(dto, certificateFile)
                            .get(0)
                            .getDocId();
                }

                ScholarshipChild child = ScholarshipChild.builder()
                        .title(childReq.getTitle())
                        .studentName(childReq.getStudentName())
                        .academicYear(childReq.getAcademicYear())
                        .marksPercentage(childReq.getMarksPercentage())
                        .createdDate(LocalDate.now())
                        .percentile(childReq.getPercentile())
                        .rankObtained(childReq.getRankObtained())
                        .schoolName(childReq.getSchoolName())
                        .photoDocId(photoDocId)
                        .certificateDocId(certificateDocId)
                        .scholarship(scholarship)
                        .build();

                children.add(child);
            }
        }

        scholarship.setChildren(children);
        Scholarship saved = scholarshipRepository.save(scholarship);
        return scholarshipMapper.toResponse(saved);
    }

    @Override
    public List<ScholarshipDto.Response> getByYear(
            String awardYear) {

        return scholarshipRepository
                .findByAwardYear(awardYear)
                .stream()
                .map(scholarshipMapper::toResponse)
                .toList();
    }

    @Override
    public List<ScholarshipDto.Response> getByType(
            String scholarshipType) {

        return scholarshipRepository
                .findByScholarshipType(
                        ScholarshipType.valueOf(
                                scholarshipType))
                .stream()
                .map(scholarshipMapper::toResponse)
                .toList();
    }

    @Override
    public List<ScholarshipDto.Response> getByYearAndType(
            String awardYear,
            String scholarshipType) {

        return scholarshipRepository
                .findByAwardYearAndScholarshipType(
                        awardYear,
                        ScholarshipType.valueOf(
                                scholarshipType))
                .stream()
                .map(scholarshipMapper::toResponse)
                .toList();
    }
}