package com.cms.cdl.service;


import com.cms.cdl.dto.honorClub.ScholarshipDto;

import java.io.IOException;
import java.util.List;

public interface ScholarshipService {

    ScholarshipDto.Response saveScholarship(
            ScholarshipDto.Request request)
            throws IOException;

    List<ScholarshipDto.Response> getByYear(
            String awardYear);

    List<ScholarshipDto.Response> getByType(
            String scholarshipType);

    List<ScholarshipDto.Response> getByYearAndType(
            String awardYear,
            String scholarshipType);
}