package com.cms.cdl.entity;

import com.cms.cdl.Enum.ScholarshipType;
import jakarta.persistence.*;
import lombok.*;
import org.springframework.data.annotation.CreatedDate;

import java.time.LocalDate;
import java.util.List;

@Entity
@Table(name = "scholarship")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Scholarship  {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String awardYear;

    @Enumerated(EnumType.STRING)
    private ScholarshipType scholarshipType;

    private String empCode;

    private String employeeName;

    private String department;

    private String subDepartment;

    private String location;

    private String project;

    private String r1ECode;

    private String r1Name;

    private String buHeadName;

    private Boolean published;
    private Boolean selected;
    @CreatedDate
    @Column(name = "created_date", updatable = false)
    private LocalDate createdDate;

    @OneToMany(
            mappedBy = "scholarship",
            cascade = CascadeType.ALL,
            orphanRemoval = true)
    private List<ScholarshipChild> children;
}