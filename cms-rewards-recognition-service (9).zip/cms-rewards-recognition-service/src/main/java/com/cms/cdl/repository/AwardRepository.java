package com.cms.cdl.repository;

import com.cms.cdl.entity.Award;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface AwardRepository extends JpaRepository<Award, Long> {
    Optional<Award> findByAwardTitle(String awardTitle);
    List<Award> findByIsOpenForNominationTrue();
}
