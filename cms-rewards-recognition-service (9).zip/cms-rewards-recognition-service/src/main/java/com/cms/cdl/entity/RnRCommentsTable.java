package com.cms.cdl.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class RnRCommentsTable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long commentId;

    private Long recognitionId;

    private Long nominationDetailId;

    private Long honorClubId;

    private Long scholarshipChildId;

    private String empCode;
    private String comments;
    private String commentDateTime;
    private String employeeName;
    private String department;
    private String emailId;
}

