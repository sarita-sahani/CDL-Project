package com.cms.cdl.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.*;
import org.antlr.v4.runtime.misc.NotNull;

import java.time.LocalDate;

@Getter
@Setter
public class RecognitionRequestDTO {

    @NotBlank
    private String empCode;

    @NotBlank
    private String employeeName;

    @NotNull
    private Long categoryId;

    @NotNull
    private Long templateId;

    private String comment;
    private String createdDate;
    private String categoryName;
    private String recognitionType;
    private String recognitionMode;
    private String certificateType;
    private Double voucherValue;
    private String voucherCode;
    private String voucherNumber;
    private LocalDate voucherExpiryDate;
    private Long voucherSerialNum;
    private Long docId;

}
