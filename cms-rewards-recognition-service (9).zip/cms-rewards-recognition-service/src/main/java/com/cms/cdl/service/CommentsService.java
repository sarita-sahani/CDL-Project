package com.cms.cdl.service;


import com.cms.cdl.entity.RnRCommentsTable;
import com.cms.cdl.Enum.InteractionType;

import java.util.List;
import java.util.concurrent.ExecutionException;

public interface CommentsService {

    RnRCommentsTable addComment(String empCode, Long id, String comments, InteractionType type)
            throws ExecutionException, InterruptedException;

    List<RnRCommentsTable> getAllRnRComments(Long id, InteractionType type);
}
