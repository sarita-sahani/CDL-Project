package com.cms.cdl.mapper;

public class RecognitionMapper {
}
