package com.cms.cdl.dto.executiveCircleDto;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AwardDTO {
    private Long id;
    private String awardTitle;
    private String noOfAwards;
    private String category;
    private String criteria;
    private String whoCanNominate;
    private boolean isOpenForNomination;
    private int maxNominations;
}
