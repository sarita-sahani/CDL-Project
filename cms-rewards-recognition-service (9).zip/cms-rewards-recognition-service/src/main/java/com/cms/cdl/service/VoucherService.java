package com.cms.cdl.service;

import com.cms.cdl.beans.file_bean.FileAndContentTypeBean;
import com.cms.cdl.dto.VoucherDto;
import com.cms.cdl.entity.Voucher;
import jakarta.transaction.Transactional;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;

public interface VoucherService {
    List<VoucherDto> getAllVouchers();
    VoucherDto addVoucher(VoucherDto voucherDto);
    List<VoucherDto> addBulkVouchers(List<VoucherDto> voucherDtos);

    // Returns a map like: { 500.0: 12, 1000.0: 5, 1500.0: 2 }
    Map<Double, Long> getActiveVoucherCounts();

    // ✅ UPDATE
    VoucherDto updateVoucher(Long id, VoucherDto dto);

    // ✅ DELETE
    void deleteVoucher(Long id);

    // Call this method from your RecognitionService when saving a Bravo recognition
    @Transactional
    Voucher assignVoucher(Double value, String usedBy, String managerName, String department);

    Voucher getNextAvailableVoucherPreview(Double value);


}
