package com.cms.cdl.dto.user_dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class ExperienceResDTO {
    private long experienceId;
    private String experience;
    private String companyName;
    private String companyAddress;
    private LocalDate dateOfJoining;
    private LocalDate dateOfReliving;
    private String jobTitle;
    private String certification;
}
