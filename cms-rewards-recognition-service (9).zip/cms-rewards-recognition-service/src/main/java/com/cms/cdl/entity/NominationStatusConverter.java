package com.cms.cdl.entity;

import jakarta.persistence.AttributeConverter;
import jakarta.persistence.Converter;

@Converter(autoApply = true)
public class NominationStatusConverter implements AttributeConverter<Nomination.NominationStatus, String> {

    @Override
    public String convertToDatabaseColumn(Nomination.NominationStatus status) {
        return status == null ? null : status.getDisplayValue();
    }

    @Override
    public Nomination.NominationStatus convertToEntityAttribute(String dbValue) {
        if (dbValue == null) return null;
        for (Nomination.NominationStatus s : Nomination.NominationStatus.values()) {
            if (s.getDisplayValue().equals(dbValue)) return s;
        }
        throw new IllegalArgumentException("Unknown status: " + dbValue);
    }
}
