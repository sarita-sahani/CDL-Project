package com.cms.cdl.utils;


import com.cms.cdl.beans.emp_bean.FileAndObjectTypeBean;
import com.cms.cdl.beans.emp_user_bean.EmpAndUserResponse;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.ExchangeStrategies;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.time.Duration;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

@Component("employeeOperations")
public class EmployeeOperations {

    private ResponseEntity responseEntity;

    @Value("${employee.fetch.by.email.API}")
    private String fetchEmpByEmail;

    @Value("${employee.fetch.by.empCode.API}")
    private String fetchEmpByEmpCode;


    @Value("${employee.search.API}")
    private String empSearchAPI;
    @Value("${employee.team.hierarchy.API}")
    private String empTeamHierarchy;

    public EmpAndUserResponse getEmpByEmailId(String emailId){
        WebClient webClient = WebClient.create();

        Mono<EmpAndUserResponse> response = webClient.get()
                .uri(fetchEmpByEmail+emailId)
                .accept(MediaType.APPLICATION_JSON)
                .retrieve()
                .bodyToMono(new ParameterizedTypeReference<EmpAndUserResponse>() {});

        EmpAndUserResponse empAndUserResponse = response.block();

        if(empAndUserResponse != null){
            return empAndUserResponse;
        }
        else {
            return null;
        }
    }

    public EmpAndUserResponse getEmpByEmpCode(String empCode) throws ExecutionException, InterruptedException {
        return fetchEmpByEmpCode(empCode).get();
    }


    public CompletableFuture<EmpAndUserResponse> fetchEmpByEmpCode(String empCode){
        WebClient webClient = WebClient.builder()
                .exchangeStrategies(ExchangeStrategies.builder()
                        .codecs(configurer -> configurer.defaultCodecs().maxInMemorySize(16 * 1024 * 1024))
                        .build())
                .build();
        System.out.println(empCode);
        return webClient.get()
                .uri(fetchEmpByEmpCode + empCode)
                .retrieve()
                .bodyToMono(EmpAndUserResponse.class)
                .timeout(Duration.ofSeconds(120))
                .toFuture();
    }

    public List<FileAndObjectTypeBean> searchEmployee(String searchValue) {
        WebClient webClient = WebClient.builder()
                .exchangeStrategies(ExchangeStrategies.builder()
                        .codecs(configurer -> configurer.defaultCodecs().maxInMemorySize(16 * 1024 * 1024))
                        .build())
                .build();

        Mono<List<FileAndObjectTypeBean>> response = webClient.get()
                .uri(empSearchAPI+searchValue)
                .accept(MediaType.APPLICATION_JSON)
                .retrieve()
                .bodyToMono(new ParameterizedTypeReference<List<FileAndObjectTypeBean>>() {});

        return response.block();
    }

//    public List<Map<String, Object>> fetchEmployeeTeamData(String empCode) {
//        WebClient webClient = WebClient.builder()
//                .exchangeStrategies(ExchangeStrategies.builder()
//                        .codecs(configurer ->
//                                configurer.defaultCodecs().maxInMemorySize(16 * 1024 * 1024))
//                        .build())
//                .build();
//
//        Mono<List<Map<String, Object>>> response = webClient.get()
//                .uri(empTeamHierarchy + empCode)
//                .accept(MediaType.APPLICATION_JSON)
//                .retrieve()
//                .bodyToMono(new ParameterizedTypeReference<List<Map<String, Object>>>() {});
//
//        return response.block();
//    }

    public Map<String, Object> fetchEmployeeTeamData(String empCode) {
        WebClient webClient = WebClient.builder()
                .exchangeStrategies(ExchangeStrategies.builder()
                        .codecs(configurer ->
                                configurer.defaultCodecs().maxInMemorySize(16 * 1024 * 1024))
                        .build())
                .build();

        Mono<Map<String, Object>> response = webClient.get()
                .uri(empTeamHierarchy + empCode)
                .accept(MediaType.APPLICATION_JSON)
                .retrieve()
                .bodyToMono(new ParameterizedTypeReference<Map<String, Object>>() {});

        return response.block();
    }

}
