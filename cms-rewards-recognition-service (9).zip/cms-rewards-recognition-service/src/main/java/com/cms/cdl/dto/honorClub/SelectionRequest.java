package com.cms.cdl.dto.honorClub;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SelectionRequest {

    private Boolean selected;
}
