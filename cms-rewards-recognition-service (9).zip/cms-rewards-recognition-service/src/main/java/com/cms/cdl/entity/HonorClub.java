package com.cms.cdl.entity;


import com.cms.cdl.Enum.HonorClubType;
import jakarta.persistence.*;
import jakarta.persistence.Table;
import lombok.Data;
import lombok.*;
import org.springframework.data.annotation.CreatedDate;

import java.time.LocalDate;

@Entity
@Table(name = "honor_club")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class HonorClub {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String awardYear;

    @Enumerated(EnumType.STRING)
    private HonorClubType honorClubType;

    private String empCode;

    private String employeeName;

    private String department;

    private Long docId;

    private Boolean published;
    private Boolean selected;
    @CreatedDate
    @Column(name = "created_date", updatable = false)
    private LocalDate createdDate;
}