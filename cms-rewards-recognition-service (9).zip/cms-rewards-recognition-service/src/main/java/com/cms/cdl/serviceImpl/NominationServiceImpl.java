package com.cms.cdl.serviceImpl;

import com.cms.cdl.dto.executiveCircleDto.NominationDTO;
import com.cms.cdl.dto.executiveCircleDto.NominationDetailDTO;
import com.cms.cdl.dto.executiveCircleDto.NominationSummaryDTO;
import com.cms.cdl.dto.executiveCircleDto.NomineeRow;
import com.cms.cdl.entity.Award;
import com.cms.cdl.entity.Nomination;
import com.cms.cdl.entity.NominationDetail;
import com.cms.cdl.exception.ResourceNotFoundException;
import com.cms.cdl.mapper.NominationMapper;
import com.cms.cdl.repository.AwardRepository;
import com.cms.cdl.repository.NominationRepository;
import com.cms.cdl.service.MailService;
import com.cms.cdl.service.NominationService;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Transactional
public class NominationServiceImpl implements NominationService {

    private final NominationRepository nominationRepository;
    private final AwardRepository      awardRepository;
    private final NominationMapper     nominationMapper;
    private final MailService mailService;

    // ── Save / Update ──────────────────────────────────────────────────────────

    @Override
    public NominationDTO saveOrUpdateNomination(NominationDTO dto) {

        Award award = awardRepository.findById(dto.getAwardId())
                .orElseThrow(() -> new EntityNotFoundException("Award not found: " + dto.getAwardId()));

        Nomination nomination = nominationRepository
                .findByAwardIdAndSubmittedByEmployeeCodeAndFinancialYear(
                        dto.getAwardId(),
                        dto.getSubmittedByEmployeeCode(),
                        dto.getFinancialYear())
                .orElseGet(() -> Nomination.builder()
                        .award(award)
                        .financialYear(dto.getFinancialYear())
                        .submittedByEmployeeCode(dto.getSubmittedByEmployeeCode())
                        .submittedByName(dto.getSubmittedByName())
                        .submittedByEmailId(dto.getSubmittedByEmailId())
                        .isNominating(false)
                        .status(Nomination.NominationStatus.DRAFT)
                        .nominationDetails(new ArrayList<>())
                        .build());

        nomination.setNominating(dto.isNominating());
        nomination.setStatus(Nomination.NominationStatus.DRAFT);
        nomination.getNominationDetails().clear();

        if (dto.isNominating() && dto.getNominationDetails() != null) {

            // ── Collect nominee codes being submitted RIGHT NOW ──────────────────
            List<String> incomingCodes = dto.getNominationDetails().stream()
                    .filter(d -> d.getNomineeEmployeeCode() != null
                            && !d.getNomineeEmployeeCode().isBlank())
                    .map(NominationDetailDTO::getNomineeEmployeeCode)
                    .toList();

            // ── Check duplicates WITHIN this submission (same person twice) ──────
            Set<String> seen = new HashSet<>();
            for (String code : incomingCodes) {
                if (!seen.add(code)) {
                    throw new IllegalArgumentException(
                            "Duplicate nominee in submission: employee code " + code
                                    + " appears more than once.");
                }
            }

            // ── Check against OTHER nominators for same award + FY ───────────────
            // i.e. has this nominee already been nominated by someone else?
            List<String> alreadyNominatedCodes =
                    nominationRepository.findNomineeCodesByAwardAndFY(
                            dto.getAwardId(),
                            dto.getFinancialYear(),
                            dto.getSubmittedByEmployeeCode()); // exclude current nominator's own rows

            List<String> conflicts = incomingCodes.stream()
                    .filter(alreadyNominatedCodes::contains)
                    .toList();

            if (!conflicts.isEmpty()) {
                // Fetch names for a friendly message
                String conflictNames = dto.getNominationDetails().stream()
                        .filter(d -> conflicts.contains(d.getNomineeEmployeeCode()))
                        .map(NominationDetailDTO::getNomineeName)
                        .collect(Collectors.joining(", "));
                throw new IllegalArgumentException(
                        "The following employee(s) have already been nominated for this award: "
                                + conflictNames);
            }

            // ── Persist details ──────────────────────────────────────────────────
            for (NominationDetailDTO detailDTO : dto.getNominationDetails()) {
                if (detailDTO.getNomineeName() != null && !detailDTO.getNomineeName().isBlank()) {
                    NominationDetail detail = nominationMapper.toDetailEntity(detailDTO, nomination);
                    nomination.getNominationDetails().add(detail);
                }
            }
        }

        NominationDTO saved = nominationMapper.toDTO(nominationRepository.save(nomination));

        // ── Send mail ────────────────────────────────────────────────────────────
        if (dto.isNominating() && dto.getNominationDetails() != null) {
            for (NominationDetailDTO detailDTO : dto.getNominationDetails()) {
                if (detailDTO.getNomineeEmailId() != null && !detailDTO.getNomineeEmailId().isBlank()
                        && detailDTO.getNomineeName() != null && !detailDTO.getNomineeName().isBlank()) {
                    mailService.sendNominationNotificationMail(
                            detailDTO.getNomineeEmailId(),
                            detailDTO.getNomineeName(),
                            dto.getSubmittedByName(),
                            award.getAwardTitle(),
                            award.getCategory(),
                            award.getCriteria(),
                            dto.getFinancialYear()
                    );
                }
            }
        }

        return saved;
    }

    // ── NEW: preview ──────────────────────────────────────────────────────────
    @Override
    @Transactional(readOnly = true)
    public List<NominationDTO> getNominationsForPreview(String employeeCode,
                                                        String financialYear) {
        List<Nomination> nominations =
                nominationRepository.findBySubmittedByEmployeeCodeAndFinancialYear(
                        employeeCode, financialYear);

        return nominations.stream()
                .map(nom -> {
                    NominationDTO dto = nominationMapper.toDTO(nom);
                    // Populate the extra display fields for the preview card
                    dto.setAwardTitle(nom.getAward().getAwardTitle());
                    dto.setAwardCategory(nom.getAward().getCategory());
                    return dto;
                })
                .collect(Collectors.toList());
    }

    // ── NEW: submit all drafts to HR ──────────────────────────────────────────
    @Override
    @Transactional
    public List<NominationDTO> submitNominationsToHR(String employeeCode, String financialYear) {

        List<Nomination> drafts =
                nominationRepository
                        .findBySubmittedByEmployeeCodeAndFinancialYearAndIsNominatingTrueAndStatus(
                                employeeCode, financialYear, Nomination.NominationStatus.DRAFT);

        if (drafts.isEmpty()) {
            throw new IllegalStateException(
                    "No draft nominations found to submit for employee: " + employeeCode);
        }

        // ── 1. Flip status to SUBMITTED ───────────────────────────────────────
        drafts.forEach(n -> n.setStatus(Nomination.NominationStatus.SUBMITTED_TO_HR));
        List<Nomination> saved = nominationRepository.saveAll(drafts);

        // ── 2. Send one consolidated mail to HR ───────────────────────────────
        // Build a single summary of all awards + nominees
        String nominatorName = drafts.get(0).getSubmittedByName();
        String nominatorCode = drafts.get(0).getSubmittedByEmployeeCode();
        String nominatorEmail = drafts.get(0).getSubmittedByEmailId();

        // Collect all nominees across all awards for the HR summary mail
        List<NomineeRow> allNominees = drafts.stream()
                .flatMap(n -> n.getNominationDetails().stream()
                        .map(d -> new NomineeRow(
                                n.getAward().getAwardTitle(),
                                n.getAward().getCategory(),
                                d.getNomineeName(),
                                d.getNomineeEmployeeCode(),
                                d.getDepartment(),
                                d.getNomineeDesignation(),
                                d.getReasonForNomination())))
                .collect(Collectors.toList());

        mailService.sendHRSubmissionMail(
                nominatorName,
                nominatorCode,
                nominatorEmail,
                financialYear,
                allNominees         // pass to your mail builder
        );

        // ── 3. Return updated DTOs ────────────────────────────────────────────
        return saved.stream()
                .map(n -> {
                    NominationDTO dto = nominationMapper.toDTO(n);
                    dto.setAwardTitle(n.getAward().getAwardTitle());
                    dto.setAwardCategory(n.getAward().getCategory());
                    return dto;
                })
                .collect(Collectors.toList());
    }

    // ── Read ───────────────────────────────────────────────────────────────────

    @Override
    @Transactional(readOnly = true)
    public NominationDTO getNominationById(Long id) {
        return nominationMapper.toDTO(
                nominationRepository.findById(id)
                        .orElseThrow(() -> new EntityNotFoundException("Nomination not found: " + id)));
    }

    @Override
    @Transactional(readOnly = true)
    public NominationDTO getNominationByAwardAndEmployee(Long awardId,
                                                         String employeeCode,
                                                         String financialYear) {
        return nominationRepository
                .findByAwardIdAndSubmittedByEmployeeCodeAndFinancialYear(awardId, employeeCode, financialYear)
                .map(nominationMapper::toDTO)
                .orElse(null);
    }

    @Override
    @Transactional(readOnly = true)
    public List<NominationDTO> getNominationsByEmployee(String employeeCode, String financialYear) {
        return nominationRepository.findByEmployeeAndFinancialYear(employeeCode, financialYear)
                .stream()
                .map(nominationMapper::toDTO)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<NominationSummaryDTO> getExecutiveCircleDetails(
            String financialYear, List<String> status, String managerEmpCode) {

        List<Nomination> nominations =
                nominationRepository.findAllWithDetailsByFinancialYear(financialYear);

        if (status != null && !status.isEmpty()) {
            nominations = nominations.stream()
                    .filter(n -> n.getStatus() != null)
                    .filter(n -> status.stream().anyMatch(s -> {
                        String enumName = n.getStatus().name();
                        String display = n.getStatus().getDisplayValue();
                        return enumName.equalsIgnoreCase(s) || display.equalsIgnoreCase(s);
                    }))
                    .collect(Collectors.toList());
        }

        if (managerEmpCode != null && !managerEmpCode.isEmpty()) {
            nominations = nominations.stream()
                    .filter(n -> n.getSubmittedByEmployeeCode() != null)
                    .filter(n -> n.getSubmittedByEmployeeCode()
                            .equalsIgnoreCase(managerEmpCode))
                    .collect(Collectors.toList());
        }

        return nominations.stream()
                .map(nominationMapper::toSummaryDTO)
                .collect(Collectors.toList());
}


    // ── Submit ─────────────────────────────────────────────────────────────────

    /**
     * Single-nomination submit (used internally and by the individual endpoint).
     */
    @Override
    public NominationDTO submitNomination(Long id) {
        Nomination nomination = nominationRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Nomination not found: " + id));
        nomination.setStatus(Nomination.NominationStatus.SUBMITTED_TO_HR);
        return nominationMapper.toDTO(nominationRepository.save(nomination));
    }

    /**
     * Submit ALL nominations for an employee in a given FY.
     *
     * Validation rules:
     *  1. Every award that is open for nomination MUST have a saved nomination record.
     *  2. If isNominating = true, at least 1 detail with a non-blank nomineeName
     *     AND a non-blank reasonForNomination must exist.
     *  3. If isNominating = false, that is a valid explicit "No" — allowed.
     *
     * Throws IllegalStateException with a user-friendly message listing
     * the award title(s) that are incomplete.
     */
    @Override
    public List<NominationDTO> submitAllNominations(String employeeCode, String financialYear) {

        // 1. All open-for-nomination awards
        List<Award> openAwards = awardRepository.findByIsOpenForNominationTrue();

        // 2. All existing nominations by this employee for this FY
        List<Nomination> saved = nominationRepository.findByEmployeeAndFinancialYear(employeeCode, financialYear);
        Map<Long, Nomination> byAwardId = saved.stream()
                .collect(Collectors.toMap(n -> n.getAward().getId(), n -> n));

        // 3. Validate each open award
        List<String> incomplete = new ArrayList<>();

        for (Award award : openAwards) {
            Nomination nom = byAwardId.get(award.getId());

            if (nom == null) {
                // No record at all — user has not touched this award
                incomplete.add(award.getAwardTitle());
                continue;
            }

            if (nom.isNominating()) {
                // Must have at least one detail with name + reason
                boolean hasValidDetail = nom.getNominationDetails().stream().anyMatch(d ->
                        d.getNomineeName()          != null && !d.getNomineeName().isBlank() &&
                        d.getReasonForNomination()  != null && !d.getReasonForNomination().isBlank());

                if (!hasValidDetail) {
                    incomplete.add(award.getAwardTitle());
                }
            }
            // isNominating = false → explicitly declined → valid, no check needed
        }

        if (!incomplete.isEmpty()) {
            throw new IllegalStateException(
                    "Error! You have not filled required field in one or more category: "
                    + String.join(", ", incomplete));
        }

        // 4. All valid — mark every DRAFT as SUBMITTED
        List<NominationDTO> submitted = new ArrayList<>();
        for (Nomination nom : saved) {
            if (nom.getStatus() == Nomination.NominationStatus.DRAFT) {
                nom.setStatus(Nomination.NominationStatus.SUBMITTED_TO_HR);
                submitted.add(nominationMapper.toDTO(nominationRepository.save(nom)));
            }
        }
        return submitted;
    }

    // ── Delete ─────────────────────────────────────────────────────────────────

    @Override
    public void deleteNomination(Long id) {
        nominationRepository.deleteById(id);
    }

    @Override
    @Transactional
    public Nomination reviewNomination(Long nominationId, String status, String hrRemarks) {
        Nomination nomination = nominationRepository.findById(nominationId)
                .orElseThrow(() -> new ResourceNotFoundException("Nomination not found with id: " + nominationId));

        // Validate status
        if (!"APPROVED".equalsIgnoreCase(status) && !"REJECTED".equalsIgnoreCase(status)) {
            throw new IllegalArgumentException("Invalid status. Only APPROVED or REJECTED allowed.");
        }

        // Convert to enum
        Nomination.NominationStatus newStatus = Nomination.NominationStatus.valueOf(status.toUpperCase());
        nomination.setStatus(newStatus);
        nomination.setHrRemarks(hrRemarks);

        return nominationRepository.save(nomination);
    }
}
