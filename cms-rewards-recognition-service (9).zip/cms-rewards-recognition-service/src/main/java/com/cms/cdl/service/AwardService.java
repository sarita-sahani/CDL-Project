package com.cms.cdl.service;


import com.cms.cdl.dto.executiveCircleDto.AwardDTO;
import com.cms.cdl.dto.executiveCircleDto.AwardEligibilityRequestDTO;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public interface AwardService {
    List<AwardDTO> getAllAwards();


    @Transactional(readOnly = true)
    List<AwardDTO> getAwardsForUser(String empCode, List<String> roles);

    AwardDTO getAwardById(Long id);
    AwardDTO createAward(AwardDTO awardDTO);
    AwardDTO updateAward(Long id, AwardDTO awardDTO);

    @Transactional
    void removeEligibility(Long id);

    List<AwardDTO> getOpenNominationAwards();

    @Transactional
    void assignEligibility(AwardEligibilityRequestDTO request);

    boolean isEmployeeEligibleForAnyAward(String empCode);

    @Transactional(readOnly = true)
    List<AwardEligibilityRequestDTO>
    getEligibilityByAward(Long awardId);
}
