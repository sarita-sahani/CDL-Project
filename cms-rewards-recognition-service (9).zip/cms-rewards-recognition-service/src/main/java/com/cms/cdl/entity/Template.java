package com.cms.cdl.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name="template")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Template {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String templateName;

    private String templateDescription;

    @Column(name="category_id")
    private Long categoryId;
}