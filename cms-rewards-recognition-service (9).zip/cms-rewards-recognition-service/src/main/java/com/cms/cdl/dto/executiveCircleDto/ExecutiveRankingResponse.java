package com.cms.cdl.dto.executiveCircleDto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ExecutiveRankingResponse {

    private Long nominationDetailId;

    private String nomineeName;

    private String department;

    private Integer rankPosition;
    private  String rankReason;
}