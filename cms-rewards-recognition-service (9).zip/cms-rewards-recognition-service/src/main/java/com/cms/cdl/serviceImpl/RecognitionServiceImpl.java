package com.cms.cdl.serviceImpl;

import com.cms.cdl.beans.emp_bean.FileAndObjectTypeBean;
import com.cms.cdl.beans.emp_user_bean.EmpAndUserResponse;
import com.cms.cdl.common_dtos.dto.document_dto.DocumentDTO;
import com.cms.cdl.common_dtos.util.dms.DocumentOperations;
import com.cms.cdl.dto.RecognitionResponseDTO;
import com.cms.cdl.dto.VoucherEligibilityDTO;
import com.cms.cdl.entity.*;
import com.cms.cdl.repository.*;
import com.cms.cdl.service.MailService;
import com.cms.cdl.service.RecognitionService;
import com.cms.cdl.service.VoucherService;
import com.cms.cdl.utils.CertificateGenerator;
import com.cms.cdl.utils.CustomMultipartFile;
import com.cms.cdl.utils.EmployeeOperations;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.nio.file.Files;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class RecognitionServiceImpl implements RecognitionService {

    private final RecognitionRepository recognitionRepository;
    private final CategoryRepository categoryRepository;
    private final TemplateRepository templateRepository;
    private final EmployeeOperations employeeOperations;
    private final TemplateImageRepository templateImageRepository;

    @Autowired
    private RecognitionLikeRepository recognitionLikeRepository;

    @Autowired
    private CommentsRepository recognitionCommentRepository;

    @Autowired
    private VoucherService voucherService;

    @Autowired
    private MailService mailService;

    @Autowired
    private CertificateGenerator certificateGenerator;
    @Autowired
    DocumentOperations documentOperations;

    @Override
    public EmpAndUserResponse getEmpInfoByEmpCode(String empCode) throws ExecutionException, InterruptedException {
        return employeeOperations.getEmpByEmpCode(empCode);
    }

    @Override
    public List<FileAndObjectTypeBean> searchEmployee(String searchValue) {
        return employeeOperations.searchEmployee(searchValue); // ✅ just calling
    }

    @Override
    public Map<String, Object> fetchEmployeeTeamData(String empCode) {
        return employeeOperations.fetchEmployeeTeamData(empCode);
    }


    @Override
    public List<Category> getCategoriesByRecognitionType(Long recognitionTypeId) {
        return categoryRepository.findByRecognitionTypeId(recognitionTypeId);
    }

    @Override
    public Category getcategoriesname(Long categoryId) {
        return categoryRepository.findCategoryNameById(categoryId);
    }

    @Override
    public List<Template> getTemplatesByCategory(Long categoryId) {
        return templateRepository.findByCategoryId(categoryId);
    }

    @Override
    public Template getTemplateDescription(Long templateId) {
        return templateRepository.findById(templateId).orElse(null);
    }

    @Override
    public List<TemplateImage> getImagesByTemplate(Long templateId) {
        return templateImageRepository.findByTemplateId(templateId);
    }

    @Override
    @Transactional
    public Recognition saveRecognitionsData(Recognition request, MultipartFile multipartFile) throws Exception {

        // ✅ Safe log
        if (multipartFile != null && !multipartFile.isEmpty()) {
            System.out.println("Uploaded File: " + multipartFile.getOriginalFilename());
        }

        request.setCreatedDate(LocalDateTime.now());
        request.setQuarter(getCurrentQuarter());
        request.setFinancialYear(getFinancialYear());

        Voucher assignedVoucher = null;

        // ================= BRAVO =================
        if ("BRAVO".equalsIgnoreCase(request.getRecognitionType())) {

            if ("ecard".equalsIgnoreCase(request.getRecognitionMode())) {
                request.setCertificateType(null);
                request.setVoucherValue(null);
            }

            if ("ecertificate".equalsIgnoreCase(request.getRecognitionMode())) {
                if ("withoutVoucher".equalsIgnoreCase(request.getCertificateType())) {
                    request.setVoucherValue(null);
                }
            }

            if (request.getVoucherValue() != null && request.getVoucherValue() > 0) {
                assignedVoucher = voucherService.assignVoucher(
                        request.getVoucherValue(),
                        request.getEmployeeName(),
                        request.getRecognizedByName(),
                        request.getNomineeDepartment()
                );
            }

            if (assignedVoucher != null) {
                request.setVoucherCode(assignedVoucher.getVoucherCode());
                request.setVoucherNumber(assignedVoucher.getVoucherNumber());
                request.setVoucherExpiryDate(assignedVoucher.getExpiryDate());
                request.setVoucherSerialNum(assignedVoucher.getId());
                request.setVoucherCompany(assignedVoucher.getVoucherCompany());
            }
        }

        // ================= HATSOFF =================
        if ("WORLDOFTHANKS".equalsIgnoreCase(request.getRecognitionType())) {
            request.setRecognitionMode("ecard");
            request.setCertificateType(null);
            request.setVoucherValue(null);
        }

        MultipartFile finalFile = null;

// ================= CASE 1: E-CERTIFICATE =================
        Recognition savedRecognition = null; // declare at top

// ================= CASE 1: E-CERTIFICATE =================
        if ("ecertificate".equalsIgnoreCase(request.getRecognitionMode())) {
            if ("withoutVoucher".equalsIgnoreCase(request.getCertificateType())) {
                request.setVoucherValue(0.0);
                request.setVoucherCode(null);
            }

            savedRecognition = recognitionRepository.save(request); // first and only save

            Long serialForGenerator = (assignedVoucher != null)
                    ? assignedVoucher.getId()
                    : savedRecognition.getId();

            Map<String, File> files = certificateGenerator.generateCertificateFiles(
                    request.getTemplateImageUrl(),
                    request.getEmployeeName(),
                    request.getRecognizedByName(),
                    assignedVoucher,
                    serialForGenerator
            );
            File generatedFile = files.get("JPG");
            finalFile = new CustomMultipartFile(generatedFile, "image/jpeg");
        }

        // ================= CASE 2: E-CARD — overlay names on the card image =================
        else if ("ecard".equalsIgnoreCase(request.getRecognitionMode())) {

            Map<String, File> files = certificateGenerator.generateCertificateFiles(
                    request.getTemplateImageUrl(),   // the selected card template
                    request.getEmployeeName(),        // nominee name
                    request.getRecognizedByName(),    // nominator name
                    null,                             // no voucher for ecard
                    null                              // no serial number
            );

            File generatedFile = files.get("JPG");
            finalFile = new CustomMultipartFile(generatedFile, "image/jpeg");
        }

// ================= CASE 3: FRONTEND IMAGE (E-CARD / HATSOFF) =================
        else if (multipartFile != null && !multipartFile.isEmpty()) {

            // ✅ USE uploaded file directly
            finalFile = multipartFile;
        }

// ================= CASE 4: FALLBACK (FROM TEMPLATE URL) =================
        else if (request.getTemplateImageUrl() != null) {

            String path = "static" + request.getTemplateImageUrl();
            ClassPathResource resource = new ClassPathResource(path);

            File file = resource.getFile();

            finalFile = new CustomMultipartFile(file, "image/jpeg");
        }

// ✅ CASE 2: E-CARD → already coming from frontend (multipartFile)
        // ================= UPLOAD TO DMS =================
        if (finalFile != null && !finalFile.isEmpty()) {
            DocumentDTO documentDTO = new DocumentDTO();
            documentDTO.setEmpCode(request.getEmpCode());
            Long docId = documentOperations.uploadDocument(documentDTO, finalFile)
                    .get(0).getDocId();
            request.setDocId(docId);
            // If already saved above (ecertificate case), update docId
            if (savedRecognition != null) {
                savedRecognition.setDocId(docId);
                savedRecognition = recognitionRepository.save(savedRecognition); // update with docId
            }
        }


        // ================= CASE 3: FALLBACK (FROM TEMPLATE URL) =================
        else if (request.getTemplateImageUrl() != null && !request.getTemplateImageUrl().isEmpty()) {

            // Ensure the path is formatted correctly
            String formattedPath = request.getTemplateImageUrl().startsWith("/")
                    ? request.getTemplateImageUrl()
                    : "/" + request.getTemplateImageUrl();
            String path = "static" + formattedPath;

            ClassPathResource resource = new ClassPathResource(path);

            // ✅ Read as an InputStream and copy to byte array (fixes JAR FileNotFoudException)
            final byte[] fileContent = org.springframework.util.StreamUtils.copyToByteArray(resource.getInputStream());

            // Create an in-memory MultipartFile
            finalFile = new org.springframework.web.multipart.MultipartFile() {
                @Override public String getName() { return "certificate"; }
                @Override public String getOriginalFilename() { return "template.jpg"; }
                @Override public String getContentType() { return "image/jpeg"; }
                @Override public boolean isEmpty() { return fileContent == null || fileContent.length == 0; }
                @Override public long getSize() { return fileContent.length; }
                @Override public byte[] getBytes() { return fileContent; }
                @Override public java.io.InputStream getInputStream() { return new java.io.ByteArrayInputStream(fileContent); }
                @Override public void transferTo(File dest) throws java.io.IOException, IllegalStateException {
                    java.nio.file.Files.write(dest.toPath(), fileContent);
                }
            };
        }

        if (savedRecognition == null) {
            savedRecognition = recognitionRepository.save(request);
        }


        // ================= SEND MAIL =================
        mailService.sendRecognitionMail(
                savedRecognition.getEmployeeEmail(),
                savedRecognition.getEmployeeName(),
                savedRecognition.getRecognizedByName(),
                savedRecognition.getRecognitionType(),
                savedRecognition.getComment(),
                finalFile,
                assignedVoucher
        );

        return savedRecognition;
    }

    @Override
    public Map<String, String> previewCertificate(Recognition request) throws Exception {

        Voucher previewVoucher = null;

        // Only fetch voucher preview for ecertificate with voucher
        if ("BRAVO".equalsIgnoreCase(request.getRecognitionType())
                && "ecertificate".equalsIgnoreCase(request.getRecognitionMode())
                && "withVoucher".equalsIgnoreCase(request.getCertificateType())
                && request.getVoucherValue() != null) {

            previewVoucher = voucherService.getNextAvailableVoucherPreview(
                    request.getVoucherValue()
            );
        }

        // For ecard: pass null voucher and null serial — only names will be printed
        // In previewCertificate:

        Voucher voucherForGenerator = null;
        if ("ecertificate".equalsIgnoreCase(request.getRecognitionMode())
                && "withVoucher".equalsIgnoreCase(request.getCertificateType())) {
            voucherForGenerator = previewVoucher;
        }
        Long serialNumber = (previewVoucher != null)
                ? previewVoucher.getId()
                : ("ecertificate".equalsIgnoreCase(request.getRecognitionMode())
                ? (request.getId() != null ? request.getId() : 0L)  // 0 for preview
                : null);

        Map<String, File> files = certificateGenerator.generateCertificateFiles(
                request.getTemplateImageUrl(),
                request.getEmployeeName(),
                request.getRecognizedByName(),
                voucherForGenerator,
                serialNumber
        );

        File jpgFile = files.get("JPG");

        String base64 = Base64.getEncoder().encodeToString(
                Files.readAllBytes(jpgFile.toPath())
        );

        Map<String, String> response = new HashMap<>();
        response.put("previewImage", base64);

        return response;
    }

//    @Override
//    public Page<Recognition> getAllDataByRecognitionType(String type, int page, int size) {
//
//        Pageable pageable = PageRequest.of(page, size, Sort.by("id").descending());
//
//        return recognitionRepository.findByRecognitionType(type, pageable);
//    }

    @Override
    public Page<RecognitionResponseDTO> getAllDataByRecognitionType(String type, int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by("id").descending());
        Page<Recognition> pageData = recognitionRepository.findByRecognitionType(type, pageable);

        // Map Recognition to RecognitionResponse DTO that includes counts
        List<RecognitionResponseDTO> content = pageData.stream()
                .map(recognition -> {
                    long likesCount = recognitionLikeRepository.countByRecognitionId(recognition.getId());
                    long commentsCount = recognitionCommentRepository.countByRecognitionId(recognition.getId());

                    return new RecognitionResponseDTO(recognition, likesCount, commentsCount);
                })
                .collect(Collectors.toList());

        return new PageImpl<>(content, pageable, pageData.getTotalElements());
    }

    @Override
    public Map<String, Object> getAllRecognitions(int page, int size) {

        Pageable pageable = PageRequest.of(page, size, Sort.by("createdDate").descending());

        Page<Recognition> worldOfThanksPage =
                recognitionRepository.findByRecognitionType("WORLDOFTHANKS", pageable);

        Page<Recognition> bravoPage =
                recognitionRepository.findByRecognitionType("BRAVO", pageable);

        Map<String, Object> result = new HashMap<>();

        result.put("worldofthanks", worldOfThanksPage.getContent());
        result.put("bravo", bravoPage.getContent());

        result.put("totalPages", Math.max(worldOfThanksPage.getTotalPages(), bravoPage.getTotalPages()));
        result.put("totalElements", worldOfThanksPage.getTotalElements() + bravoPage.getTotalElements());

        return result;
    }

    //fpr Voucher validation logic ///
    @Override
    public VoucherEligibilityDTO getVoucherEligibility(String managerCode) throws ExecutionException, InterruptedException {

        boolean isBuManager = isBuLevelManager(managerCode);

        int limit = isBuManager ? 2000 : 1000;

        String quarter = getCurrentQuarter();
        int year = LocalDate.now().getYear();

        Integer usedAmount = recognitionRepository.getUsedVoucherAmount(
                managerCode,
                quarter,
                year
        );

        int remaining = limit - usedAmount;

        List<Integer> allowedValues = new ArrayList<>();

        if (remaining >= 500) allowedValues.add(500);
        if (remaining >= 1000) allowedValues.add(1000);
        if (remaining >= 1500) allowedValues.add(1500);
        if (remaining >= 2000) allowedValues.add(2000);

        return new VoucherEligibilityDTO(
                isBuManager,
                limit,
                usedAmount,
                remaining,
                allowedValues
        );
    }

    @Override
    public void validateVoucherBeforeSubmit(String managerCode, Integer voucherValue) throws ExecutionException, InterruptedException {

        VoucherEligibilityDTO eligibility = getVoucherEligibility(managerCode);

        if (voucherValue > eligibility.getRemainingAmount()) {
            throw new RuntimeException(
                    "Voucher limit exceeded. Remaining quarterly balance is ₹"
                            + eligibility.getRemainingAmount()
            );
        }
    }


    private boolean isBuLevelManager(String managerCode) throws ExecutionException, InterruptedException {
        EmpAndUserResponse response = employeeOperations.getEmpByEmpCode(managerCode);

        if (response == null || response.getUserDTO() == null) {
            return false;
        }

        return response.getUserDTO()
                .getUserRoleDTOS()
                .stream()
                .anyMatch(role ->
                        role.getRoleDTO() != null &&
                                "BU Head".equalsIgnoreCase(role.getRoleDTO().getName())
                );

    }



    private String getCurrentQuarter() {
        int month = LocalDate.now().getMonthValue();

        if (month >= 1 && month <= 3) return "Q4";
        if (month >= 4 && month <= 6) return "Q1";
        if (month >= 7 && month <= 9) return "Q2";
        return "Q3";
    }

    private Integer getFinancialYear() {
        LocalDate today = LocalDate.now();
        int year = today.getYear();

        return today.getMonthValue() >= 4 ? year : year - 1;
    }


}