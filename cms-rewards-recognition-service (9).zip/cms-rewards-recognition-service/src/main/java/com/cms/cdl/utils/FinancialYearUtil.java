package com.cms.cdl.utils;

import org.springframework.stereotype.Component;

import java.time.LocalDate;

/**
 * Indian Financial Year: April 1 → March 31
 *
 * Examples (based on current date):
 *   May  2026  →  code="26-27",  label="2026-27"
 *   Jan  2026  →  code="25-26",  label="2025-26"
 */
@Component
public class FinancialYearUtil {

    /**
     * Returns FY in short format: "26-27"
     */
    public static String getCurrentFinancialYear() {
        LocalDate today = LocalDate.now();
        int year  = today.getYear();
        int month = today.getMonthValue();

        int startYear = (month >= 4) ? year : year - 1;
        int endYear   = startYear + 1;

        return twoDigit(startYear) + "-" + twoDigit(endYear);
    }

    /**
     * Returns FY in long format: "2026-27"
     */
    public static String getCurrentFinancialYearFull() {
        LocalDate today = LocalDate.now();
        int year  = today.getYear();
        int month = today.getMonthValue();

        int startYear = (month >= 4) ? year : year - 1;
        int endYear   = startYear + 1;

        return startYear + "-" + twoDigit(endYear);
    }

    private static String twoDigit(int year) {
        return String.valueOf(year).substring(2); // 2026 → "26"
    }
}
