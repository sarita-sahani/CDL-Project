package com.cms.cdl.repository;

import com.cms.cdl.entity.RnRLikesTable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface RecognitionLikeRepository extends JpaRepository<RnRLikesTable, Long> {


    long countByRecognitionId(Long recognitionId);

    List<RnRLikesTable> findByRecognitionId(Long id);

    List<RnRLikesTable> findByNominationDetailId(Long id);

    List<RnRLikesTable> findByHonorClubId(Long id);

    List<RnRLikesTable> findByScholarshipChildId(Long id);

    boolean existsByRecognitionIdAndEmpCode(Long id,String empCode);

    boolean existsByNominationDetailIdAndEmpCode(Long id,String empCode);

    boolean existsByHonorClubIdAndEmpCode(Long id,String empCode);

    boolean existsByScholarshipChildIdAndEmpCode(Long id,String empCode);

}