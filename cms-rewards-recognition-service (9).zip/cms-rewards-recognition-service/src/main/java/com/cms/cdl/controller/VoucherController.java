package com.cms.cdl.controller;

import com.cms.cdl.beans.file_bean.FileAndContentTypeBean;
import com.cms.cdl.dto.*;
import com.cms.cdl.service.VoucherService;
import org.springframework.beans.factory.annotation.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;
import java.util.concurrent.ExecutionException;

@CrossOrigin("*") // Adjust if your React runs on a different port
@RestController
@RequestMapping("/api/recognition")
public class VoucherController {

    @Autowired
    private VoucherService voucherService;


    // Fetch all vouchers to populate the table
    @GetMapping("/getAllVouchers")
    public ResponseEntity<List<VoucherDto>> getAllVouchers() {
        return ResponseEntity.ok(voucherService.getAllVouchers());
    }

    // Add a single voucher from the Modal form
    @PostMapping("/addVoucher")
    public ResponseEntity<VoucherDto> addVoucher(@RequestBody VoucherDto voucherDto) {
        VoucherDto savedVoucher = voucherService.addVoucher(voucherDto);
        return new ResponseEntity<>(savedVoucher, HttpStatus.CREATED);
    }

    // Bulk upload from Excel
    @PostMapping("/addBulkVouchers")
    public ResponseEntity<List<VoucherDto>> addBulkVouchers(@RequestBody List<VoucherDto> voucherDtos) {
        List<VoucherDto> savedVouchers = voucherService.addBulkVouchers(voucherDtos);
        return new ResponseEntity<>(savedVouchers, HttpStatus.CREATED);
    }

    @GetMapping("/vouchers/active-counts")
    public ResponseEntity<Map<Double, Long>> getActiveVoucherCounts() {
        return ResponseEntity.ok(voucherService.getActiveVoucherCounts());
    }

    // ✅ UPDATE Voucher
    @PutMapping("/updateVoucher/{id}")
    public ResponseEntity<VoucherDto> updateVoucher(
            @PathVariable Long id,
            @RequestBody VoucherDto voucherDto) {

        VoucherDto updatedVoucher = voucherService.updateVoucher(id, voucherDto);
        return ResponseEntity.ok(updatedVoucher);
    }

    // ✅ DELETE Voucher
    @DeleteMapping("/deleteVoucher/{id}")
    public ResponseEntity<String> deleteVoucher(@PathVariable Long id) {

        voucherService.deleteVoucher(id);
        return ResponseEntity.ok("Voucher deleted successfully");
    }


}
