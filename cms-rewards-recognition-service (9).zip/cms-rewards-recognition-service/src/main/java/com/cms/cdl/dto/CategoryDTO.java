package com.cms.cdl.dto;

public class CategoryDTO {
}
