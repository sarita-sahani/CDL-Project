package com.cms.cdl.Enum;

public enum ScholarshipType {

    CLASS_10,
    CLASS_12
}