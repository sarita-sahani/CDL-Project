package com.cms.cdl.repository;

import com.cms.cdl.entity.TemplateImage;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface TemplateImageRepository extends JpaRepository<TemplateImage, Long> {
    List<TemplateImage> findByTemplateId(Long templateId);
}
