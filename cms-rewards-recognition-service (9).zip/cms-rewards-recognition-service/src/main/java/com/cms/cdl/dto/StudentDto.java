package com.cms.cdl.dto;

import lombok.*;

@Getter
@Setter
public class StudentDto {

    private String title;

    private String studentName;

    private String academicYear;

    private Double marksPercentage;

    private Double percentile;

    private String rankObtained;

    private String schoolName;

    private Long photoDocId;

    private Long certificateDocId;
}