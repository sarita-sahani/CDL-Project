package com.cms.cdl.dto.executiveCircleDto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AwardEligibilityRequestDTO {

    private Long id;

    private Long awardId;

    private String awardTitle;

    private String empCode;

    private String empName;

    private String email;

    private String  role;

    private Boolean isActive;
}