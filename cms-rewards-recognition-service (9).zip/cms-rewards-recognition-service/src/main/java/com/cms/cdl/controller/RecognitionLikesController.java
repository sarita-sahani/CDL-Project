package com.cms.cdl.controller;

import com.cms.cdl.Enum.InteractionType;
import com.cms.cdl.entity.RnRLikesTable;
import com.cms.cdl.service.RecognitionLikeService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.concurrent.ExecutionException;


@RestController
@RequestMapping("/api/recognition")
@RequiredArgsConstructor
@CrossOrigin("*")
public class RecognitionLikesController {

    @Autowired
    RecognitionLikeService recognitionLikeService;
    // Bravo / World of Thanks — existing endpoint, isNomination = false
    @PostMapping("/like/{recognitionId}/{empCode}")
    public ResponseEntity<String> likeRecognition(
            @PathVariable Long recognitionId,
            @PathVariable String empCode) throws ExecutionException, InterruptedException {
        return ResponseEntity.ok(recognitionLikeService.likeRecognition(recognitionId, empCode, InteractionType.RECOGNITION));  // ← false
    }

    // Executive Circle — same service method, isNomination = true
    @PostMapping("/likeNomination/{id}/{empCode}")
    public ResponseEntity<String> likeNomination(@PathVariable Long id,
                                                 @PathVariable String empCode)
            throws ExecutionException, InterruptedException {
        return ResponseEntity.ok(recognitionLikeService.likeRecognition(id, empCode, InteractionType.NOMINATION));
    }


    // HonorClub — same service method, isNomination = true
    @PostMapping("/likeHonorClub/{id}/{empCode}")
    public ResponseEntity<String> likeHonorClub(@PathVariable Long id,
                                                 @PathVariable String empCode)
            throws ExecutionException, InterruptedException {
        return ResponseEntity.ok(recognitionLikeService.likeRecognition(id, empCode, InteractionType.HONOR_CLUB));
    }

    //scholarships
    @PostMapping("/likeScholarships/{id}/{empCode}")
    public ResponseEntity<String> likeScholarships(@PathVariable Long id,
                                                @PathVariable String empCode)
            throws ExecutionException, InterruptedException {
        return ResponseEntity.ok(recognitionLikeService.likeRecognition(id, empCode, InteractionType.SCHOLARSHIP));
    }

    // Bravo / World of Thanks — existing endpoint
    @GetMapping("/likes/{recognitionId}")
    public ResponseEntity<List<RnRLikesTable>> getRecognitionLikes(@PathVariable Long recognitionId) {
        return ResponseEntity.ok(recognitionLikeService.getRecognitionLikes(recognitionId, InteractionType.RECOGNITION));  // ← false
    }

    // Executive Circle — same service method, isNomination = true
    @GetMapping("/nominationLikes/{id}")
    public ResponseEntity<List<RnRLikesTable>> getNominationLikes(@PathVariable Long id) {
        return ResponseEntity.ok(recognitionLikeService.getRecognitionLikes(id, InteractionType.NOMINATION));
    }

    // Executive Circle — same service method, isNomination = true
    @GetMapping("/getHonorClubLikes/{id}")
    public ResponseEntity<List<RnRLikesTable>> getHonorClubLikes(@PathVariable Long id) {
        return ResponseEntity.ok(recognitionLikeService.getRecognitionLikes(id, InteractionType.HONOR_CLUB));
    }

    // Executive Circle — same service method, isNomination = true
    @GetMapping("/getScholarshipsLikes/{id}")
    public ResponseEntity<List<RnRLikesTable>> getScholarshipsLikes(@PathVariable Long id) {
        return ResponseEntity.ok(recognitionLikeService.getRecognitionLikes(id, InteractionType.SCHOLARSHIP));
    }
}
