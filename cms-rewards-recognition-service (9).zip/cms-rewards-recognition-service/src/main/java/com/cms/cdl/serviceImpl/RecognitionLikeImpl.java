package com.cms.cdl.serviceImpl;

import com.cms.cdl.beans.emp_user_bean.EmpAndUserResponse;
import com.cms.cdl.Enum.InteractionType;
import com.cms.cdl.entity.RnRLikesTable;
import com.cms.cdl.repository.RecognitionLikeRepository;
import com.cms.cdl.service.RecognitionLikeService;
import com.cms.cdl.utils.EmployeeOperations;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.concurrent.ExecutionException;

@Service
public class RecognitionLikeImpl implements RecognitionLikeService {

    @Autowired
    private RecognitionLikeRepository likeRepo;

    @Autowired
    private EmployeeOperations employeeOperations;

    @Autowired
    private MailServiceImpl mailService;

    @Override
    public String likeRecognition(
            Long id,
            String empCode,
            InteractionType type)
            throws ExecutionException, InterruptedException {

        boolean alreadyLiked = switch (type) {

            case RECOGNITION ->
                    likeRepo.existsByRecognitionIdAndEmpCode(id, empCode);

            case NOMINATION ->
                    likeRepo.existsByNominationDetailIdAndEmpCode(id, empCode);

            case HONOR_CLUB ->
                    likeRepo.existsByHonorClubIdAndEmpCode(id, empCode);

            case SCHOLARSHIP ->
                    likeRepo.existsByScholarshipChildIdAndEmpCode(id, empCode);
        };

        if (alreadyLiked) {
            return "Already liked";
        }

        EmpAndUserResponse emp =
                employeeOperations.getEmpByEmpCode(empCode);

        RnRLikesTable like = new RnRLikesTable();

        switch (type) {

            case RECOGNITION ->
                    like.setRecognitionId(id);

            case NOMINATION ->
                    like.setNominationDetailId(id);

            case HONOR_CLUB ->
                    like.setHonorClubId(id);

            case SCHOLARSHIP ->
                    like.setScholarshipChildId(id);
        }

        like.setEmpCode(empCode);

        like.setEmployeeName(
                emp.getFileAndObjectTypeBean()
                        .getEmpResDTO()
                        .getFirstName());

        like.setEmailId(
                emp.getFileAndObjectTypeBean()
                        .getEmpResDTO()
                        .getEmailId());

        like.setDepartment(
                emp.getFileAndObjectTypeBean()
                        .getEmpResDTO()
                        .getMainDeptResDTO()
                        .getMainDepartment());

        DateTimeFormatter fmt =
                DateTimeFormatter.ofPattern(
                        "dd MMMM yyyy hh:mm a");

        like.setLikedAt(
                LocalDateTime.now(
                                ZoneId.of("Asia/Kolkata"))
                        .format(fmt));

        likeRepo.save(like);

        return "Liked successfully";
    }

    @Override
    public List<RnRLikesTable> getRecognitionLikes(
            Long id,
            InteractionType type) {

        return switch (type) {

            case RECOGNITION ->
                    likeRepo.findByRecognitionId(id);

            case NOMINATION ->
                    likeRepo.findByNominationDetailId(id);

            case HONOR_CLUB ->
                    likeRepo.findByHonorClubId(id);

            case SCHOLARSHIP ->
                    likeRepo.findByScholarshipChildId(id);
        };
    }
}
