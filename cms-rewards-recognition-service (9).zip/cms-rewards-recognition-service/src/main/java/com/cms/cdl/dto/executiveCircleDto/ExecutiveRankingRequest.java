package com.cms.cdl.dto.executiveCircleDto;


import lombok.Data;

@Data
public class ExecutiveRankingRequest {

    private String financialYear;

    private String awardTitle;

    private Long nominationDetailId;

    private Integer rankPosition;
    private String reason;
}