package com.cms.cdl.dto.honorClub;

import com.cms.cdl.Enum.ScholarshipType;
import lombok.*;

import java.util.List;

public class ScholarshipDto {

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class Request {

        private String awardYear;

        private ScholarshipType scholarshipType;

        private String empCode;

        private String employeeName;

        private String department;

        private String subDepartment;

        private String location;

        private String project;

        private String r1ECode;

        private String r1Name;

        private String buHeadName;

        private List<ChildRequest> children;
    }

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class ChildRequest {

        private String title;

        private String studentName;

        private String academicYear;

        private Double marksPercentage;

        private Double percentile;

        private String rankObtained;

        private String schoolName;

        //private MultipartFile photoFile;

       // private MultipartFile certificateFile;

        private String photoFile;           // ← base64 string
        private String photoFileName;       // ← original file name
        private String certificateFile;     // ← base64 string
        private String certificateFileName;
    }

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class Response {

        private Long id;

        private String awardYear;

        private ScholarshipType scholarshipType;

        private String empCode;

        private String employeeName;

        private String department;

        private String subDepartment;

        private String location;

        private String project;

        private String r1ECode;

        private String r1Name;

        private String buHeadName;

        private Boolean selected;

        private Boolean published;

        private List<ChildResponse> children;
    }

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class ChildResponse {

        private Long id;

        private String title;

        private String studentName;

        private String academicYear;

        private Double marksPercentage;

        private Double percentile;

        private String rankObtained;

        private String schoolName;

        private Long photoDocId;

        private Long certificateDocId;
    }
}
