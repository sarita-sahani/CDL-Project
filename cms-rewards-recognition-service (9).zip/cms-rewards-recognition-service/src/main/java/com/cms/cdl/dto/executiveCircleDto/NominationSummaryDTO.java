package com.cms.cdl.dto.executiveCircleDto;

import com.cms.cdl.entity.Nomination;
import lombok.*;

import java.time.LocalDateTime;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class NominationSummaryDTO {

    private Long nominationId;

    private String awardTitle;

    private String category;

    private String financialYear;

    // ── Nominator Details ─────────────────────
    private String submittedByEmployeeCode;

    private String submittedByName;

    private String submittedByEmailId;

    private Boolean isNominating;

    private String status;
    private String hrRemarks;

    private LocalDateTime createdAt;

    // ── Existing Summary Fields ───────────────
    private String nomination1;
    private String nomination2;
    private String nomination3;
    private String nomination4;

    private String department1;
    private String department2;
    private String department3;
    private String department4;

    private String reason1;
    private String reason2;
    private String reason3;
    private String reason4;

    // ── Full Details List ─────────────────────
    private List<NominationDetailDTO> nominationDetails;
}