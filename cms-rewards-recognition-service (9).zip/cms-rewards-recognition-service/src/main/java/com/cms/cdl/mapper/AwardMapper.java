package com.cms.cdl.mapper;

import com.cms.cdl.dto.executiveCircleDto.*;
import com.cms.cdl.entity.Award;
import org.springframework.stereotype.Component;

@Component
public class AwardMapper {

    public AwardDTO toDTO(Award award) {
        if (award == null) return null;
        return AwardDTO.builder()
                .id(award.getId())
                .awardTitle(award.getAwardTitle())
                .noOfAwards(award.getNoOfAwards())
                .category(award.getCategory())
                .criteria(award.getCriteria())
                .whoCanNominate(award.getWhoCanNominate())
                .isOpenForNomination(award.isOpenForNomination())
                .maxNominations(award.getMaxNominations())
                .build();
    }

    public Award toEntity(AwardDTO dto) {
        if (dto == null) return null;
        return Award.builder()
                .id(dto.getId())
                .awardTitle(dto.getAwardTitle())
                .noOfAwards(dto.getNoOfAwards())
                .category(dto.getCategory())
                .criteria(dto.getCriteria())
                .whoCanNominate(dto.getWhoCanNominate())
                .isOpenForNomination(dto.isOpenForNomination())
                .maxNominations(dto.getMaxNominations())
                .build();
    }
}
