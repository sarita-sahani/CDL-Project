package com.cms.cdl.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class VoucherEligibilityDTO {

    private boolean buManager;
    private Integer quarterLimit;
    private Integer usedAmount;
    private Integer remainingAmount;
    private List<Integer> allowedVoucherValues;
}
