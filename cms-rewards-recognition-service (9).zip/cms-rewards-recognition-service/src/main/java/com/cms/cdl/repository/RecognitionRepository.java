package com.cms.cdl.repository;

import com.cms.cdl.entity.Recognition;
import org.springframework.data.domain.*;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface RecognitionRepository extends JpaRepository<Recognition,Long> {
    List<Recognition> findByRecognitionTypeIgnoreCase(String recognitionType);
    Page<Recognition> findByRecognitionType(String type, Pageable pageable);

    @Query("""
        SELECT COALESCE(SUM(r.voucherValue), 0)
        FROM Recognition r
        WHERE r.recognizedByCode = :managerCode
        AND r.recognitionType = 'BRAVO'
        AND r.certificateType = 'withVoucher'
        AND r.quarter = :quarter
        AND r.financialYear = :year
    """)
    Integer getUsedVoucherAmount(
            @Param("managerCode") String managerCode,
            @Param("quarter") String quarter,
            @Param("year") Integer year
    );
}