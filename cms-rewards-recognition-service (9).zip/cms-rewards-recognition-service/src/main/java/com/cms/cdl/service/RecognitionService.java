package com.cms.cdl.service;

import com.cms.cdl.beans.emp_bean.FileAndObjectTypeBean;
import com.cms.cdl.beans.emp_user_bean.EmpAndUserResponse;
import com.cms.cdl.dto.RecognitionResponseDTO;
import com.cms.cdl.dto.VoucherEligibilityDTO;
import com.cms.cdl.entity.Category;
import com.cms.cdl.entity.Recognition;
import com.cms.cdl.entity.Template;
import com.cms.cdl.entity.TemplateImage;
import org.springframework.data.domain.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;

public interface RecognitionService {
    EmpAndUserResponse getEmpInfoByEmpCode(String empCode) throws ExecutionException, InterruptedException;

    Map<String, Object> fetchEmployeeTeamData(String empCode);

    List<Category> getCategoriesByRecognitionType(Long recognitionTypeId);

    Category getcategoriesname(Long categoryId);

    List<Template> getTemplatesByCategory(Long categoryId);

    Template getTemplateDescription(Long templateId);

    List<TemplateImage> getImagesByTemplate(Long templateId);

    Recognition saveRecognitionsData(Recognition request, MultipartFile multipartFile) throws Exception;



    List<FileAndObjectTypeBean> searchEmployee(String searchValue);

    Map<String, String> previewCertificate(Recognition request) throws Exception;

    Page<RecognitionResponseDTO> getAllDataByRecognitionType(String type, int page, int size);

    Map<String, Object> getAllRecognitions(int page, int size);

    VoucherEligibilityDTO getVoucherEligibility(String managerCode) throws ExecutionException, InterruptedException;

    void validateVoucherBeforeSubmit(String managerCode, Integer voucherValue) throws ExecutionException, InterruptedException;
}
