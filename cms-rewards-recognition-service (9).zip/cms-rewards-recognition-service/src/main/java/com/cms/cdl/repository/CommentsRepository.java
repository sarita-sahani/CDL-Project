package com.cms.cdl.repository;

import com.cms.cdl.entity.RnRCommentsTable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CommentsRepository extends JpaRepository<RnRCommentsTable, Long> {

    List<RnRCommentsTable> findByRecognitionId(Long id);

    List<RnRCommentsTable> findByNominationDetailId(Long id);

    List<RnRCommentsTable> findByHonorClubId(Long id);

    List<RnRCommentsTable> findByScholarshipChildId(Long id);


    long countByRecognitionId(Long recognitionId);
    List<RnRCommentsTable> findByRecognitionIdOrderByCommentDateTimeDesc(Long recognitionId);



}
