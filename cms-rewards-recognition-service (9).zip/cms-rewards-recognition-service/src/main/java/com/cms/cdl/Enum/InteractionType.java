package com.cms.cdl.Enum;

public enum InteractionType {
    RECOGNITION,
    NOMINATION,
    HONOR_CLUB,
    SCHOLARSHIP
}