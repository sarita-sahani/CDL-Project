package com.cms.cdl.repository;

import com.cms.cdl.entity.RecognitionType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface RecognitionTypeRepository extends JpaRepository<RecognitionType, Long> {
    RecognitionType findByTypeName(String typeName);
}
