package com.cms.cdl.controller;

import com.cms.cdl.dto.honorClub.HonorClubDto;
import com.cms.cdl.Enum.HonorClubType;
import com.cms.cdl.service.HonorClubService;
import com.cms.cdl.utils.ApiResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;

@RestController
@RequestMapping("/api/honor-club")
@CrossOrigin("*")
@RequiredArgsConstructor
public class HonorClubController {

    private final HonorClubService honorClubService;

    @PostMapping(value = "/saveHonorClubData",
            consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ApiResponse saveHonorClubData(
            @ModelAttribute HonorClubDto.Request request) throws IOException {

        return ApiResponse.success(
                honorClubService.saveHonorClubData(request));
    }

    @GetMapping("/year/{awardYear}")
    public ApiResponse getHonorClubDataByYear(
            @PathVariable String awardYear) {

        return ApiResponse.success(
                honorClubService
                        .getHonorClubDataByYear(
                                awardYear));
    }

    @GetMapping("/type/{honorClubType}")
    public ApiResponse getHonorClubDataByType(
            @PathVariable HonorClubType honorClubType) {

        return ApiResponse.success(
                honorClubService
                        .getHonorClubDataByType(
                                honorClubType));
    }

    @GetMapping("/filter")
    public ApiResponse getHonorClubDataByYearAndType(
            @RequestParam String awardYear,
            @RequestParam HonorClubType honorClubType) {

        return ApiResponse.success(
                honorClubService
                        .getHonorClubDataByYearAndType(
                                awardYear,
                                honorClubType));
    }
}