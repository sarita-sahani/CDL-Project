package com.cms.cdl.beans.emp_bean;

import com.cms.cdl.beans.file_bean.FileAndContentTypeBean;
import com.cms.cdl.dto.response_dto.emp_full_response.EmpResDTO;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class FileAndObjectTypeBean {
    FileAndContentTypeBean fileAndContentTypeBean;
    EmpResDTO empResDTO;
}
