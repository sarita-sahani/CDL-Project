package com.cms.cdl.repository;

import com.cms.cdl.entity.Voucher;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface VoucherRepository extends JpaRepository<Voucher, Long> {

    // 1. Get counts of unused active vouchers grouped by value
    @Query("SELECT v.voucherValue, COUNT(v) FROM Voucher v WHERE v.voucherStatus = 'Active' AND v.usageStatus = 'Unused' GROUP BY v.voucherValue")
    List<Object[]> countActiveVouchersByValue();

    // 2. Find the soonest to expire voucher for a specific value
    Optional<Voucher> findFirstByVoucherValueAndVoucherStatusAndUsageStatusOrderByExpiryDateAsc(
            Double voucherValue, String voucherStatus, String usageStatus
    );

    @Query("SELECT v.voucherNumber FROM Voucher v ORDER BY v.id DESC LIMIT 1")
    String findLastVoucherNumber();

//    Optional<Voucher> findTopByVoucherValueAndStatusOrderByExpiryDateAsc(
//            Double voucherValue,
//            String status
//    );
}
