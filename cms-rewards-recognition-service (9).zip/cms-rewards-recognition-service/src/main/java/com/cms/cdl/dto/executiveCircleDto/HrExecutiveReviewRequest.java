package com.cms.cdl.dto.executiveCircleDto;

import lombok.Data;

@Data
public class HrExecutiveReviewRequest {

    private Long nominationId;

    private String status;
    private String hrRemarks;
}