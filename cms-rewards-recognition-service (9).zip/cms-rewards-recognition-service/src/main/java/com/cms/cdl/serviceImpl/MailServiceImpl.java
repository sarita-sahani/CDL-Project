package com.cms.cdl.serviceImpl;

import com.cms.cdl.dto.executiveCircleDto.HRMailAwardGroup;
import com.cms.cdl.dto.executiveCircleDto.NomineeRow;
import com.cms.cdl.entity.Voucher;
import com.cms.cdl.service.MailService;
import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.springframework.web.multipart.MultipartFile;


@Service
public class MailServiceImpl implements MailService {
    @Autowired
    private JavaMailSender mailSender;
    @Autowired
    ThymeleafService thymeleafService;
    @Value("${spring.mail.username}")
    private String fromEmail;

//    @Override
//    public void sendRecognitionMail(Recognition recognition){
//
//        try {
//            MimeMessage mimeMessage = mailSender.createMimeMessage();
//
//            MimeMessageHelper helper = new MimeMessageHelper(
//                    mimeMessage,
//                    MimeMessageHelper.MULTIPART_MODE_MIXED_RELATED,
//                    StandardCharsets.UTF_8.name()
//            );
//
//            helper.setFrom(fromEmail);
//            helper.setTo(recognition.getEmployeeEmail());
//            helper.setSubject("🎉 You've Received a Recognition Award! 🎉");
//
//            // attach selected image
//            if (recognition.getTemplateImageUrl() != null) {
//                File file = new File(
//                        "D:/your-project-path/src/main/resources/static"
//                                + recognition.getTemplateImageUrl()
//                );
//
//                helper.addAttachment(file.getName(), file);
//            }
//
//            // ✅ Prepare variables for Thymeleaf
//            Map<String, Object> variables = new HashMap<>();
//            variables.put("toName", recognition.getEmployeeName());
//            variables.put("fromName", recognition.getRecognizedByName());
//            variables.put("recognitionType", recognition.getRecognitionType());
//            variables.put("messageText", recognition.getComment());
//
//            // ✅ Load HTML template
//            String htmlContent = thymeleafService.createContent(
//                    "employee-rewards-recognition-notification.html",
//                    variables
//            );
//
//            helper.setText(htmlContent, true); // true = HTML
//
//            mailSender.send(mimeMessage);
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

//    @Override
//    public void sendRecognitionMail(String toEmail,
//                                    String nomineeName,
//                                    String nominatorName,
//                                    String recognitionType,
//                                    String messageText,
//                                    String templateImageUrl) {
//
//        try {
//            MimeMessage mimeMessage = mailSender.createMimeMessage();
//
//            MimeMessageHelper helper = new MimeMessageHelper(
//                    mimeMessage,
//                    true,
//                    StandardCharsets.UTF_8.name()
//            );
//
//            helper.setFrom(fromEmail);
//            helper.setTo(toEmail);
//            helper.setSubject("🎉 Congratulations! You've Received a Recognition Award");
//
//            Map<String, Object> variables = new HashMap<>();
//            variables.put("nomineeName", nomineeName);
//            variables.put("nominatorName", nominatorName);
//            variables.put("recognitionType", recognitionType);
//            variables.put("messageText", messageText);
//
//            String htmlContent = thymeleafService.createContent(
//                    "employee-rewards-recognition-notification.html",
//                    variables
//            );
//
//            helper.setText(htmlContent, true);
//
//            // ✅ Attach certificate from static folder
//            if (templateImageUrl != null && !templateImageUrl.isEmpty()) {
//                ClassPathResource resource =
//                        new ClassPathResource("static" + templateImageUrl);
//
//                if (resource.exists()) {
//                    helper.addAttachment(
//                            "Recognition-Certificate.jpg",
//                            resource
//                    );
//                }
//            }
//
//            mailSender.send(mimeMessage);
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

    @Override
    @Async
    public void sendRecognitionMail(String toEmail,
                                    String nomineeName,
                                    String nominatorName,
                                    String recognitionType,
                                    String messageText,
                                    MultipartFile certificateFiles, // ✅ Renamed to plural to reflect Map
                                    Voucher voucher) {

        try {
            MimeMessage mimeMessage = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true, StandardCharsets.UTF_8.name());

            helper.setFrom(fromEmail);
            helper.setTo(toEmail);
            helper.setSubject("🎉 Congratulations! You've Received a Recognition Award");

            // Populate HTML template variables
            Map<String, Object> variables = new HashMap<>();
            variables.put("nomineeName", nomineeName);
            variables.put("nominatorName", nominatorName);
            variables.put("recognitionType", recognitionType);
            variables.put("messageText", messageText);

            if (voucher != null) {
                variables.put("voucherCode", voucher.getVoucherCode());
                variables.put("voucherValue", voucher.getVoucherValue());
                variables.put("voucherNumber", voucher.getVoucherNumber());
                variables.put("voucherExpiry", voucher.getExpiryDate());
            }

            String htmlContent = thymeleafService.createContent("employee-rewards-recognition-notification.html", variables);
            helper.setText(htmlContent, true);

            // ✅ FIX: Extract files from the Map to attach them properly
            if (certificateFiles != null && !certificateFiles.isEmpty()) {
                    helper.addAttachment(
                            Objects.requireNonNull(certificateFiles.getOriginalFilename()),
                            certificateFiles
                    );
                }

        mailSender.send(mimeMessage);
        }
        catch (MessagingException ex) {
            throw new RuntimeException(ex);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    //send mail notification to the marketing team if Pending voucher is only five

    @Override
    public void sendLowVoucherAlert(List<String> emailIds, long remainingCount) {
        try {
            // ✅ Build variables
            Map<String, Object> variables = new HashMap<>();
            variables.put("remainingCount", remainingCount);
            variables.put("alertDate", LocalDate.now()
                    .format(DateTimeFormatter.ofPattern("dd MMM yyyy")));

            // ✅ Load and process Thymeleaf template
            String htmlContent = thymeleafService.createContent(
                    "low-voucher-alert-notification.html", variables
            );

            // ✅ Build MimeMessage
            MimeMessage mimeMessage = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(
                    mimeMessage, true, StandardCharsets.UTF_8.name()
            );

            helper.setTo(emailIds.toArray(new String[0]));
            helper.setFrom(fromEmail);
            helper.setSubject("Action Required: Voucher Inventory Low — "
                    + remainingCount + " Remaining");
            helper.setText(htmlContent, true);

            mailSender.send(mimeMessage);
            System.out.println("✅ Low voucher alert sent successfully.");

        } catch (MessagingException e) {
            System.err.println("❌ Failed to send alert email: " + e.getMessage());
        }
    }

    @Override
    public void sendNominationNotificationMail(String toEmail,
                                               String nomineeName,
                                               String nominatorName,
                                               String awardTitle,
                                               String awardCategory,
                                               String awardCriteria,
                                               String financialYear) {
        try {
            MimeMessage mimeMessage = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true, StandardCharsets.UTF_8.name());

            helper.setFrom(fromEmail);
            helper.setTo(toEmail);
            helper.setSubject("🏆 You've Been Nominated for the " + awardTitle + " – Executive Circle Awards");

            Map<String, Object> variables = new HashMap<>();
            variables.put("nomineeName",    nomineeName);
            variables.put("nominatorName",  nominatorName);
            variables.put("awardTitle",     awardTitle);
            variables.put("awardCategory",  awardCategory);
            variables.put("awardCriteria", awardCriteria);
            variables.put("financialYear",  financialYear);

            String htmlContent = thymeleafService.createContent(
                    "executive-circle-nomination-notification.html", variables);
            helper.setText(htmlContent, true);

            mailSender.send(mimeMessage);

        } catch (MessagingException ex) {
            throw new RuntimeException(ex);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void sendHRSubmissionMail(String nominatorName,
                                     String nominatorCode,
                                     String nominatorEmail,
                                     String financialYear,
                                     List<NomineeRow> awardGroups) {
        try {
            MimeMessage mimeMessage = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true, StandardCharsets.UTF_8.name());

            helper.setFrom(fromEmail);
            helper.setTo("sarita_p@cms.co.in");
            helper.setReplyTo(nominatorEmail);
            helper.setSubject("📋 Executive Circle Nominations Submitted – FY " + financialYear
                    + " – " + nominatorName + " (" + nominatorCode + ")");

            // ── Each NomineeRow = one nominee, so total nominees = list size ──────
            int totalNominees = awardGroups.size();

            // ── Count distinct award titles for totalAwards ───────────────────────
            long totalAwards = awardGroups.stream()
                    .map(NomineeRow::awardTitle)
                    .distinct()
                    .count();

            Map<String, Object> variables = new HashMap<>();
            variables.put("nominatorName",  nominatorName);
            variables.put("nominatorCode",  nominatorCode);
            variables.put("nominatorEmail", nominatorEmail);
            variables.put("financialYear",  financialYear);
            variables.put("submittedOn",
                    LocalDate.now().format(DateTimeFormatter.ofPattern("dd-MMM-yyyy")));
            variables.put("totalAwards",   totalAwards);
            variables.put("totalNominees", totalNominees);
            variables.put("awardGroups",   awardGroups);   // th:each="row : ${awardGroups}"

            String htmlContent = thymeleafService.createContent(
                    "executive-circle-hr-mail-notification.html", variables);
            helper.setText(htmlContent, true);

            mailSender.send(mimeMessage);

        } catch (MessagingException ex) {
            throw new RuntimeException(ex);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
