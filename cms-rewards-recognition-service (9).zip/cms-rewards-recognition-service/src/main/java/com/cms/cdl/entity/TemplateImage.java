package com.cms.cdl.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "template_images")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class TemplateImage {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String imageUrl;

    @Column(name = "template_id")
    private Long templateId;
}