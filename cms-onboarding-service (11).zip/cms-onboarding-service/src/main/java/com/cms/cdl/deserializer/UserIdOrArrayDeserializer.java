package com.cms.cdl.deserializer;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.JsonNode;

import java.io.IOException;

/**
 * This upstream API returns "who did this" user fields either as a plain
 * string or as a [userId, displayName] array. This normalizes both shapes
 * into a single String.
 */
public class UserIdOrArrayDeserializer extends JsonDeserializer<String> {
    @Override
    public String deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
        JsonNode node = p.getCodec().readTree(p);
        if (node.isArray()) {
            if (node.isEmpty()) return null;
            // node.get(0) = login id e.g. "sarita_p", node.get(1) = display name e.g. "Sarita P"
            return node.size() > 1 ? node.get(1).asText() : node.get(0).asText();
        }
        return node.isNull() ? null : node.asText();
    }
}