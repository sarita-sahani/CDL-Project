package com.cms.cdl.service.onboarding_service;

import com.cms.cdl.dto.document_dto.DocumentDTO;
import com.cms.cdl.dto.request_dto.onboarding_req_dto.*;
import com.cms.cdl.dto.response_dto.CandidateFullDetailsDTO;
import com.cms.cdl.dto.response_dto.EmployeeDiretoryDetailsDTO;
import com.cms.cdl.dto.response_dto.GeneralListCandidatesData;
import com.cms.cdl.mapper.OnBoardingMapper;
import com.cms.cdl.model.*;
import com.cms.cdl.repository.*;
import com.cms.cdl.util.OnBoardingOperationsCandidates;
import com.cms.cdl.util.OnboardingOperations;
import com.cms.cdl.util.UrlToMultipartFileConvert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.util.retry.Retry;

import java.time.Duration;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.stream.Collectors;

@Service
public class OnboardingServiceImpl implements OnboardingService{

    @Autowired
    private OnboardingOperations onboardingOperations;

    @Autowired
    private EONPersonalRepository eonPersonalRepository;

    @Autowired
    private EONGeneralRepository eonGeneralRepository;

    @Autowired
    private EONEducationRepository eonEducationRepository;

    @Autowired
    private EONSkillRepository eonSkillRepository;

    @Autowired
    private EONFamilyRepository eonFamilyRepository;

    @Autowired
    private EONBankRepository eonBankRepository;
    @Autowired
    private EONPFRepository eonpfRepository;
    @Autowired
    private EONLanguageRepository eonLanguageRepository;
    @Autowired
    private EONInterestRepository eonInterestRepository;
    @Autowired
    private EONProfessionalExpRepository eonProfessionalExpRepository;
    @Autowired
    private EONProfReferRepository eonProfReferRepository;
    @Autowired
    private EONDocProofRepository eonDocProofRepository;
    @Autowired
    private EONDeclQuestRepository eonDeclQuestRepository;
    @Autowired
    private EONCandDeclRepository eonCandDeclRepository;
    @Autowired
    private EONHRDeclarationRepository eonhrDeclarationRepository;
    @Autowired
    private EONOverallStatusRepository eonOverallStatusRepository;

    @Autowired
    private OnBoardingMapper onBoardingMapper;
    @Autowired
    UrlToMultipartFileConvert urlToMultipartFileConvert;
    @Autowired
    private ExecutorService onboardingExecutor;

    @Autowired
    private OnBoardingOperationsCandidates onBoardingOperationsCandidates;
    @Autowired
    private EmployeeOnboardingRepository employeeRepo;

    private static final Logger logger = LoggerFactory.getLogger(OnboardingServiceImpl.class);

    private static final Duration REQUEST_TIMEOUT = Duration.ofSeconds(10);
    // Overall budget for fetchHRCompletedCandidateDetailsById, which now staggers 16
    // field fetches over ~2.25s and lets each retry twice on timeout. Must stay well
    // above (max stagger delay + REQUEST_TIMEOUT + retry backoff) or this outer timeout
    // fires first and wipes out the whole response instead of just the slow field.
    private static final Duration FULL_DETAILS_TIMEOUT = Duration.ofSeconds(40);
    private static final int MAX_RETRIES = 2;


    @Override
    public Mono<List<GeneralListCandidatesData>> fetchAllHRCompletedGeneralCandidatesDetails() {
        return onBoardingOperationsCandidates.overallHRCompletedCandIds()
                .flatMapMany(tuple -> {
                    String sessionId = tuple.getT1();
                    List<String> candIds = tuple.getT2();
                    return Flux.fromIterable(candIds)
                            .flatMap(candId -> fetchHRCompletedGeneralCandidateDetails(candId, sessionId)
                                    .doOnNext(dto -> System.out.println("Fetched DTO for candidate: " + candId)));
                })
                .collectList();
    }

//    @Override
//    public Mono<GeneralListCandidatesData> fetchHRCompletedGeneralCandidateDetails(String candId, String sessionId) {
//        // Fetch overall status first
//        Mono<EONOverallStatusReqDTO> overallStatusMono = onBoardingOperationsCandidates.overallStatusDataOfSingleCandidates(candId, sessionId)
//                .onErrorResume(ex -> Mono.empty()); // Return empty Mono on error
//
//        // Fetch general data, using overallStatusMono as a trigger
//        return overallStatusMono
//                .flatMap(overallStatusData -> {
//                    // We have overall status, now fetch general data in parallel with a just-in-time value.
//                    Mono<EONGeneralReqDTO> generalMono = onBoardingOperationsCandidates.fetchEonGeneralData(candId, sessionId)
//                            .onErrorResume(ex -> Mono.empty());
//
//                    return Mono.zip(Mono.just(overallStatusData), generalMono)
//                            .map(tuple -> {
//                                GeneralListCandidatesData dto = new GeneralListCandidatesData();
//                                dto.setCandId(candId);
//                                dto.setEonOverallStatusReqDTO(tuple.getT1());
//                                dto.setEonGeneralReqDTO(tuple.getT2());
//                                return dto;
//                            });
//                })
//                .switchIfEmpty(Mono.defer(() -> {
//                    // If overallStatusMono was empty, fetch only general data
//                    return onBoardingOperationsCandidates.fetchEonGeneralData(candId, sessionId)
//                            .map(generalData -> {
//                                GeneralListCandidatesData dto = new GeneralListCandidatesData();
//                                dto.setCandId(candId);
//                                dto.setEonGeneralReqDTO(generalData);
//                                return dto;
//                            })
//                            .switchIfEmpty(Mono.just(new GeneralListCandidatesData())); // Return an empty DTO if both fail
//                }))
//                .doOnError(throwable -> System.err.println("An error occurred in the combined stream: " + throwable.getMessage()));
//    }

    @Override
    public Mono<GeneralListCandidatesData> fetchHRCompletedGeneralCandidateDetails(String candId, String sessionId) {
        // Fetch both in parallel
        Mono<EONOverallStatusReqDTO> overallStatusMono = onBoardingOperationsCandidates
                .overallStatusDataOfSingleCandidates(candId, sessionId)
                .onErrorResume(ex -> {
                    System.err.println("Overall status error for " + candId + ": " + ex.getMessage());
                    return Mono.just(EONOverallStatusReqDTO.empty()); // Return empty DTO instead of Mono.empty()
                });

        Mono<EONGeneralReqDTO> generalMono = onBoardingOperationsCandidates
                .fetchEonGeneralData(candId, sessionId)
                .onErrorResume(ex -> {
                    System.err.println("General data error for " + candId + ": " + ex.getMessage());
                    return Mono.just(EONGeneralReqDTO.empty()); // Return empty DTO instead of Mono.empty()
                });

        return Mono.zip(overallStatusMono, generalMono)
                .map(tuple -> {
                    GeneralListCandidatesData dto = new GeneralListCandidatesData();
                    dto.setCandId(candId);
                    dto.setEonOverallStatusReqDTO(tuple.getT1());
                    dto.setEonGeneralReqDTO(tuple.getT2());
                    return dto;
                })
                .doOnError(throwable ->
                        System.err.println("Error in combined stream for " + candId + ": " + throwable.getMessage()));
    }

//    @Override
//    public Mono<GeneralListCandidatesData> fetchHRCompletedGeneralCandidateDetails(String candId, String sessionId) {
//        Mono<EONGeneralReqDTO> general = onBoardingOperationsCandidates.fetchEonGeneralData(candId, sessionId)
//                .onErrorResume(ex -> {
//                    System.err.println("Failed to fetch general data for " + candId + ": " + ex.getMessage());
//                    return Mono.just( EONGeneralReqDTO.empty());
//                })
//                .defaultIfEmpty( EONGeneralReqDTO.empty());
//
//        Mono<EONOverallStatusReqDTO> overallstatusCandidatesdata = onBoardingOperationsCandidates.overallStatusDataOfSingleCandidates(candId, sessionId)
//                .onErrorResume(ex -> {
//                    System.err.println("Failed to fetch overallstatuscandidatesdata data for " + candId + ": " + ex.getMessage());
//                    return Mono.just( EONOverallStatusReqDTO.empty());
//                })
//                .defaultIfEmpty( EONOverallStatusReqDTO.empty());
//
//        return Mono.zip(general, overallstatusCandidatesdata)
//                .map(tuple -> {
//                    GeneralListCandidatesData dto = new GeneralListCandidatesData();
//                    dto.setCandId(candId);
//                    dto.setEonGeneralReqDTO(tuple.getT1());
//                    dto.setEonOverallStatusReqDTO(tuple.getT2());
//                    return dto;
//                });
//    }

//    @Override
//    public Mono<List<CandidateFullDetailsDTO>> fetchAllHRCompletedCandidatesDetails() {
//        return onBoardingOperationsCandidates.overallHRCompletedCandIds()
//                .flatMapMany(tuple -> {
//                    String sessionId = tuple.getT1();
//                    List<String> candIds = tuple.getT2();
//                    return Flux.fromIterable(candIds)
//                            .flatMap(candId -> fetchCandidateDetailsReactive(candId, sessionId)
//                                    .doOnNext(dto -> System.out.println("Fetched DTO for candidate: " + candId)));
//                })
//                .collectList();
//    }

    @Override
    public Mono<CandidateFullDetailsDTO> fetchHRCompletedCandidateDetailsById(String candId) {
        logger.info("Fetching " +
                "HR completed candidate details for ID: {}", candId);

        return getValidSessionId()
                .flatMap(sessionId -> {
                    logger.debug("Using session ID: {} for candidate: {}", sessionId, candId);
                    return fetchCandidateDetailsReactive(candId, sessionId);
                })
                .timeout(FULL_DETAILS_TIMEOUT)
                .doOnSuccess(dto -> logger.info("Successfully fetched details for candidate: {}", candId))
                .doOnError(error -> logger.error("Error fetching candidate {}: {}", candId, error.getMessage()))
                .onErrorResume(error -> {
                    logger.error("Falling back to empty DTO for candidate: {}", candId, error);
                    return Mono.just(createEmptyCandidateDetailsDTO(candId));
                });
    }

    // NOTE: this used to check an in-memory `sessionCache` (a single
    // ConcurrentHashMap entry, "active_session") before deciding whether to log in
    // again. That cache never expired and was never invalidated on failure - once a
    // session was cached, it was reused by every subsequent request from every user
    // until the app was restarted. When that one session eventually went stale on
    // the external server, every candidate's fetch silently started coming back
    // empty for the fields fetched under it, with no automatic recovery. There is now
    // no session caching here at all: every call gets its own fresh session id.
    private Mono<String> getValidSessionId() {
        return onBoardingOperationsCandidates.overallHRCompletedCandIds()
                .map(tuple -> {
                    String sessionId = tuple.getT1();
                    return sessionId;
                })
                .filter(sessionId -> sessionId != null && !sessionId.isEmpty())
                .switchIfEmpty(Mono.error(new RuntimeException("No valid session ID found")))
                .retryWhen(Retry.backoff(MAX_RETRIES, Duration.ofSeconds(1))
                        .doBeforeRetry(retrySignal ->
                                logger.warn("Retrying session ID fetch. Attempt: {}", retrySignal.totalRetries() + 1)))
                .timeout(Duration.ofSeconds(5));
    }

    @Override
    public Mono<CandidateFullDetailsDTO> fetchCandidateDetailsReactive(String candId, String sessionId) {
        logger.debug("Fetching all candidate details for ID: {} with session: {}", candId, sessionId);

        // Create all monos with proper error handling and timeouts.
        // NOTE: each fetch gets a short retry-with-backoff BEFORE falling back to
        // empty(). The external onboarding API shares one session_id across all 16
        // concurrent calls below and appears to serialize/lock on it, so a fetch that
        // times out once is usually just queued behind its siblings, not actually
        // broken - a quick retry recovers it instead of silently returning nulls.
        Mono<EONGeneralReqDTO> general = fetchWithLogging(candId, "general",
                onBoardingOperationsCandidates.fetchEonGeneralData(candId, sessionId)
                        .timeout(REQUEST_TIMEOUT)
                        .retryWhen(retrySpec(candId, "general"))
                        .onErrorResume(e -> {
                            logger.warn("General data failed for {}: {}", candId, e.getMessage());
                            return Mono.just(EONGeneralReqDTO.empty());
                        }));

        Mono<EONPersonalReqDTO> personal = fetchWithLogging(candId, "personal",
                onBoardingOperationsCandidates.fetchEonPersonalDataReactive(candId, sessionId)
                        .timeout(REQUEST_TIMEOUT)
                        .retryWhen(retrySpec(candId, "personal"))
                        .onErrorResume(e -> {
                            logger.warn("Personal data failed for {}: {}", candId, e.getMessage());
                            return Mono.just(EONPersonalReqDTO.empty());
                        }));

        Mono<EONEducationReqDTO> education = fetchWithLogging(candId, "education",
                onBoardingOperationsCandidates.fetchEonEducationData(candId, sessionId)
                        .timeout(REQUEST_TIMEOUT)
                        .retryWhen(retrySpec(candId, "education"))
                        .onErrorResume(e -> Mono.just(EONEducationReqDTO.empty())));

        Mono<EONSkillReqDTO> skill = fetchWithLogging(candId, "skill",
                onBoardingOperationsCandidates.fetchEonSkillData(candId, sessionId)
                        .timeout(REQUEST_TIMEOUT)
                        .retryWhen(retrySpec(candId, "skill"))
                        .onErrorResume(e -> Mono.just(EONSkillReqDTO.empty())));

        Mono<EONFamilyReqDTO> family = fetchWithLogging(candId, "family",
                onBoardingOperationsCandidates.fetchEonFamilyData(candId, sessionId)
                        .timeout(REQUEST_TIMEOUT)
                        .retryWhen(retrySpec(candId, "family"))
                        .onErrorResume(e -> Mono.just(EONFamilyReqDTO.empty())));

        Mono<EONBankReqDTO> bank = fetchWithLogging(candId, "bank",
                onBoardingOperationsCandidates.fetchEonBankData(candId, sessionId)
                        .timeout(REQUEST_TIMEOUT)
                        .retryWhen(retrySpec(candId, "bank"))
                        .onErrorResume(e -> Mono.just(EONBankReqDTO.empty())));

        Mono<EONPFReqDTO> pf = fetchWithLogging(candId, "pf",
                onBoardingOperationsCandidates.fetchEonPfData(candId, sessionId)
                        .timeout(REQUEST_TIMEOUT)
                        .retryWhen(retrySpec(candId, "pf"))
                        .onErrorResume(e -> Mono.just(EONPFReqDTO.empty())));

        Mono<EONLanguageReqDTO> language = fetchWithLogging(candId, "language",
                onBoardingOperationsCandidates.fetchEonLangData(candId, sessionId)
                        .timeout(REQUEST_TIMEOUT)
                        .retryWhen(retrySpec(candId, "language"))
                        .onErrorResume(e -> Mono.just(EONLanguageReqDTO.empty())));

        Mono<EONInterestReqDTO> interest = fetchWithLogging(candId, "interest",
                onBoardingOperationsCandidates.fetchEonInterestData(candId, sessionId)
                        .timeout(REQUEST_TIMEOUT)
                        .retryWhen(retrySpec(candId, "interest"))
                        .onErrorResume(e -> Mono.just(EONInterestReqDTO.empty())));

        Mono<EONProfExpReqDTO> profExp = fetchWithLogging(candId, "profExp",
                onBoardingOperationsCandidates.fetchEonProfExpData(candId, sessionId)
                        .timeout(REQUEST_TIMEOUT)
                        .retryWhen(retrySpec(candId, "profExp"))
                        .onErrorResume(e -> Mono.just(EONProfExpReqDTO.empty())));

        Mono<EONProfRefReqDTO> profRef = fetchWithLogging(candId, "profRef",
                onBoardingOperationsCandidates.fetchEonProfRefData(candId, sessionId)
                        .timeout(REQUEST_TIMEOUT)
                        .retryWhen(retrySpec(candId, "profRef"))
                        .onErrorResume(e -> Mono.just(EONProfRefReqDTO.empty())));

        Mono<EONDocsProofReqDTO> docsProof = fetchWithLogging(candId, "docsProof",
                onBoardingOperationsCandidates.fetchEonDocsProofDataReactive(candId, sessionId)
                        .timeout(REQUEST_TIMEOUT)
                        .retryWhen(retrySpec(candId, "docsProof"))
                        .onErrorResume(e -> Mono.just(EONDocsProofReqDTO.empty())));

        Mono<EONDeclQnrReqDTO> declQnr = fetchWithLogging(candId, "declQnr",
                onBoardingOperationsCandidates.fetchEonDeclQnrData(candId, sessionId)
                        .timeout(REQUEST_TIMEOUT)
                        .retryWhen(retrySpec(candId, "declQnr"))
                        .onErrorResume(e -> Mono.just(EONDeclQnrReqDTO.empty())));

        Mono<EONCandDeclReqDTO> candDeclr = fetchWithLogging(candId, "candDeclr",
                onBoardingOperationsCandidates.fetchEonCandDeclarationData(candId, sessionId)
                        .timeout(REQUEST_TIMEOUT)
                        .retryWhen(retrySpec(candId, "candDeclr"))
                        .onErrorResume(e -> Mono.just(EONCandDeclReqDTO.empty())));

        Mono<EONHRDeclReqDTO> hrDeclr = fetchWithLogging(candId, "hrDeclr",
                onBoardingOperationsCandidates.fetchEonHRDeclarationData(candId, sessionId)
                        .timeout(REQUEST_TIMEOUT)
                        .retryWhen(retrySpec(candId, "hrDeclr"))
                        .onErrorResume(e -> Mono.just(EONHRDeclReqDTO.empty())));

        Mono<EONOverallStatusReqDTO> overallStatus = fetchWithLogging(candId, "overallStatus",
                onBoardingOperationsCandidates.overallStatusDataOfSingleCandidates(candId, sessionId)
                        .timeout(REQUEST_TIMEOUT)
                        .retryWhen(retrySpec(candId, "overallStatus"))
                        .onErrorResume(e -> Mono.just(EONOverallStatusReqDTO.empty())));

        // Stagger when each call actually FIRES (delaySubscription), not just when its
        // result is emitted. The external onboarding API shares a single session_id
        // across every call in this batch and appears to serialize on it - previously
        // this used delayElement(100ms), which delays emitting a result *after* the
        // HTTP call already completed, so it did nothing to spread out the 16
        // simultaneous requests that were actually causing the contention/timeouts.
        List<Mono<?>> monos = Arrays.asList(
                general.delaySubscription(Duration.ofMillis(0)),
                personal.delaySubscription(Duration.ofMillis(150)),
                education.delaySubscription(Duration.ofMillis(300)),
                skill.delaySubscription(Duration.ofMillis(450)),
                family.delaySubscription(Duration.ofMillis(600)),
                bank.delaySubscription(Duration.ofMillis(750)),
                pf.delaySubscription(Duration.ofMillis(900)),
                language.delaySubscription(Duration.ofMillis(1050)),
                interest.delaySubscription(Duration.ofMillis(1200)),
                profExp.delaySubscription(Duration.ofMillis(1350)),
                profRef.delaySubscription(Duration.ofMillis(1500)),
                docsProof.delaySubscription(Duration.ofMillis(1650)),
                declQnr.delaySubscription(Duration.ofMillis(1800)),
                candDeclr.delaySubscription(Duration.ofMillis(1950)),
                hrDeclr.delaySubscription(Duration.ofMillis(2100)),
                overallStatus.delaySubscription(Duration.ofMillis(2250))
        );

        return Mono.zip(monos, results -> {
            CandidateFullDetailsDTO dto = new CandidateFullDetailsDTO();
            dto.setCandId(candId);

            // Set each DTO with null checking
            dto.setEonGeneralReqDTO(safeCast(results[0], EONGeneralReqDTO.class, EONGeneralReqDTO.empty()));
            dto.setEonPersonalReqDTO(safeCast(results[1], EONPersonalReqDTO.class, EONPersonalReqDTO.empty()));
            dto.setEonEducationReqDTO(safeCast(results[2], EONEducationReqDTO.class, EONEducationReqDTO.empty()));
            dto.setEonSkillReqDTO(safeCast(results[3], EONSkillReqDTO.class, EONSkillReqDTO.empty()));
            dto.setEonFamilyReqDTO(safeCast(results[4], EONFamilyReqDTO.class, EONFamilyReqDTO.empty()));
            dto.setEonBankReqDTO(safeCast(results[5], EONBankReqDTO.class, EONBankReqDTO.empty()));
            dto.setEonpfReqDTO(safeCast(results[6], EONPFReqDTO.class, EONPFReqDTO.empty()));
            dto.setEonLanguageReqDTO(safeCast(results[7], EONLanguageReqDTO.class, EONLanguageReqDTO.empty()));
            dto.setEonInterestReqDTO(safeCast(results[8], EONInterestReqDTO.class, EONInterestReqDTO.empty()));
            dto.setEonProfExpReqDTO(safeCast(results[9], EONProfExpReqDTO.class, EONProfExpReqDTO.empty()));
            dto.setEonProfRefReqDTO(safeCast(results[10], EONProfRefReqDTO.class, EONProfRefReqDTO.empty()));
            dto.setEonDocsProofReqDTO(safeCast(results[11], EONDocsProofReqDTO.class, EONDocsProofReqDTO.empty()));
            dto.setEonDeclQnrReqDTO(safeCast(results[12], EONDeclQnrReqDTO.class, EONDeclQnrReqDTO.empty()));
            dto.setEonCandDeclReqDTO(safeCast(results[13], EONCandDeclReqDTO.class, EONCandDeclReqDTO.empty()));
            dto.setEonhrDeclReqDTO(safeCast(results[14], EONHRDeclReqDTO.class, EONHRDeclReqDTO.empty()));
            dto.setEonOverallStatusReqDTO(safeCast(results[15], EONOverallStatusReqDTO.class, EONOverallStatusReqDTO.empty()));

            // Log summary of what data was received
            logDataSummary(candId, dto);

            return dto;
        });
    }

    private <T> T safeCast(Object obj, Class<T> clazz, T defaultValue) {
        if (clazz.isInstance(obj)) {
            return clazz.cast(obj);
        }
        logger.warn("Failed to cast object to {}, using default", clazz.getSimpleName());
        return defaultValue;
    }

    // Short retry-with-backoff used on every per-section external fetch. This does NOT
    // fix a data/mapping bug - it papers over transient contention on the shared
    // external session_id (a fetch that timed out was very likely just queued behind
    // its siblings on the external server, not actually failing), so a couple of quick
    // retries recovers data that would otherwise silently come back as empty().
    private Retry retrySpec(String candId, String dataType) {
        return Retry.backoff(2, Duration.ofMillis(500))
                .maxBackoff(Duration.ofSeconds(2))
                .doBeforeRetry(signal -> logger.warn(
                        "Retrying {} fetch for candidate {} (attempt {}) after: {}",
                        dataType, candId, signal.totalRetries() + 1, signal.failure().getMessage()));
    }

    private <T> Mono<T> fetchWithLogging(String candId, String dataType, Mono<T> mono) {
        return mono
                .doOnSubscribe(s -> logger.debug("Starting {} fetch for candidate: {}", dataType, candId))
                .doOnSuccess(result -> {
                    if (result == null) {
                        logger.warn("{} data returned null for candidate: {}", dataType, candId);
                    } else {
                        logger.debug("Successfully fetched {} for candidate: {}", dataType, candId);
                    }
                })
                .doOnError(e -> logger.error("Failed to fetch {} for candidate {}: {}", dataType, candId, e.getMessage()));
    }

    private void logDataSummary(String candId, CandidateFullDetailsDTO dto) {
        Map<String, Boolean> dataStatus = new LinkedHashMap<>();
        dataStatus.put("General", dto.getEonGeneralReqDTO() != null && !dto.getEonGeneralReqDTO().equals(EONGeneralReqDTO.empty()));
        dataStatus.put("Personal", dto.getEonPersonalReqDTO() != null && !dto.getEonPersonalReqDTO().equals(EONPersonalReqDTO.empty()));
        dataStatus.put("Education", dto.getEonEducationReqDTO() != null && !dto.getEonEducationReqDTO().equals(EONEducationReqDTO.empty()));
        dataStatus.put("Bank", dto.getEonBankReqDTO() != null && !dto.getEonBankReqDTO().equals(EONBankReqDTO.empty()));

        logger.info("Data summary for candidate {}: {}", candId, dataStatus);
    }

    private CandidateFullDetailsDTO createEmptyCandidateDetailsDTO(String candId) {
        CandidateFullDetailsDTO dto = new CandidateFullDetailsDTO();
        dto.setCandId(candId);
        dto.setEonGeneralReqDTO(EONGeneralReqDTO.empty());
        dto.setEonPersonalReqDTO(EONPersonalReqDTO.empty());
        dto.setEonEducationReqDTO(EONEducationReqDTO.empty());
        dto.setEonSkillReqDTO(EONSkillReqDTO.empty());
        dto.setEonFamilyReqDTO(EONFamilyReqDTO.empty());
        dto.setEonBankReqDTO(EONBankReqDTO.empty());
        dto.setEonpfReqDTO(EONPFReqDTO.empty());
        dto.setEonLanguageReqDTO(EONLanguageReqDTO.empty());
        dto.setEonInterestReqDTO(EONInterestReqDTO.empty());
        dto.setEonProfExpReqDTO(EONProfExpReqDTO.empty());
        dto.setEonProfRefReqDTO(EONProfRefReqDTO.empty());
        dto.setEonDocsProofReqDTO(EONDocsProofReqDTO.empty());
        dto.setEonDeclQnrReqDTO(EONDeclQnrReqDTO.empty());
        dto.setEonCandDeclReqDTO(EONCandDeclReqDTO.empty());
        dto.setEonhrDeclReqDTO(EONHRDeclReqDTO.empty());
        dto.setEonOverallStatusReqDTO(EONOverallStatusReqDTO.empty());
        return dto;
    }

//    @Override
//    public Mono<CandidateFullDetailsDTO> fetchHRCompletedCandidateDetailsById(String candId) {
//        // 1. First, fetch the valid sessionId internally
//        return onBoardingOperationsCandidates.overallHRCompletedCandIds()
//                .flatMap(tuple -> {
//                    String sessionId = tuple.getT1(); // Extract the session ID
//
//                    // 2. Use that session ID to fetch the specific candidate details
//                    return fetchCandidateDetailsReactive(candId, sessionId)
//                            .doOnNext(dto -> System.out.println("Fetched DTO for candidate: " + candId));
//                })
//                .doOnError(e -> System.err.println("Error in single candidate fetch: " + e.getMessage()));
//    }



//    @Override
//    public Mono<CandidateFullDetailsDTO> fetchCandidateDetailsReactive(String candId, String sessionId) {
//        Mono<EONGeneralReqDTO> general = onBoardingOperationsCandidates.fetchEonGeneralData(candId, sessionId)
//                .onErrorResume(ex -> {
//                    System.err.println("Failed to fetch general data for " + candId + ": " + ex.getMessage());
//                    return Mono.just( EONGeneralReqDTO.empty());
//                })
//                .defaultIfEmpty( EONGeneralReqDTO.empty());
//
//        Mono<EONPersonalReqDTO> personal = Mono.fromFuture(
//                onBoardingOperationsCandidates.fetchEonPersonalData(candId, sessionId)
//                        .exceptionally(ex -> {
//                            System.err.println("Failed to fetch personal data for " + candId + ": " + ex.getMessage());
//                            return EONPersonalReqDTO.empty(); // Return fallback DTO
//                        })
//        ).defaultIfEmpty(EONPersonalReqDTO.empty());
//
//
//
//        Mono<EONEducationReqDTO> education = onBoardingOperationsCandidates.fetchEonEducationData(candId, sessionId)
//                .onErrorResume(ex -> {
//                    System.err.println("Failed to fetch education data for " + candId + ": " + ex.getMessage());
//                    return Mono.just(EONEducationReqDTO.empty());
//                })
//                .defaultIfEmpty( EONEducationReqDTO.empty());
//
//        Mono<EONSkillReqDTO> skill = onBoardingOperationsCandidates.fetchEonSkillData(candId, sessionId)
//                .onErrorResume(ex -> {
//                    System.err.println("Failed to fetch skill data for " + candId + ": " + ex.getMessage());
//                    return Mono.just( EONSkillReqDTO.empty());
//                })
//                .defaultIfEmpty( EONSkillReqDTO.empty());
//
//        Mono<EONFamilyReqDTO> family = onBoardingOperationsCandidates.fetchEonFamilyData(candId,sessionId)
//                .onErrorResume(ex -> {
//                    System.err.println("Failed to fetch family data for " + candId + ": " + ex.getMessage());
//                    return Mono.just( EONFamilyReqDTO.empty());
//                })
//                .defaultIfEmpty( EONFamilyReqDTO.empty());
//
//        Mono<EONBankReqDTO> bank = onBoardingOperationsCandidates.fetchEonBankData(candId,sessionId)
//                .onErrorResume(ex -> {
//                    System.err.println("Failed to fetch bank data for " + candId + ": " + ex.getMessage());
//                    return Mono.just( EONBankReqDTO.empty());
//                })
//                .defaultIfEmpty( EONBankReqDTO.empty());
//
//        Mono<EONPFReqDTO> pf = onBoardingOperationsCandidates.fetchEonPfData(candId,sessionId)
//                .onErrorResume(ex -> {
//                    System.err.println("Failed to fetch pf data for " + candId + ": " + ex.getMessage());
//                    return Mono.just( EONPFReqDTO.empty());
//                })
//                .defaultIfEmpty( EONPFReqDTO.empty());
//
//        Mono<EONLanguageReqDTO> language = onBoardingOperationsCandidates.fetchEonLangData(candId,sessionId)
//                .onErrorResume(ex -> {
//                    System.err.println("Failed to fetch language data for " + candId + ": " + ex.getMessage());
//                    return Mono.just( EONLanguageReqDTO.empty());
//                })
//                .defaultIfEmpty( EONLanguageReqDTO.empty());
//
//        Mono<EONInterestReqDTO> interest = onBoardingOperationsCandidates.fetchEonInterestData(candId,sessionId)
//                .onErrorResume(ex -> {
//                    System.err.println("Failed to fetch interest data for " + candId + ": " + ex.getMessage());
//                    return Mono.just( EONInterestReqDTO.empty());
//                })
//                .defaultIfEmpty( EONInterestReqDTO.empty());
//
//        Mono<EONProfExpReqDTO> profExp = onBoardingOperationsCandidates.fetchEonProfExpData(candId,sessionId)
//                .onErrorResume(ex -> {
//                    System.err.println("Failed to fetch profexp data for " + candId + ": " + ex.getMessage());
//                    return Mono.just( EONProfExpReqDTO.empty());
//                })
//                .defaultIfEmpty( EONProfExpReqDTO.empty());
//
//        Mono<EONProfRefReqDTO> profRef = onBoardingOperationsCandidates.fetchEonProfRefData(candId,sessionId)
//                .onErrorResume(ex -> {
//                    System.err.println("Failed to fetch profref data for " + candId + ": " + ex.getMessage());
//                    return Mono.just( EONProfRefReqDTO.empty());
//                })
//                .defaultIfEmpty( EONProfRefReqDTO.empty());
//
//        Mono<EONDocsProofReqDTO> docsProof = Mono.fromFuture(onBoardingOperationsCandidates.fetchEonDocsProofData(candId,sessionId)
//                .exceptionally(ex -> {
//                    System.err.println("Failed to fetch docsproof data for " + candId + ": " + ex.getMessage());
//                    return EONDocsProofReqDTO.empty(); // Return fallback DTO
//                })
//        ).defaultIfEmpty(EONDocsProofReqDTO.empty());
//
//        Mono<EONDeclQnrReqDTO> declQnr = onBoardingOperationsCandidates.fetchEonDeclQnrData(candId, sessionId)
//                .onErrorResume(ex -> {
//                    System.err.println("Failed to fetch declqnr data for " + candId + ": " + ex.getMessage());
//                    return Mono.just( EONDeclQnrReqDTO.empty());
//                })
//                .defaultIfEmpty( EONDeclQnrReqDTO.empty());
//
//        Mono<EONCandDeclReqDTO> candDeclr = onBoardingOperationsCandidates.fetchEonCandDeclarationData(candId, sessionId)
//                .onErrorResume(ex -> {
//                    System.err.println("Failed to fetch candidatesdeclr data for " + candId + ": " + ex.getMessage());
//                    return Mono.just( EONCandDeclReqDTO.empty());
//                })
//                .defaultIfEmpty( EONCandDeclReqDTO.empty());
//
//        Mono<EONHRDeclReqDTO> hrDeclr = onBoardingOperationsCandidates.fetchEonHRDeclarationData(candId, sessionId)
//                .onErrorResume(ex -> {
//                    System.err.println("Failed to fetch hrdeclr data for " + candId + ": " + ex.getMessage());
//                    return Mono.just( EONHRDeclReqDTO.empty());
//                })
//                .defaultIfEmpty( EONHRDeclReqDTO.empty());
//
//        Mono<EONOverallStatusReqDTO> overallstatusCandidatesdata = onBoardingOperationsCandidates.overallStatusDataOfSingleCandidates(candId, sessionId)
//                .onErrorResume(ex -> {
//                    System.err.println("Failed to fetch overallstatuscandidatesdata data for " + candId + ": " + ex.getMessage());
//                    return Mono.just( EONOverallStatusReqDTO.empty());
//                })
//                .defaultIfEmpty( EONOverallStatusReqDTO.empty());
//
//
//        //        // Combine into a list of Monos
//        List<Mono<?>> monos = Arrays.asList(
//                general, personal, education, skill, family, bank, pf, language, interest,
//                profExp, profRef, docsProof, declQnr, candDeclr, hrDeclr,overallstatusCandidatesdata
//        );
//
//        // Use Mono.zip with array of Monos
//        return Mono.zip(monos, results -> {
//            CandidateFullDetailsDTO dto = new CandidateFullDetailsDTO();
//            dto.setCandId(candId);
//            dto.setEonGeneralReqDTO((EONGeneralReqDTO) results[0]);
//            dto.setEonPersonalReqDTO((EONPersonalReqDTO) results[1]);
//            dto.setEonEducationReqDTO((EONEducationReqDTO) results[2]);
//            dto.setEonSkillReqDTO((EONSkillReqDTO) results[3]);
//            dto.setEonFamilyReqDTO((EONFamilyReqDTO) results[4]);
//            dto.setEonBankReqDTO((EONBankReqDTO) results[5]);
//            dto.setEonpfReqDTO((EONPFReqDTO) results[6]);
//            dto.setEonLanguageReqDTO((EONLanguageReqDTO) results[7]);
//            dto.setEonInterestReqDTO((EONInterestReqDTO) results[8]);
//            dto.setEonProfExpReqDTO((EONProfExpReqDTO) results[9]);
//            dto.setEonProfRefReqDTO((EONProfRefReqDTO) results[10]);
//            dto.setEonDocsProofReqDTO((EONDocsProofReqDTO) results[11]);
//            dto.setEonDeclQnrReqDTO((EONDeclQnrReqDTO) results[12]);
//            dto.setEonCandDeclReqDTO((EONCandDeclReqDTO) results[13]);
//            dto.setEonhrDeclReqDTO((EONHRDeclReqDTO) results[14]);
//            dto.setEonOverallStatusReqDTO((EONOverallStatusReqDTO) results[15]);
//            return dto;
//        });
//    }

    @Override
    public void saveOnBoardingCandidatesDetails(CandidateFullDetailsDTO dto) throws Exception {
        List<CompletableFuture<Void>> futures = new ArrayList<>();

//        if (dto.getEonPersonalReqDTO() != null) {
//            // eonPersonalRepository.save(onBoardingMapper.toPersonalEntity(dto.getEonPersonalReqDTO()));
//            EONPersonal eonPerosnalData = onBoardingMapper.toEntity(dto.getEonPersonalReqDTO());
//            System.out.println("eon personal request data===" + eonPerosnalData);
//            if (eonPerosnalData != null) {
//                List<DocumentDTO> personaldto = urlToMultipartFileConvert.handleFileForwarding(dto.getEonPersonalReqDTO().filePhotoImage().get(0), dto.getEonPersonalReqDTO().filePhotoImage().get(1), dto.getEonPersonalReqDTO().candID());
//                Long docId = personaldto.get(0).getDocId();
//                eonPerosnalData.setFilePhotoImageDocID(docId);
//                eonPersonalRepository.save(eonPerosnalData);
//            }
//        }

        // 1. Handle Personal Data (Resiliently)
        if (dto.getEonPersonalReqDTO() != null) {
            EONPersonal eonPersonalData = onBoardingMapper.toEntity(dto.getEonPersonalReqDTO());
            String candId = dto.getEonPersonalReqDTO().candID();

            try {
                // If this fails, it won't stop the rest of the method
                List<DocumentDTO> personaldto = urlToMultipartFileConvert.handleFileForwarding(
                        dto.getEonPersonalReqDTO().filePhotoImage().get(0),
                        dto.getEonPersonalReqDTO().filePhotoImage().get(1),
                        candId
                );
                if (personaldto != null && !personaldto.isEmpty()) {
                    eonPersonalData.setFilePhotoImageDocID(personaldto.get(0).getDocId());
                }
            } catch (Exception e) {
                System.err.println("WARNING: Photo download failed for " + candId + ". Proceeding without photo. Error: " + e.getMessage());
            }
            eonPersonalRepository.save(eonPersonalData);
        }

        if (dto.getEonGeneralReqDTO() != null) {
            futures.add(CompletableFuture.runAsync(() -> {
                eonGeneralRepository.save(onBoardingMapper.toGeneralEntity(dto.getEonGeneralReqDTO()));
            }, onboardingExecutor));
        }


        if (dto.getEonEducationReqDTO() != null) {
            futures.add(CompletableFuture.runAsync(() -> {
                eonEducationRepository.save(onBoardingMapper.toEducationEntity(dto.getEonEducationReqDTO()));
            }, onboardingExecutor));
        }

        if (dto.getEonSkillReqDTO() != null) {
            futures.add(CompletableFuture.runAsync(() -> {
                eonSkillRepository.save(onBoardingMapper.toSkillEntity(dto.getEonSkillReqDTO()));
            }, onboardingExecutor));
        }

        if (dto.getEonFamilyReqDTO() != null) {
            futures.add(CompletableFuture.runAsync(() -> {
                eonFamilyRepository.save(onBoardingMapper.toFamilyEntity(dto.getEonFamilyReqDTO()));
            }, onboardingExecutor));
        }

        if (dto.getEonBankReqDTO() != null) {
            futures.add(CompletableFuture.runAsync(() -> {
                eonBankRepository.save(onBoardingMapper.toBankEntity(dto.getEonBankReqDTO()));
            }, onboardingExecutor));
        }

        if (dto.getEonpfReqDTO() != null) {
            futures.add(CompletableFuture.runAsync(() -> {
                eonpfRepository.save(onBoardingMapper.toPFEntity(dto.getEonpfReqDTO()));
            }, onboardingExecutor));
        }

        if (dto.getEonLanguageReqDTO() != null) {
            futures.add(CompletableFuture.runAsync(() -> {
                eonLanguageRepository.save(onBoardingMapper.toLanguageEntity(dto.getEonLanguageReqDTO()));
            }, onboardingExecutor));
        }

        if (dto.getEonInterestReqDTO() != null) {
            futures.add(CompletableFuture.runAsync(() -> {
                eonInterestRepository.save(onBoardingMapper.toInterestEntity(dto.getEonInterestReqDTO()));
            }, onboardingExecutor));
        }

        if (dto.getEonProfExpReqDTO() != null) {
            futures.add(CompletableFuture.runAsync(() -> {
                eonProfessionalExpRepository.save(onBoardingMapper.toProfExpEntity(dto.getEonProfExpReqDTO()));
            }, onboardingExecutor));
        }

        if (dto.getEonProfRefReqDTO() != null) {
            futures.add(CompletableFuture.runAsync(() -> {
                eonProfReferRepository.save(onBoardingMapper.toProfRefEntity(dto.getEonProfRefReqDTO()));
            }, onboardingExecutor));
        }

        if (dto.getEonDocsProofReqDTO() != null) {
            // eonDocProofRepository.save(onBoardingMapper.toDocsProofEntity(dto.getEonDocsProofReqDTO()));


            EONDocumentProof eonDocumentProofdata = onBoardingMapper.toEonDocsProofEntity(dto.getEonDocsProofReqDTO());

            if (eonDocumentProofdata != null) {
                String candId = dto.getEonDocsProofReqDTO().candID();

                // Use the helper method to handle each document
                // Use ONLY the safeHandleDocument method
                eonDocumentProofdata.setAadharDocId(safeHandleDocumentSingle(dto.getEonDocsProofReqDTO().fileAadhar(), candId));
                eonDocumentProofdata.setFilePANDocId(safeHandleDocumentSingle(dto.getEonDocsProofReqDTO().filePAN(), candId));
                eonDocumentProofdata.setFileVoterDocId(safeHandleDocumentSingle(dto.getEonDocsProofReqDTO().fileVoter(), candId));
                eonDocumentProofdata.setFileAddrProof1DocId(safeHandleDocumentSingle(dto.getEonDocsProofReqDTO().fileAddrProof1(), candId));
                eonDocumentProofdata.setFileDrivingDocId(safeHandleDocumentSingle(dto.getEonDocsProofReqDTO().fileDriving(), candId));
                eonDocumentProofdata.setFileEmpDocId(safeHandleDocumentSingle(dto.getEonDocsProofReqDTO().fileEmp(), candId));
                eonDocumentProofdata.setFilePassportDocId(safeHandleDocumentSingle(dto.getEonDocsProofReqDTO().filePassport(), candId));
                eonDocumentProofdata.setFileAddrProof2DocId(safeHandleDocumentSingle(dto.getEonDocsProofReqDTO().fileAddrProof2(), candId));
                eonDocumentProofdata.setFileAddrProof3DocId(safeHandleDocumentSingle(dto.getEonDocsProofReqDTO().fileAddrProof3(), candId));
                // Save and return response DTO
                //onBoardingMapper.toDocsProofEntity(eonDocProofRepository.save(eonDocumentProofdata));
                eonDocProofRepository.save(eonDocumentProofdata);

            }
        }

        if (dto.getEonDeclQnrReqDTO() != null) {
            futures.add(CompletableFuture.runAsync(() -> {
                eonDeclQuestRepository.save(onBoardingMapper.toDeclQnrEntity(dto.getEonDeclQnrReqDTO()));
            }, onboardingExecutor));
        }

        if (dto.getEonCandDeclReqDTO() != null) {
            futures.add(CompletableFuture.runAsync(() -> {
                eonCandDeclRepository.save(onBoardingMapper.toCandDeclEntity(dto.getEonCandDeclReqDTO()));
            }, onboardingExecutor));
        }

        if (dto.getEonhrDeclReqDTO() != null) {
            futures.add(CompletableFuture.runAsync(() -> {
                eonhrDeclarationRepository.save(onBoardingMapper.toHRDeclEntity(dto.getEonhrDeclReqDTO()));
            }, onboardingExecutor));
        }

        if (dto.getEonOverallStatusReqDTO() != null) {
            futures.add(CompletableFuture.runAsync(() -> {
                dto.getEonOverallStatusReqDTO().setOverallStatus("Initiated");
                eonOverallStatusRepository.save(onBoardingMapper.toOverallStatusEntity(dto.getEonOverallStatusReqDTO()));
            }, onboardingExecutor));
        }
        CompletableFuture
                .allOf(futures.toArray(new CompletableFuture[0]))
                .join();
    }

    // Helper for DocsProof
    private Long safeHandleDocumentSingle(List<String> fileUrls, String candId) {
        try {
            if (fileUrls == null || fileUrls.size() < 2) return null;
            List<DocumentDTO> docs = urlToMultipartFileConvert.handleFileForwarding(fileUrls.get(0), fileUrls.get(1), candId);
            return (docs != null && !docs.isEmpty()) ? docs.get(0).getDocId() : null;
        } catch (Exception e) {
            System.err.println("Upload failed for " + candId + ": " + e.getMessage());
            return null;
        }
    }

    private List<Long> safeHandleDocumentList(List<String> fileUrls, String candId) {
        Long id = safeHandleDocumentSingle(fileUrls, candId);
        return (id != null) ? List.of(id) : null;
    }

//@Override
//    public void saveOnBoardingCandidatesDetails(CandidateFullDetailsDTO dto) throws Exception {
//        List<CompletableFuture<Void>> futures = new ArrayList<>();
//
//        if (dto.getEonPersonalReqDTO() != null) {
//            // eonPersonalRepository.save(onBoardingMapper.toPersonalEntity(dto.getEonPersonalReqDTO()));
//            EONPersonal eonPerosnalData = onBoardingMapper.toEntity(dto.getEonPersonalReqDTO());
//            System.out.println("eon personal request data===" + eonPerosnalData);
//            if (eonPerosnalData != null) {
//                List<DocumentDTO> personaldto = urlToMultipartFileConvert.handleFileForwarding(dto.getEonPersonalReqDTO().filePhotoImage().get(0), dto.getEonPersonalReqDTO().filePhotoImage().get(1), dto.getEonPersonalReqDTO().candID());
//                Long docId = personaldto.get(0).getDocId();
//                eonPerosnalData.setFilePhotoImageDocID(docId);
//                eonPersonalRepository.save(eonPerosnalData);
//            }
//        }
//
//        if (dto.getEonGeneralReqDTO() != null) {
//        eonGeneralRepository.save(onBoardingMapper.toGeneralEntity(dto.getEonGeneralReqDTO()));
//        }
//
//        if (dto.getEonEducationReqDTO() != null) {
//            eonEducationRepository.save(onBoardingMapper.toEducationEntity(dto.getEonEducationReqDTO()));
//        }
//
//        if (dto.getEonSkillReqDTO() != null) {
//            eonSkillRepository.save(onBoardingMapper.toSkillEntity(dto.getEonSkillReqDTO()));
//        }
//
//        if (dto.getEonFamilyReqDTO() != null) {
//            eonFamilyRepository.save(onBoardingMapper.toFamilyEntity(dto.getEonFamilyReqDTO()));
//        }
//
//        if (dto.getEonBankReqDTO() != null) {
//            eonBankRepository.save(onBoardingMapper.toBankEntity(dto.getEonBankReqDTO()));
//        }
//
//        if (dto.getEonpfReqDTO() != null) {
//            eonpfRepository.save(onBoardingMapper.toPFEntity(dto.getEonpfReqDTO()));
//        }
//
//        if (dto.getEonLanguageReqDTO() != null) {
//            eonLanguageRepository.save(onBoardingMapper.toLanguageEntity(dto.getEonLanguageReqDTO()));
//        }
//
//        if (dto.getEonInterestReqDTO() != null) {
//            eonInterestRepository.save(onBoardingMapper.toInterestEntity(dto.getEonInterestReqDTO()));
//        }
//
//        if (dto.getEonProfExpReqDTO() != null) {
//            eonProfessionalExpRepository.save(onBoardingMapper.toProfExpEntity(dto.getEonProfExpReqDTO()));
//        }
//
//        if (dto.getEonProfRefReqDTO() != null) {
//            eonProfReferRepository.save(onBoardingMapper.toProfRefEntity(dto.getEonProfRefReqDTO()));
//        }
//
//        if (dto.getEonDocsProofReqDTO() != null) {
//            // eonDocProofRepository.save(onBoardingMapper.toDocsProofEntity(dto.getEonDocsProofReqDTO()));
//
//
//            EONDocumentProof eonDocumentProofdata = onBoardingMapper.toEonDocsProofEntity(dto.getEonDocsProofReqDTO());
//
//            if (eonDocumentProofdata != null) {
//                String candId = dto.getEonDocsProofReqDTO().candID();
//
//                // Use the helper method to handle each document
//                eonDocumentProofdata.setAadharDocId(handleDocument(dto.getEonDocsProofReqDTO().fileAadhar(), candId));
//                eonDocumentProofdata.setFilePANDocId(handleDocument(dto.getEonDocsProofReqDTO().filePAN(), candId));
//                eonDocumentProofdata.setFileVoterDocId(handleDocument(dto.getEonDocsProofReqDTO().fileVoter(), candId));
//                eonDocumentProofdata.setFileAddrProof1DocId(handleDocument(dto.getEonDocsProofReqDTO().fileAddrProof1(), candId));
//                eonDocumentProofdata.setFileDrivingDocId(handleDocument(dto.getEonDocsProofReqDTO().fileDriving(), candId));
//                eonDocumentProofdata.setFileEmpDocId(handleDocument(dto.getEonDocsProofReqDTO().fileEmp(), candId));
//                eonDocumentProofdata.setFilePassportDocId(handleDocument(dto.getEonDocsProofReqDTO().filePassport(), candId));
//                eonDocumentProofdata.setFileAddrProof2DocId(handleDocument(dto.getEonDocsProofReqDTO().fileAddrProof2(), candId));
//                eonDocumentProofdata.setFileAddrProof3DocId(handleDocument(dto.getEonDocsProofReqDTO().fileAddrProof3(), candId));
//
//                // Save and return response DTO
//                //onBoardingMapper.toDocsProofEntity(eonDocProofRepository.save(eonDocumentProofdata));
//                eonDocProofRepository.save(eonDocumentProofdata);
//
//            }
//        }
//
//        if (dto.getEonDeclQnrReqDTO() != null) {
//            eonDeclQuestRepository.save(onBoardingMapper.toDeclQnrEntity(dto.getEonDeclQnrReqDTO()));
//        }
//
//        if (dto.getEonCandDeclReqDTO() != null) {
//            eonCandDeclRepository.save(onBoardingMapper.toCandDeclEntity(dto.getEonCandDeclReqDTO()));
//        }
//
//        if (dto.getEonhrDeclReqDTO() != null) {
//            eonhrDeclarationRepository.save(onBoardingMapper.toHRDeclEntity(dto.getEonhrDeclReqDTO()));
//        }
//
//    if (dto.getEonOverallStatusReqDTO() != null) {
//        dto.getEonOverallStatusReqDTO().setOverallStatus("Initiated");
//        eonOverallStatusRepository.save(onBoardingMapper.toOverallStatusEntity(dto.getEonOverallStatusReqDTO()));
//    }
//    }

    //to save document id in dms//
    private Long handleDocument(List<String> fileUrls, String candId) throws Exception {
        if (fileUrls == null || fileUrls.size() < 2) {
            throw new IllegalArgumentException("Expected two file URLs, but got: " + fileUrls);
        }

        List<DocumentDTO> docs = urlToMultipartFileConvert.handleFileForwarding(fileUrls.get(0), fileUrls.get(1), candId);
        if (docs == null || docs.isEmpty()) {
            throw new IllegalStateException("Document forwarding failed or returned empty list");
        }

        return docs.get(0).getDocId();
    }
    //fetch data from local entity class///
    @Override
    public EONPersonal fetchEonPersonalData(String candId) {
        EONPersonal eonPersonalList= eonPersonalRepository.findByCandID(candId);
        return eonPersonalList;
    }

    @Override
    public EONBank fetchEonBankData(String candId) {
        EONBank eonBank=eonBankRepository.findByCandID(candId);
        return eonBank;
    }

    @Override
    public EONCandidateDeclaration fetchEonCandidateDeclarationData(String candId) {
        EONCandidateDeclaration eonCandidateDeclaration=eonCandDeclRepository.findByCandID(candId);
        return eonCandidateDeclaration;
    }

    @Override
    public EONDeclQuestionnaire fetchEonDeclQuestionnaireData(String candId) {
        EONDeclQuestionnaire eonDeclQuestionnaire=eonDeclQuestRepository.findByCandID(candId);
        return eonDeclQuestionnaire;
    }

    @Override
    public EONDocumentProof fetchEonDocumentProofData(String candId) {
        EONDocumentProof eonDocumentProof=eonDocProofRepository.findByCandID(candId);
        return eonDocumentProof;
    }

    @Override
    public EONEducation fetchEonEducationData(String candId) {
        EONEducation eonEducation=eonEducationRepository.findByCandID(candId);
        return eonEducation;
    }

    @Override
    public EONFamily fetchEonFamilyData(String candId) {
        EONFamily eonFamily=eonFamilyRepository.findByCandID(candId);
        return eonFamily;
    }

    @Override
    public EONGeneral fetchEonGeneralData(String candId) {
        EONGeneral eonGeneral=eonGeneralRepository.findByCandID(candId);
        return eonGeneral;
    }

    @Override
    public EONHRDeclaration fetchEonHRDeclarationData(String candId) {
        EONHRDeclaration eonhrDeclaration=eonhrDeclarationRepository.findByCandID(candId);
        return eonhrDeclaration;
    }

    @Override
    public EONInterest fetchEonInterestData(String candId) {
        EONInterest eonInterest=eonInterestRepository.findByCandID(candId);
        return eonInterest;
    }

    @Override
    public EONLanguage fetchEonLanguageData(String candId) {
        EONLanguage eonLanguage=eonLanguageRepository.findByCandID(candId);
        return eonLanguage;
    }

    @Override
    public EONOverallStatus fetchEonOverallStatusData(String candId) {
        EONOverallStatus eonOverallStatus=eonOverallStatusRepository.findByCandID(candId);
        return eonOverallStatus;
    }

    @Override
    public EONPF fetchEonPFData(String candId) {
        EONPF eonpf=eonpfRepository.findByCandID(candId);
        return eonpf;
    }

    @Override
    public EONProfessionalReference fetchEonProfessionalReferenceData(String candId) {
        EONProfessionalReference eonProfessionalReference=eonProfReferRepository.findByCandID(candId);
        return eonProfessionalReference;
    }

    @Override
    public EONProfressionalExperience fetchEonProfressionalExperienceData(String candId) {
        EONProfressionalExperience eonProfressionalExperience = eonProfessionalExpRepository.findByCandID(candId);
        return eonProfressionalExperience;
    }

    @Override
    public EONSkill fetchEonSkillData(String candId) {
        EONSkill eonSkill=eonSkillRepository.findByCandID(candId);
        return eonSkill;
    }



//    @Override
//    public EmployeeOnboardingInfo saveEmployeeDataInOnboardingTable(EmployeeOnboardingInfo onboardingInfo) {
//        // Assuming empOnboardingRefNum1 is unique for each candidate
//        Optional<EmployeeOnboardingInfo> existingRecord =
//                repository.findByEmpOnboardingRefNum(onboardingInfo.getEmpOnboardingRefNum());
//
////        if (existingRecord.isPresent()) {
////            EmployeeOnboardingInfo existing = existingRecord.get();
////
////            // Update only required fields
////            existing.setIsProbationApplicable(onboardingInfo.getIsProbationApplicable());
////            existing.setRptManagerName(onboardingInfo.getRptManagerName());
////            existing.setRptMgrEmployeeCode(onboardingInfo.getRptMgrEmployeeCode());
////            existing.setRptManagerEmailId(onboardingInfo.getRptManagerEmailId());
////            existing.setMlwfApplicability(onboardingInfo.getMlwfApplicability());
////            existing.setGmcApplicability(onboardingInfo.getGmcApplicability());
////            existing.setGtlApplicability(onboardingInfo.getGtlApplicability());
////            existing.setGpaApplicability(onboardingInfo.getGpaApplicability());
////            existing.setWcApplicability(onboardingInfo.getWcApplicability());
////            existing.setHiringHr(onboardingInfo.getHiringHr());
////            existing.setEeSubgroup(onboardingInfo.getEeSubgroup());
////            existing.setEmploymentStatus(onboardingInfo.getEmploymentStatus());
////            existing.setGrade(onboardingInfo.getGrade());
////            existing.setPayrollAreaType(onboardingInfo.getPayrollAreaType());
////            existing.setBuHead(onboardingInfo.getBuHead());
////            existing.setMainDepartment(onboardingInfo.getMainDepartment());
////            existing.setSubDepartment(onboardingInfo.getSubDepartment());
////            existing.setProject(onboardingInfo.getProject());
////            existing.setOrganisationCode(onboardingInfo.getOrganisationCode());
////            existing.setDesignation(onboardingInfo.getDesignation());
////            existing.setOrganisationHierarchy(onboardingInfo.getOrganisationHierarchy());
////            existing.setFullNameAsPerPAN(onboardingInfo.getFullNameAsPerPAN());
////            existing.setCurrentPfNumber(onboardingInfo.getCurrentPfNumber());
////            existing.setCurrentESICNumber(onboardingInfo.getCurrentESICNumber());
////            existing.setStatus(onboardingInfo.getStatus());
////            existing.setConfirmationDate(onboardingInfo.getConfirmationDate());
////            existing.setProbationPeriod(onboardingInfo.getProbationPeriod());
////            existing.setMaxProbationExtension(onboardingInfo.getMaxProbationExtension());
////            existing.setGender(onboardingInfo.getGender());
////
//        if (existingRecord.isPresent()) {
//            EmployeeOnboardingInfo existing = existingRecord.get();
//            onBoardingMapper.updateEmployeeOnboardingInfoFromDto(onboardingInfo, existing);
//            return repository.save(existing);
//
//        } else {
//            // Insert new
//            return repository.save(onboardingInfo);
//        }
//    }

    @Override
    public EmployeeOnboardingInfo saveEmployeeDataInOnboardingTable(EmployeeOnboardingInfo onboardingInfo) {
        // This is the implementation provided in the user's context
        Optional<EmployeeOnboardingInfo> existingRecord =
                employeeRepo.findByEmpOnboardingRefNum(onboardingInfo.getEmpOnboardingRefNum());

        if (existingRecord.isPresent()) {
            EmployeeOnboardingInfo existing = existingRecord.get();
            // Assuming onBoardingMapper.updateEmployeeOnboardingInfoFromDto correctly maps fields
            onBoardingMapper.updateEmployeeOnboardingInfoFromDto(onboardingInfo, existing);
            return employeeRepo.save(existing);
        } else {
            // Insert new
            return employeeRepo.save(onboardingInfo);
        }
    }


    @Override
    @Transactional
    public EmployeeDiretoryDetailsDTO saveCandidateDetails(String candId, EmployeeDiretoryDetailsDTO completeDto) {

        // ... (logic for EmployeeOnboardingInfo, Personal, and General remains correct, as it was fixed previously)

        // 1. EmployeeOnboardingInfo (Main Table)
        if (completeDto.getEmployeeOnboardingInfo() != null) {
            EmployeeOnboardingInfo existingInfo = employeeRepo.findByCandID(candId);
            EmployeeOnboardingInfo entityToSave;

            if (existingInfo != null) {
                // Found existing record: UPDATE
                // Copy fields from DTO to existing entity, ignoring 'id' and 'candID'
                BeanUtils.copyProperties(completeDto.getEmployeeOnboardingInfo(), existingInfo, "id", "candID");
                entityToSave = existingInfo;
            } else {
                // No existing record: INSERT
                entityToSave = completeDto.getEmployeeOnboardingInfo();
            }

            entityToSave.setCandID(candId);
            EmployeeOnboardingInfo savedInfo = employeeRepo.save(entityToSave);
            completeDto.setEmployeeOnboardingInfo(savedInfo);
        }

        // 2. Personal Info
        if (completeDto.getPersonal() != null) {
            EONPersonal existing = eonPersonalRepository.findByCandID(candId);
            EONPersonal entityToSave;

            if (existing != null) {
                BeanUtils.copyProperties(completeDto.getPersonal(), existing, "id", "candID");
                entityToSave = existing;
            } else {
                entityToSave = completeDto.getPersonal();
            }

            entityToSave.setCandID(candId);
            EONPersonal savedPersonal = eonPersonalRepository.save(entityToSave);
            completeDto.setPersonal(savedPersonal);
        }

        // 3. General Info
        if (completeDto.getGeneral() != null) {
            EONGeneral existing = eonGeneralRepository.findByCandID(candId);
            EONGeneral entityToSave;

            if (existing != null) {
                BeanUtils.copyProperties(completeDto.getGeneral(), existing, "id", "candID");
                entityToSave = existing;
            } else {
                entityToSave = completeDto.getGeneral();
            }

            entityToSave.setCandID(candId);
            EONGeneral savedGeneral = eonGeneralRepository.save(entityToSave);
            completeDto.setGeneral(savedGeneral);
        }

        // 4. Family Info
        if (completeDto.getFamily() != null) {
            EONFamily existing = eonFamilyRepository.findByCandID(candId);
            EONFamily entityToSave;

            if (existing != null) {
                // Found existing record: UPDATE
                // 1. Perform copy operation (returns void)
                BeanUtils.copyProperties(completeDto.getFamily(), existing, "id", "candID");
                // 2. Set entityToSave to the updated existing object
                entityToSave = existing;
            } else {
                // No existing record: INSERT
                entityToSave = completeDto.getFamily();
            }

            entityToSave.setCandID(candId);
            completeDto.setFamily(eonFamilyRepository.save(entityToSave));
        }

        // 5. Bank Info
        if (completeDto.getBank() != null) {
            EONBank existing = eonBankRepository.findByCandID(candId);
            EONBank entityToSave;

            if (existing != null) {
                BeanUtils.copyProperties(completeDto.getBank(), existing, "id", "candID");
                entityToSave = existing;
            } else {
                entityToSave = completeDto.getBank();
            }

            entityToSave.setCandID(candId);
            completeDto.setBank(eonBankRepository.save(entityToSave));
        }

        // 6. Statutory Details (PF)
        if (completeDto.getPf() != null) {
            EONPF existing = eonpfRepository.findByCandID(candId);
            EONPF entityToSave;

            if (existing != null) {
                BeanUtils.copyProperties(completeDto.getPf(), existing, "id", "candID");
                entityToSave = existing;
            } else {
                entityToSave = completeDto.getPf();
            }

            entityToSave.setCandID(candId);
            completeDto.setPf(eonpfRepository.save(entityToSave));
        }

        // 7. Skills
        if (completeDto.getSkill() != null) {
            EONSkill existing = eonSkillRepository.findByCandID(candId);
            EONSkill entityToSave;

            if (existing != null) {
                BeanUtils.copyProperties(completeDto.getSkill(), existing, "id", "candID");
                entityToSave = existing;
            } else {
                entityToSave = completeDto.getSkill();
            }

            entityToSave.setCandID(candId);
            completeDto.setSkill(eonSkillRepository.save(entityToSave));
        }

        // 8. Education
        if (completeDto.getEducation() != null) {
            EONEducation existing = eonEducationRepository.findByCandID(candId);
            EONEducation entityToSave;

            if (existing != null) {
                BeanUtils.copyProperties(completeDto.getEducation(), existing, "id", "candID");
                entityToSave = existing;
            } else {
                entityToSave = completeDto.getEducation();
            }

            entityToSave.setCandID(candId);
            completeDto.setEducation(eonEducationRepository.save(entityToSave));
        }
        //9.cnaddecl///

        if (completeDto.getCandidateDeclaration() != null) {
            EONCandidateDeclaration existing = eonCandDeclRepository.findByCandID(candId);
            EONCandidateDeclaration entityToSave;

            if (existing != null) {
                BeanUtils.copyProperties(completeDto.getCandidateDeclaration(), existing, "id", "candID");
                entityToSave = existing;
            } else {
                entityToSave = completeDto.getCandidateDeclaration();
            }

            entityToSave.setCandID(candId);
            completeDto.setCandidateDeclaration(eonCandDeclRepository.save(entityToSave));
        }

        //10.declarationQuestion///

        if (completeDto.getDeclQuestionnaire() != null) {
            EONDeclQuestionnaire existing = eonDeclQuestRepository.findByCandID(candId);
            EONDeclQuestionnaire entityToSave;

            if (existing != null) {
                BeanUtils.copyProperties(completeDto.getDeclQuestionnaire(), existing, "id", "candID");
                entityToSave = existing;
            } else {
                entityToSave = completeDto.getDeclQuestionnaire();
            }

            entityToSave.setCandID(candId);
            completeDto.setDeclQuestionnaire(eonDeclQuestRepository.save(entityToSave));
        }

        //11.docs proof///

        if (completeDto.getDocumentProof() != null) {
            EONDocumentProof existing = eonDocProofRepository.findByCandID(candId);
            EONDocumentProof entityToSave;

            if (existing != null) {
                BeanUtils.copyProperties(completeDto.getDocumentProof(), existing, "id", "candID");
                entityToSave = existing;
            } else {
                entityToSave = completeDto.getDocumentProof();
            }

            entityToSave.setCandID(candId);
            completeDto.setDocumentProof(eonDocProofRepository.save(entityToSave));
        }

        //12.Hr Declaration///

        if (completeDto.getHrDeclaration() != null) {
            EONHRDeclaration existing = eonhrDeclarationRepository.findByCandID(candId);
            EONHRDeclaration entityToSave;

            if (existing != null) {
                BeanUtils.copyProperties(completeDto.getHrDeclaration(), existing, "id", "candID");
                entityToSave = existing;
            } else {
                entityToSave = completeDto.getHrDeclaration();
            }

            entityToSave.setCandID(candId);
            completeDto.setHrDeclaration(eonhrDeclarationRepository.save(entityToSave));
        }

        //13.Interest///

        if (completeDto.getInterest() != null) {
            EONInterest existing = eonInterestRepository.findByCandID(candId);
            EONInterest entityToSave;

            if (existing != null) {
                BeanUtils.copyProperties(completeDto.getInterest(), existing, "id", "candID");
                entityToSave = existing;
            } else {
                entityToSave = completeDto.getInterest();
            }

            entityToSave.setCandID(candId);
            completeDto.setInterest(eonInterestRepository.save(entityToSave));
        }

        // 14. Language
        if (completeDto.getLanguage() != null) {
            EONLanguage existing = eonLanguageRepository.findByCandID(candId);
            EONLanguage entityToSave;

            if (existing != null) {
                BeanUtils.copyProperties(completeDto.getLanguage(), existing, "id", "candID");
                entityToSave = existing;
            } else {
                entityToSave = completeDto.getLanguage();
            }

            entityToSave.setCandID(candId);
            completeDto.setLanguage(eonLanguageRepository.save(entityToSave));
        }

        // 15. Overallstatus
        if (completeDto.getOverallStatus() != null) {
            EONOverallStatus existing = eonOverallStatusRepository.findByCandID(candId);
            EONOverallStatus entityToSave;

            if (existing != null) {
                BeanUtils.copyProperties(completeDto.getOverallStatus(), existing, "id", "candID");
                entityToSave = existing;
            } else {
                entityToSave = completeDto.getOverallStatus();
            }

            entityToSave.setCandID(candId);
            completeDto.setOverallStatus(eonOverallStatusRepository.save(entityToSave));
        }

        // 16. ProfessionalRef
        if (completeDto.getProfReference() != null) {
            EONProfessionalReference existing = eonProfReferRepository.findByCandID(candId);
            EONProfessionalReference entityToSave;

            if (existing != null) {
                BeanUtils.copyProperties(completeDto.getProfReference(), existing, "id", "candID");
                entityToSave = existing;
            } else {
                entityToSave = completeDto.getProfReference();
            }

            entityToSave.setCandID(candId);
            completeDto.setProfReference(eonProfReferRepository.save(entityToSave));
        }

        // 17. Professional Experience
        if (completeDto.getProfExp() != null) {
            EONProfressionalExperience existing = eonProfessionalExpRepository.findByCandID(candId);
            EONProfressionalExperience entityToSave;

            if (existing != null) {
                BeanUtils.copyProperties(completeDto.getProfExp(), existing, "id", "candID");
                entityToSave = existing;
            } else {
                entityToSave = completeDto.getProfExp();
            }

            entityToSave.setCandID(candId);
            completeDto.setProfExp(eonProfessionalExpRepository.save(entityToSave));
        }

        // ... continue this corrected UPSERT pattern for all other remaining entities ...

        return completeDto;
    }


//    @Override
//    public EmployeeOnboardingInfo saveEmployeeDataInOnboardingTable(EmployeeOnboardingInfo onboardingInfo) {
//        return repository.save(onboardingInfo);
//    }

    @Override
    public List<EmployeeDiretoryDetailsDTO> getAllCandidates() {
        List<EmployeeOnboardingInfo> employees = employeeRepo.findAll();

        return employees.stream().map(emp -> {
            String candId = emp.getCandID();
            EmployeeDiretoryDetailsDTO dto = new EmployeeDiretoryDetailsDTO();
            dto.setCandId(candId);

            // Use the ternary operator to check for null and instantiate a new object if null

            // 1. EONGeneral
            EONGeneral general = eonGeneralRepository.findByCandID(candId);
            dto.setGeneral(general != null ? general : new EONGeneral());

            // 2. EONPersonal
            EONPersonal personal = eonPersonalRepository.findByCandID(candId);
            dto.setPersonal(personal != null ? personal : new EONPersonal());

            // 3. EONFamily
            EONFamily family = eonFamilyRepository.findByCandID(candId);
            dto.setFamily(family != null ? family : new EONFamily());

            // 4. EONBank
            EONBank bank = eonBankRepository.findByCandID(candId);
            dto.setBank(bank != null ? bank : new EONBank());

            // 5. EONCandidateDeclaration
            EONCandidateDeclaration candDecl = eonCandDeclRepository.findByCandID(candId);
            dto.setCandidateDeclaration(candDecl != null ? candDecl : new EONCandidateDeclaration());

            // 6. EONDeclQuestionnaire
            EONDeclQuestionnaire declQuest = eonDeclQuestRepository.findByCandID(candId);
            dto.setDeclQuestionnaire(declQuest != null ? declQuest : new EONDeclQuestionnaire());

            // 7. EONDocumentProof
            EONDocumentProof docProof = eonDocProofRepository.findByCandID(candId);
            dto.setDocumentProof(docProof != null ? docProof : new EONDocumentProof());

            // 8. EONEducation
            EONEducation education = eonEducationRepository.findByCandID(candId);
            dto.setEducation(education != null ? education : new EONEducation());

            // 9. EONHRDeclaration
            EONHRDeclaration hrDecl = eonhrDeclarationRepository.findByCandID(candId);
            dto.setHrDeclaration(hrDecl != null ? hrDecl : new EONHRDeclaration());

            // 10. EONInterest
            EONInterest interest = eonInterestRepository.findByCandID(candId);
            dto.setInterest(interest != null ? interest : new EONInterest());

            // 11. EONLanguage
            EONLanguage language = eonLanguageRepository.findByCandID(candId);
            dto.setLanguage(language != null ? language : new EONLanguage());

            // 12. EONOverallStatus
            EONOverallStatus overallStatus = eonOverallStatusRepository.findByCandID(candId);
            dto.setOverallStatus(overallStatus != null ? overallStatus : new EONOverallStatus());

            // 13. EONPF
            EONPF pf = eonpfRepository.findByCandID(candId);
            dto.setPf(pf != null ? pf : new EONPF());

            // 14. EONProfessionalReference
            EONProfessionalReference profRef = eonProfReferRepository.findByCandID(candId);
            dto.setProfReference(profRef != null ? profRef : new EONProfessionalReference());

            // 15. EONProfressionalExperience
            EONProfressionalExperience profExp = eonProfessionalExpRepository.findByCandID(candId);
            dto.setProfExp(profExp != null ? profExp : new EONProfressionalExperience());

            // 16. EONSkill
            EONSkill skill = eonSkillRepository.findByCandID(candId);
            dto.setSkill(skill != null ? skill : new EONSkill());

            // 17. EmployeeOnboardingInfo (Likely always exists, but for consistency)
            EmployeeOnboardingInfo onboardingInfo = employeeRepo.findByCandID(candId);
            dto.setEmployeeOnboardingInfo(onboardingInfo != null ? onboardingInfo : new EmployeeOnboardingInfo());

            return dto;
        }).collect(Collectors.toList());
    }

//@Override
//    public List<EmployeeDiretoryDetailsDTO> getAllCandidates() {
//        List<EmployeeOnboardingInfo> employees = employeeRepo.findAll();
//
//        return employees.stream().map(emp -> {
//            String candId = emp.getCandID();
//            EmployeeDiretoryDetailsDTO dto = new EmployeeDiretoryDetailsDTO();
//           dto.setCandId(candId);
//            dto.setGeneral(eonGeneralRepository.findByCandID(candId));
//            dto.setPersonal(eonPersonalRepository.findByCandID(candId));
//            dto.setFamily(eonFamilyRepository.findByCandID(candId));
//            dto.setBank(eonBankRepository.findByCandID(candId));
//            dto.setCandidateDeclaration(eonCandDeclRepository.findByCandID(candId));
//            dto.setDeclQuestionnaire(eonDeclQuestRepository.findByCandID(candId));
//            dto.setDocumentProof(eonDocProofRepository.findByCandID(candId));
//            dto.setEducation(eonEducationRepository.findByCandID(candId));
//            dto.setHrDeclaration(eonhrDeclarationRepository.findByCandID(candId));
//            dto.setInterest(eonInterestRepository.findByCandID(candId));
//            dto.setLanguage(eonLanguageRepository.findByCandID(candId));
//            dto.setOverallStatus(eonOverallStatusRepository.findByCandID(candId));
//            dto.setPf(eonpfRepository.findByCandID(candId));
//            dto.setProfReference(eonProfReferRepository.findByCandID(candId));
//            dto.setProfExp(eonProfessionalExpRepository.findByCandID(candId));
//            dto.setSkill(eonSkillRepository.findByCandID(candId));
//            dto.setEmployeeOnboardingInfo(employeeRepo.findByCandID(candId));
//            return dto;
//        }).collect(Collectors.toList());
//    }

    @Override
    public EmployeeDiretoryDetailsDTO getCandidateDetailsById(String candId) {
        EmployeeOnboardingInfo emp = employeeRepo.findByCandID(candId);
        if (emp == null) return null;

        EmployeeDiretoryDetailsDTO dto = new EmployeeDiretoryDetailsDTO();
        dto.setCandId(candId);
        dto.setGeneral(eonGeneralRepository.findByCandID(candId));
        dto.setPersonal(eonPersonalRepository.findByCandID(candId));
        dto.setFamily(eonFamilyRepository.findByCandID(candId));
        dto.setBank(eonBankRepository.findByCandID(candId));
        dto.setCandidateDeclaration(eonCandDeclRepository.findByCandID(candId));
        dto.setDeclQuestionnaire(eonDeclQuestRepository.findByCandID(candId));
        dto.setDocumentProof(eonDocProofRepository.findByCandID(candId));
        dto.setEducation(eonEducationRepository.findByCandID(candId));
        dto.setHrDeclaration(eonhrDeclarationRepository.findByCandID(candId));
        dto.setInterest(eonInterestRepository.findByCandID(candId));
        dto.setLanguage(eonLanguageRepository.findByCandID(candId));
        dto.setOverallStatus(eonOverallStatusRepository.findByCandID(candId));
        dto.setPf(eonpfRepository.findByCandID(candId));
        dto.setProfReference(eonProfReferRepository.findByCandID(candId));
        dto.setProfExp(eonProfessionalExpRepository.findByCandID(candId));
        dto.setSkill(eonSkillRepository.findByCandID(candId));
        dto.setEmployeeOnboardingInfo(employeeRepo.findByCandID(candId));

        return dto;
    }


    @Override
    @Transactional
    public EmployeeDiretoryDetailsDTO updateCandidateDetails(String candId, EmployeeDiretoryDetailsDTO updatedDto) {

        // 1. EmployeeOnboardingInfo (Main Table)
        if (updatedDto.getEmployeeOnboardingInfo() != null) {
            EmployeeOnboardingInfo existingInfo = employeeRepo.findByCandID(candId);
            if (existingInfo != null) {
                // The candID from the path is used implicitly by fetching 'existingInfo'
                BeanUtils.copyProperties(updatedDto.getEmployeeOnboardingInfo(), existingInfo, "id", "candID");
                employeeRepo.save(existingInfo);
            }
        }

        // 2. Personal Info (Already Correct)
        if (updatedDto.getPersonal() != null) {
            EONPersonal existing = eonPersonalRepository.findByCandID(candId);
            if (existing != null) {
                BeanUtils.copyProperties(updatedDto.getPersonal(), existing, "id", "candID");
                eonPersonalRepository.save(existing);
            }
        }

        // 3. General Info (CORRECTION APPLIED)
        if (updatedDto.getGeneral() != null) {
            EONGeneral existing = eonGeneralRepository.findByCandID(candId);
            if (existing != null) {
                BeanUtils.copyProperties(updatedDto.getGeneral(), existing, "id", "candID");
                eonGeneralRepository.save(existing);
            }
        }

        // 4. Family Info (CORRECTION APPLIED)
        if (updatedDto.getFamily() != null) {
            EONFamily existing = eonFamilyRepository.findByCandID(candId);
            if (existing != null) {
                BeanUtils.copyProperties(updatedDto.getFamily(), existing, "id", "candID");
                eonFamilyRepository.save(existing);
            }
        }

        // 5. Bank Info (CORRECTION APPLIED)
        if (updatedDto.getBank() != null) {
            EONBank existing = eonBankRepository.findByCandID(candId);
            if (existing != null) {
                BeanUtils.copyProperties(updatedDto.getBank(), existing, "id", "candID");
                eonBankRepository.save(existing);
            }
        }

        // 6. Statutory Details (PF) (CORRECTION APPLIED)
        if (updatedDto.getPf() != null) {
            EONPF existing = eonpfRepository.findByCandID(candId);
            if (existing != null) {
                BeanUtils.copyProperties(updatedDto.getPf(), existing, "id", "candID");
                eonpfRepository.save(existing);
            }
        }

        // 7. Skills (CORRECTION APPLIED)
        if (updatedDto.getSkill() != null) {
            EONSkill existing = eonSkillRepository.findByCandID(candId);
            if (existing != null) {
                BeanUtils.copyProperties(updatedDto.getSkill(), existing, "id", "candID");
                eonSkillRepository.save(existing);
            }
        }

        // 8. Education (CORRECTION APPLIED - Example)
        if (updatedDto.getEducation() != null) {
            EONEducation existing = eonEducationRepository.findByCandID(candId);
            if (existing != null) {
                BeanUtils.copyProperties(updatedDto.getEducation(), existing, "id", "candID");
                eonEducationRepository.save(existing);
            }
        }

        //9.cnaddecl///

        if (updatedDto.getCandidateDeclaration() != null) {
            EONCandidateDeclaration existing = eonCandDeclRepository.findByCandID(candId);

            if (existing != null) {
                BeanUtils.copyProperties(updatedDto.getCandidateDeclaration(), existing, "id", "candID");
                eonCandDeclRepository.save(existing);
            }

        }

        //10.declarationQuestion///

        if (updatedDto.getDeclQuestionnaire() != null) {
            EONDeclQuestionnaire existing = eonDeclQuestRepository.findByCandID(candId);
            EONDeclQuestionnaire entityToSave;

            if (existing != null) {
                BeanUtils.copyProperties(updatedDto.getDeclQuestionnaire(), existing, "id", "candID");
                eonDeclQuestRepository.save(existing);
            }


        }

        //11.docs proof///

        if (updatedDto.getDocumentProof() != null) {
            EONDocumentProof existing = eonDocProofRepository.findByCandID(candId);

            if (existing != null) {
                BeanUtils.copyProperties(updatedDto.getDocumentProof(), existing, "id", "candID");
                eonDocProofRepository.save(existing);
            }

        }

        //12.Hr Declaration///

        if (updatedDto.getHrDeclaration() != null) {
            EONHRDeclaration existing = eonhrDeclarationRepository.findByCandID(candId);

            if (existing != null) {
                BeanUtils.copyProperties(updatedDto.getHrDeclaration(), existing, "id", "candID");
                eonhrDeclarationRepository.save(existing);
            }

        }

        //13.Interest///

        if (updatedDto.getInterest() != null) {
            EONInterest existing = eonInterestRepository.findByCandID(candId);

            if (existing != null) {
                BeanUtils.copyProperties(updatedDto.getInterest(), existing, "id", "candID");
                eonInterestRepository.save(existing);
            }
        }

        // 14. Language
        if (updatedDto.getLanguage() != null) {
            EONLanguage existing = eonLanguageRepository.findByCandID(candId);

            if (existing != null) {
                BeanUtils.copyProperties(updatedDto.getLanguage(), existing, "id", "candID");
                eonLanguageRepository.save(existing);
            }
        }

        // 15. Overallstatus
        if (updatedDto.getOverallStatus() != null) {
            EONOverallStatus existing = eonOverallStatusRepository.findByCandID(candId);

            if (existing != null) {
                BeanUtils.copyProperties(updatedDto.getOverallStatus(), existing, "id", "candID");
                eonOverallStatusRepository.save(existing);
            }
        }

        // 16. ProfessionalRef
        if (updatedDto.getProfReference() != null) {
            EONProfessionalReference existing = eonProfReferRepository.findByCandID(candId);

            if (existing != null) {
                BeanUtils.copyProperties(updatedDto.getProfReference(), existing, "id", "candID");
                eonProfReferRepository.save(existing);
            }
        }


        // 17. Professional Experience (CORRECTION APPLIED - Example)
        if (updatedDto.getProfExp() != null) {
            EONProfressionalExperience existing = eonProfessionalExpRepository.findByCandID(candId);
            if (existing != null) {
                BeanUtils.copyProperties(updatedDto.getProfExp(), existing, "id", "candID");
                eonProfessionalExpRepository.save(existing);
            }
        }

        // ... and so on for all remaining entities ...

        // 10. Return the updated DTO (or refetch the entity data)
        return updatedDto;
    }


    @Override
    public EmployeeOnboardingInfo getCandidateByCandId(String candID) {
        return  employeeRepo.findByCandID(candID);

    }
    @Override
    public EmployeeOnboardingInfo updateCandidate(String candID, EmployeeOnboardingInfo updated) {
        EmployeeOnboardingInfo existing = getCandidateByCandId(candID);
        existing.setFullNameAsPerPAN(updated.getFullNameAsPerPAN());
        existing.setMainDepartment(updated.getMainDepartment());
        existing.setDesignation(updated.getDesignation());
        existing.setConfirmationDate(updated.getConfirmationDate());
        existing.setMainDepartment(updated.getMainDepartment());
        existing.setDesignation(updated.getDesignation());
        existing.setRptManagerName(updated.getRptManagerName());
        existing.setHiringHr(updated.getHiringHr());
        existing.setEmploymentStatus(updated.getEmploymentStatus());
        // Only update if the incoming payload has a value for it.
        if (updated.getExcelExportStatus() != null) {
            existing.setExcelExportStatus(updated.getExcelExportStatus());
        }
        return employeeRepo.save(existing);
    }

    @Override
    public void deleteCandidate(String candID) {
        employeeRepo.deleteByCandID(candID);
    }

    @Override
    public boolean deactivateCandidate(String candID) {
        EONOverallStatus status = eonOverallStatusRepository.findByCandID(candID);

        if (status == null) {
            return false;
        }

        status.setOverallStatus("InActive");
        eonOverallStatusRepository.save(status);

        return true;
    }

    // NEW: activateCandidate method
    @Override
    @Transactional
    public boolean activateCandidate(String candID) {
        EONOverallStatus status = eonOverallStatusRepository.findByCandID(candID);
        if (status == null) {
            return false; // Candidate not found
        }
        status.setOverallStatus("Active"); // Sets to Active
        eonOverallStatusRepository.save(status);
        return true;
    }


}