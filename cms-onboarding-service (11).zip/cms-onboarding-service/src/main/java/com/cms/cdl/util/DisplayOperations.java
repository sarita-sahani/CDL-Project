package com.cms.cdl.util;

import com.cms.cdl.dto.request_dto.display_dto.*;
import com.cms.cdl.dto.request_dto.onboarding_req_dto.EONDeclQnrReqDTO;
import com.cms.cdl.dto.request_dto.onboarding_req_dto.EONEducationReqDTO;
import com.cms.cdl.dto.request_dto.onboarding_req_dto.EONOverallStatusReqDTO;
import com.cms.cdl.dto.request_dto.wrapperDTO.*;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.time.Duration;
import java.util.*;
import java.util.stream.StreamSupport;

@Component
@Slf4j
public class DisplayOperations {

    @Value("${eon.base.API}")
    private String externalBaseUrl;
    @Value("${generate.session-id.API}")
    private String sessionIdAPI;
    @Value("${job.post.base-API}")
    private String jobPostBaseAPI;
    @Value("${tech.panel.base-API}")
    private String techPanelBaseAPI;
    @Value("${interview.schedule.base-API}")
    private String interviewScheduleBaseAPI;
    @Value("${interview.feedback.base-API}")
    private String interviewFeedbackBaseAPI;
    @Value("${job.application.base-API}")
    private  String jobApplicationBaseAPI;

    public String jobApplicationAPI = "&user_id=admin&page_name=list_jobappl_data";
    //public String jobApplicationAPI ="&user_id=admin&page_name=mod_jobappl_data&JOB_APP_ID=12";
    public String techPanelAPI = "&user_id=admin&page_name=list_ipanel_data&EmpID=_NA_";
    public String jobPostAPI = "&user_id=admin&page_name=mod_jobpost_data";
    // public String jobPostAPI = "&user_id=admin&page_name=mod_jobpost_data&INT_REF_DATA=1234";
    public String interviewScheduleAPI = "&user_id=admin&page_name=list_intview_data";
    public String interviewFeedbackAPI = "&user_id=admin&page_name=list_intfb_data";

    private final WebClient webClient = WebClient.builder()
            .filter((request, next) -> {
                log.info("➡️ Outgoing request: {} {}", request.method(), request.url());
                return next.exchange(request);
            })
            .build();

    // ----- Session handling -----
    // NOTE: this used to cache the session id forever (a single `.cache()`'d Mono,
    // refreshed only via refreshSessionId() - a method nothing in the codebase ever
    // called). That meant the very first session obtained after app startup was
    // reused for the lifetime of the process, across every candidate and every
    // request. Once that one session expired/got invalidated server-side, every
    // fetch using it would start silently returning empty data with no way to
    // recover short of restarting the app. There is now no caching at all: every
    // call to generateSessionId() performs a fresh login.

    // ----- Server health check (ping) -----
    // Called before every fresh session-id fetch, mirroring
    // ErecruitmentOperations#isServerUp, so we fail fast with a clear
    // message instead of letting the session call hang/timeout.
    private Mono<Boolean> isServerUp() {
        String url = externalBaseUrl + "ping?RetFormat=JSON&input_data=cdl";
        return webClient.get()
                .uri(url)
                .accept(MediaType.APPLICATION_JSON)
                .retrieve()
                .bodyToMono(String.class)
                .timeout(Duration.ofSeconds(5))
                .map(response -> {
                    if (response == null || response.isBlank()) {
                        log.error("❌ Session-id ping returned an empty response");
                        return false;
                    }
                    try {
                        ObjectMapper mapper = new ObjectMapper();
                        JsonNode root = mapper.readTree(response);
                        if (root.isArray() && root.size() > 0) root = root.get(0);
                        int retcode = root.path("retcode").asInt(0);
                        boolean up = retcode == 1;
                        if (!up) {
                            log.error("❌ Session-id ping responded but retcode={} (server considered down)", retcode);
                        }
                        return up;
                    } catch (Exception e) {
                        log.error("❌ Failed to parse session-id ping response: {}", e.getMessage());
                        return false;
                    }
                })
                .onErrorResume(e -> {
                    log.error("❌ Session-id ping failed: {}", e.getMessage());
                    return Mono.just(false);
                });
    }

    /**
     * Reactive equivalent of ErecruitmentOperations#ensureServerIsUp.
     * Errors out before attempting a login if the ping says the server is down.
     */
    private Mono<Void> ensureServerIsUp() {
        return isServerUp()
                .flatMap(up -> up
                        ? Mono.<Void>empty()
                        : Mono.error(new RuntimeException("Session service is down. Please try again later.")));
    }

    /**
     * Calls the session-id API and extracts session_id (equivalent of
     * ErecruitmentOperations#loginAdmin). Always preceded by ensureServerIsUp().
     * Called fresh every time - no caching, see note above.
     */
    private Mono<String> fetchNewSessionId() {
        log.info("Calling session-id API to obtain a fresh session id");
        return webClient.get()
                .uri(sessionIdAPI)
                .accept(MediaType.APPLICATION_JSON)
                .retrieve()
                .bodyToMono(new ParameterizedTypeReference<Map<String, Object>>() {})
                .timeout(Duration.ofSeconds(5))
                .onErrorMap(throwable -> {
                    log.error("❌ Failed to obtain session id: {}", throwable.getMessage());
                    return new RuntimeException("Failed to obtain session id", throwable);
                })
                .flatMap(responseMap -> {
                    Object sessionIdObj = responseMap.get("session_id");
                    if (sessionIdObj != null) {
                        return Mono.just(sessionIdObj.toString());
                    } else {
                        log.error("❌ Session ID not found in response: {}", responseMap);
                        return Mono.error(new RuntimeException("Session ID not found in response"));
                    }
                });
    }

    /**
     * Public entry point used by every fetch method below. Always performs a fresh
     * login - deliberately not cached. See the note above the session-handling
     * section for why a cached session was the actual cause of intermittent nulls.
     */
    public Mono<String> generateSessionId() {
        return ensureServerIsUp().then(fetchNewSessionId());
    }


    public Mono<List<JobPostDTO>> fetchJobPostData(String intRefData) {
        return generateSessionId()
                .flatMap(sessionId -> {
                    // Construct URL
                    String url = jobPostBaseAPI + sessionId + jobPostAPI;
                    if (intRefData != null && !intRefData.isBlank() && !intRefData.equalsIgnoreCase("all")) {
                        url += "&INT_REF_DATA=" + intRefData;
                    }
                    System.out.println("jobpost url=====" +url);
                    return WebClient.create().get()
                            .uri(url)
                            .accept(MediaType.APPLICATION_JSON)
                            .retrieve()
                            .bodyToMono(JobPostWrapperDTO.class)
                            .map(wrapper -> {
                                Object rawData = wrapper.getRetdata();

                                // Configure the mapper to ignore unknown properties
                                ObjectMapper mapper = new ObjectMapper();
                                mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

                                if (rawData == null) {
                                    return Collections.emptyList();
                                }

                                if (rawData instanceof List) {
                                    return mapper.convertValue(rawData, new TypeReference<List<JobPostDTO>>() {});
                                } else {
                                    JobPostDTO singleJob = mapper.convertValue(rawData, JobPostDTO.class);
                                    return Collections.singletonList(singleJob);
                                }

                            });
                });
    }
    //    public Mono<List<JobPostDTO>> fetchJobPostData(String intRefData) {
//        return generateSessionId()
//                .flatMap(sessionId -> WebClient.create().get()
//                        .uri(jobPostBaseAPI + sessionId + jobPostAPI + intRefData)
//                        .accept(MediaType.APPLICATION_JSON)
//                        .retrieve()
//                        .bodyToMono(JobPostWrapperDTO.class)
//                        .map(JobPostWrapperDTO::getRetdata)
//                );
//
//    }
    public Mono<List<TechPanelDTO>> fetchTechPanelData() {
        return generateSessionId()
                .flatMap(sessionId -> WebClient.create().get()
                        .uri(techPanelBaseAPI + sessionId + techPanelAPI)
                        .accept(MediaType.APPLICATION_JSON)
                        .retrieve()
                        .bodyToMono(TechPanelWrapperDTO.class)
                        .map(TechPanelWrapperDTO::getRetdata)
                );
    }


    public Mono<List<InterviewScheduleDTO>> fetchInterviewScheduleData(int jobAppId) {
        return generateSessionId()
                .flatMap(sessionId -> {
                    String url = interviewScheduleBaseAPI + sessionId + interviewScheduleAPI + "&JobAppID=" + jobAppId;
                    System.out.println("interview schedule data==="+url);
                    return WebClient.create().get()
                            .uri(url)
                            .accept(MediaType.APPLICATION_JSON)
                            .retrieve()
                            .bodyToMono(InterviewScheduleWrapperDTO.class)
                            .map(wrapper -> wrapper.getRetdata() == null
                                    ? Collections.<InterviewScheduleDTO>emptyList()
                                    : wrapper.getRetdata());
                });
    }


    public Mono<List<InterviewFeedbackDTO>> fetchInterviewFeedbackData(int jobAppNum) {
        return generateSessionId()
                .flatMap(sessionId -> {
                    // Update with your actual external API URL structure
                    // Assuming it takes JOB_ID as a query param
                    String url = interviewFeedbackBaseAPI + sessionId + interviewFeedbackAPI + "&JobAppNum=" + jobAppNum;
                    System.out.println("interview feedback===="+url);
                    return WebClient.create().get()
                            .uri(url)
                            .accept(MediaType.APPLICATION_JSON)
                            .retrieve()
                            .bodyToMono(InterviewFeedbackWrapperDTO.class)
                            .map(wrapper -> wrapper.getRetdata() == null
                                    ? Collections.<InterviewFeedbackDTO>emptyList()
                                    : wrapper.getRetdata());
                });
    }



    public Mono<List<JobApplicationDTO>> fetchJobApplicationData(int jobId) {
        return generateSessionId()
                .flatMap(sessionId -> {
                    String url = jobApplicationBaseAPI + sessionId + jobApplicationAPI + "&JOB_ID=" + jobId;
                    System.out.println("jobapplication url==="+url);
                    return WebClient.create().get()
                            .uri(url)
                            .accept(MediaType.APPLICATION_JSON)
                            .retrieve()
                            .bodyToMono(JobApplicationWrapperDTO.class)
                            .map(wrapper -> {
                                List<JobApplicationDTO> data = wrapper.getRetdata();
                                return data == null ? Collections.<JobApplicationDTO>emptyList() : data;
                            });
                });
    }


}