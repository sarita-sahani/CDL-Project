package com.cms.cdl.dto.request_dto.display_dto;

import com.cms.cdl.deserializer.UserIdOrArrayDeserializer;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import java.time.LocalDate;

public record InterviewScheduleDTO(
        @JsonProperty("IntNum") int intNum,
        @JsonProperty("JobAppID") int jobAppID,
        @JsonProperty("JobPostID") int jobPostID,
        @JsonProperty("PanelID") String panelID,
        @JsonProperty("IntDate") String intDate,
        @JsonProperty("StartTime") String startTime,
        @JsonProperty("EndTime") String endTime,
        @JsonProperty("IntMode") String intMode,
        @JsonProperty("MeetingLink") String meetingLink,
        @JsonProperty("MeetingInfo") String meetingInfo,
        @JsonProperty("Remarks") String remarks,
        @JsonProperty("IntStatus") String intStatus,
        @JsonProperty("ScheduledByUser")
        @JsonDeserialize(using = UserIdOrArrayDeserializer.class)
        String scheduledByUser,

        @JsonProperty("ScheduledDate ") String scheduledDate,
        @JsonProperty("OWNER_USERID")
        @JsonDeserialize(using = UserIdOrArrayDeserializer.class)
        String ownerUserID,
        @JsonProperty("OWNER_USERORG") String ownerUserOrg,
        @JsonProperty("MeetingICS") String meetingICS,
        @JsonProperty("PanelUserID")
        @JsonDeserialize(using = UserIdOrArrayDeserializer.class)
        String panelUserID,
        @JsonProperty("IntType") String intType
) {
}

