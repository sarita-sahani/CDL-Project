import React from "react";
import { useNavigate } from "react-router-dom";
import Header from "../components/Header";
import { Heart, Star, Target } from "lucide-react";

const FLECKS = [
  "absolute rounded-full w-1.5 h-1.5 bg-[#FFD700] opacity-80 top-[12%] left-[6%] motion-safe:animate-pulse [animation-delay:0s]",
  "absolute rounded-full w-1 h-1 bg-[#FFA500] opacity-80 top-[28%] left-[14%] motion-safe:animate-pulse [animation-delay:0.6s]",
  "absolute rounded-full w-2 h-2 bg-[#FFD700] opacity-80 top-[8%] left-[22%] motion-safe:animate-pulse [animation-delay:1.2s]",
  "absolute rounded-full w-1 h-1 bg-[#FF6B35] opacity-80 top-[22%] left-[33%] motion-safe:animate-pulse [animation-delay:1.8s]",
  "absolute rounded-full w-1.5 h-1.5 bg-[#FFD700] opacity-80 top-[5%] left-[41%] motion-safe:animate-pulse [animation-delay:2.4s]",
  "absolute rounded-full w-1 h-1 bg-[#FFA500] opacity-80 top-[18%] left-[52%] motion-safe:animate-pulse [animation-delay:0.3s]",
  "absolute rounded-full w-2 h-2 bg-[#FFD700] opacity-80 top-[9%] left-[63%] motion-safe:animate-pulse [animation-delay:0.9s]",
  "absolute rounded-full w-1 h-1 bg-[#FF6B35] opacity-80 top-[24%] left-[71%] motion-safe:animate-pulse [animation-delay:1.5s]",
  "absolute rounded-full w-1.5 h-1.5 bg-[#FFD700] opacity-80 top-[6%] left-[82%] motion-safe:animate-pulse [animation-delay:2.1s]",
  "absolute rounded-full w-1 h-1 bg-[#FFA500] opacity-80 top-[20%] left-[91%] motion-safe:animate-pulse [animation-delay:0.4s]",
  "absolute rounded-full w-1.5 h-1.5 bg-[#FFA500] opacity-80 top-[82%] left-[8%] motion-safe:animate-pulse [animation-delay:1.1s]",
  "absolute rounded-full w-1 h-1 bg-[#FFD700] opacity-80 top-[90%] left-[18%] motion-safe:animate-pulse [animation-delay:1.7s]",
  "absolute rounded-full w-2 h-2 bg-[#FF6B35] opacity-80 top-[78%] left-[29%] motion-safe:animate-pulse [animation-delay:2.3s]",
  "absolute rounded-full w-1 h-1 bg-[#FFA500] opacity-80 top-[94%] left-[38%] motion-safe:animate-pulse [animation-delay:0.2s]",
  "absolute rounded-full w-1.5 h-1.5 bg-[#FFD700] opacity-80 top-[84%] left-[47%] motion-safe:animate-pulse [animation-delay:0.8s]",
  "absolute rounded-full w-1 h-1 bg-[#FFA500] opacity-80 top-[92%] left-[58%] motion-safe:animate-pulse [animation-delay:1.4s]",
  "absolute rounded-full w-2 h-2 bg-[#FFD700] opacity-80 top-[80%] left-[68%] motion-safe:animate-pulse [animation-delay:2s]",
  "absolute rounded-full w-1 h-1 bg-[#FF6B35] opacity-80 top-[96%] left-[77%] motion-safe:animate-pulse [animation-delay:0.5s]",
  "absolute rounded-full w-1.5 h-1.5 bg-[#FFA500] opacity-80 top-[86%] left-[88%] motion-safe:animate-pulse [animation-delay:1s]",
  "absolute rounded-full w-1 h-1 bg-[#FFD700] opacity-80 top-[76%] left-[96%] motion-safe:animate-pulse [animation-delay:1.6s]",
  "absolute rounded-full w-0.5 h-0.5 bg-white opacity-90 top-[15%] left-[45%] motion-safe:animate-ping [animation-delay:0.5s]",
  "absolute rounded-full w-0.5 h-0.5 bg-white opacity-90 top-[85%] left-[55%] motion-safe:animate-ping [animation-delay:1.3s]",
  "absolute rounded-full w-1 h-1 bg-white opacity-70 top-[45%] left-[75%] motion-safe:animate-pulse [animation-delay:0.7s]",
  "absolute rounded-full w-0.5 h-0.5 bg-white opacity-90 top-[35%] left-[20%] motion-safe:animate-ping [animation-delay:1.9s]",
  "absolute rounded-full w-1 h-1 bg-white opacity-70 top-[65%] left-[40%] motion-safe:animate-pulse [animation-delay:0.1s]",
];

const SPARKLES = [
  "absolute text-[#FFD700] text-2xl opacity-60 top-[3%] left-[15%] motion-safe:animate-pulse [animation-delay:0.2s]",
  "absolute text-[#FF6B35] text-xl opacity-50 top-[2%] right-[20%] motion-safe:animate-pulse [animation-delay:0.8s]",
  "absolute text-[#FFD700] text-3xl opacity-40 bottom-[5%] left-[25%] motion-safe:animate-pulse [animation-delay:1.4s]",
  "absolute text-[#FFA500] text-xl opacity-50 bottom-[3%] right-[15%] motion-safe:animate-pulse [animation-delay:2s]",
  "absolute text-[#FFD700] text-2xl opacity-30 top-[45%] left-[5%] motion-safe:animate-pulse [animation-delay:0.6s]",
  "absolute text-[#FF6B35] text-2xl opacity-30 top-[40%] right-[4%] motion-safe:animate-pulse [animation-delay:1.6s]",
];

const AWARD_CATEGORIES = [
  {
    icon: Heart,
    title: "WORLD OF THANKS",
    iconColor: "from-amber-500 to-orange-500",
    description: "An employee can recognise another.",
    buttonText: "Recognise Now",
    buttonAction: "/recognise-now/WORLDOFTHANKS",
    status: "active",
    requiresManager: false,
  },
  {
    icon: Star,
    title: "BRAVO",
    iconColor: "from-red-500 to-rose-500",
    description: "Manager to recognize his direct Reportee.",
    buttonText: "Recognise Now",
    buttonAction: "/recognise-now/BRAVO",
    status: "active",
    requiresManager: true,
  },
  {
    icon: Target,
    title: "SPECIAL RECOGNITION",
    iconColor: "from-indigo-500 to-purple-500",
    description: "An Exceptional Recognition for employees who have won Bravo.",
    buttonText: "Coming Soon",
    buttonAction: "#",
    status: "coming-soon",
    requiresManager: false,
  },
];

const HatsOffScreen = () => {
  const navigate = useNavigate();

  const roles = JSON.parse(sessionStorage.getItem("role") || "[]");
  const isManager = roles.includes("CMS Manager");

  return (
    <>
      <Header />
      <div className="px-2 pt-6 pb-10 mt-[70px] min-h-[calc(105vh-60px)]">
        <div className="w-full max-w-7xl mx-auto">
          <div className="rounded-[1.4rem] p-[3px] shadow-2xl shadow-black/30 bg-[linear-gradient(135deg,#FF6B35_0%,#FF7559_35%,#FFD700_50%,#FF7559_65%,#FF6B35_100%)]">
            <div className="relative overflow-hidden rounded-[1.2rem] ring-1 ring-[#FFD700]/40 bg-[linear-gradient(180deg,#1a2a6c_0%,#3a1c47_40%,#7a1b2e_70%,#b91c1c_100%)]">
              {/* Decorative elements */}
              <div className="pointer-events-none absolute inset-0">
                {FLECKS.map((cls, i) => (
                  <span key={i} className={cls} />
                ))}
              </div>

              <div className="pointer-events-none absolute inset-0">
                {SPARKLES.map((cls, i) => (
                  <span key={`sparkle-${i}`} className={cls}>
                    ✦
                  </span>
                ))}
              </div>

              <div className="pointer-events-none absolute -top-16 -left-16 w-56 h-56 rounded-full bg-[#FFD700]/20 blur-3xl" />
              <div className="pointer-events-none absolute -bottom-20 -right-20 w-72 h-72 rounded-full bg-[#FF6B35]/15 blur-3xl" />

              {/* Corner decorations */}
              <span className="pointer-events-none absolute top-3 right-3 w-6 h-6 border-t border-r border-[#FFD700]/60 rounded-tr-md" />
              <span className="pointer-events-none absolute bottom-3 right-3 w-6 h-6 border-b border-r border-[#FFD700]/60 rounded-br-md" />
              <span className="pointer-events-none absolute bottom-3 left-3 w-6 h-6 border-b border-l border-[#FFD700]/60 rounded-bl-md" />
              <span className="pointer-events-none absolute top-3 left-3 w-6 h-6 border-t border-l border-[#FFD700]/60 rounded-tl-md" />

              {/* Header with Hats Off - Logo from image */}
              <div className="relative z-10 flex flex-col items-center justify-center pt-10">
                <svg
                  width="80"
                  height="80"
                  viewBox="0 0 100 100"
                  className="drop-shadow-xl"
                >
                  {/* Top hat */}
                  <rect x="25" y="20" width="50" height="40" rx="4" fill="#2C1810" />
                  <rect x="25" y="20" width="50" height="40" rx="4" stroke="#FFD700" strokeWidth="2" />
                  
                  {/* Hat brim */}
                  <rect x="15" y="55" width="70" height="10" rx="3" fill="#2C1810" />
                  <rect x="15" y="55" width="70" height="10" rx="3" stroke="#FFD700" strokeWidth="2" />
                  
                  {/* Hat band */}
                  <rect x="25" y="38" width="50" height="6" fill="#FFD700" />
                  
                  {/* Star on hat */}
                  <polygon
                    points="50,28 53,36 62,36 55,41 57,50 50,45 43,50 45,41 38,36 47,36"
                    fill="#FFD700"
                    stroke="#E85D2C"
                    strokeWidth="1"
                  />
                  
                  {/* Sparkle dots around hat */}
                  <circle cx="18" cy="30" r="2" fill="#FFD700" opacity="0.8" />
                  <circle cx="82" cy="30" r="2" fill="#FFD700" opacity="0.8" />
                  <circle cx="15" cy="45" r="1.5" fill="#FFA500" opacity="0.6" />
                  <circle cx="85" cy="45" r="1.5" fill="#FFA500" opacity="0.6" />
                  <circle cx="20" cy="18" r="1.5" fill="#FFD700" opacity="0.5" />
                  <circle cx="80" cy="18" r="1.5" fill="#FFD700" opacity="0.5" />
                </svg>

                <h1 className="mt-3 text-4xl font-bold tracking-wide text-[#FFD700] drop-shadow-lg">
                  HATS OFF
                </h1>
              </div>

              {/* Award Categories - Three Cards Layout */}
              <div className="relative z-10 px-6 md:px-14 pt-14 pb-24">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-x-6 gap-y-8">
                  {AWARD_CATEGORIES.map((award, i) => {
                    const Icon = award.icon;
                    const shouldShowButton =
                      award.status === "active" &&
                      (!award.requiresManager || (award.requiresManager && isManager));

                    return (
                      <div key={i} className="flex flex-col items-start">
                        {/* Icon and Title */}
                        <div className="relative flex items-center mb-4">
                          <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${award.iconColor} flex items-center justify-center shadow-md flex-shrink-0 -mr-3 z-10`}>
                            <Icon size={18} className="text-white" />
                          </div>
                          <div className="bg-white rounded-full pl-8 pr-6 py-2.5 shadow-lg">
                            <span className="text-[#b91c1c] font-bold tracking-wide text-xs md:text-sm whitespace-nowrap">
                              {award.title}
                            </span>
                          </div>
                        </div>

                        {/* Description */}
                        <p className="text-[#FFF5E6] text-sm leading-relaxed drop-shadow-sm mb-4">
                          {award.description}
                        </p>

                        {/* Button */}
                        {shouldShowButton ? (
                          <button
                            onClick={() => navigate(award.buttonAction)}
                            className="inline-flex items-center px-5 py-2 rounded-full text-sm font-semibold text-white bg-gradient-to-r from-red-600 to-orange-500 hover:shadow-lg hover:shadow-red-900/30 transition-all duration-300"
                          >
                            {award.buttonText}
                          </button>
                        ) : award.requiresManager && !isManager ? (
                          <button
                            disabled
                            className="px-5 py-2 rounded-full text-sm font-semibold bg-gray-600/50 text-gray-300 cursor-not-allowed"
                          >
                            Manager Only
                          </button>
                        ) : (
                          <button
                            disabled
                            className="px-5 py-2 rounded-full text-sm font-semibold bg-gray-600/50 text-gray-300 cursor-not-allowed"
                          >
                            {award.buttonText}
                          </button>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Buttons */}
              <div className="absolute bottom-6 left-0 right-0 px-6 md:px-8 flex justify-between items-center z-20">
                <button
                  onClick={() => navigate(-1)}
                  className="inline-flex items-center z-20 px-6 py-2 rounded-full bg-white/10 border border-[#FFD700] text-[#FFD700] font-semibold hover:bg-[#FFD700] hover:text-[#7a1b2e] transition-all duration-300"
                >
                  ← Back
                </button>

                <button
                  onClick={() => navigate("/recognitionDashboard")}
                  className="group inline-flex items-center gap-2 px-10 py-3 rounded-full bg-gradient-to-r from-[#FF6B35] to-[#FFD700] text-white font-bold tracking-wide shadow-lg hover:shadow-2xl hover:shadow-[#FF6B35]/50 transition-all duration-300 hover:scale-105"
                >
                  Enter
                  <span className="transition-transform duration-300 group-hover:translate-x-1">
                    &raquo;
                  </span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default HatsOffScreen;