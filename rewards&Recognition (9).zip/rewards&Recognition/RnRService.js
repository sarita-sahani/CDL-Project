import axios from "axios";
import { add } from "date-fns";

const API = "http://localhost:9035/api/recognition";

const RnRService = {

   employeeInfoData(empCode) { 
      return axios.get(`${API}/getEmployeeInfo/${empCode}`);
   },         

 
 searchEmployee(searchValue) {
    return axios.get(`${API}/searchEmployee?searchValue=${searchValue}`);
  },

  getEmployeeTeamData(empCode) {
    return axios.get(`${API}/getEmployeeteamdata?empCode=${empCode}`);
  },

 getVoucherEligibility(empCode) {
    return axios.get(`${API}/voucher/eligibility/${empCode}`);
},

getCategories: (recognitionTypeId) =>
    axios.get(`${API}/categories/${recognitionTypeId}`),

// getCategoryName: (categoryId) =>
//     axios.get(`${API}/getcategoriesname/${categoryId}`),

  getTemplates: (categoryId) =>
    axios.get(`${API}/templates/${categoryId}`),

  getTemplateImages: (templateId) =>
    axios.get(`${API}/template-images/${templateId}`),

 getTemplatesDescription: (templateId) =>
    axios.get(`${API}/template-description/${templateId}`),

 submitRecognition: (formData) =>
     axios.post(`${API}/saveRecognitionsData`, formData, {
        headers: {
            "Content-Type": "multipart/form-data",
        },
    }),
 

 previewCertificate: (payload) => 
     axios.post(`${API}/previewCertificate`, payload),


  getAllRecognitionsList: (page, size) =>
   axios.get(`${API}/getAllRecognitions?page=${page}&size=${size}`),

getAllDataByRecognitionType: (type, page, size) =>
    axios.get(`${API}/getAllDataByRecognitionType/${type}`, {
        params: { page, size }
    }),

 getRecognitionComments: (recognitionId) =>
    axios.get(`${API}/getAllRecognitionComments/${recognitionId}`),

addRecognitionComment: (id, empCode) =>
  `${API}/addComments/${id}/${empCode}`,

// ── Bravo / World of Thanks ──────────────────────────────────────────────────
likeRecognition: (id, empCode) =>
  axios.post(`${API}/like/${id}/${empCode}`),

getRecognitionLikes: (id) =>
  axios.get(`${API}/likes/${id}`),

// ── Executive Circle (nomination-based) ──────────────────────────────────────
likeNomination: (nominationId, empCode) =>
  axios.post(`${API}/likeNomination/${nominationId}/${empCode}`),

getNominationLikes: (nominationId) =>
  axios.get(`${API}/nominationLikes/${nominationId}`),

getNominationComments: (nominationId) =>
  axios.get(`${API}/getAllNominationComments/${nominationId}`),

addNominationComment: (nominationId, empCode) =>
  `${API}/addNominationComments/${nominationId}/${empCode}`,

//honor- club

likeHonorClub: (honorClubId, empCode) =>
  axios.post(`${API}/likeHonorClub/${honorClubId}/${empCode}`),

getHonorClubLikes: (honorClubId) =>
  axios.get(`${API}/getHonorClubLikes/${honorClubId}`),

getAllHonorClubComments: (honorClubId) =>
  axios.get(`${API}/getAllHonorClubComments/${honorClubId}`),

addHonorClubComments: (honorClubId, empCode) =>
  `${API}/addHonorClubComments/${honorClubId}/${empCode}`,

//scholarships comments and like api

likeScholarships: (scholarshipId, empCode) =>
  axios.post(`${API}/likeScholarships/${scholarshipId}/${empCode}`),

getScholarshipsLikes: (scholarshipId) =>
  axios.get(`${API}/getScholarshipsLikes/${scholarshipId}`),

getAllScholarshipsComments: (scholarshipId) =>
  axios.get(`${API}/getAllScholarshipsComments/${scholarshipId}`),

addScholarshipComments: (scholarshipId, empCode) =>
  `${API}/addScholarshipComments/${scholarshipId}/${empCode}`,

// 1. Fetch all vouchers
  getAllVouchers: () => 
    axios.get(`${API}/getAllVouchers`),

  // 2. Add a single voucher
  addVoucher: (data) => 
    axios.post(`${API}/addVoucher`, data),

  // 3. Bulk upload vouchers from Excel
  addBulkVouchers: (dataArray) => 
    axios.post(`${API}/addBulkVouchers`, dataArray),

  // In RnRService.js
  getActiveVoucherCounts: () => 
    axios.get(`${API}/vouchers/active-counts`),
  
updateVoucher: (id, data) => axios.put(`${API}/updateVoucher/${id}`, data),
deleteVoucher: (id) => axios.delete(`${API}/deleteVoucher/${id}`),


};


export default RnRService;