import React, { useEffect, useState, useRef } from "react";
import { useParams, useNavigate } from "react-router-dom";
import RnRService from "./RnRService";
import { X, Search, ChevronDown, Image as ImageIcon, Award, Users, MessageSquare, CreditCard } from 'lucide-react';
import Header from "../components/Header";

function RecogniseNow() {
    const { recognitionTypeId } = useParams();

   const empCode = localStorage.getItem("empId");
    //const empCode = "9083338"
    const empName = localStorage.getItem("EmployeeFullName");
    const empEmail = localStorage.getItem("email");
    console.log("emp code in recognise now", empCode);

    const [categories, setCategories] = useState([]);
    const [templates, setTemplates] = useState([]);
    const [selectedCategoryId, setSelectedCategoryId] = useState("");
    const [selectedTemplateId, setSelectedTemplateId] = useState("");
    const [message, setMessage] = useState("");
    const [comment, setComment] = useState("");
    const [temaplateUrl, setTemaplateUrl] = useState("");
    const [showModal, setShowModal] = useState(false);
    const [isCustomMessage, setIsCustomMessage] = useState(false);

    // Employee related state
    const [selectedEmployee, setSelectedEmployee] = useState(null);
    const [employeesList, setEmployeesList] = useState([]);
    const [searchTerm, setSearchTerm] = useState("");
    const [teamMembers, setTeamMembers] = useState([]);
    const [loadingEmployees, setLoadingEmployees] = useState(false);
    const [templateImages, setTemplateImages] = useState([]);

    const [isFormValid, setIsFormValid] = useState(false);
    const [isSubmitted, setIsSubmitted] = useState(false); // becomes true only after Preview/Submit is attempted
    const navigate = useNavigate();

    const type = recognitionTypeId?.toString().toUpperCase();
    const isBravo = type === "BRAVO" || type === "2";
    //const isHatsOff = type === "HATSOFF" || type === "1";
    const isHatsOff = type === "WORLDOFTHANKS" || type === "1";

    const [recognitionMode, setRecognitionMode] = useState("ecard");
    const [certificateType, setCertificateType] = useState("");
    const [voucherValue, setVoucherValue] = useState(500);
    const [voucherLoading, setVoucherLoading] = useState(false);
    const [voucherEligibility, setVoucherEligibility] = useState(null);
    const [showPreviewModal, setShowPreviewModal] = useState(false);
    const [selectedImageObj, setSelectedImageObj] = useState(null);
    const [allCategoryImages, setAllCategoryImages] = useState([]);
    const [voucherCounts, setVoucherCounts] = useState({});
    const [generatedPreview, setGeneratedPreview] = useState("");

    const debounceTimer = useRef(null);

    const fetchVoucherEligibility = async () => {
    try {
        setVoucherLoading(true);
        // 1. Fetch manager's allowed budget
        const res = await RnRService.getVoucherEligibility(empCode);
        setVoucherEligibility(res.data);
        
        // 2. Fetch available inventory from Admin pool
        const countRes = await RnRService.getActiveVoucherCounts();
        
        // --- NEW FIX: Normalize the keys from "500.0" to 500 ---
        const rawCounts = countRes.data || {};
        const normalizedCounts = {};
        Object.keys(rawCounts).forEach(key => {
            // parseFloat converts "500.0" to the clean integer 500
            normalizedCounts[parseFloat(key)] = rawCounts[key]; 
        });
        
        setVoucherCounts(normalizedCounts); // Now state holds { 500: 3, 1000: 2 }

        const values = res.data?.allowedVoucherValues || [];
        setVoucherValue(values.length > 0 ? values[0] : 0);
    } catch (error) {
        console.error("Error fetching voucher data", error);
        setVoucherEligibility(null);
    } finally {
        setVoucherLoading(false);
    }
};
    

    useEffect(() => {
        if (isBravo && recognitionMode === "ecertificate" && certificateType === "withVoucher") {
            fetchVoucherEligibility();
        }
    }, [isBravo, recognitionMode, certificateType]);

    const API_BASE_URL = "http://localhost:9035";
    const getFullImageUrl = (path) => { 
        if (!path) return "";
        const cleanPath = path.startsWith("/") ? path.slice(1) : path;
        return `${API_BASE_URL}/${cleanPath}`;
    };

    useEffect(() => {
        if (recognitionTypeId) {
            // const typeId = recognitionTypeId === "HATSOFF" ? 1 : 2;
            const typeId = recognitionTypeId === "WORLDOFTHANKS" ? 1 : 2;
            loadCategories(typeId);
        }
    }, [recognitionTypeId]);

    const loadCategories = async (typeId) => {
        try {
            const res = await RnRService.getCategories(typeId);
            setCategories(res.data || []);
        } catch (error) {
            console.error("Error fetching categories", error);
        }
    };

    useEffect(() => {
        if (isBravo) {
            fetchTeamMembers();
        } else {
            setTeamMembers([]);
            setSelectedEmployee(null);
        }
    }, [isBravo]);

    useEffect(() => {
        if (isHatsOff && searchTerm && searchTerm.trim().length > 0) {
            if (debounceTimer.current) clearTimeout(debounceTimer.current);
            debounceTimer.current = setTimeout(() => {
                searchEmployees(searchTerm);
            }, 300);
        } else {
            setEmployeesList([]);
        }
        return () => {
            if (debounceTimer.current) clearTimeout(debounceTimer.current);
        };
    }, [searchTerm, isHatsOff]);

    // Form validation
    useEffect(() => {
        let valid = selectedCategoryId && selectedEmployee;

        const isECertificate = isBravo && recognitionMode === "ecertificate";
        if (!isECertificate) {
            valid = valid && (isCustomMessage || selectedTemplateId);
        }

        if (isBravo && recognitionMode === "ecertificate") {
            valid = valid && certificateType;
            if (certificateType === "withVoucher") {
                valid = valid && voucherValue > 0 && voucherEligibility?.remainingAmount > 0;
            }
        }

        setIsFormValid(valid);
    }, [
        selectedCategoryId, isCustomMessage, selectedTemplateId, recognitionMode,
        certificateType, voucherValue, selectedEmployee, isBravo, voucherEligibility
    ]);

    const searchEmployees = async (searchValue) => {
        setLoadingEmployees(true);
        try {
            const res = await RnRService.searchEmployee(searchValue);
            const data = res.data || [];
            const mappedEmployees = data.map(item => ({
                empCode: item.empResDTO?.empCode,
                employeeName: item.empResDTO?.fullNameAsAadhaar ||
                    `${item.empResDTO?.firstName} ${item.empResDTO?.lastName}`.trim() ||
                    item.empResDTO?.emailId,
                employeeEmail: item.empResDTO?.emailId,
                department: item.empResDTO?.mainDeptResDTO?.mainDepartment,
                designation: item.empResDTO?.designationResDTO?.designationName
            }));
            setEmployeesList(mappedEmployees);
        } catch (error) {
            console.error("Error searching employees", error);
            setEmployeesList([]);
        } finally {
            setLoadingEmployees(false);
        }
    };

    const fetchTeamMembers = async () => {
        try {
            const res = await RnRService.getEmployeeTeamData(empCode);
            const teamList = res.data?.teamList || [];
            const mappedTeam = teamList.map((item) => {
                const emp = item.empHierarchyResDTO;
                return {
                    empCode: emp?.empCode,
                    employeeName: emp?.fullNameAsAadhaar ||
                        `${emp?.firstName || ""} ${emp?.middleName || ""} ${emp?.lastName || ""}`.trim() ||
                        emp?.empCode,
                    employeeEmail: emp?.emailId,
                    designation: emp?.designationResDTO?.designationName,
                    department: emp?.mainDeptResDTO?.mainDepartment
                };
            });
            setTeamMembers(mappedTeam);
        } catch (error) {
            console.error("Error fetching team members", error);
        }
    };

    const handleEmployeeSelect = (employee) => {
        setSelectedEmployee(employee);
        setSearchTerm(employee.employeeName || "");
        setEmployeesList([]);
    };

    const handleCategoryChange = async (e) => {
        const catId = e.target.value;
        setSelectedCategoryId(catId);
        setTemplates([]);
        setSelectedImageObj(null);
        setSelectedTemplateId("");
        setTemplateImages([]);
        setAllCategoryImages([]);
        setMessage("");
        setComment("");
        setTemaplateUrl("");

        if (!catId) return;

        try {
            const res = await RnRService.getTemplates(catId);
            const templateList = res.data || [];
            setTemplates(templateList);

            const allImagesPromises = templateList.map(template =>
                RnRService.getTemplateImages(template.id).then(res => res.data || [])
            );
            const allImagesArrays = await Promise.all(allImagesPromises);
            const combinedImages = allImagesArrays.flat();
            setAllCategoryImages(combinedImages);

            if (templateList.length > 0 && !isCustomMessage) {
                const first = templateList[0];
                setSelectedTemplateId(first.id);
                setMessage(first.templateName);
                setComment(first.templateDescription || "");
                const imgRes = await RnRService.getTemplateImages(first.id);
                setTemplateImages(imgRes.data || []);
            } else if (isCustomMessage) {
                setTemplateImages(combinedImages);
            }
        } catch (error) {
            console.error("Error fetching templates", error);
        }
    };

const handlePreview = async () => {
    setIsSubmitted(true); // reveal validation errors only now

    if (!isFormValid) {
        alert("Please fill all required fields");
        return;
    }

    // ✅ Both ecertificate AND ecard now call the backend preview
    if (recognitionMode === "ecertificate" || recognitionMode === "ecard") {
        if (!selectedImageObj?.imageUrl && !temaplateUrl) {
            alert("Please select a card/certificate template");
            return;
        }

        try {
            const payload = {
                templateImageUrl: selectedImageObj?.imageUrl || temaplateUrl,
                employeeName: selectedEmployee?.employeeName,
                recognizedByName: empName,
                recognitionType: isBravo ? "BRAVO" : "HATSOFF",
                recognitionMode,
                certificateType: recognitionMode === "ecard" ? null : certificateType,
                voucherValue: recognitionMode === "ecard" ? null : voucherValue,
                nomineeDepartment: selectedEmployee?.department,
                voucherSerialNum: null
            };

            const res = await RnRService.previewCertificate(payload);
            setGeneratedPreview(`data:image/jpeg;base64,${res.data.previewImage}`);
            setShowPreviewModal(true);
        } catch (error) {
            console.error("Preview failed", error);
            alert("Preview generation failed");
        }
    } else {
        // HATSOFF with no mode (shouldn't happen but safe fallback)
        setGeneratedPreview("");
        setShowPreviewModal(true);
    }
};


    const getCategoryName = () => {
        const cat = categories.find(c => c.id === Number(selectedCategoryId));
        return cat ? cat.categoryName : "";
    };

    const cat = categories.find(c => c.id === Number(selectedCategoryId));
    const certificateImage = cat?.certificateUrl;
    const previewImage = recognitionMode === "ecertificate" ? certificateImage : temaplateUrl;


const handleSubmit = async () => {
    setIsSubmitted(true); // reveal validation errors only now

    if (!isFormValid) return;

    try {
        const selectedCategory = categories.find(
            c => c.id === Number(selectedCategoryId)
        );

        // ✅ Get the active image URL
        const activeTemplateUrl = selectedImageObj?.imageUrl || certificateImage || temaplateUrl;

        const payload = {
            empCode: selectedEmployee.empCode,
            employeeName: selectedEmployee.employeeName,
            employeeEmail: selectedEmployee.employeeEmail || "",
            nomineeDepartment: selectedEmployee.department || "",
            recognizedByCode: empCode,
            recognizedByName: empName,
            recognizedByEmail: empEmail,
            categoryId: Number(selectedCategoryId),
            templateId: selectedTemplateId
                ? Number(selectedTemplateId)
                : null,
            categoryName: selectedCategory?.categoryName || "",
            comment,
           // recognitionType: isBravo ? "BRAVO" : "HATSOFF",
            recognitionType: isBravo ? "BRAVO" : "WORLDOFTHANKS",
            
            // ✅ MOVED OUTSIDE isBravo: This ensures HATSOFF and E-Cards send the URL
            templateImageUrl: activeTemplateUrl, 
           recognitionMode: isBravo ? recognitionMode : "ecard",
            ...(isBravo && {
                recognitionMode,
                certificateType,
                voucherValue:
                    certificateType === "withVoucher"
                        ? Number(voucherValue)
                        : null,
            }),
        };

        const formData = new FormData();

        formData.append(
            "request",
            new Blob([JSON.stringify(payload)], {
                type: "application/json",
            })
        );

        // ❌ DO NOT send certificate from frontend (Backend handles it now)
        await RnRService.submitRecognition(formData);

        alert("Recognition submitted successfully ✅");
        navigate("/recognitionDashboard");

    } catch (error) {
        console.error("Error submitting recognition:", error);
        alert("Something went wrong ❌");
    }
};
const handleCancel = () => {
        navigate(-1);
    };

    useEffect(() => {
        if (recognitionMode === "ecertificate") {
            setSelectedTemplateId("");
            setTemplateImages([]);
            setSelectedImageObj(null);
            setTemaplateUrl("");
        }
    }, [recognitionMode]);

    return (
        <>
            <Header />
            <div className="min-h-screen bg-gradient-to-br from-gray-100 to-gray-200 p-6 mt-[70px]">
                {/* TOP HEADER BAR - Professional Navy Blue */}
                <div className={`mb-8 rounded-2xl shadow-xl p-5 text-white flex justify-between items-center
                    ${isBravo ? "bg-gradient-to-b from-red-900 to-red-700" : "bg-gradient-to-b from-red-900 to-red-700"}`}>
                    <div className="flex items-center gap-3">
                        {isBravo ? <Award className="w-7 h-7" /> : <Users className="w-7 h-7" />}
                        <div className="text-xl font-bold tracking-wide">
                            {isBravo ? "Bravo Recognition" : "Hats Off - World of Thanks"}
                        </div>
                    </div>
                    <button onClick={() => navigate("/recognitionDashboard")} className="bg-white/20 hover:bg-white/30 text-white rounded-full p-2 transition-all duration-200 backdrop-blur-sm">
                        <X size={18} />
                    </button>
                </div>

                <div className="max-w-4xl mx-auto">
                    <div className="bg-white rounded-2xl shadow-2xl overflow-hidden border border-gray-100">
                        <div className="p-8 space-y-6">
                            {/* Category */}
                            <div className="space-y-2">
                                <label className="flex items-center gap-2 text-sm font-semibold text-gray-800">
                                    <span className="text-blue-600 text-lg">★</span> Category <span className="text-red-500">*</span>
                                </label>
                                <div className="relative">
                                    <select
                                        className={`w-full appearance-none bg-gray-50 border ${isSubmitted && !selectedCategoryId ? "border-red-300 ring-1 ring-red-200" : "border-gray-300"} rounded-xl p-3 text-gray-800 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200`}
                                        value={selectedCategoryId}
                                        onChange={handleCategoryChange}
                                    >
                                        <option value="">-- Select Category --</option>
                                        {categories.map((cat) => (
                                            <option key={cat.id} value={cat.id}>{cat.categoryName}</option>
                                        ))}
                                    </select>
                                    <ChevronDown className="absolute right-3 top-3.5 text-gray-500 pointer-events-none" size={18} />
                                </div>
                                {isSubmitted && !selectedCategoryId && <p className="text-red-500 text-xs flex items-center gap-1 mt-1">⚠️ This field is required.</p>}
                            </div>

                            {/* Employee */}
                            <div className="space-y-2">
                                <label className="flex items-center gap-2 text-sm font-semibold text-gray-800">
                                    <Users size={16} className="text-blue-600" /> Employee <span className="text-red-500">*</span>
                                </label>
                                {isBravo ? (
                                    <div className="relative">
                                        <select
                                            className="w-full appearance-none bg-gray-50 border border-gray-300 rounded-xl p-3 text-gray-800 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                            value={selectedEmployee?.empCode || ""}
                                            onChange={(e) => {
                                                const emp = teamMembers.find(m => m.empCode === e.target.value);
                                                setSelectedEmployee(emp);
                                            }}
                                        >
                                            <option value="">-- Select Team Member --</option>
                                            {teamMembers.map((member) => (
                                                <option key={member.empCode} value={member.empCode}>
                                                    {member.employeeName} ({member.empCode})
                                                </option>
                                            ))}
                                        </select>
                                        <ChevronDown className="absolute right-3 top-3.5 text-gray-500 pointer-events-none" size={18} />
                                    </div>
                                ) : (
                                    <div className="relative">
                                        <div className="relative">
                                            <Search className="absolute left-3 top-3.5 text-gray-500" size={18} />
                                            <input
                                                type="text"
                                                className="w-full bg-gray-50 border border-gray-300 rounded-xl p-3 pl-10 text-gray-800 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                                placeholder="Type employee name or code..."
                                                value={searchTerm}
                                                onChange={(e) => setSearchTerm(e.target.value)}
                                            />
                                        </div>
                                        {loadingEmployees && <div className="absolute right-3 top-3 text-gray-500 text-sm">Searching...</div>}
                                        {employeesList.length > 0 && (
                                            <ul className="absolute z-20 w-full bg-white border border-gray-200 rounded-xl mt-2 max-h-64 overflow-auto shadow-lg">
                                                {employeesList.map((emp) => (
                                                    <li key={emp.empCode} className="p-3 hover:bg-blue-50 cursor-pointer transition-colors duration-150 border-b border-gray-100 last:border-0" onClick={() => handleEmployeeSelect(emp)}>
                                                        <div className="font-medium text-gray-800">{emp.employeeName}</div>
                                                        <div className="text-xs text-gray-500">{emp.empCode} • {emp.department || '—'}</div>
                                                    </li>
                                                ))}
                                            </ul>
                                        )}
                                    </div>
                                )}
                                {isSubmitted && !selectedEmployee && <p className="text-red-500 text-xs flex items-center gap-1 mt-1">⚠️ Please select an employee.</p>}
                                {/* {selectedEmployee && (
                                    <div className="mt-2 text-sm bg-blue-50 text-blue-700 p-2 rounded-lg inline-block border border-blue-200">
                                        Selected: {selectedEmployee.employeeName} ({selectedEmployee.empCode})
                                    </div>
                                )} */}
                            </div>

                            {/* Bravo - Select Type */}
                            {isBravo && (
                                <div className="space-y-2">
                                    <label className="flex items-center gap-2 text-sm font-semibold text-gray-800">
                                        <CreditCard size={16} className="text-blue-600" /> Select Type <span className="text-red-500">*</span>
                                    </label>
                                    <div className="flex gap-8 items-center">
                                        <label className="flex items-center gap-2 cursor-pointer">
                                            <input
                                                type="radio"
                                                value="ecard"
                                                checked={recognitionMode === "ecard"}
                                                onChange={() => { setRecognitionMode("ecard"); setCertificateType(""); }}
                                                className="w-4 h-4 text-blue-600 focus:ring-blue-500 border-gray-300"
                                            />
                                            <span className="text-gray-800">E-Card</span>
                                        </label>
                                        <label className="flex items-center gap-2 cursor-pointer">
                                            <input
                                                type="radio"
                                                value="ecertificate"
                                                checked={recognitionMode === "ecertificate"}
                                                onChange={() => setRecognitionMode("ecertificate")}
                                                className="w-4 h-4 text-blue-600 focus:ring-blue-500 border-gray-300"
                                            />
                                            <span className="text-gray-800">E-Certificate</span>
                                        </label>
                                    </div>
                                </div>
                            )}

                            {/* Conditional sections */}
                            {!isBravo && (
                                <>
                                    <div className="space-y-2">
                                        <label className="text-sm font-semibold text-gray-800">Message Template <span className="text-red-500">*</span></label>
                                        <select
                                            className={`w-full bg-gray-50 border ${isSubmitted && !isCustomMessage && !selectedTemplateId ? "border-red-300 ring-1 ring-red-200" : "border-gray-300"} rounded-xl p-3 text-gray-800 focus:outline-none focus:ring-2 focus:ring-blue-500`}
                                            value={isCustomMessage ? "custom" : selectedTemplateId}
                                            onChange={async (e) => {
                                                const value = e.target.value;
                                                if (value === "custom") {
                                                    setIsCustomMessage(true);
                                                    setSelectedTemplateId("");
                                                    setMessage("");
                                                    setComment("");
                                                    setSelectedImageObj(null);
                                                    setTemaplateUrl("");
                                                    setTemplateImages(allCategoryImages);
                                                } else {
                                                    setIsCustomMessage(false);
                                                    setSelectedTemplateId(value);
                                                    const selected = templates.find((t) => t.id === Number(value));
                                                    if (selected) {
                                                        setMessage(selected.templateName);
                                                        setComment(selected.templateDescription || "");
                                                        const imgRes = await RnRService.getTemplateImages(selected.id);
                                                        setTemplateImages(imgRes.data || []);
                                                        setSelectedImageObj(null);
                                                        setTemaplateUrl("");
                                                    }
                                                }
                                            }}
                                        >
                                            <option value="">-- Select Message --</option>
                                            <option value="custom">✏️ Custom Message</option>
                                            {templates.map((temp) => (
                                                <option key={temp.id} value={temp.id}>{temp.templateName}</option>
                                            ))}
                                        </select>
                                        {isSubmitted && !isCustomMessage && !selectedTemplateId && <p className="text-red-500 text-xs">Please select a message template.</p>}
                                    </div>

                                    <div className="space-y-2">
                                        <label className="text-sm font-semibold text-gray-800">Card / Certificate Design</label>
                                        <div className="flex flex-col sm:flex-row gap-3 items-start sm:items-center">
                                            <div className="flex-1 bg-gray-50 border border-gray-300 rounded-xl p-3 flex items-center gap-2 h-[50px] w-full">
                                                {selectedImageObj ? (
                                                    <>
                                                        <ImageIcon size={16} className="text-blue-600" />
                                                        <span className="text-sm text-gray-700 truncate">{selectedImageObj.imageUrl.split("/").pop()}</span>
                                                    </>
                                                ) : (
                                                    <span className="text-gray-500 text-sm">No design selected</span>
                                                )}
                                            </div>
                                            <button className="px-6 py-2.5 bg-gradient-to-b from-blue-900 to-blue-700 text-white rounded-xl hover:shadow-lg transition-all duration-200 font-medium text-sm whitespace-nowrap" onClick={() => setShowModal(true)}>
                                                Browse Designs
                                            </button>
                                        </div>
                                    </div>

                                    <div className="space-y-2">
                                        <label className="text-sm font-semibold text-gray-800">Comment / Note</label>
                                        <textarea
                                            className={`w-full border border-gray-300 rounded-xl p-3 text-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500 ${!isCustomMessage ? "bg-gray-100 text-gray-500" : "bg-white"}`}
                                            rows="3"
                                            value={comment}
                                            readOnly={!isCustomMessage}
                                            placeholder={!isCustomMessage ? "Auto-filled from template" : "Write your personal message here..."}
                                            onChange={(e) => setComment(e.target.value)}
                                        />
                                    </div>
                                </>
                            )}

                            {isBravo && recognitionMode === "ecard" && (
                                <>
                                    <div className="space-y-2">
                                        <label className="text-sm font-semibold text-gray-800">Message Template <span className="text-red-500">*</span></label>
                                        <select
                                            className={`w-full bg-gray-50 border ${isSubmitted && !isCustomMessage && !selectedTemplateId ? "border-red-300 ring-1 ring-red-200" : "border-gray-300"} rounded-xl p-3 text-gray-800 focus:outline-none focus:ring-2 focus:ring-blue-500`}
                                            value={isCustomMessage ? "custom" : selectedTemplateId}
                                            onChange={async (e) => {
                                                const value = e.target.value;
                                                if (value === "custom") {
                                                    setIsCustomMessage(true);
                                                    setSelectedTemplateId("");
                                                    setMessage("");
                                                    setComment("");
                                                    setSelectedImageObj(null);
                                                    setTemaplateUrl("");
                                                    setTemplateImages(allCategoryImages);
                                                } else {
                                                    setIsCustomMessage(false);
                                                    setSelectedTemplateId(value);
                                                    const selected = templates.find((t) => t.id === Number(value));
                                                    if (selected) {
                                                        setMessage(selected.templateName);
                                                        setComment(selected.templateDescription || "");
                                                        const imgRes = await RnRService.getTemplateImages(selected.id);
                                                        setTemplateImages(imgRes.data || []);
                                                        setSelectedImageObj(null);
                                                        setTemaplateUrl("");
                                                    }
                                                }
                                            }}
                                        >
                                            <option value="">-- Select Message --</option>
                                            <option value="custom">✏️ Custom Message</option>
                                            {templates.map((temp) => (
                                                <option key={temp.id} value={temp.id}>{temp.templateName}</option>
                                            ))}
                                        </select>
                                        {isSubmitted && !isCustomMessage && !selectedTemplateId && <p className="text-red-500 text-xs">Please select a message template.</p>}
                                    </div>

                                    <div className="space-y-2">
                                        <label className="text-sm font-semibold text-gray-800">Card Design</label>
                                        <div className="flex flex-col sm:flex-row gap-3 items-start sm:items-center">
                                            <div className="flex-1 bg-gray-50 border border-gray-300 rounded-xl p-3 flex items-center gap-2 h-[50px] w-full">
                                                {selectedImageObj ? (
                                                    <>
                                                        <ImageIcon size={16} className="text-blue-600" />
                                                        <span className="text-sm text-gray-700 truncate">{selectedImageObj.imageUrl.split("/").pop()}</span>
                                                    </>
                                                ) : (
                                                    <span className="text-gray-500 text-sm">No design selected</span>
                                                )}
                                            </div>
                                            <button className="px-6 py-2.5 bg-gradient-to-r from-blue-700 to-indigo-700 text-white rounded-xl hover:shadow-lg transition-all duration-200 font-medium text-sm whitespace-nowrap" onClick={() => setShowModal(true)}>
                                                Browse Cards
                                            </button>
                                        </div>
                                    </div>

                                    <div className="space-y-2">
                                        <label className="text-sm font-semibold text-gray-800">Comment (Optional)</label>
                                        <textarea
                                            className={`w-full border border-gray-300 rounded-xl p-3 text-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500 ${!isCustomMessage ? "bg-gray-100 text-gray-500" : "bg-white"}`}
                                            rows="3"
                                            value={comment}
                                            readOnly={!isCustomMessage}
                                            placeholder={!isCustomMessage ? "Auto-filled from template" : "Add a personal note..."}
                                            onChange={(e) => setComment(e.target.value)}
                                        />
                                    </div>
                                </>
                            )}

                            {isBravo && recognitionMode === "ecertificate" && (
                                <>
                                    <div className="space-y-2">
                                        <label className="text-sm font-semibold text-gray-800">Certificate Type <span className="text-red-500">*</span></label>
                                        <select className="w-full bg-gray-50 border border-gray-300 rounded-xl p-3 text-gray-800 focus:outline-none focus:ring-2 focus:ring-blue-500" value={certificateType} onChange={(e) => setCertificateType(e.target.value)}>
                                            <option value="">-- Select --</option>
                                            <option value="withoutVoucher">Certificate without Voucher</option>
                                            <option value="withVoucher">Certificate with Voucher</option>
                                        </select>
                                    </div>

                                    {certificateType === "withVoucher" && (
                                        <div className="space-y-2">
                                            <label className="text-sm font-semibold text-gray-800">Voucher Value</label>
                                            {voucherLoading ? (
                                                <div className="w-full bg-gray-50 border border-gray-300 rounded-xl p-3 text-gray-500">Loading balance...</div>
                                            ) : (
                                               <select
    className="w-full bg-gray-50 border border-gray-300 rounded-xl p-3 text-gray-800 focus:outline-none focus:ring-2 focus:ring-blue-500"
    value={voucherValue}
    onChange={(e) => setVoucherValue(Number(e.target.value))}
    disabled={!voucherEligibility?.allowedVoucherValues?.length}
>
    {voucherEligibility?.allowedVoucherValues?.length > 0 ? (
        voucherEligibility.allowedVoucherValues.map((value) => {
            // Get available count from our state
            const availableInInventory = voucherCounts[value] || 0;
            const isOutOfStock = availableInInventory === 0;

            return (
                <option key={value} value={value} disabled={isOutOfStock}>
                    ₹{value} {isOutOfStock ? "(Out of Stock)" : `(${availableInInventory} voucher${availableInInventory === 1 ? "" : "s"} remaining)`}
                </option>
            );
        })
    ) : (
        <option value="">No balance left</option>
    )}
</select>
                                            )}
                                            {voucherEligibility && !voucherLoading && (
                                                <p className="text-sm text-green-700 flex items-center gap-1 mt-1">
                                                    <span className="inline-block w-1.5 h-1.5 bg-green-600 rounded-full"></span>
                                                    Remaining Quarterly Balance: ₹{voucherEligibility.remainingAmount}
                                                </p>
                                            )}
                                        </div>
                                    )}

                                    <div className="space-y-2">
                                        <label className="text-sm font-semibold text-gray-800">Certificate Template</label>
                                        <div className="flex flex-col sm:flex-row gap-3 items-start sm:items-center">
                                            <div className="flex-1 bg-gray-50 border border-gray-300 rounded-xl p-3 flex items-center gap-2 h-[50px] w-full">
                                                {selectedImageObj ? (
                                                    <>
                                                        <ImageIcon size={16} className="text-blue-600" />
                                                        <span className="text-sm text-gray-700 truncate">{selectedImageObj.imageUrl?.split("/").pop()}</span>
                                                    </>
                                                ) : (
                                                    <span className="text-gray-500 text-sm">No certificate selected</span>
                                                )}
                                            </div>
                                            <button className="px-6 py-2.5 bg-gradient-to-r from-blue-700 to-indigo-700 text-white rounded-xl hover:shadow-lg transition-all duration-200 font-medium text-sm whitespace-nowrap" onClick={() => setShowModal(true)}>
                                                Select Certificate
                                            </button>
                                        </div>
                                    </div>
                                </>
                            )}

                            {/* Action Buttons */}
                            <div className="flex justify-end gap-4 pt-4 border-t border-gray-200">
                                <button className="px-8 py-2.5 rounded-xl font-medium text-gray-700 bg-gray-100 hover:bg-gray-200 transition-all duration-200" onClick={handleCancel}>
                                    Cancel
                                </button>
                                <button className="px-8 py-2.5 rounded-xl font-medium text-white bg-gradient-to-r from-blue-700 to-indigo-700 hover:shadow-xl transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed" disabled={!isFormValid} onClick={handlePreview}>
                                    Preview
                                </button>
                                <button className="px-8 py-2.5 rounded-xl font-medium text-white bg-gradient-to-r from-emerald-700 to-teal-700 hover:shadow-xl transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed" disabled={!isFormValid} onClick={handleSubmit}>
                                    Submit Recognition
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Modal for template/certificate selection - Updated Header Color */}
                {showModal && (
                    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex justify-center items-center z-50 p-4">
                        <div className="bg-white rounded-2xl shadow-2xl w-full max-w-4xl max-h-[90vh] overflow-hidden">
                            <div className="bg-gradient-to-b from-red-900 to-red-700 text-white p-5 flex justify-between items-center">
                                <h3 className="text-xl font-semibold flex items-center gap-2">
                                    <ImageIcon size={22} />
                                    {recognitionMode === "ecertificate" ? "Select Certificate Template" : "Select Card Design"}
                                </h3>
                                <button onClick={() => setShowModal(false)} className="text-white/80 hover:text-white transition-colors"><X size={24} /></button>
                            </div>
                            <div className="p-6 overflow-y-auto max-h-[70vh]">
                                {recognitionMode === "ecertificate" ? (
                                    <div className="flex justify-center">
                                        <div className="border rounded-xl shadow-lg p-4 w-full max-w-md">
                                            <img src={getFullImageUrl(certificateImage?.trim())} alt="certificate" className="w-full h-64 object-contain rounded-lg bg-gray-50" onError={(e) => { e.target.src = "https://via.placeholder.com/600x250?text=Certificate+Not+Found"; }} />
                                            <p className="text-sm mt-3 text-blue-600 text-center font-mono">{certificateImage?.split("/").pop()}</p>
                                            <button className="mt-4 w-full bg-gray-300 hover:bg-blue-600 hover:text-white text-gray-700 py-2 rounded-lg font-medium hover:shadow-md transition" onClick={() => { setSelectedImageObj({ id: "certificate", imageUrl: certificateImage }); setTemaplateUrl(certificateImage); setShowModal(false); }}>Choose This Certificate</button>
                                        </div>
                                    </div>
                                ) : templateImages.length > 0 ? (
                                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                                        {templateImages.map((img) => (
                                            <div key={img.id} className="border rounded-xl shadow-md overflow-hidden hover:shadow-lg transition">
                                                <div className="aspect-video bg-gray-50"><img src={getFullImageUrl(img.imageUrl)} alt="template" className="w-full h-full object-contain" /></div>
                                                <div className="p-3 bg-white">
                                                    <p className="text-xs text-blue-600 font-mono truncate mb-3">{img.imageUrl.split("/").pop()}</p>
                                                    <button className="w-full bg-gray-300 hover:bg-blue-600 hover:text-white text-gray-700 py-2 rounded-lg text-sm font-medium transition-all" onClick={() => { setSelectedImageObj(img); setTemaplateUrl(img.imageUrl); setShowModal(false); }}>Select Design</button>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                ) : <div className="text-center text-gray-500 py-12">No designs available.</div>}
                            </div>
                        </div>
                    </div>
                )}

                {/* Preview Modal - Updated Header Color */}
                {showPreviewModal && (
                    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex justify-center items-center z-50 p-4">
                        <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-hidden flex flex-col">
                            <div className="bg-gradient-to-b from-red-900 to-red-700 text-white p-5 flex justify-between items-center">
                                <h3 className="text-xl font-semibold flex items-center gap-2"><Award size={22} /> Preview Recognition</h3>
                                <button onClick={() => setShowPreviewModal(false)} className="text-white/80 hover:text-white"><X size={24} /></button>
                            </div>
                            <div className="p-6 space-y-5 overflow-y-auto flex-1 min-h-0">
                                <div className="bg-gradient-to-br from-gray-50 to-gray-100 rounded-xl p-5 shadow-inner">
                                    {/* {previewImage && <img src={getFullImageUrl(previewImage)} alt="preview" className="w-full h-56 object-contain rounded-lg mb-4 border border-gray-200 bg-white" />} */}
                                    {generatedPreview ? (
    <img
        src={generatedPreview}
        alt="Generated Preview"
        className="w-full h-56 object-contain rounded-lg mb-4 border border-gray-200 bg-white"
    />
) : (
    previewImage && (
        <img
            src={getFullImageUrl(previewImage)}
            alt="preview"
            className="w-full h-56 object-contain rounded-lg mb-4 border border-gray-200 bg-white"
        />
    )
)}
                                    <div className="text-xl font-bold text-gray-800">{message}</div>
                                    {comment && <div className="text-gray-600 mt-2 italic border-l-3 border-blue-300 pl-3">{comment}</div>}
                                    <div className="mt-4 pt-3 border-t border-gray-200 flex flex-col md:flex-row md:justify-between md:items-center gap-2">
                                        <div className="text-sm"><span className="text-gray-500">Employee: </span><strong className="text-gray-800">{selectedEmployee?.employeeName}</strong> ({selectedEmployee?.empCode})</div>
                                        <div className="text-xs text-gray-500">Category: {getCategoryName()}</div>
                                    </div>
                                    <div className="mt-2 text-sm text-gray-500">Recognized by: <strong className="text-gray-700">{empName}</strong> ({empCode})</div>
                                </div>
                                {isBravo && (
                                    <div className="grid grid-cols-2 gap-4 text-sm bg-gray-50 p-4 rounded-xl border border-gray-100">
                                        <div><span className="text-gray-500">Type</span><div className="font-medium text-gray-800 capitalize flex items-center gap-1">{recognitionMode === "ecard" ? <CreditCard size={14} /> : <Award size={14} />}{recognitionMode}</div></div>
                                        {recognitionMode === "ecertificate" && (
                                            <>
                                                <div><span className="text-gray-500">Certificate</span><div className="font-medium text-gray-800">{certificateType === "withVoucher" ? "With Voucher" : "Without Voucher"}</div></div>
                                                {certificateType === "withVoucher" && <div><span className="text-gray-500">Voucher</span><div className="font-medium text-green-600">₹{voucherValue}</div></div>}
                                            </>
                                        )}
                                    </div>
                                )}
                            </div>
                            <div className="flex justify-end gap-3 p-5 border-t bg-gray-50">
                                <button className="px-5 py-2 rounded-xl bg-gray-200 hover:bg-gray-300 transition-all" onClick={() => setShowPreviewModal(false)}>Cancel</button>
                                <button className="px-6 py-2 rounded-xl text-white bg-gradient-to-r from-emerald-700 to-teal-700 hover:shadow-lg transition-all" onClick={() => { setShowPreviewModal(false); handleSubmit(); }}>✅ Confirm & Submit</button>
                            </div>
                        </div>
                    </div>
                )}
            </div>
        </>
    );
}

export default RecogniseNow;