import React from "react";
import { useNavigate, useLocation } from "react-router-dom";
import Header from "../components/Header";

const FLECKS = [
  "absolute rounded-full w-1.5 h-1.5 bg-[#FFD700] opacity-80 top-[12%] left-[6%] motion-safe:animate-pulse [animation-delay:0s]",
  "absolute rounded-full w-1 h-1 bg-[#FFA500] opacity-80 top-[28%] left-[14%] motion-safe:animate-pulse [animation-delay:0.6s]",
  "absolute rounded-full w-2 h-2 bg-[#FFD700] opacity-80 top-[8%] left-[22%] motion-safe:animate-pulse [animation-delay:1.2s]",
  "absolute rounded-full w-1 h-1 bg-[#FF6B35] opacity-80 top-[22%] left-[33%] motion-safe:animate-pulse [animation-delay:1.8s]",
  "absolute rounded-full w-1.5 h-1.5 bg-[#FFD700] opacity-80 top-[5%] left-[41%] motion-safe:animate-pulse [animation-delay:2.4s]",
  "absolute rounded-full w-1 h-1 bg-[#FFA500] opacity-80 top-[18%] left-[52%] motion-safe:animate-pulse [animation-delay:0.3s]",
  "absolute rounded-full w-2 h-2 bg-[#FFD700] opacity-80 top-[9%] left-[63%] motion-safe:animate-pulse [animation-delay:0.9s]",
  "absolute rounded-full w-1 h-1 bg-[#FF6B35] opacity-80 top-[24%] left-[71%] motion-safe:animate-pulse [animation-delay:1.5s]",
  "absolute rounded-full w-1.5 h-1.5 bg-[#FFD700] opacity-80 top-[6%] left-[82%] motion-safe:animate-pulse [animation-delay:2.1s]",
  "absolute rounded-full w-1 h-1 bg-[#FFA500] opacity-80 top-[20%] left-[91%] motion-safe:animate-pulse [animation-delay:0.4s]",
  "absolute rounded-full w-1.5 h-1.5 bg-[#FFA500] opacity-80 top-[82%] left-[8%] motion-safe:animate-pulse [animation-delay:1.1s]",
  "absolute rounded-full w-1 h-1 bg-[#FFD700] opacity-80 top-[90%] left-[18%] motion-safe:animate-pulse [animation-delay:1.7s]",
  "absolute rounded-full w-2 h-2 bg-[#FF6B35] opacity-80 top-[78%] left-[29%] motion-safe:animate-pulse [animation-delay:2.3s]",
  "absolute rounded-full w-1 h-1 bg-[#FFA500] opacity-80 top-[94%] left-[38%] motion-safe:animate-pulse [animation-delay:0.2s]",
  "absolute rounded-full w-1.5 h-1.5 bg-[#FFD700] opacity-80 top-[84%] left-[47%] motion-safe:animate-pulse [animation-delay:0.8s]",
  "absolute rounded-full w-1 h-1 bg-[#FFA500] opacity-80 top-[92%] left-[58%] motion-safe:animate-pulse [animation-delay:1.4s]",
  "absolute rounded-full w-2 h-2 bg-[#FFD700] opacity-80 top-[80%] left-[68%] motion-safe:animate-pulse [animation-delay:2s]",
  "absolute rounded-full w-1 h-1 bg-[#FF6B35] opacity-80 top-[96%] left-[77%] motion-safe:animate-pulse [animation-delay:0.5s]",
  "absolute rounded-full w-1.5 h-1.5 bg-[#FFA500] opacity-80 top-[86%] left-[88%] motion-safe:animate-pulse [animation-delay:1s]",
  "absolute rounded-full w-1 h-1 bg-[#FFD700] opacity-80 top-[76%] left-[96%] motion-safe:animate-pulse [animation-delay:1.6s]",
  "absolute rounded-full w-0.5 h-0.5 bg-white opacity-90 top-[15%] left-[45%] motion-safe:animate-ping [animation-delay:0.5s]",
  "absolute rounded-full w-0.5 h-0.5 bg-white opacity-90 top-[85%] left-[55%] motion-safe:animate-ping [animation-delay:1.3s]",
  "absolute rounded-full w-1 h-1 bg-white opacity-70 top-[45%] left-[75%] motion-safe:animate-pulse [animation-delay:0.7s]",
  "absolute rounded-full w-0.5 h-0.5 bg-white opacity-90 top-[35%] left-[20%] motion-safe:animate-ping [animation-delay:1.9s]",
  "absolute rounded-full w-1 h-1 bg-white opacity-70 top-[65%] left-[40%] motion-safe:animate-pulse [animation-delay:0.1s]",
];

const SPARKLES = [
  "absolute text-[#FFD700] text-2xl opacity-60 top-[3%] left-[15%] motion-safe:animate-pulse [animation-delay:0.2s]",
  "absolute text-[#FF6B35] text-xl opacity-50 top-[2%] right-[20%] motion-safe:animate-pulse [animation-delay:0.8s]",
  "absolute text-[#FFD700] text-3xl opacity-40 bottom-[5%] left-[25%] motion-safe:animate-pulse [animation-delay:1.4s]",
  "absolute text-[#FFA500] text-xl opacity-50 bottom-[3%] right-[15%] motion-safe:animate-pulse [animation-delay:2s]",
  "absolute text-[#FFD700] text-2xl opacity-30 top-[45%] left-[5%] motion-safe:animate-pulse [animation-delay:0.6s]",
  "absolute text-[#FF6B35] text-2xl opacity-30 top-[40%] right-[4%] motion-safe:animate-pulse [animation-delay:1.6s]",
];

// PDF file paths - store in public/documents/
const RULES_PDFS = {
  HATS_OFF: "/RnRImages/Hats Off.jpg",
  EXECUTIVE_CIRCLE: "/RnRImages/Executive Circle Awards.jpg",
  HONOR_CLUB: "/RnRImages/Honor Club.jpg",
};

// Function to open PDF in new tab
const openPDF = (pdfPath) => {
  window.open(pdfPath, "_blank");
};

const CATEGORIES = [
  {
    key: "HATS_OFF",
    icon: "🎩",
    label: "HATS OFF",
    description:
      "Hats Off is where any Employee can recognize another. This is open to all employees and can be used to recognize your juniors, peers, colleagues and even your managers. Please refer to",
    linkText: "rules and eligibility",
    linkSuffix: "provided to help you get going.",
    pdfPath: RULES_PDFS.HATS_OFF,
    destination: "/rr-category",
    committee: "Canteen Committee",
  },
  {
    key: "EXECUTIVE_CIRCLE",
    icon: "🏆",
    label: "EXECUTIVE CIRCLE",
    description:
      "Our Executive Circle is a \u201cBy Nomination only\u201d award program. Executive Circle is an annual circle of achievers, awarded once a year to an elite group of employees for achieving specific goals or exceeding expectations or going beyond the call of duty. Nominations are submitted by Leaders to the Management who decides on the final list. Please refer to",
    linkText: "rules and eligibility",
    linkSuffix: "provided to help you get going.",
    pdfPath: RULES_PDFS.EXECUTIVE_CIRCLE,
    destination: "/executive-circle-list",
    committee: "HR Committee",
  },
  {
    key: "HONOR_CLUB",
    icon: "🎖️",
    label: "HONOR CLUB",
    description:
      "These are awards in recognition of tenure and service to the company. This is an exclusive club of CMSites who have helped CMS succeed through various economic cycles. Currently tenures and service over 10 and 20 years from date of joining are recognized. Please refer to",
    linkText: "Rules and Eligibility",
    linkSuffix: "criteria.",
    pdfPath: RULES_PDFS.HONOR_CLUB,
    destination: "/honor-club-list",
    committee: "Tech Committee",
  },
];

const A2BCategoriesScreen = () => {
  const navigate = useNavigate();
  const location = useLocation();

  // If a specific card was clicked on RnRHomePage, we get its key here.
  // If the user lands on this page directly (e.g. via a menu link), state
  // will be empty and we fall back to showing all three categories.
  const selectedKey = location.state?.category;

  const visibleCategories = selectedKey
    ? CATEGORIES.filter((cat) => cat.key === selectedKey)
    : CATEGORIES;

  const isSingleView = visibleCategories.length === 1;

  // Where the "Enter" button should go. If we arrived via a specific card,
  // go straight to that feature's page. Otherwise fall back to the old default.
  const enterDestination =
    location.state?.destination ||
    (isSingleView ? visibleCategories[0].destination : "/rewardsHomePage");

  const handleEnter = () => {
    navigate(enterDestination, {
      state: {
        committee:
          location.state?.committee ||
          (isSingleView ? visibleCategories[0].committee : undefined),
      },
    });
  };

  return (
    <>
      <Header />
      <div className=" pt-6  mt-[70px]  min-h-[calc(105vh-60px)]">
        <div className="w-full max-w-7xl mx-auto">
          <div className="rounded-[1.4rem] p-[3px] shadow-2xl shadow-black/30 bg-[linear-gradient(135deg,#FF6B35_0%,#FF7559_35%,#FFD700_50%,#FF7559_65%,#FF6B35_100%)]">
            <div className="relative overflow-hidden rounded-[1.2rem] ring-1 ring-[#FFD700]/40 bg-[linear-gradient(180deg,#1a2a6c_0%,#3a1c47_40%,#7a1b2e_70%,#b91c1c_100%)]">
              <div className="pointer-events-none absolute inset-0">
                {FLECKS.map((cls, i) => (
                  <span key={i} className={cls} />
                ))}
              </div>

              <div className="pointer-events-none absolute inset-0">
                {SPARKLES.map((cls, i) => (
                  <span key={`sparkle-${i}`} className={cls}>
                    ✦
                  </span>
                ))}
              </div>

              <div className="pointer-events-none absolute -top-16 -left-16 w-56 h-56 rounded-full bg-[#FFD700]/20 blur-3xl" />
              <div className="pointer-events-none absolute -bottom-20 -right-20 w-72 h-72 rounded-full bg-[#FF6B35]/15 blur-3xl" />

              <span className="pointer-events-none absolute top-3 right-3 w-6 h-6 border-t border-r border-[#FFD700]/60 rounded-tr-md" />
              <span className="pointer-events-none absolute bottom-3 right-3 w-6 h-6 border-b border-r border-[#FFD700]/60 rounded-br-md" />
              <span className="pointer-events-none absolute bottom-3 left-3 w-6 h-6 border-b border-l border-[#FFD700]/60 rounded-bl-md" />
              <span className="pointer-events-none absolute top-3 left-3 w-6 h-6 border-t border-l border-[#FFD700]/60 rounded-tl-md" />

              <div className="relative z-10 flex items-start pt-8 pl-8">
                <svg width="56" height="72" viewBox="0 0 56 72" fill="none" xmlns="http://www.w3.org/2000/svg" className="shrink-0 drop-shadow-md">
                  <path d="M14 30L4 66L28 56L52 66L42 30Z" fill="#CC5500" />
                  <path d="M14 30L4 66L28 56L20 30Z" fill="#FF6B35" />
                  <path d="M42 30L52 66L28 56L36 30Z" fill="#E85D2C" />
                  <circle cx="28" cy="26" r="20" fill="#CC5500" />
                  <circle cx="28" cy="26" r="17" fill="#FF6B35" />
                  <circle cx="28" cy="26" r="12.5" fill="#FFD700" />
                  <circle cx="28" cy="26" r="12.5" stroke="#CC5500" strokeWidth="1.2" fill="none" />
                  <path d="M28 19L29.9 23.6L35 24.1L31.2 27.4L32.4 32.4L28 29.8L23.6 32.4L24.8 27.4L21 24.1L26.1 23.6Z" fill="#CC5500" />
                </svg>
                <div className="relative -ml-1 mt-3 pl-6 pr-8 py-2.5 rounded-r-full shadow-lg bg-[linear-gradient(90deg,#E85D2C_0%,#FF6B35_55%,#FFD700_100%)]">
                  <span className="font-serif text-white text-lg md:text-xl font-semibold tracking-wide drop-shadow-sm">
                    Above and Beyond (A2B)
                  </span>
                  <span className="absolute -right-3 top-1/2 -translate-y-1/2 w-0 h-0 border-t-[18px] border-b-[18px] border-l-[12px] border-t-transparent border-b-transparent border-l-[#E85D2C]" />
                </div>
              </div>

              <div className="relative z-10 px-6 md:px-14 pt-14 pb-24">
                <div
                  className={
                    isSingleView
                      ? "grid grid-cols-1 gap-y-12 max-w-xl mx-auto"
                      : "grid grid-cols-1 md:grid-cols-3 gap-x-8 gap-y-12"
                  }
                >
                  {visibleCategories.map((cat, i) => (
                    <div key={i} className="flex flex-col items-start">
                      <div className="relative flex items-center mb-4">
                        <span className="text-3xl md:text-4xl -mr-3 z-10 drop-shadow-md">
                          {cat.icon}
                        </span>
                        <div className="bg-white rounded-full pl-8 pr-6 py-2.5 shadow-lg">
                          <span className="text-[#b91c1c] font-bold tracking-wide text-sm md:text-base whitespace-nowrap">
                            {cat.label}
                          </span>
                        </div>
                      </div>

                      <p className="text-[#FFF5E6] text-sm leading-relaxed drop-shadow-sm">
                        {cat.description}{" "}
                        <span
                          onClick={() => openPDF(cat.pdfPath)}
                          className="text-[#FFD700] underline decoration-[#FFD700]/70 font-semibold cursor-pointer hover:text-white transition-colors"
                        >
                          {cat.linkText}
                        </span>{" "}
                        {cat.linkSuffix}
                      </p>
                    </div>
                  ))}
                </div>

                {/* Only show this when viewing a single category so users can
                    jump back to seeing all three without leaving the page */}
                {/* {isSingleView && (
                  <div className="mt-8 text-center">
                    <button
                      onClick={() => navigate("/r-r", { state: null })}
                      className="text-[#FFD700] underline text-sm hover:text-white transition-colors"
                    >
                      View all categories
                    </button>
                  </div>
                )} */}
              </div>

              <div className="absolute bottom-6 left-0 right-0 px-6 md:px-8 flex justify-between items-center z-20">
                <button
                  onClick={() => navigate(-1)}
                  className="inline-flex items-center z-20 px-6 py-2 rounded-full bg-white/10 border border-[#FFD700] text-[#FFD700] font-semibold hover:bg-[#FFD700] hover:text-[#7a1b2e] transition-all duration-300"
                >
                  ← Back
                </button>

                <button
                  onClick={handleEnter}
                  className="group inline-flex items-center gap-2 px-10 py-3 rounded-full bg-gradient-to-r from-[#FF6B35] to-[#FFD700] text-white font-bold tracking-wide shadow-lg hover:shadow-2xl hover:shadow-[#FF6B35]/50 transition-all duration-300 hover:scale-105"
                >
                  Enter
                  <span className="transition-transform duration-300 group-hover:translate-x-1">
                    &raquo;
                  </span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default A2BCategoriesScreen;