import React, { useState, useEffect } from 'react';
import NominationForm          from './NominationForm';
import NominationSummaryModal   from './NominationSummaryModal';
import { X, Award, ChevronRight, Lock, Send } from 'lucide-react';
import Swal from 'sweetalert2';
import {
  fetchAllAwards,
  fetchAwardsByUser,
  fetchCurrentFinancialYear,
  getNominationsByEmployee,
} from './ExecuitiveCircleApi';
import Header    from '../../components/Header';
import { useNavigate } from 'react-router-dom';
import ExecutiveCircleReport from './ExecutiveCircleReport';

const ExecutiveCirclePage = () => {
  const currentUser = {
    employeeCode: localStorage.getItem('empId') || '',
    name:         localStorage.getItem('EmployeeFullName') || '',
    email:        localStorage.getItem('email') || '',
  };

  const [awards, setAwards]                     = useState([]);
  const [eligibleAwardIds, setEligibleAwardIds] = useState(new Set());
  const [selectedAward, setSelectedAward]       = useState(null);
  const [view, setView]                         = useState('form');
  const [loading, setLoading]                   = useState(true);
  const [financialYear, setFinancialYear]       = useState(null);
  const [fyLabel, setFyLabel]                   = useState('');
  const [previewOpen, setPreviewOpen]           = useState(false);

  // Track submitted/approved awards (for form lock, bullet colour, and tick)
  const [submittedAwardIds, setSubmittedAwardIds] = useState(new Set());
  const [isOverallSubmitted, setIsOverallSubmitted] = useState(false);

  const navigate = useNavigate();

  useEffect(() => {
    (async () => {
      try {
        const fy = await fetchCurrentFinancialYear();
        setFinancialYear(fy.label);
        setFyLabel(fy.label);

        const allList = await fetchAllAwards();
        setAwards(allList);
        if (allList.length > 0) setSelectedAward(allList[0]);

        if (currentUser.employeeCode) {
          const eligibleList = await fetchAwardsByUser(currentUser.employeeCode);
          setEligibleAwardIds(new Set(eligibleList.map((a) => a.id)));

          try {
            const nominations = await getNominationsByEmployee(
              currentUser.employeeCode, fy.label
            );
            const getAwardId = (n) => n.awardId ?? n.award?.id ?? n.awardID ?? null;

            // Filter for "Submitted to HR" or "Approved" statuses
            const submittedNoms = (nominations || []).filter(
  (n) => n.status === 'Submitted to HR' || n.status === 'Approved'
);
            const submittedIds = new Set(submittedNoms.map(getAwardId).filter(Boolean));
            setSubmittedAwardIds(submittedIds);
            setIsOverallSubmitted(submittedNoms.length > 0);
          } catch (_) {}
        }
      } catch (err) {
        console.error('Init failed:', err);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const canNominate = (award) => eligibleAwardIds.has(award.id);

  const handlePreviewClose = async () => {
    setPreviewOpen(false);
    if (!currentUser.employeeCode || !financialYear) return;
    try {
      const nominations = await getNominationsByEmployee(currentUser.employeeCode, financialYear);
      const getAwardId = (n) => n.awardId ?? n.award?.id ?? n.awardID ?? null;
      const submittedNoms = (nominations || []).filter(
  (n) => n.status === 'Submitted to HR' || n.status === 'Approved'
);
      const submittedIds = new Set(submittedNoms.map(getAwardId).filter(Boolean));
      setSubmittedAwardIds(submittedIds);
      setIsOverallSubmitted(submittedNoms.length > 0);
    } catch (_) {}
  };

  const handleSidebarClick = (award) => {
    setSelectedAward(award);
    setView('form');
  };

  const handleOpenModal = async () => {
    setPreviewOpen(true);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-100 flex items-center justify-center">
        <span className="text-gray-500 text-sm">Loading Executive Circle...</span>
      </div>
    );
  }

  if (view === 'details') {
    return (
      <>
        <Header />
        <div className="min-h-screen bg-gray-100 font-sans flex flex-col mt-16 pt-4">
          <TopBanner
            financialYear={financialYear}
            onDetailsClick={() => setView('details')}
            onBack={() => navigate('/executive-circle-list')}
            isDetailsView
          />
          <div className="flex-1 bg-white overflow-y-auto">
            <ExecutiveCircleReport
              financialYear={financialYear}
              onBack={() => {
                setView('form');
                if (!selectedAward && awards.length > 0) setSelectedAward(awards[0]);
              }}
            />
          </div>
          {/* <Footer /> */}
        </div>
      </>
    );
  }

  return (
    <>
      <Header />

      <NominationSummaryModal
        isOpen={previewOpen}
        onClose={handlePreviewClose}
        financialYear={financialYear}
        currentUser={currentUser}
      />

      <div className="min-h-screen bg-gray-100 font-sans flex flex-col mt-16 pt-4">
        <TopBanner
          financialYear={financialYear}
          onDetailsClick={() => setView('details')}
          onBack={() => navigate('/executive-circle-list')}
        />

        <div className="flex flex-1 overflow-hidden">

          {/* ── Sidebar ── */}
          <aside className="flex flex-col bg-white border-r border-gray-200 w-72 shrink-0">
            <div className="flex-1 overflow-y-auto p-4">
              <h3 className="text-xs font-bold uppercase text-gray-400 tracking-wider mb-3">
                Award Categories
              </h3>
              <ul className="space-y-2">
                {[...awards]
                  .sort((a, b) => {
                    const aEligible = eligibleAwardIds.has(a.id) ? 0 : 1;
                    const bEligible = eligibleAwardIds.has(b.id) ? 0 : 1;
                    return aEligible - bEligible;
                  })
                  .map((award) => {
                    const active = view === 'form' && selectedAward?.id === award.id;
                    const accessible = canNominate(award);
                    const submitted = submittedAwardIds.has(award.id);

                    // Bullet colour: green if submitted/approved, else gray
                    const bulletColor = submitted ? 'border-green-500 bg-green-500' : 'border-gray-400 bg-transparent';

                    return (
                      <li
                        key={award.id}
                        onClick={() => handleSidebarClick(award)}
                        className={`flex items-center gap-3 px-3 py-3 rounded-lg cursor-pointer transition text-base ${
                          active
                            ? 'bg-blue-900 text-white font-semibold'
                            : 'hover:bg-gray-300 text-gray-800'
                        }`}
                        title={
                          submitted
                            ? 'Submitted to HR'
                            : !accessible
                            ? 'Not open for nomination'
                            : award.awardTitle
                        }
                      >
                        {/* Circle bullet */}
                        <span
                          className={`inline-block w-3 h-3 rounded-full border-2 flex-shrink-0 ${bulletColor}`}
                        />

                        <span className="flex-1">{award.awardTitle}</span>

                        {/* Green tick for submitted/approved only */}
                        {submitted && !active && (
                          <span className="text-green-600 font-bold text-sm">✔</span>
                        )}

                        {/* Lock for ineligible (only if not submitted) */}
                        {!accessible && !submitted && (
                          <Lock
                            size={12}
                            className="shrink-0"
                            style={{ opacity: active ? 0.55 : 0.4 }}
                          />
                        )}

                        <ChevronRight size={13} className="shrink-0 opacity-0 group-hover:opacity-100" />
                      </li>
                    );
                  })}
              </ul>
            </div>

            {/* Preview & Submit row */}
            <div
              onClick={handleOpenModal}
              className="flex items-center gap-2 px-4 py-3 text-sm font-semibold text-gray-700 cursor-pointer border-t-2 border-gray-200 hover:bg-amber-50 hover:text-amber-800 transition"
            >
              <Send size={14} className="shrink-0" />
              <span className="flex-1">Nomination Details &amp; Submit To HR</span>
              <ChevronRight size={13} className="opacity-60" />
            </div>
          </aside>

          {/* ── Main content ── */}
          <main className="flex-1 bg-white overflow-y-auto px-4">
            {selectedAward ? (
              <div className="px-8 py-5">
                <NominationForm
                  key={selectedAward.id}
                  award={selectedAward}
                  financialYear={financialYear}
                  currentUser={currentUser}
                  canNominate={canNominate(selectedAward)}
                  isSubmittedProp={submittedAwardIds.has(selectedAward.id)}
                  isOverallSubmitted={isOverallSubmitted}
                />
              </div>
            ) : null}
          </main>
        </div>

        {/* <Footer /> */}
      </div>
    </>
  );
};

/* ── Shared components ────────────────────────────────────────────────────── */
const TopBanner = ({ financialYear, onDetailsClick, onBack, isDetailsView }) => (
  <div className=" bg-gradient-to-b from-red-900 to-red-700 text-white px-6 py-3 flex items-center justify-between shadow-sm">
    <div className="flex items-center gap-3">
      <Award size={20} className="opacity-80" />
      <div className="flex flex-col leading-tight">
        <span className="text-base font-bold tracking-wide">EXECUTIVE CIRCLE AWARDS</span>
        <span className="text-xs opacity-80">Financial Year {financialYear}</span>
      </div>
    </div>
    <div className="flex items-center gap-2">
      <button
        onClick={onBack}
        className="bg-white/20 hover:bg-white/30 text-white rounded-full p-2 transition-all backdrop-blur-sm"
        title="Back"
      >
        <X size={16} />
      </button>
    </div>
  </div>
);

// const Footer = () => (
//   <div className="bg-orange-600 text-white text-center py-2 text-xs shrink-0">
//     Copyright © 2025 CMS Computers Limited. All Rights Reserved.
//   </div>
// );

export default ExecutiveCirclePage;