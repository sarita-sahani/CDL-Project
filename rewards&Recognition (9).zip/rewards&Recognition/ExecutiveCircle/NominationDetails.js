import React, { useState, useEffect, useMemo } from 'react';
import { getExecutiveCircleDetails, downloadExcel } from './ExecuitiveCircleApi';

/**
 * Props
 * ─────
 * financialYear – "26-27"  (from ExecutiveCirclePage → backend)
 * onBack()      – navigate back to form view
 */
const NominationDetails = ({ financialYear, onBack }) => {
  const [summaries, setSummaries] = useState([]);
  const [loading, setLoading]     = useState(true);
  const [search, setSearch]       = useState('');
  const [pageSize, setPageSize]   = useState(10);
  const [page, setPage]           = useState(0);
   const ManagerEmpCode = localStorage.getItem("empId");

  useEffect(() => {
    if (!financialYear) return;
    setLoading(true);
    getExecutiveCircleDetails(financialYear, ["Submitted to HR", "Approved"], ManagerEmpCode)
      .then(setSummaries)
      .catch(() => setSummaries([]))
      .finally(() => setLoading(false));
  }, [financialYear]);

  const filtered = useMemo(() => {
    if (!search) return summaries;
    const q = search.toLowerCase();
    return summaries.filter(
      (s) =>
        s.awardTitle?.toLowerCase().includes(q)  ||
        s.category?.toLowerCase().includes(q)    ||
        s.nomination1?.toLowerCase().includes(q) ||
        s.nomination2?.toLowerCase().includes(q) ||
        s.nomination3?.toLowerCase().includes(q) ||
        s.nomination4?.toLowerCase().includes(q)
    );
  }, [summaries, search]);

  const totalPages = Math.ceil(filtered.length / pageSize) || 1;
  const paginated  = filtered.slice(page * pageSize, page * pageSize + pageSize);

  // Sort icon — purely decorative (↕) to match screenshot
  const SortIcon = () => (
    <span className="ml-1 opacity-70 text-xs">↕</span>
  );

  return (
    <div className="font-sans min-h-screen flex flex-col">

      {/* ── Full-width Red Header Bar ─────────────────────────────────────────── */}
      <div className="flex justify-between items-center  bg-gradient-to-b from-red-900 to-red-700 px-4 py-2.5">
        <span className="text-white font-bold text-sm tracking-wide">
          Nomination Details
        </span>
        <button
          onClick={onBack}
          className="bg-blue-900 hover:bg-blue-800 text-white text-xs font-semibold
                     px-5 py-1.5 rounded transition-colors"
        >
          Back
        </button>
      </div>

      {/* ── Page body ────────────────────────────────────────────────────────── */}
      <div className="p-4 flex-1">

        {/* Controls: show entries (left) | excel + search (right) */}
        <div className="flex justify-between items-center mb-3 text-xs text-gray-700">

          {/* Left — Show N entries */}
          <div className="flex items-center gap-1.5">
            <span>Show</span>
            <select
              value={pageSize}
              onChange={(e) => { setPageSize(Number(e.target.value)); setPage(0); }}
              className="border border-gray-400 rounded px-1.5 py-0.5 text-xs
                         focus:outline-none focus:ring-1 focus:ring-blue-400"
            >
              {[10, 25, 50].map((n) => <option key={n}>{n}</option>)}
            </select>
            <span>entries</span>
          </div>

          {/* Right — Excel download + Search */}
          <div className="flex items-center gap-2.5">
            <button
              onClick={() => downloadExcel(financialYear)}
              className="bg-green-700 hover:bg-green-600 text-white text-xs font-semibold
                         px-3 py-1.5 rounded transition-colors"
            >
              ⬇ Download Excel
            </button>
            <span className="text-gray-600">Search:</span>
            <input
              value={search}
              onChange={(e) => { setSearch(e.target.value); setPage(0); }}
              placeholder="Search..."
              className="border border-gray-400 rounded px-2.5 py-1.5 text-xs w-44
                         focus:outline-none focus:ring-1 focus:ring-blue-400"
            />
          </div>
        </div>

        {/* ── Table ──────────────────────────────────────────────────────────── */}
        {loading ? (
          <div className="text-center py-10 text-gray-400 text-sm">Loading...</div>
        ) : (
          <div className="overflow-x-auto border border-gray-300 rounded">
            <table className="w-full border-collapse text-xs">
              <thead>
                <tr className="bg-purple-700 text-white">
                  <th className="px-3 py-2 text-left border border-purple-600 font-semibold whitespace-nowrap">
                    Award title <SortIcon />
                  </th>
                  <th className="px-3 py-2 text-left border border-purple-600 font-semibold whitespace-nowrap">
                    Category <SortIcon />
                  </th>
                  <th className="px-3 py-2 text-left border border-purple-600 font-semibold whitespace-nowrap">
                    Nomination1 <SortIcon />
                  </th>
                  <th className="px-3 py-2 text-left border border-purple-600 font-semibold whitespace-nowrap">
                    Nomination2 <SortIcon />
                  </th>
                  <th className="px-3 py-2 text-left border border-purple-600 font-semibold whitespace-nowrap">
                    Nomination3 <SortIcon />
                  </th>
                  <th className="px-3 py-2 text-left border border-purple-600 font-semibold whitespace-nowrap">
                    Nomination4 <SortIcon />
                  </th>
                </tr>
              </thead>
              <tbody>
                {paginated.length === 0 ? (
                  <tr>
                    <td
                      colSpan={6}
                      className="text-center py-8 text-gray-500 text-xs border border-gray-200"
                    >
                      No data available in table
                    </td>
                  </tr>
                ) : (
                  paginated.map((s, i) => (
                    <tr
                      key={s.nominationId ?? i}
                      className={i % 2 === 1 ? 'bg-gray-50' : 'bg-white'}
                    >
                      {/* Award Title */}
                      <td className="px-3 py-2 border border-gray-200 font-semibold text-gray-800 whitespace-nowrap">
                        {s.awardTitle || '—'}
                      </td>

                      {/* Category */}
                      <td className="px-3 py-2 border border-gray-200 text-gray-700 whitespace-nowrap">
                        {s.category || '—'}
                      </td>

                      {/* Nomination 1 — name + dept + reason tooltip */}
                      <td className="px-3 py-2 border border-gray-200 text-gray-700">
                        <NomineeCell
                          name={s.nomination1}
                          department={s.department1}
                          reason={s.reason1}
                        />
                      </td>

                      {/* Nomination 2 */}
                      <td className="px-3 py-2 border border-gray-200 text-gray-700">
                        <NomineeCell
                          name={s.nomination2}
                          department={s.department2}
                          reason={s.reason2}
                        />
                      </td>

                      {/* Nomination 3 */}
                      <td className="px-3 py-2 border border-gray-200 text-gray-700">
                        <NomineeCell
                          name={s.nomination3}
                          department={s.department3}
                          reason={s.reason3}
                        />
                      </td>

                      {/* Nomination 4 */}
                      <td className="px-3 py-2 border border-gray-200 text-gray-700">
                        <NomineeCell
                          name={s.nomination4}
                          department={s.department4}
                          reason={s.reason4}
                        />
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        )}

        {/* ── Pagination ─────────────────────────────────────────────────────── */}
        <div className="flex justify-between items-center mt-3 text-xs text-gray-500">
          <span>
            Showing{' '}
            {filtered.length === 0 ? 0 : page * pageSize + 1} to{' '}
            {Math.min((page + 1) * pageSize, filtered.length)} of {filtered.length} entries
          </span>
          <div className="flex gap-2">
            <button
              disabled={page === 0}
              onClick={() => setPage((p) => Math.max(0, p - 1))}
              className={`px-3 py-1 rounded text-xs font-medium transition-colors
                ${page === 0
                  ? 'bg-gray-100 text-gray-400 cursor-default'
                  : 'bg-blue-900 text-white hover:bg-blue-800 cursor-pointer'}`}
            >
              Previous
            </button>
            <button
              disabled={page >= totalPages - 1}
              onClick={() => setPage((p) => Math.min(totalPages - 1, p + 1))}
              className={`px-3 py-1 rounded text-xs font-medium transition-colors
                ${page >= totalPages - 1
                  ? 'bg-gray-100 text-gray-400 cursor-default'
                  : 'bg-blue-900 text-white hover:bg-blue-800 cursor-pointer'}`}
            >
              Next
            </button>
          </div>
        </div>

      </div>{/* end body */}
    </div>
  );
};

/* ─────────────────────────────────────────────────────────────────────────────
   NomineeCell
   Shows the nominee name. If department / reason are available (from the
   NominationForm payload) they appear as subtle sub-text beneath the name.
   ───────────────────────────────────────────────────────────────────────────── */
const NomineeCell = ({ name, department, reason }) => {
  if (!name) return <span className="text-gray-400">—</span>;

  return (
    <div className="min-w-[120px]">
      {/* Nominee name — primary */}
      <div className="font-medium text-gray-800">{name}</div>

      {/* Department — secondary */}
      {department && (
        <div className="text-gray-500 text-xs mt-0.5">
          {department}
        </div>
      )}

      {/* Reason — tertiary, italicised, capped at 2 lines */}
      {reason && (
        <div
          className="text-gray-400 text-xs mt-0.5 italic leading-tight"
          style={{
            display: '-webkit-box',
            WebkitLineClamp: 2,
            WebkitBoxOrient: 'vertical',
            overflow: 'hidden',
          }}
          title={reason}   /* full text on hover */
        >
          {reason}
        </div>
      )}
    </div>
  );
};

export default NominationDetails;