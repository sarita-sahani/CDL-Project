import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, Trophy, Save } from "lucide-react";
import Swal from "sweetalert2";
import Header from "../../components/Header";
import {
  fetchCurrentFinancialYear,
  getRankingCandidates,
  saveExecutiveCircleRanking,
  getExecutiveCircleRanking,
} from "./ExecuitiveCircleApi";

const ExecutiveCircleRanking = () => {
  const navigate = useNavigate();
  const [financialYear, setFinancialYear] = useState("");
  const [allData, setAllData] = useState([]);
  const [awardTitles, setAwardTitles] = useState([]);
  const [selectedAward, setSelectedAward] = useState("");
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(false);
  const [fetchingRankings, setFetchingRankings] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      const fyResponse = await fetchCurrentFinancialYear();
      const fy = fyResponse?.data || fyResponse?.currentFinancialYear || fyResponse;
      const fyString = typeof fy === "object" && fy !== null ? fy.label : fy;
      setFinancialYear(fyString);

      const response = await getRankingCandidates(fyString);
      const nominations = response?.data || response || [];

      const transformed = nominations.map((item) => ({
        ...item,
        awardCode: item.awardTitle?.code || item.awardTitle,
        awardLabel: item.awardTitle?.label || item.awardTitle,
      }));
      setAllData(transformed);

      const awardMap = new Map();
      transformed.forEach((item) => {
        if (!awardMap.has(item.awardCode)) {
          awardMap.set(item.awardCode, item.awardLabel);
        }
      });
      const uniqueAwards = Array.from(awardMap.entries()).map(([code, label]) => ({
        code,
        label,
      }));
      setAwardTitles(uniqueAwards);

      // Default to the first award title and load its data automatically
      if (uniqueAwards.length > 0) {
        const firstAwardCode = uniqueAwards[0].code;
        setSelectedAward(firstAwardCode);
        await loadNomineesForAward(firstAwardCode, transformed, fyString);
      }
    } catch (error) {
      console.error(error);
      await Swal.fire({
        icon: 'error',
        title: 'Error loading data',
        text: error.message,
      });
    } finally {
      setLoading(false);
    }
  };

  // Builds the nominee rows for a given award and fetches any saved rankings.
  // Accepts the source data and financial year explicitly so it can be called
  // right after loadData() resolves, before the allData/financialYear state
  // updates have necessarily flushed.
  const loadNomineesForAward = async (awardCode, dataSource, fyOverride) => {
    const fyToUse = fyOverride ?? financialYear;

    const filtered = dataSource.filter((item) => item.awardCode === awardCode);
    const nominees = [];
    filtered.forEach((nomination) => {
      const nominatedByEmployeeCode = nomination.submittedByEmployeeCode || "";
      const nominatedByName = nomination.submittedByName || "";
      nomination.nominationDetails?.forEach((detail) => {
        nominees.push({
          id: detail.id,
          nominationDetailId: detail.id,
          nomineeName: detail.nomineeName,
          employeeCode: detail.nomineeEmployeeCode,
          department: detail.department,
          reason: detail.reasonForNomination,
          nominatedByEmployeeCode,
          nominatedByName,
          rankPosition: null,
          rankReason: "",
        });
      });
    });

    setFetchingRankings(true);
    try {
      const rankingsResponse = await getExecutiveCircleRanking(fyToUse, awardCode);
      const rankings = rankingsResponse?.data || [];
      const rankMap = {};
      rankings.forEach((r) => {
        rankMap[r.nominationDetailId] = {
          rankPosition: r.rankPosition,
          rankReason: r.rankReason || "",
        };
      });
      nominees.forEach((nominee) => {
        const rankInfo = rankMap[nominee.nominationDetailId];
        if (rankInfo) {
          nominee.rankPosition = rankInfo.rankPosition;
          nominee.rankReason = rankInfo.rankReason;
        }
      });
    } catch (error) {
      console.error("Error fetching rankings:", error);
    } finally {
      setFetchingRankings(false);
    }

    setRows(nominees);
  };

  const handleAwardChange = async (awardCode) => {
    setSelectedAward(awardCode);
    await loadNomineesForAward(awardCode, allData);
  };

  const handleRankSelect = async (nomineeId, newRank) => {
    if (!newRank) return;

    const currentRow = rows.find((r) => r.id === nomineeId);
    if (!currentRow) return;

    // Prompt for reason
    const { value: reason, isConfirmed } = await Swal.fire({
      title: "Reason for ranking",
      html: `
        <p>You are assigning <strong>Rank ${newRank}</strong> to <strong>${currentRow.nomineeName}</strong>.</p>
        <p style="margin-top: 8px; font-size: 0.9rem; color: #555;">Please provide a reason for this ranking.</p>
      `,
      input: "text",
      inputLabel: "Reason",
      inputValue: currentRow.rankReason || "",
      inputPlaceholder: "Enter your justification...",
      showCancelButton: true,
      confirmButtonText: "Assign Rank",
      cancelButtonText: "Cancel",
      inputValidator: (value) => {
        if (!value || value.trim() === "") {
          return "Reason is required!";
        }
        return null;
      },
    });

    if (isConfirmed && reason) {
      const updatedRows = rows.map((row) => {
        if (row.rankPosition === Number(newRank) && row.id !== nomineeId) {
          return { ...row, rankPosition: null, rankReason: "" };
        }
        if (row.id === nomineeId) {
          return { ...row, rankPosition: Number(newRank), rankReason: reason };
        }
        return row;
      });
      setRows(updatedRows);
    }
    // If cancelled, do nothing
  };

  const saveRanking = async () => {
    try {
      const rankedRows = rows.filter((row) => row.rankPosition);
      if (rankedRows.length === 0) {
        await Swal.fire({
          icon: 'warning',
          title: 'No Rankings',
          text: 'Please assign at least one ranking before saving.',
          confirmButtonText: 'OK'
        });
        return;
      }

      const missingReason = rankedRows.some((row) => !row.rankReason || row.rankReason.trim() === "");
      if (missingReason) {
        await Swal.fire({
          icon: 'warning',
          title: 'Missing Reason',
          text: 'All rankings must have a reason. Please assign a reason for each rank.',
          confirmButtonText: 'OK'
        });
        return;
      }

      // Confirmation dialog
      const result = await Swal.fire({
        title: 'Confirm Save',
        text: 'Are you sure you want to save these rankings?',
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'Yes, Save',
        cancelButtonText: 'Cancel',
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
      });

      if (!result.isConfirmed) {
        return;
      }

      setLoading(true);
      for (const row of rankedRows) {
        await saveExecutiveCircleRanking({
          financialYear,
          awardTitle: selectedAward,
          nominationDetailId: row.nominationDetailId,
          rankPosition: row.rankPosition,
          reason: row.rankReason,
        });
      }

      await Swal.fire({
        icon: 'success',
        title: 'Saved!',
        text: 'Ranking saved successfully.',
        timer: 1500,
        showConfirmButton: false,
      });

      await handleAwardChange(selectedAward);
    } catch (error) {
      await Swal.fire({
        icon: 'error',
        title: 'Error',
        text: error.message || 'Failed to save rankings.',
      });
    } finally {
      setLoading(false);
    }
  };

  const rankedCount = rows.filter((r) => r.rankPosition).length;

  const rankBadgeClass = (rank) => {
    switch (rank) {
      case 1: return "bg-amber-100 text-amber-800 border-amber-300";
      case 2: return "bg-slate-200 text-slate-700 border-slate-300";
      case 3: return "bg-orange-100 text-orange-800 border-orange-300";
      default: return "";
    }
  };

  return (
    <>
      <Header />
      <div className="min-h-screen bg-slate-50 mt-[70px] w-full font-sans pt-6 pb-10 px-4 sm:px-6 lg:px-8">
        <div className="max-w-full mx-auto bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
          {/* Header */}
          <div className="bg-gradient-to-r from-red-900 to-red-700 px-6 py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <button
                  onClick={() => navigate("/executive-circle-list")}
                  className="text-white hover:text-gray-200 transition p-1 rounded-full bg-white/15 hover:bg-white/25"
                  title="Go back"
                >
                  <ArrowLeft size={20} />
                </button>
                <h2 className="text-lg font-semibold text-white flex items-center gap-2">
                  <Trophy size={18} />
                  Executive Circle Ranking
                </h2>
              </div>
              <div className="text-white/90 text-sm font-medium bg-white/15 px-4 py-1.5 rounded-lg">
                FY: {financialYear}
              </div>
            </div>
          </div>

          {/* Content */}
          <div className="p-6">
            {/* Toolbar */}
            <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-4 mb-5 pb-4 border-b border-slate-200">
              <div className="w-full md:w-96">
                <label className="block mb-1.5 text-xs font-semibold uppercase tracking-wide text-slate-500">
                  Award Title
                </label>
                <select
                  value={selectedAward}
                  onChange={(e) => handleAwardChange(e.target.value)}
                  className="w-full border border-slate-300 rounded-md px-3 py-2 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-red-200 focus:border-red-400 transition"
                >
                  <option value="">Select Award</option>
                  {awardTitles.map((award) => (
                    <option key={award.code} value={award.code}>
                      {award.label}
                    </option>
                  ))}
                </select>
              </div>

              {selectedAward && (
                <div className="flex flex-wrap items-center gap-3">
                  <span className="text-xs font-semibold text-slate-500 bg-slate-100 rounded-full px-3 py-1.5">
                    {rankedCount} of {rows.length} nominees ranked
                  </span>
                  <button
                    onClick={saveRanking}
                    disabled={loading || !selectedAward}
                    className="inline-flex items-center gap-2 rounded-md bg-red-700 px-5 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-red-800 hover:shadow transition disabled:bg-slate-300 disabled:cursor-not-allowed disabled:shadow-none"
                  >
                    <Save size={15} />
                    Save Ranking
                  </button>
                </div>
              )}
            </div>

            {selectedAward && (
              <div className="overflow-x-auto rounded-lg border border-slate-200">
                <table className="w-full text-sm">
                  <thead className="bg-slate-100">
                    <tr>
                      <th className="px-4 py-3 text-center text-xs font-semibold uppercase tracking-wide text-slate-500">Sr. No.</th>
                      <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-slate-500">Nominee Name</th>
                      <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-slate-500">Employee Code</th>
                      <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-slate-500">Department</th>
                      <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-slate-500">Reason</th>
                      <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-slate-500">Nominated By (Code)</th>
                      <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-slate-500">Nominated By (Name)</th>
                      <th className="px-4 py-3 text-center text-xs font-semibold uppercase tracking-wide text-slate-500">Rank</th>
                      <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-slate-500">Rank Reason</th>
                    </tr>
                  </thead>
                  <tbody>
                    {rows.length === 0 ? (
                      <tr>
                        <td colSpan="9" className="text-center py-10 text-slate-400">
                          {fetchingRankings ? "Loading rankings..." : "No nominees for this award."}
                        </td>
                      </tr>
                    ) : (
                      rows.map((row, idx) => {
                        const usedRanks = rows
                          .filter((r) => r.id !== row.id && r.rankPosition)
                          .map((r) => r.rankPosition);
                        const isRanked = row.rankPosition !== null && row.rankPosition !== undefined;

                        return (
                          <tr key={row.id} className="odd:bg-white even:bg-slate-50/70 border-b border-slate-100 hover:bg-red-50/60 transition-colors duration-150">
                            <td className="px-4 py-3 text-center text-slate-500">{idx + 1}</td>
                            <td className="px-4 py-3 text-slate-700 font-medium">{row.nomineeName}</td>
                            <td className="px-4 py-3 text-slate-700">{row.employeeCode}</td>
                            <td className="px-4 py-3 text-slate-700">{row.department}</td>
                            <td className="px-4 py-3 text-slate-700">{row.reason}</td>
                            <td className="px-4 py-3 text-slate-700">{row.nominatedByEmployeeCode}</td>
                            <td className="px-4 py-3 text-slate-700">{row.nominatedByName}</td>
                            <td className="px-4 py-3 text-center">
                              <div className="flex items-center justify-center gap-2">
                                {isRanked && (
                                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${rankBadgeClass(row.rankPosition)}`}>
                                    #{row.rankPosition}
                                  </span>
                                )}
                                <select
                                  value={row.rankPosition || ""}
                                  onChange={(e) => handleRankSelect(row.id, e.target.value)}
                                  disabled={isRanked}
                                  className={`border rounded-md px-3 py-1.5 w-24 text-sm transition ${
                                    isRanked
                                      ? "bg-slate-100 border-slate-200 text-slate-500 cursor-not-allowed"
                                      : "border-slate-300 bg-white focus:outline-none focus:ring-2 focus:ring-red-200 focus:border-red-400"
                                  }`}
                                >
                                  <option value="">Select</option>
                                  {[1, 2, 3]
                                    .filter(
                                      (rank) =>
                                        !usedRanks.includes(rank) || rank === row.rankPosition
                                    )
                                    .map((rank) => (
                                      <option key={rank} value={rank}>
                                        Rank {rank}
                                      </option>
                                    ))}
                                </select>
                              </div>
                            </td>
                            <td className="px-4 py-3 text-sm text-slate-700">
                              {row.rankReason || (isRanked ? "Reason not provided" : "—")}
                            </td>
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      </div>
    </>
  );
};

export default ExecutiveCircleRanking;