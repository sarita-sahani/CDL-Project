const BASE_URL = 'http://localhost:9035/api';

const handleResponse = async (res) => {
  if (!res.ok) {
    const text = await res.text();
    let msg = `HTTP ${res.status}`;
    try {
      const parsed = JSON.parse(text);
      msg = parsed.error || parsed.message || msg;
    } catch {
      msg = text || msg;
    }
    throw new Error(msg);
  }
  const text = await res.text();
  return text ? JSON.parse(text) : null;
};

// ── Financial Year ─────────────────────────────────────────────────────────────
let _fyCache = null;
export const fetchCurrentFinancialYear = () => {
  if (!_fyCache) {
    _fyCache = fetch(`${BASE_URL}/financial-year/currentYear`).then(handleResponse);
  }
  return _fyCache;
};

export const fetchAllAwards = () =>
  fetch(`${BASE_URL}/awards`).then(handleResponse);


export const fetchAwardsByUser = (empCode) =>
  fetch(`${BASE_URL}/awards/user?empCode=${encodeURIComponent(empCode)}`)
    .then(handleResponse);

export const assignAwardEligibility = (data) =>
  fetch(`${BASE_URL}/awards/award-eligibility`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  }).then(handleResponse);

export const getEligibilityByAward = (awardId) =>
  fetch(`${BASE_URL}/awards/eligibility/${awardId}`)
    .then(handleResponse);

export const removeEligibility = (id) =>
  fetch(`${BASE_URL}/awards/remove-eligibility/${id}`, {
    method: 'DELETE',
  }).then(handleResponse);
    
  export const checkAnyAwardEligibility = async (empCode) => {
  const res = await fetch(
    `${BASE_URL}/awards/check-eligibility?empCode=${encodeURIComponent(empCode)}`
  );
  if (!res.ok) throw new Error('Eligibility check failed');
  return res.json(); // true/false
};
// ── Nominations ────────────────────────────────────────────────────────────────
export const saveNomination = (data) =>
  fetch(`${BASE_URL}/nominations/saveNominationsDetails`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  }).then(handleResponse);

export const getNominationByAwardEmployee = (awardId, empCode, fy) =>
  fetch(`${BASE_URL}/nominations/award/${awardId}/employee/${empCode}?financialYear=${fy}`)
    .then(handleResponse);

export const getNominationsByEmployee = (empCode, fy) =>
  fetch(`${BASE_URL}/nominations/employee/${empCode}?financialYear=${fy}`).then(handleResponse);

// export const getAllexecutiveCircleDetails = (fy) =>
//   fetch(`${BASE_URL}/nominations/getAllexecutiveCircleDetails?financialYear=${fy}`).then(handleResponse);

// export const getAllNominationSummaries = (fy, status) => {
//   let url = `${BASE_URL}/nominations/executiveCircleDetails?financialYear=${encodeURIComponent(fy)}`;
//   if (status) {
//     url += `&status=${encodeURIComponent(status)}`;
//   }
//   return fetch(url).then(handleResponse);
// };

export const getExecutiveCircleDetails = (fy, status = null, managerEmpCode = null) => {
  const params = new URLSearchParams();

  if (fy) params.append('financialYear', fy);

  // append each status separately so backend receives status=X&status=Y
  if (status) {
    (Array.isArray(status) ? status : [status])
      .forEach(s => params.append('status', s));
  }

  if (managerEmpCode) params.append('managerEmpCode', managerEmpCode);

  return fetch(`${BASE_URL}/nominations/executiveCircleDetails?${params.toString()}`)
    .then(handleResponse);
};

export const submitAllNominations = (empCode, fy) =>
  fetch(
    `${BASE_URL}/nominations/submit-all` +
      `?employeeCode=${encodeURIComponent(empCode)}&financialYear=${fy}`,
    { method: 'POST' }
  ).then(handleResponse);

export const submitNomination = (id) =>
  fetch(`${BASE_URL}/nominations/${id}/submit`, { method: 'POST' }).then(handleResponse);

export const fetchNominationsByUser = (employeeCode, financialYear) =>
  fetch(
    `${BASE_URL}/nominations/preview?employeeCode=${encodeURIComponent(employeeCode)}&financialYear=${encodeURIComponent(financialYear)}`
  ).then((r) => {
    if (!r.ok) throw new Error('Failed to load preview');
    return r.json();
  });

export const submitAllNominationsEmployees = async (employeeCode, financialYear) => {
  const res = await fetch(`${BASE_URL}/nominations/submit`, {
    method:  'POST',
    headers: { 'Content-Type': 'application/json' },
    body:    JSON.stringify({ employeeCode, financialYear }),
  });
  if (!res.ok) {
    const msg = await res.text();
    throw new Error(msg || 'Submission failed');
  }
  return res.json();
};

export const downloadExcel = (fy) => {
  const a = document.createElement('a');
  a.href = `${BASE_URL}/nominations/export/excel?financialYear=${fy}`;
  a.download = `NominationDetails_FY${fy}.xlsx`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
};

// ── Executive Circle Ranking ─────────────────────────────────────────────

export const getRankingCandidates = (fy) =>
  {
  const financialYear =
    typeof fy === "object"
      ? fy.label
      : fy;

  return fetch(
    `${BASE_URL}/nominations/executiveCircleDetails?financialYear=${encodeURIComponent(financialYear)}`
  ).then(handleResponse);
};

export const updateNominationStatus = async (nominationId, status, hrRemarks) => {
  const response = await fetch(`${BASE_URL}/nominations/${nominationId}/review`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ status, hrRemarks }),
  });
  if (!response.ok) {
    const text = await response.text();
    throw new Error(text || 'Failed to update nomination status');
  }
  return response.json();
};

export const saveExecutiveCircleRanking = (data) =>
  fetch(`${BASE_URL}/rankings/saveExecutiveCircleRank`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(data),
  }).then(handleResponse);


  export const getExecutiveCircleRanking = async (financialYear, awardTitle) => {
  const response = await fetch(
    `${BASE_URL}/rankings/getExecutiveCircleRanking?financialYear=${financialYear}&awardTitle=${encodeURIComponent(awardTitle)}`
  );
  if (!response.ok) {
    throw new Error("Failed to fetch rankings");
  }
  const data = await response.json();
  return data; // assuming the response shape is { data: [...] }
};

export const getAwardWinners = (financialYear) =>
  fetch(`${BASE_URL}/rankings/ExecutiveCircleWinners?financialYear=${encodeURIComponent(financialYear)}`)
    .then(handleResponse);