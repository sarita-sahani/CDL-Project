// HrReviewPage.js

import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import * as XLSX from "xlsx";
import { saveAs } from "file-saver";
import { X } from "lucide-react";
import Swal from "sweetalert2";

import Header from "../../components/Header";
import {
  fetchCurrentFinancialYear,
  getExecutiveCircleDetails,
  updateNominationStatus,
} from "./ExecuitiveCircleApi";

const HrExecutiveReviewPage = () => {
  const navigate = useNavigate();

  const [financialYear, setFinancialYear] = useState("");
  const [fyOptions, setFyOptions] = useState([]);
  const [reportData, setReportData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [currentPage, setCurrentPage] = useState(1);

  // Load FY and data
  useEffect(() => {
    loadFinancialYear();
  }, []);

  const loadFinancialYear = async () => {
    try {
      const response = await fetchCurrentFinancialYear();
      const currentFYLabel = response.label || response;
      if (!currentFYLabel) throw new Error("No financial year data");

      let startYearMatch = currentFYLabel.match(/(\d{4})/);
      let startYear = startYearMatch ? parseInt(startYearMatch[1]) : new Date().getFullYear();

      const options = [];
      for (let i = 0; i <= 2; i++) {
        const yearStart = startYear - i;
        const yearEnd = (yearStart + 1).toString().slice(-2);
        options.push(`${yearStart}-${yearEnd}`);
      }
      setFyOptions(options);
      setFinancialYear(currentFYLabel);
      fetchReportData(currentFYLabel);
    } catch (err) {
      console.error("Failed to load financial year:", err);
    //   const fallback = ["2026-27", "2025-26", "2024-25", "2023-24"];
    //   setFyOptions(fallback);
    //   setFinancialYear("2026-27");
    //   fetchReportData("2026-27");
    }
  };

  const fetchReportData = async (fy) => {
    try {
      setLoading(true);
      const res = await getExecutiveCircleDetails(fy, ["Submitted to HR", "Approved"]);
      setReportData(res || []);
    } catch (err) {
      console.error("Error fetching report:", err);
    } finally {
      setLoading(false);
    }
  };

  // Filter, pagination
  const filteredData = reportData.filter((r) =>
    JSON.stringify(r).toLowerCase().includes(searchQuery.toLowerCase())
  );

  const totalPages = Math.ceil(filteredData.length / rowsPerPage);
  const paginatedData = filteredData.slice(
    (currentPage - 1) * rowsPerPage,
    currentPage * rowsPerPage
  );

  // Export Excel
  const handleExcel = () => {
    const exportData = filteredData.map((r) => ({
      "Nomination date": r.createdAt ? new Date(r.createdAt).toLocaleDateString("en-GB") : "",
      "Award Title": r.awardTitle,
      Category: r.category,
      "Financial Year": r.financialYear,
      "Nominated By": r.submittedByName,
      "Status": r.status,
      "HR Remarks": r.hrRemarks || "",
      "Nominee Name 1": r.nominationDetails?.[0]?.nomineeName,
      "EmpCode 1": r.nominationDetails?.[0]?.nomineeEmployeeCode,
      "Dept 1": r.nominationDetails?.[0]?.department,
      "Reason 1": r.nominationDetails?.[0]?.reasonForNomination,
      "Nominee Name 2": r.nominationDetails?.[1]?.nomineeName,
      "EmpCode 2": r.nominationDetails?.[1]?.nomineeEmployeeCode,
      "Dept 2": r.nominationDetails?.[1]?.department,
      "Reason 2": r.nominationDetails?.[1]?.reasonForNomination,
      "Nominee Name 3": r.nominationDetails?.[2]?.nomineeName,
      "EmpCode 3": r.nominationDetails?.[2]?.nomineeEmployeeCode,
      "Dept 3": r.nominationDetails?.[2]?.department,
      "Reason 3": r.nominationDetails?.[2]?.reasonForNomination,
      "Nominee Name 4": r.nominationDetails?.[3]?.nomineeName,
      "EmpCode 4": r.nominationDetails?.[3]?.nomineeEmployeeCode,
      "Dept 4": r.nominationDetails?.[3]?.department,
      "Reason 4": r.nominationDetails?.[3]?.reasonForNomination,
    }));
    const worksheet = XLSX.utils.json_to_sheet(exportData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Executive Circle HR Review");
    const excelBuffer = XLSX.write(workbook, { bookType: "xlsx", type: "array" });
    const file = new Blob([excelBuffer], { type: "application/octet-stream" });
    saveAs(file, `HrReview_${financialYear}.xlsx`);
  };

  // Handle Approve
  const handleApprove = async (nominationId) => {
    const confirm = await Swal.fire({
      icon: "question",
      title: "Confirm Approval",
      text: "Are you sure you want to approve this nomination?",
      showCancelButton: true,
      confirmButtonColor: "#22c55e",
      cancelButtonColor: "#6b7280",
      confirmButtonText: "Yes, Approve",
    });
    if (!confirm.isConfirmed) return;

    try {
      await updateNominationStatus(nominationId, "APPROVED", null);
      Swal.fire("Approved", "Nomination has been approved.", "success");
      fetchReportData(financialYear);
    } catch (error) {
      Swal.fire("Error", "Could not approve nomination.", "error");
    }
  };

  // Handle Reject (with remarks)
  const handleReject = async (nominationId) => {
    const { value: remarks } = await Swal.fire({
      icon: "warning",
      title: "Reject Nomination",
      input: "textarea",
      inputLabel: "Reason for rejection (remarks)",
      inputPlaceholder: "Enter your remarks here...",
      inputAttributes: { "aria-label": "Type your remarks" },
      showCancelButton: true,
      confirmButtonColor: "#b91c1c",
      cancelButtonColor: "#6b7280",
      confirmButtonText: "Reject",
      inputValidator: (value) => {
        if (!value || value.trim() === "") {
          return "Please enter a reason for rejection";
        }
        return null;
      },
    });

    if (remarks === undefined) return;

    try {
      await updateNominationStatus(nominationId, "REJECTED", remarks);
      Swal.fire("Rejected", "Nomination has been rejected.", "error");
      fetchReportData(financialYear);
    } catch (error) {
      Swal.fire("Error", "Could not reject nomination.", "error");
    }
  };

  return (
    <>
      <Header />
      <div className="min-h-screen bg-gray-50 mt-[50px] p-6 font-sans">
        <div className=" bg-gradient-to-b from-red-900 to-red-700 text-white px-4 py-2 flex justify-between items-center rounded-t">
          <span className="text-sm font-semibold">
            HR Review – Executive Circle ({financialYear})
          </span>
          <button
            onClick={() => navigate("/Dashboard")}
            className="text-white hover:text-gray-200 transition p-1 rounded-full bg-white/20 hover:bg-white/30"
            title="Go back"
          >
            <X size={24} />
          </button>
        </div>

        <div className="bg-white p-4 rounded-b shadow-sm">
          {/* Top Controls */}
          <div className="flex flex-wrap justify-between items-center mb-3">
            <div className="flex items-center gap-2 text-sm">
              <button
                onClick={handleExcel}
                className="border border-gray-300 px-4 py-1 rounded hover:bg-gray-50 transition"
              >
                Excel
              </button>

              <select
                value={financialYear}
                onChange={(e) => {
                  setFinancialYear(e.target.value);
                  setCurrentPage(1);
                  fetchReportData(e.target.value);
                }}
                className="border border-red-800 text-red-800 font-semibold rounded px-2 py-0.5 h-7 bg-white cursor-pointer"
              >
                {fyOptions.map((fy) => (
                  <option key={fy} value={fy}>
                    {fy}
                  </option>
                ))}
              </select>

              <span>Show</span>
              <select
                value={rowsPerPage}
                onChange={(e) => {
                  setRowsPerPage(Number(e.target.value));
                  setCurrentPage(1);
                }}
                className="border border-gray-300 rounded px-2 py-0.5 h-6 text-xs bg-white cursor-pointer"
              >
                {[5, 10, 25, 50, 100].map((n) => (
                  <option key={n} value={n}>
                    {n}
                  </option>
                ))}
              </select>
              <span>entries</span>
            </div>

            <div className="flex items-center gap-2 text-sm">
              <span>Search:</span>
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  setCurrentPage(1);
                }}
                className="border border-gray-300 px-2 py-1 text-sm w-44 rounded"
              />
            </div>
          </div>

          {/* Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-sm border-collapse min-w-[3500px]">
              <thead>
                <tr className="bg-gray-100">
                  {[
                    "Sr.No",
                    "Nomination date",
                    "Award Title",
                    "Category",
                    "Year",
                    "Nominated By",
                    "Nominee Name 1",
                    "EmpCode 1",
                    "Dept 1",
                    "Reason 1",
                    "Nominee Name 2",
                    "EmpCode 2",
                    "Dept 2",
                    "Reason 2",
                    "Nominee Name 3",
                    "EmpCode 3",
                    "Dept 3",
                    "Reason 3",
                    "Nominee Name 4",
                    "EmpCode 4",
                    "Dept 4",
                    "Reason 4",
                    "Status",
                    "HR Remarks",
                    "Actions",
                  ].map((h) => (
                    <th
                      key={h}
                      className="px-3 py-2.5 text-left whitespace-nowrap border-b-2 border-gray-300 text-xs font-semibold"
                    >
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {loading ? (
                  <tr>
                    <td colSpan={30} className="text-center py-5">
                      Loading...
                    </td>
                  </tr>
                ) : paginatedData.length === 0 ? (
                  <tr>
                    <td colSpan={30} className="text-center py-5 text-gray-400">
                      No records found
                    </td>
                  </tr>
                ) : (
                  paginatedData.map((r, i) => (
                    <tr
                      key={r.nominationId}
                      className="border-b border-gray-100 hover:bg-blue-50 transition-colors"
                    >
                      <td className="px-3 py-2.5">
                        {(currentPage - 1) * rowsPerPage + i + 1}
                      </td>
                      <td className="px-3 py-2.5">
                        {r.createdAt ? new Date(r.createdAt).toLocaleDateString("en-GB") : "-"}
                      </td>
                      <td className="px-3 py-2.5">{r.awardTitle || "-"}</td>
                      <td className="px-3 py-2.5">{r.category || "-"}</td>
                      <td className="px-3 py-2.5">{r.financialYear || "-"}</td>
                       
                      <td className="px-3 py-2.5">{r.submittedByName || "-"}</td>
                     

                      {/* Nominee details as before */}
                      <td className="px-3 py-2.5">{r.nominationDetails?.[0]?.nomineeName || "-"}</td>
                      <td className="px-3 py-2.5">{r.nominationDetails?.[0]?.nomineeEmployeeCode || "-"}</td>
                      <td className="px-3 py-2.5">{r.nominationDetails?.[0]?.department || "-"}</td>
                      <td className="px-3 py-2.5">{r.nominationDetails?.[0]?.reasonForNomination || "-"}</td>

                      <td className="px-3 py-2.5">{r.nominationDetails?.[1]?.nomineeName || "-"}</td>
                      <td className="px-3 py-2.5">{r.nominationDetails?.[1]?.nomineeEmployeeCode || "-"}</td>
                      <td className="px-3 py-2.5">{r.nominationDetails?.[1]?.department || "-"}</td>
                      <td className="px-3 py-2.5">{r.nominationDetails?.[1]?.reasonForNomination || "-"}</td>

                      <td className="px-3 py-2.5">{r.nominationDetails?.[2]?.nomineeName || "-"}</td>
                      <td className="px-3 py-2.5">{r.nominationDetails?.[2]?.nomineeEmployeeCode || "-"}</td>
                      <td className="px-3 py-2.5">{r.nominationDetails?.[2]?.department || "-"}</td>
                      <td className="px-3 py-2.5">{r.nominationDetails?.[2]?.reasonForNomination || "-"}</td>

                      <td className="px-3 py-2.5">{r.nominationDetails?.[3]?.nomineeName || "-"}</td>
                      <td className="px-3 py-2.5">{r.nominationDetails?.[3]?.nomineeEmployeeCode || "-"}</td>
                      <td className="px-3 py-2.5">{r.nominationDetails?.[3]?.department || "-"}</td>
                      <td className="px-3 py-2.5">{r.nominationDetails?.[3]?.reasonForNomination || "-"}</td>
                      <td className="px-3 py-2.5">{r.status || "-"}</td>

                      {/* HR Remarks */}
                      <td className="px-3 py-2.5 max-w-xs break-words">
                        {r.hrRemarks || "-"}
                      </td>

                      {/* Actions Dropdown */}
                     <td className="px-3 py-2.5">
  {r.status === "Approved" ? (
    <span className="inline-block bg-green-100 text-green-800 px-2 py-1 rounded text-xs font-semibold">
      Approved
    </span>
  ) : (
    <select
      onChange={(e) => {
        const action = e.target.value;
        if (action === "approve") {
          handleApprove(r.nominationId);
        } else if (action === "reject") {
          handleReject(r.nominationId);
        }
        e.target.value = "";
      }}
      className="border border-gray-300 rounded px-2 py-1 text-xs bg-white cursor-pointer"
      defaultValue=""
    >
      <option value="" disabled>Actions</option>
      <option value="approve" className="text-green-600">✓ Approve</option>
      <option value="reject" className="text-red-600">✗ Reject</option>
    </select>
  )}
</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>

          {/* Pagination */}
          <div className="flex flex-wrap justify-between items-center mt-4 text-sm text-gray-600">
            <span>
              Showing {(currentPage - 1) * rowsPerPage + 1} to{" "}
              {Math.min(currentPage * rowsPerPage, filteredData.length)} of{" "}
              {filteredData.length} entries
            </span>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
                disabled={currentPage === 1}
                className={`border border-gray-300 px-3 py-1 rounded text-sm ${
                  currentPage === 1
                    ? "bg-gray-200 cursor-not-allowed"
                    : "bg-white hover:bg-gray-50"
                }`}
              >
                Previous
              </button>
              {Array.from({ length: totalPages }, (_, i) => (
                <span
                  key={i}
                  onClick={() => setCurrentPage(i + 1)}
                  className={`px-3 py-1 text-sm border border-gray-300 rounded cursor-pointer ${
                    currentPage === i + 1
                      ? "bg-gray-800 text-white"
                      : "bg-white text-gray-800 hover:bg-gray-100"
                  }`}
                >
                  {i + 1}
                </span>
              ))}
              <button
                onClick={() => setCurrentPage((prev) => Math.min(prev + 1, totalPages))}
                disabled={currentPage === totalPages || totalPages === 0}
                className={`border border-gray-300 px-3 py-1 rounded text-sm ${
                  currentPage === totalPages || totalPages === 0
                    ? "bg-gray-200 cursor-not-allowed"
                    : "bg-white hover:bg-gray-50"
                }`}
              >
                Next
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default HrExecutiveReviewPage;