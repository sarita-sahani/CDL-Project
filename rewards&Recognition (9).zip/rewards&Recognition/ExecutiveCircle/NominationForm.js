import React, { useState, useEffect, useRef, useCallback } from 'react';
import { saveNomination, getNominationByAwardEmployee } from './ExecuitiveCircleApi';
import RnRService from '../RnRService';
import Swal from 'sweetalert2';
import { Lock, CheckCircle } from 'lucide-react';

/**
 * Props
 * ─────
 * award         – { id, awardTitle, category, noOfAwards, criteria, maxNominations }
 * financialYear – "26-27"
 * currentUser   – { employeeCode, name, email }
 * canNominate   – boolean
 * onSaved(dto)  – optional callback after successful save
 */
const NominationForm = ({ award, financialYear, currentUser, canNominate, onSaved, isSubmittedProp, isOverallSubmitted }) => {
  const maxSlots = award.maxNominations || 4;

  const [slots, setSlots] = useState(() =>
    Array.from({ length: maxSlots }, (_, i) => ({
      seq:              i + 1,
      employee:         null,
      department:       '',
      reason:           '',
      searchTerm:       '',
      employeesList:    [],
      loadingEmployees: false,
    }))
  );

  const [isNominating, setIsNominating]       = useState(true);
  const [saving, setSaving]                   = useState(false);
  const [existingId, setExistingId]           = useState(null);
  const [nominationLoaded, setNominationLoaded] = useState(false);
  const [status, setStatus]                   = useState(''); // ← NEW

  // ── KEY FIX: tracks whether this award is already submitted/approved ──────
  // Now also considers 'Approved' as locked
  const [isSubmittedLocal, setIsSubmittedLocal] = useState(false);
  const isSubmitted = isSubmittedProp || isSubmittedLocal ||
    (isOverallSubmitted && nominationLoaded && !isNominating);

  const debounceTimers = useRef(Array.from({ length: maxSlots }, () => null));

  // ── Load existing nomination — sets isSubmitted from API response ────────────
  const loadNomination = useCallback(() => {
    if (!award.id || !currentUser?.employeeCode || !financialYear) return;

    getNominationByAwardEmployee(award.id, currentUser.employeeCode, financialYear)
      .then((existing) => {
        if (!existing) {
          // No record found — if parent says submitted, this award was "No" (no detail record saved)
          if (isSubmittedProp) setIsNominating(false);
          setNominationLoaded(true);
          setStatus('');
          return;
        }

        setExistingId(existing.id);
        setIsNominating(existing.nominating);
        const isLocked = existing.status === 'Submitted to HR' || existing.status === 'Approved';
        setIsSubmittedLocal(isLocked);
        setStatus(existing.status); // ← store the actual status
        setNominationLoaded(true);

        if (existing.nominationDetails?.length) {
          setSlots((prev) =>
            prev.map((s) => {
              const d = existing.nominationDetails.find((x) => x.sequenceNo === s.seq);
              if (!d) return s;
              const emp = {
                employeeName: d.nomineeName,
                empCode:      d.nomineeEmployeeCode,
                emailId:      d.nomineeEmailId,
                designation:  d.nomineeDesignation,
                department:   d.department,
              };
              return {
                ...s,
                employee:   emp,
                department: d.department || '',
                emailId:    emp.emailId  || '',
                reason:     d.reasonForNomination || '',
                searchTerm: d.nomineeName || '',
              };
            })
          );
        }
      })
      .catch(() => {});
  }, [award.id, currentUser?.employeeCode, financialYear]);

  useEffect(() => { loadNomination(); }, [loadNomination]);

  // ── Per-slot field updater ───────────────────────────────────────────────────
  const updateSlotField = (index, field, value) =>
    setSlots((prev) => {
      const next = [...prev];
      next[index] = { ...next[index], [field]: value };
      return next;
    });

  // ── Employee search ──────────────────────────────────────────────────────────
  const searchEmployees = async (searchValue, index) => {
    updateSlotField(index, 'loadingEmployees', true);
    try {
      const res  = await RnRService.searchEmployee(searchValue);
      const data = res.data || [];
      const mappedEmployees = data.map(item => ({
        empCode:       item.empResDTO?.empCode,
        employeeName:  item.empResDTO?.fullNameAsAadhaar ||
                       `${item.empResDTO?.firstName} ${item.empResDTO?.lastName}`.trim() ||
                       item.empResDTO?.emailId,
        employeeEmail: item.empResDTO?.emailId,
        department:    item.empResDTO?.mainDeptResDTO?.mainDepartment,
        designation:   item.empResDTO?.designationResDTO?.designationName,
      }));
      updateSlotField(index, 'employeesList', mappedEmployees);
    } catch (error) {
      console.error('Error searching employees', error);
      updateSlotField(index, 'employeesList', []);
    } finally {
      updateSlotField(index, 'loadingEmployees', false);
    }
  };

  const handleSearchChange = (e, index) => {
    const val = e.target.value;
    setSlots((prev) => {
      const next = [...prev];
      next[index] = {
        ...next[index],
        searchTerm:    val,
        employee:      null,
        department:    '',
        employeesList: val.trim().length < 2 ? [] : next[index].employeesList,
      };
      return next;
    });
    if (debounceTimers.current[index]) clearTimeout(debounceTimers.current[index]);
    if (val.trim().length >= 2) {
      debounceTimers.current[index] = setTimeout(() => searchEmployees(val, index), 300);
    }
  };

  const handleEmployeeSelect = (emp, index) => {
    setSlots((prev) => {
      const next = [...prev];
      next[index] = {
        ...next[index],
        employee:      emp,
        searchTerm:    emp.employeeName || '',
        department:    emp.department   || '',
        employeesList: [],
      };
      return next;
    });
  };

  // ── Save ─────────────────────────────────────────────────────────────────────
  const handleSave = async () => {
    if (isNominating) {
      if (!slots[0].employee) {
        Swal.fire({ icon: 'warning', title: 'Required Field',
          text: 'Nomination 1 is required — please select an employee.',
          confirmButtonColor: '#1e3a8a' });
        return;
      }
      if (!slots[0].reason.trim()) {
        Swal.fire({ icon: 'warning', title: 'Required Field',
          text: 'Reason for Nomination 1 is required.',
          confirmButtonColor: '#1e3a8a' });
        return;
      }
    }

    setSaving(true);
    try {
      const payload = {
        id:                      existingId || undefined,
        awardId:                 award.id,
        financialYear,
        submittedByEmployeeCode: currentUser.employeeCode,
        submittedByName:         currentUser.name,
        submittedByEmailId:      currentUser.email,
        nominating:              isNominating,
        nominationDetails: isNominating
          ? slots.filter((s) => s.employee).map((s) => ({
              sequenceNo:          s.seq,
              nomineeEmployeeCode: s.employee.empCode,
              nomineeName:         s.employee.employeeName,
              nomineeEmailId:      s.employee.employeeEmail,
              nomineeDesignation:  s.employee.designation,
              department:          s.department,
              reasonForNomination: s.reason,
            }))
          : [],
      };
      const saved = await saveNomination(payload);
      setExistingId(saved.id);

      // reload to refresh status
      loadNomination();

      await Swal.fire({
        icon: 'success', title: 'Saved!',
        text: 'Nomination saved successfully.',
        confirmButtonColor: '#1e3a8a',
        timer: 2500, timerProgressBar: true,
      });

      if (onSaved) onSaved(saved);
    } catch (e) {
      Swal.fire({ icon: 'error', title: 'Save Failed',
        text: 'Failed to save: ' + e.message,
        confirmButtonColor: '#1e3a8a' });
    } finally {
      setSaving(false);
    }
  };

  // ── Award header (shared by all render paths) ────────────────────────────────
  const AwardHeader = () => (
    <div className="mb-6">
      <div className="text-center mb-5">
        <div className="inline-block relative">
          <h2 className="text-xl font-bold text-gray-900 tracking-wide border-b-2 border-red-700 pb-1 px-2">
            {award.awardTitle}
          </h2>
        </div>
      </div>

      <div className="flex items-start justify-between gap-10 pr-6">
        <div className="flex flex-col gap-3 min-w-0">
          {award.category && (
            <div>
              <p className="text-xs font-semibold text-gray-500 uppercase tracking-widest mb-1">
                Category
              </p>
              <div className="inline-block bg-purple-700 text-white text-xs font-semibold
                              px-3 py-1.5 rounded shadow-sm select-none">
                {award.category}
              </div>
            </div>
          )}
        </div>

        {award.criteria && (
          <div className="border border-dashed border-blue-400 bg-blue-50 rounded
                          px-4 py-3 text-xs text-gray-600 shrink-0 max-w-md mt-1 ml-auto">
            <p className="text-xs font-bold text-gray-700 uppercase tracking-wide mb-1.5">
              Criteria
            </p>
            <p className="leading-relaxed">{award.criteria}</p>
          </div>
        )}
      </div>

      <div className="mt-5 border-t border-gray-200" />
    </div>
  );

  // ── Gate 1: not eligible ─────────────────────────────────────────────────────
  if (!canNominate) {
    return (
      <div className="p-5">
        <AwardHeader />
        <div className="flex items-start gap-3 bg-gray-100 border border-gray-300
                        text-gray-700 px-4 py-3.5 rounded text-sm leading-relaxed">
          <span className="text-lg leading-none mt-0.5">🔒</span>
          <div>
            <p className="font-semibold text-gray-800 mb-0.5">Not Open for Nomination</p>
            <p className="text-xs text-gray-600">
              Executive Management determined Award and not open for nomination.
            </p>
          </div>
        </div>
      </div>
    );
  }

  // ── Gate 2: submitted or approved → full read-only view ────────────────────
  if (isSubmitted) {
    const filledSlots = slots.filter((s) => s.employee);

    // Determine banner message based on status
    const getBannerMessage = () => {
      if (status === 'Approved') {
        return { title: 'Nomination Approved', description: 'This nomination has been approved and is locked.' };
      }
      return { title: 'Nomination Submitted to HR', description: 'This nomination is locked. No further changes can be made.' };
    };
    const banner = getBannerMessage();

    return (
      <div className="pb-5">
        <AwardHeader />

        {/* Lock banner – dynamic status */}
        <div className="flex items-center gap-3 bg-green-50 border border-green-300
                        rounded-lg px-4 py-3 mb-5">
          <CheckCircle size={18} className="text-green-600 shrink-0" />
          <div className="flex-1">
            <p className="text-sm font-semibold text-green-800">{banner.title}</p>
            <p className="text-xs text-green-700 mt-0.5">{banner.description}</p>
          </div>
        </div>

        {/* Nominating status — plain text, no radio */}
        <p className="text-xs font-semibold text-gray-500 uppercase tracking-widest mb-1">
          Nominating
        </p>
        <div className="inline-flex items-center gap-2 mb-5 bg-gray-100 border border-gray-200
                        text-gray-700 text-sm font-medium px-4 py-2 rounded">
          {isNominating ? '✅  Yes' : '❌  No'}
        </div>

        {/* Read-only nominee table */}
        {isNominating && filledSlots.length > 0 && (
          <div className="overflow-x-auto rounded-lg border border-gray-200 shadow-sm">
            <table className="w-full border-collapse text-xs">
              <thead>
                <tr className="bg-purple-800 text-white">
                  {['#', 'Nominee', 'Employee Code', 'Department', 'Designation', 'Reason for Nomination']
                    .map((h) => (
                      <th key={h}
                          className="text-left px-3 py-2.5 border border-purple-700 font-semibold">
                        {h}
                      </th>
                    ))}
                </tr>
              </thead>
              <tbody>
                {filledSlots.map((slot, i) => (
                  <tr key={slot.seq} className={i % 2 === 0 ? 'bg-white' : 'bg-purple-50'}>
                    <td className="px-3 py-2.5 border border-gray-200 text-gray-400
                                   text-center w-6 font-semibold">
                      {slot.seq}
                    </td>
                    <td className="px-3 py-2.5 border border-gray-200">
                      <p className="font-semibold text-gray-800">{slot.employee.employeeName}</p>
                      {slot.employee.emailId && (
                        <p className="text-gray-400 text-xs mt-0.5">{slot.employee.emailId}</p>
                      )}
                    </td>
                    <td className="px-3 py-2.5 border border-gray-200 text-gray-600">
                      {slot.employee.empCode || '—'}
                    </td>
                    <td className="px-3 py-2.5 border border-gray-200 text-gray-600">
                      {slot.department || '—'}
                    </td>
                    <td className="px-3 py-2.5 border border-gray-200 text-gray-600">
                      {slot.employee.designation || '—'}
                    </td>
                    <td className="px-3 py-2.5 border border-gray-200 text-gray-600 max-w-xs">
                      <p className="whitespace-pre-wrap leading-relaxed">
                        {slot.reason || '—'}
                      </p>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {isNominating && filledSlots.length === 0 && (
          <p className="text-sm text-gray-400 italic">No nominees were recorded.</p>
        )}

        {/* No save button — intentionally omitted */}
      </div>
    );
  }

  // ── Gate 3: editable form (DRAFT or new) ────────────────────────────────────
  return (
    <div className="pb-5">
      <AwardHeader />

      {/* Nominate radio */}
      <p className="text-sm text-gray-700 mb-1">Do you want to nominate?</p>
      <div className="flex gap-6 mb-4 text-sm">
        <label className={`flex items-center gap-1.5 ${isSubmitted ? 'cursor-not-allowed opacity-50' : 'cursor-pointer'}`}>
          <input type="radio" name={`nom_${award.id}`} checked={isNominating}
            onChange={() => !isSubmitted && setIsNominating(true)}
            disabled={isSubmitted}
            className="accent-blue-900" />
          Yes
        </label>
        <label className="flex items-center gap-1.5 cursor-pointer">
          <input type="radio" name={`nom_${award.id}`} checked={!isNominating}
            onChange={() => setIsNominating(false)} className="accent-blue-900"
            disabled={isSubmitted} />
          No
        </label>
      </div>

      {/* Nomination table */}
      {isNominating && (
        <div className="overflow-x-auto">
          <table className="w-full border-collapse text-xs">
            <thead>
              <tr className="bg-purple-800 text-white">
                <th className="text-left px-3 py-2 border border-purple-600 w-1/3 font-semibold">
                  Nomination
                </th>
                <th className="text-left px-3 py-2 border border-purple-600 w-1/4 font-semibold">
                  Department
                </th>
                <th className="text-left px-3 py-2 border border-purple-600 font-semibold">
                  Reason for Nomination *
                </th>
              </tr>
            </thead>
            <tbody>
              {slots.map((slot, idx) => (
                <tr key={slot.seq} className={idx % 2 === 1 ? 'bg-purple-50' : 'bg-white'}>

                  {/* Nomination column with inline search */}
                  <td className="px-2 py-1.5 border border-gray-200 align-top">
                    <div className="text-gray-400 text-xs mb-1">
                      Nomination {slot.seq}{slot.seq === 1 ? ' *' : ''}
                    </div>
                    <div className="relative">
                      <input
                        type="text"
                        autoComplete="off"
                        value={slot.searchTerm}
                        onChange={(e) => handleSearchChange(e, idx)}
                        placeholder="Type name or code..."
                        className="w-full px-2.5 py-2 border border-gray-300 rounded text-xs
                                   focus:outline-none focus:ring-1 focus:ring-blue-400
                                   focus:border-blue-400 box-border"
                      />
                      {slot.loadingEmployees && (
                        <span className="absolute right-2 top-1/2 -translate-y-1/2 text-xs text-gray-400">
                          Searching...
                        </span>
                      )}
                      {slot.employeesList.length > 0 && (
                        <ul className="absolute top-full left-0 z-50 w-full bg-white border
                                       border-gray-200 rounded-lg mt-1 max-h-48 overflow-auto
                                       shadow-lg list-none p-0 m-0">
                          {slot.employeesList.map((emp) => (
                            <li
                              key={emp.empCode}
                              onMouseDown={(e) => e.preventDefault()}
                              onClick={() => handleEmployeeSelect(emp, idx)}
                              className="px-3 py-2 hover:bg-blue-50 cursor-pointer transition-colors
                                         border-b border-gray-100 last:border-0"
                            >
                              <div className="font-medium text-gray-800">{emp.employeeName}</div>
                              <div className="text-xs text-gray-500 mt-0.5">
                                {emp.empCode} • {emp.department || '—'}
                              </div>
                            </li>
                          ))}
                        </ul>
                      )}
                    </div>
                    {slot.employee && (
                      <div className="text-gray-500 text-xs mt-1">
                        Code: {slot.employee.empCode}
                      </div>
                    )}
                  </td>

                  {/* Department */}
                  <td className="px-2 py-1.5 border border-gray-200 align-top">
                    <div className="text-gray-400 text-xs mb-1">
                      Department {slot.seq}{slot.seq === 1 ? ' *' : ''}
                    </div>
                    <input
                      className="w-full px-2.5 py-2 border border-gray-300 rounded text-xs
                                 bg-gray-50 focus:outline-none focus:ring-1 focus:ring-blue-400
                                 focus:border-blue-400"
                      value={slot.department}
                      onChange={(e) => updateSlotField(idx, 'department', e.target.value)}
                      placeholder="Auto-filled on selection"
                      readOnly={!!slot.employee?.department}
                    />
                  </td>

                  {/* Reason */}
                  <td className="px-2 py-1.5 border border-gray-200 align-top">
                    <textarea
                      className="w-full px-2.5 py-1.5 border border-gray-300 rounded text-xs
                                 resize-y min-h-[52px] box-border
                                 focus:outline-none focus:ring-1 focus:ring-blue-400
                                 focus:border-blue-400"
                      value={slot.reason}
                      onChange={(e) => updateSlotField(idx, 'reason', e.target.value)}
                      placeholder={`Reason for nomination ${slot.seq}${slot.seq === 1 ? ' (required)' : ''}`}
                    />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Save & Continue — disabled when submitted */}
      <div className="flex justify-end mt-4">
        <button
          onClick={handleSave}
          disabled={saving || isSubmitted}
          title={isSubmitted ? 'This nomination has been submitted to HR and cannot be changed.' : ''}
          className={`text-white text-sm font-semibold px-6 py-2.5 rounded transition-colors
            ${saving || isSubmitted ? 'bg-gray-400 cursor-not-allowed opacity-60' : 'bg-blue-900 hover:bg-blue-800'}`}
        >
          {saving ? 'Saving...' : 'Save & Continue'}
        </button>
      </div>
    </div>
  );
};

export default NominationForm;