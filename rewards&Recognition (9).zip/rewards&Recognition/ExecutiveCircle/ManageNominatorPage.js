import React, { useEffect, useState } from 'react';
import Header from '../../components/Header';
import { X, Search, ShieldCheck, Trash2, ChevronDown } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import RnRService from '../RnRService';
import Swal from 'sweetalert2';

import {
  fetchAllAwards,
  fetchCurrentFinancialYear,
  assignAwardEligibility,
  removeEligibility,
  getEligibilityByAward,
} from './ExecuitiveCircleApi';

const ManageNominatorPage = () => {

  const navigate = useNavigate();

  const [awards, setAwards]                     = useState([]);
  const [selectedAward, setSelectedAward]       = useState(null);

  const [financialYear, setFinancialYear]       = useState('');
  const [fyLabel, setFyLabel]                   = useState('');

  const [searchKeyword, setSearchKeyword]       = useState('');
  const [employees, setEmployees]               = useState([]);
  const [selectedEmployee, setSelectedEmployee] = useState(null);

  const [assignedUsers, setAssignedUsers]       = useState([]);

  const [loading, setLoading]                   = useState(true);
  const [saving, setSaving]                     = useState(false);

  const currentUser = {
    employeeCode: localStorage.getItem('empId') || '',
    name:         localStorage.getItem('EmployeeFullName') || '',
    email:        localStorage.getItem('email') || '',
  };

  // ── INIT ──────────────────────────────────────────────────────────────────
  useEffect(() => {
    init();
  }, []);

  const init = async () => {
    try {
      const fy = await fetchCurrentFinancialYear();
      setFinancialYear(fy.label);
      setFyLabel(fy.label);

      const awardsData = await fetchAllAwards();
      setAwards(awardsData);

      // Default to first award
      if (awardsData.length > 0) {
        setSelectedAward(awardsData[0]);
        loadAssignedUsers(awardsData[0].id);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  // ── LOAD ASSIGNED USERS ───────────────────────────────────────────────────
  const loadAssignedUsers = async (awardId) => {
    try {
      const data = await getEligibilityByAward(awardId);
      setAssignedUsers(data || []);
    } catch (e) {
      console.error(e);
    }
  };

  // ── AWARD DROPDOWN CHANGE ─────────────────────────────────────────────────
  const handleAwardChange = (e) => {
    const award = awards.find((a) => String(a.id) === e.target.value);
    setSelectedAward(award || null);
    setSelectedEmployee(null);
    setSearchKeyword('');
    setEmployees([]);
    setAssignedUsers([]);
    if (award) loadAssignedUsers(award.id);
  };

  // ── SEARCH EMPLOYEES ──────────────────────────────────────────────────────
  const searchEmployees = async (searchValue) => {
    try {
      const res  = await RnRService.searchEmployee(searchValue);
      const data = res.data || [];
      return data.map((item) => ({
        empCode:     item.empResDTO?.empCode,
        empName:
          item.empResDTO?.fullNameAsAadhaar ||
          `${item.empResDTO?.firstName || ''} ${item.empResDTO?.lastName || ''}`.trim() ||
          item.empResDTO?.emailId,
        email:       item.empResDTO?.emailId,
        department:  item.empResDTO?.mainDeptResDTO?.mainDepartment,
        designation: item.empResDTO?.designationResDTO?.designationName,
      }));
    } catch (err) {
      console.error('Error searching employees', err);
      return [];
    }
  };

  const handleEmployeeSearch = async (keyword) => {
    setSearchKeyword(keyword);
    if (!keyword || keyword.trim().length < 2) { setEmployees([]); return; }
    try {
      const data = await searchEmployees(keyword);
      setEmployees(data || []);
    } catch (e) {
      console.error(e);
      setEmployees([]);
    }
  };

  // ── ASSIGN ────────────────────────────────────────────────────────────────
  const handleAssign = async () => {
    if (!selectedAward) {
      Swal.fire({ icon: 'warning', title: 'Select Award', text: 'Please select an award first.', confirmButtonColor: '#1e3a8a' });
      return;
    }
    if (!selectedEmployee) {
      Swal.fire({ icon: 'warning', title: 'Select Employee', text: 'Please search and select an employee.', confirmButtonColor: '#1e3a8a' });
      return;
    }
    try {
      setSaving(true);
      await assignAwardEligibility({
        awardId:       selectedAward.id,
        empCode:       selectedEmployee.empCode,
        empName:       selectedEmployee.empName,
        email:         selectedEmployee.email,
        financialYear,
      });
      Swal.fire({ icon: 'success', title: 'Success', text: 'Permission assigned successfully', confirmButtonColor: '#1e3a8a' });
      setSelectedEmployee(null);
      setSearchKeyword('');
      setEmployees([]);
      loadAssignedUsers(selectedAward.id);
    } catch (e) {
      Swal.fire({ icon: 'error', title: 'Error', text: e.message || 'Failed to assign permission', confirmButtonColor: '#dc2626' });
    } finally {
      setSaving(false);
    }
  };

  // ── REMOVE ────────────────────────────────────────────────────────────────
  const handleRemove = async (id) => {
    const result = await Swal.fire({
      title: 'Remove Permission?',
      text: 'This user will no longer be able to nominate for this award.',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#dc2626',
      cancelButtonColor: '#6b7280',
      confirmButtonText: 'Yes, Remove',
    });
    if (!result.isConfirmed) return;
    try {
      await removeEligibility(id);
      Swal.fire({ icon: 'success', title: 'Removed', text: 'Permission removed successfully', confirmButtonColor: '#1e3a8a' });
      loadAssignedUsers(selectedAward.id);
    } catch (e) {
      console.error(e);
    }
  };

  // ── LOADING ───────────────────────────────────────────────────────────────
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center text-gray-500 text-sm">
        Loading...
      </div>
    );
  }

  // ─────────────────────────────────────────────────────────────────────────
  return (
    <>
      <Header />

      <div className="min-h-screen bg-gray-100 font-sans flex flex-col mt-16 pt-4">

        {/* ── TOP BANNER ──────────────────────────────────────────────────── */}
        <div className="bg-red-700 text-white px-6 py-3 flex items-center justify-between shadow-sm shrink-0">
          <div className="flex flex-col leading-tight">
            <span className="text-base font-bold tracking-wide">
              EXECUTIVE CIRCLE — MANAGE NOMINATORS
            </span>
            <span className="text-xs opacity-80">
              Financial Year {financialYear}
            </span>
          </div>
          <button
            onClick={() => navigate(-1)}
            className="bg-white/20 hover:bg-white/30 text-white rounded-full p-2 transition"
            title="Back"
          >
            <X size={18} />
          </button>
        </div>

        {/* ── BODY (no sidebar) ───────────────────────────────────────────── */}
        <div className="flex-1 overflow-y-auto p-6">

          {/* ── ROW 1: Award dropdown + Category info side by side ────────── */}
          <div className="bg-white rounded shadow-sm border border-gray-200 p-5 mb-5">

            <div className="flex flex-col md:flex-row md:items-start gap-6">

              {/* LEFT — Award dropdown */}
              <div className="md:w-72 shrink-0">
                <label className="block text-xs font-semibold text-gray-600 mb-1.5 uppercase tracking-wide">
                  Select Award
                </label>

                <div className="relative">
                  <select
                    value={selectedAward?.id ?? ''}
                    onChange={handleAwardChange}
                    className="w-full appearance-none border border-gray-300 rounded
                               px-3 py-2.5 pr-9 text-sm text-gray-800 bg-white
                               focus:outline-none focus:ring-2 focus:ring-blue-500
                               cursor-pointer"
                  >
                    <option value="" disabled>— Choose an award —</option>
                    {awards.map((a) => (
                      <option key={a.id} value={a.id}>
                        {a.awardTitle}
                      </option>
                    ))}
                  </select>
                  <ChevronDown
                    size={16}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none"
                  />
                </div>
              </div>

              {/* VERTICAL DIVIDER (desktop only) */}
              {selectedAward && (
                <div className="hidden md:block w-px bg-gray-200 self-stretch" />
              )}

              {/* RIGHT — Category details (only shown when award is selected) */}
              {selectedAward && (
                <div className="flex-1 grid grid-cols-1 sm:grid-cols-2 gap-x-8 gap-y-3 text-sm">

                  {/* Award title */}
                  <div className="sm:col-span-2 flex items-center gap-2 mb-1">
                    <ShieldCheck size={17} className="text-blue-900 shrink-0" />
                    <span className="text-base font-bold text-blue-900">
                      {selectedAward.awardTitle}
                    </span>
                  </div>

                  {/* Category */}
                  <div>
                    <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-0.5">
                      Category
                    </p>
                    <p className="text-gray-800">{selectedAward.category || '—'}</p>
                  </div>

                  

                  {/* Criteria */}
                  <div className="sm:col-span-2">
                    <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-0.5">
                      Criteria
                    </p>
                    <p className="text-gray-700 leading-relaxed">{selectedAward.criteria || '—'}</p>
                  </div>

                  

                  {/* Open for nomination badge */}
                  {/* <div className="sm:col-span-2">
                    <span
                      className={`inline-block text-xs font-semibold px-2.5 py-1 rounded-full
                        ${selectedAward.isOpenForNomination
                          ? 'bg-green-100 text-green-800'
                          : 'bg-red-100 text-red-700'}`}
                    >
                      {selectedAward.isOpenForNomination
                        ? '✓ Open for nomination'
                        : '🔒 Not open for nomination'}
                    </span>
                  </div> */}
                </div>
              )}
            </div>
          </div>

          {/* ── ASSIGN SECTION ──────────────────────────────────────────────── */}
          <div className="bg-white rounded shadow-sm border border-gray-200 p-5 mb-5">

            <h3 className="text-sm font-bold text-gray-800 mb-4">
              Assign Nominator Permission
            </h3>

            {/* Employee search */}
            <div className="relative mb-4">
              <div className="flex items-center border border-gray-300 rounded px-3 focus-within:ring-2 focus-within:ring-blue-500">
                <Search size={15} className="text-gray-400 shrink-0" />
                <input
                  type="text"
                  value={searchKeyword}
                  onChange={(e) => handleEmployeeSearch(e.target.value)}
                  placeholder="Search employee by name or code..."
                  className="w-full px-3 py-2.5 outline-none text-sm"
                />
              </div>

              {/* Dropdown results */}
              {employees.length > 0 && (
                <div className="absolute z-20 bg-white border border-gray-200 rounded shadow-md
                                w-full mt-1 max-h-60 overflow-y-auto">
                  {employees.map((emp) => (
                    <div
                      key={emp.empCode}
                      onClick={() => {
                        setSelectedEmployee(emp);
                        setSearchKeyword(`${emp.empCode} - ${emp.empName}`);
                        setEmployees([]);
                      }}
                      className="px-4 py-2.5 hover:bg-blue-50 cursor-pointer border-b border-gray-100 last:border-0"
                    >
                      <div className="font-semibold text-gray-800 text-sm">{emp.empName}</div>
                      <div className="text-xs text-gray-500 mt-0.5">
                        {emp.empCode}
                        {emp.department ? ` · ${emp.department}` : ''}
                        {emp.designation ? ` · ${emp.designation}` : ''}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Selected employee preview */}
            {selectedEmployee && (
              <div className="bg-blue-50 border border-blue-200 rounded p-4 mb-4 text-sm">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  <div>
                    <span className="font-semibold text-gray-700">Employee Code: </span>
                    <span className="text-gray-800">{selectedEmployee.empCode}</span>
                  </div>
                  <div>
                    <span className="font-semibold text-gray-700">Name: </span>
                    <span className="text-gray-800">{selectedEmployee.empName}</span>
                  </div>
                  <div>
                    <span className="font-semibold text-gray-700">Email: </span>
                    <span className="text-gray-800">{selectedEmployee.email}</span>
                  </div>
                </div>
              </div>
            )}

            <button
              onClick={handleAssign}
              disabled={saving}
              className={`px-5 py-2 rounded text-sm font-semibold text-white transition-colors
                ${saving ? 'bg-gray-400 cursor-not-allowed' : 'bg-blue-900 hover:bg-blue-800'}`}
            >
              {saving ? 'Assigning...' : 'Assign Permission'}
            </button>
          </div>

          {/* ── ASSIGNED NOMINATORS TABLE ────────────────────────────────────── */}
          <div className="bg-white rounded shadow-sm border border-gray-200 p-5">

            <h3 className="text-sm font-bold text-gray-800 mb-4">
              Assigned Nominators
              {assignedUsers.length > 0 && (
                <span className="ml-2 text-xs font-normal text-gray-500">
                  ({assignedUsers.length})
                </span>
              )}
            </h3>

            {assignedUsers.length === 0 ? (
              <div className="text-sm text-gray-500 py-4 text-center">
                No nominators assigned for this award yet.
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="min-w-full text-sm border-collapse">
                  <thead>
                    <tr className="bg-purple-500 text-white text-xs">
                      <th className="px-4 py-2.5 border border-purple-600 text-left font-semibold">#</th>
                      <th className="px-4 py-2.5 border border-purple-600 text-left font-semibold">Emp Code</th>
                      <th className="px-4 py-2.5 border border-purple-600 text-left font-semibold">Name</th>
                      <th className="px-4 py-2.5 border border-purple-600 text-left font-semibold">Email</th>
                      <th className="px-4 py-2.5 border border-purple-600 text-center font-semibold">Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {assignedUsers.map((user, i) => (
                      <tr
                        key={user.id}
                        className={i % 2 === 1 ? 'bg-gray-50' : 'bg-white'}
                      >
                        <td className="px-4 py-2.5 border border-gray-200 text-gray-500 text-xs">
                          {i + 1}
                        </td>
                        <td className="px-4 py-2.5 border border-gray-200 text-gray-700">
                          {user.empCode}
                        </td>
                        <td className="px-4 py-2.5 border border-gray-200 font-semibold text-gray-800">
                          {user.empName}
                        </td>
                        <td className="px-4 py-2.5 border border-gray-200 text-gray-600">
                          {user.email}
                        </td>
                        <td className="px-4 py-2.5 border border-gray-200 text-center">
                          <button
                            onClick={() => handleRemove(user.id)}
                            className="inline-flex items-center gap-1 text-red-600 hover:text-red-800
                                       hover:bg-red-50 px-2 py-1 rounded transition-colors text-xs"
                            title="Remove nominator"
                          >
                            <Trash2 size={13} />
                            Remove
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>

        </div>

        {/* ── FOOTER ──────────────────────────────────────────────────────── */}
        <div className="bg-orange-600 text-white text-center py-2 text-xs shrink-0">
          Copyright © 2025 CMS Computers Limited. All Rights Reserved.
        </div>
      </div>
    </>
  );
};

export default ManageNominatorPage;