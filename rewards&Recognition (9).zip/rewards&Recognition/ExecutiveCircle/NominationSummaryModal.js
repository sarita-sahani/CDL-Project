import React, { useState, useEffect, useMemo, useCallback } from 'react';
import {
  getExecutiveCircleDetails,
  downloadExcel,
  submitAllNominationsEmployees,
  fetchNominationsByUser,
  getNominationsByEmployee,
  fetchAwardsByUser,
} from './ExecuitiveCircleApi';
import { X, Send, CheckCircle, AlertTriangle } from 'lucide-react';
import Swal from 'sweetalert2';

/**
 * Props
 * ─────
 * isOpen        – boolean
 * onClose()     – called to close (also triggers parent to refresh submitted dots)
 * financialYear – e.g. "26-27"
 * currentUser   – { employeeCode, name, email }
 */
const NominationSummaryModal = ({ isOpen, onClose, financialYear, currentUser }) => {
  const [summaries, setSummaries]   = useState([]);
  const [loading, setLoading]       = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [search, setSearch]         = useState('');
  const [pageSize, setPageSize]     = useState(10);
  const [page, setPage]             = useState(0);
   const ManagerEmpCode = localStorage.getItem("empId");

  // Draft / submitted counts — derived from user's own nominations
  const [draftCount, setDraftCount]         = useState(0);
  const [submittedCount, setSubmittedCount] = useState(0);

  // ── NEW: eligible awards that have NO nomination record at all ────────────
  // i.e. user never saved yes/no for that award → must action before submit
  const [incompleteAwards, setIncompleteAwards] = useState([]); // [{ id, awardTitle }]

  // ── Load summary table + draft/submitted counts + incomplete check ────────
  const load = useCallback(async () => {
    if (!financialYear) return;
    setLoading(true);
    try {
      const [summaryData, myNoms, eligibleList] = await Promise.all([
        getExecutiveCircleDetails(financialYear, ["Submitted to HR", "Approved","Draft"], ManagerEmpCode),
        // getNominationsByEmployee returns per-award nomination records for this employee
        // shape: [{ awardId, award: { id }, status, nominating, ... }]
        currentUser?.employeeCode
          ? getNominationsByEmployee(currentUser.employeeCode, financialYear)
          : Promise.resolve([]),
        currentUser?.employeeCode
          ? fetchAwardsByUser(currentUser.employeeCode)
          : Promise.resolve([]),
      ]);

      setSummaries(summaryData || []);

      const noms = myNoms || [];

      // Debug: log the first nomination to confirm field shape
      if (noms.length > 0) {
        console.log('[NominationSummaryModal] sample nomination record:', noms[0]);
      }
      console.log('[NominationSummaryModal] eligibleList:', eligibleList);

      // Extract the award ID — handle both { awardId } and { award: { id } } shapes
      const getAwardId = (n) => n.awardId ?? n.award?.id ?? n.awardID ?? null;

     const draftNoms     = noms.filter((n) => n.status === 'Draft');
     const submittedNoms = noms.filter((n) => n.status === 'Submitted to HR'); // handle both possible submitted statuses
      setDraftCount(draftNoms.length);
      setSubmittedCount(submittedNoms.length);

      // Awards the user is eligible for but has NO saved nomination record at all
      // (neither DRAFT nor SUBMITTED — meaning they never opened and saved yes/no)
      const nominatedAwardIds = new Set(
        noms.map(getAwardId).filter(Boolean)
      );
      console.log('[NominationSummaryModal] nominatedAwardIds:', [...nominatedAwardIds]);

      const incomplete = (eligibleList || []).filter(
        (award) => !nominatedAwardIds.has(award.id)
      );
      console.log('[NominationSummaryModal] incompleteAwards:', incomplete);
      setIncompleteAwards(incomplete);

    } catch (err) {
      console.error('[NominationSummaryModal] load error:', err);
      setSummaries([]);
    } finally {
      setLoading(false);
    }
  }, [financialYear, currentUser?.employeeCode]);

  useEffect(() => {
    if (isOpen) {
      setSearch('');
      setPage(0);
      load();
    }
  }, [isOpen, load]);

  // ── Escape key ────────────────────────────────────────────────────────────
  useEffect(() => {
    const handler = (e) => { if (e.key === 'Escape') onClose(); };
    if (isOpen) window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [isOpen, onClose]);

  // ── Body scroll lock ──────────────────────────────────────────────────────
  useEffect(() => {
    document.body.style.overflow = isOpen ? 'hidden' : '';
    return () => { document.body.style.overflow = ''; };
  }, [isOpen]);

  // ── Filtered + paginated rows ─────────────────────────────────────────────
  const filtered = useMemo(() => {
    if (!search) return summaries;
    const q = search.toLowerCase();
    return summaries.filter(
      (s) =>
        s.awardTitle?.toLowerCase().includes(q)  ||
        s.category?.toLowerCase().includes(q)    ||
        s.nomination1?.toLowerCase().includes(q) ||
        s.nomination2?.toLowerCase().includes(q) ||
        s.nomination3?.toLowerCase().includes(q) ||
        s.nomination4?.toLowerCase().includes(q)
    );
  }, [summaries, search]);

  const totalPages = Math.ceil(filtered.length / pageSize) || 1;
  const paginated  = filtered.slice(page * pageSize, page * pageSize + pageSize);

  // ── MODIFIED: Submit to HR ─ no incomplete award check ────────────────────
  const handleSubmitToHR = async () => {
    // Only check if there are drafts to submit
    if (draftCount === 0) {
      Swal.fire({
        icon: 'info',
        title: 'Nothing to Submit',
        text: 'All nominations are already submitted or you have not nominated for any award.',
        confirmButtonColor: '#1e3a8a',
      });
      return;
    }

    const result = await Swal.fire({
      icon: 'warning',
      title: 'Submit to HR?',
      html: `
        <p style="font-size:14px;color:#374151;margin:0">
          You are about to submit <strong>${draftCount} nomination(s)</strong> to HR.<br/><br/>
          <span style="color:#b91c1c;font-weight:600">Once submitted, you cannot make further changes.</span>
        </p>
      `,
      showCancelButton:   true,
      confirmButtonText:  'Yes, Submit',
      cancelButtonText:   'Cancel',
      confirmButtonColor: '#1e3a8a',
      cancelButtonColor:  '#6b7280',
    });

    if (!result.isConfirmed) return;

    setSubmitting(true);
    try {
      await submitAllNominationsEmployees(currentUser.employeeCode, financialYear);
      setDraftCount(0);
      setSubmittedCount((c) => c + draftCount);
      setIncompleteAwards([]);
      Swal.fire({
        icon:               'success',
        title:              'Submitted Successfully!',
        text:               'Your nominations have been submitted to HR. A confirmation mail has been sent.',
        confirmButtonColor: '#1e3a8a',
      });
    } catch (e) {
      Swal.fire({
        icon:               'error',
        title:              'Submission Failed',
        text:               e.message || 'Something went wrong. Please try again.',
        confirmButtonColor: '#1e3a8a',
      });
    } finally {
      setSubmitting(false);
    }
  };

  if (!isOpen) return null;

  const SortIcon = () => <span className="ml-1 opacity-70 text-xs">↕</span>;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center"
      style={{ background: 'rgba(0,0,0,0.55)', backdropFilter: 'blur(2px)' }}
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
    >
      {/* ── Modal panel ── */}
      <div
        className="relative bg-white flex flex-col"
        style={{
          width:        '95vw',
          maxWidth:     1100,
          maxHeight:    '92vh',
          borderRadius: 12,
          boxShadow:    '0 24px 64px rgba(0,0,0,0.32)',
          overflow:     'hidden',
        }}
      >

        {/* ══ HEADER ══════════════════════════════════════════════════════════ */}
        <div
          className="flex items-center justify-between px-6 py-4 shrink-0  bg-gradient-to-b from-red-900 to-red-700"
        
        >
          <div className="flex items-center gap-3">
            <div
              className="flex items-center justify-center rounded-full text-lg"
              style={{ width: 36, height: 36, background: 'rgba(255,255,255,0.15)' }}
            >
              🏆
            </div>
            <div>
              <h2 className="text-white font-bold text-base tracking-wide leading-tight">
                Nomination Details
              </h2>
              <p className="text-red-200 text-xs mt-0.5">
                Financial Year {financialYear} · Review before submitting to HR
              </p>
            </div>
          </div>

          {/* Stats strip */}
          <div className="flex items-center gap-5 mr-4">
            <StatChip dot="#22c55e" label="Submitted to HR" value={submittedCount} />
            <StatChip dot="#facc15" label="Draft"     value={draftCount}     />
            <StatChip dot="#94a3b8" label="Total"     value={summaries.length} />
          </div>

          <button
            onClick={onClose}
            className="rounded-full p-1.5 transition-colors"
            style={{ background: 'rgba(255,255,255,0.15)' }}
            title="Close"
          >
            <X size={18} color="#fff" />
          </button>
        </div>

        {/* ══ DRAFT WARNING BANNER ════════════════════════════════════════════ */}
        {!loading && draftCount > 0 && (
          <div className="flex items-start gap-3 border-b border-red-200 bg-red-50
                          px-6 py-3 text-sm text-red-800 leading-relaxed shrink-0">
            <AlertTriangle size={16} className="shrink-0 mt-0.5 text-red-500" />
            <span>
              Please review all your nominations below. Once you click{' '}
              <strong>Submit to HR</strong>, you will{' '}
              <strong>not</strong> be able to make any further changes.
            </span>
          </div>
        )}

        {/* ══ BODY ════════════════════════════════════════════════════════════ */}
        <div className="flex-1 overflow-y-auto p-5">

          {/* Controls row */}
          <div className="flex justify-between items-center mb-3 text-xs text-gray-700">

            {/* Left — Show N entries */}
            <div className="flex items-center gap-1.5">
              <span>Show</span>
              <select
                value={pageSize}
                onChange={(e) => { setPageSize(Number(e.target.value)); setPage(0); }}
                className="border border-gray-400 rounded px-1.5 py-0.5 text-xs
                           focus:outline-none focus:ring-1 focus:ring-blue-400"
              >
                {[10, 25, 50].map((n) => <option key={n}>{n}</option>)}
              </select>
              <span>entries</span>
            </div>

            {/* Right — Excel + Search */}
            <div className="flex items-center gap-2.5">
              <button
                onClick={() => downloadExcel(financialYear)}
                className="bg-green-700 hover:bg-green-600 text-white text-xs font-semibold
                           px-3 py-1.5 rounded transition-colors"
              >
                ⬇ Download Excel
              </button>
              <span className="text-gray-600">Search:</span>
              <input
                value={search}
                onChange={(e) => { setSearch(e.target.value); setPage(0); }}
                placeholder="Search..."
                className="border border-gray-400 rounded px-2.5 py-1.5 text-xs w-44
                           focus:outline-none focus:ring-1 focus:ring-blue-400"
              />
            </div>
          </div>

          {/* Table */}
          {loading ? (
            <div className="text-center py-16 text-gray-400 text-sm">Loading...</div>
          ) : (
            <div className="overflow-x-auto border border-gray-300 rounded">
              <table className="w-full border-collapse text-xs">
                <thead>
                  <tr className="bg-purple-700 text-white">
                    {['Award Title', 'Category', 'Nomination 1', 'Nomination 2', 'Nomination 3', 'Nomination 4'].map((h) => (
                      <th key={h} className="px-3 py-2 text-left border border-purple-600 font-semibold whitespace-nowrap">
                        {h} <SortIcon />
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {paginated.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="text-center py-10 text-gray-500 border border-gray-200">
                        No data available in table
                      </td>
                    </tr>
                  ) : (
                    paginated.map((s, i) => (
                      <tr key={s.nominationId ?? i} className={i % 2 === 1 ? 'bg-gray-50' : 'bg-white'}>
                        <td className="px-3 py-2 border border-gray-200 font-semibold text-gray-800 whitespace-nowrap">
                          {s.awardTitle || '—'}
                        </td>
                        <td className="px-3 py-2 border border-gray-200 text-gray-700 whitespace-nowrap">
                          {s.category || '—'}
                        </td>
                        <td className="px-3 py-2 border border-gray-200 text-gray-700">
                          <NomineeCell name={s.nomination1} department={s.department1} reason={s.reason1} />
                        </td>
                        <td className="px-3 py-2 border border-gray-200 text-gray-700">
                          <NomineeCell name={s.nomination2} department={s.department2} reason={s.reason2} />
                        </td>
                        <td className="px-3 py-2 border border-gray-200 text-gray-700">
                          <NomineeCell name={s.nomination3} department={s.department3} reason={s.reason3} />
                        </td>
                        <td className="px-3 py-2 border border-gray-200 text-gray-700">
                          <NomineeCell name={s.nomination4} department={s.department4} reason={s.reason4} />
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          )}

          {/* Pagination */}
          <div className="flex justify-between items-center mt-3 text-xs text-gray-500">
            <span>
              Showing{' '}
              {filtered.length === 0 ? 0 : page * pageSize + 1} to{' '}
              {Math.min((page + 1) * pageSize, filtered.length)} of {filtered.length} entries
            </span>
            <div className="flex gap-2">
              <button
                disabled={page === 0}
                onClick={() => setPage((p) => Math.max(0, p - 1))}
                className={`px-3 py-1 rounded text-xs font-medium transition-colors
                  ${page === 0
                    ? 'bg-gray-100 text-gray-400 cursor-default'
                    : 'bg-blue-900 text-white hover:bg-blue-800 cursor-pointer'}`}
              >
                Previous
              </button>
              <button
                disabled={page >= totalPages - 1}
                onClick={() => setPage((p) => Math.min(totalPages - 1, p + 1))}
                className={`px-3 py-1 rounded text-xs font-medium transition-colors
                  ${page >= totalPages - 1
                    ? 'bg-gray-100 text-gray-400 cursor-default'
                    : 'bg-blue-900 text-white hover:bg-blue-800 cursor-pointer'}`}
              >
                Next
              </button>
            </div>
          </div>

        </div>{/* end body */}

        {/* ══ FOOTER ══════════════════════════════════════════════════════════ */}
        {!loading && (
          <div className="flex items-center justify-between gap-3 px-6 py-4 shrink-0
                          border-t border-gray-200 bg-gray-50">

            <button
              onClick={onClose}
              className="bg-white hover:bg-gray-100 text-gray-700 text-sm font-semibold
                         px-5 py-2.5 rounded border border-gray-300 transition-colors"
            >
              Close
            </button>

            <div className="flex items-center gap-3">

              {/* All done badge */}
              {draftCount === 0 && submittedCount > 0 && (
                <div className="flex items-center gap-2 bg-green-50 border border-green-300
                                text-green-800 px-4 py-2 rounded text-sm font-semibold">
                  <CheckCircle size={14} />
                  All nominations submitted to HR.
                </div>
              )}

              {/* Submit button — always active when drafts exist; restriction removed */}
              {draftCount > 0 && (
                <button
                  onClick={handleSubmitToHR}
                  disabled={submitting}
                  className={`flex items-center gap-2 text-white text-sm font-semibold
                              px-5 py-2.5 rounded transition-colors
                              ${submitting
                                ? 'bg-gray-400 cursor-not-allowed opacity-60'
                                : 'bg-blue-900 hover:bg-blue-800 cursor-pointer'}`}
                >
                  <Send size={14} />
                  {submitting ? 'Submitting…' : `Submit ${draftCount} Nomination(s) to HR`}
                </button>
              )}
            </div>
          </div>
        )}

      </div>{/* end modal panel */}
    </div>
  );
};

/* ── Stat chip in header ─────────────────────────────────────────────────────── */
const StatChip = ({ dot, label, value }) => (
  <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
    <span style={{ width: 8, height: 8, borderRadius: '50%', background: dot, flexShrink: 0 }} />
    <span style={{ fontSize: 11, color: '#fecaca', fontWeight: 500 }}>{label}</span>
    <strong style={{ fontSize: 14, color: '#fff', fontWeight: 700 }}>{value}</strong>
  </div>
);

/* ── NomineeCell ─────────────────────────────────────────────────────────────── */
const NomineeCell = ({ name, department, reason }) => {
  if (!name) return <span className="text-gray-400">—</span>;
  return (
    <div className="min-w-[120px]">
      <div className="font-medium text-gray-800">{name}</div>
      {department && (
        <div className="text-gray-500 text-xs mt-0.5">{department}</div>
      )}
      {reason && (
        <div
          className="text-gray-400 text-xs mt-0.5 italic leading-tight"
          style={{
            display: '-webkit-box',
            WebkitLineClamp: 2,
            WebkitBoxOrient: 'vertical',
            overflow: 'hidden',
          }}
          title={reason}
        >
          {reason}
        </div>
      )}
    </div>
  );
};

export default NominationSummaryModal;