import React, { useState, useEffect, useCallback } from 'react';
import { fetchNominationsByUser, submitAllNominationsEmployees } from './ExecuitiveCircleApi';
import {
  CheckCircle, Clock, Send, ChevronDown, ChevronUp,
  User, Award, AlertTriangle, X,
} from 'lucide-react';
import Swal from 'sweetalert2';


const PreviewAndSubmit = ({ isOpen, onClose, financialYear, currentUser }) => {
  const [nominations, setNominations] = useState([]);
  const [loading, setLoading]         = useState(false);
  const [submitting, setSubmitting]   = useState(false);
  const [expandedIds, setExpandedIds] = useState(new Set());

  // ── Load nominations every time the modal opens ───────────────────────────
  const loadNominations = useCallback(() => {
    if (!currentUser?.employeeCode || !financialYear) return;
    setLoading(true);
    fetchNominationsByUser(currentUser.employeeCode, financialYear)
      .then((data) => {
        setNominations(data || []);
        setExpandedIds(new Set((data || []).map((n) => n.id))); // expand all by default
      })
      .catch(() => setNominations([]))
      .finally(() => setLoading(false));
  }, [currentUser?.employeeCode, financialYear]);

  useEffect(() => {
    if (isOpen) loadNominations();
  }, [isOpen, loadNominations]);

  // ── Escape key closes modal ───────────────────────────────────────────────
  useEffect(() => {
    const handler = (e) => { if (e.key === 'Escape') onClose(); };
    if (isOpen) window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [isOpen, onClose]);

  // ── Lock body scroll while open ───────────────────────────────────────────
  useEffect(() => {
    document.body.style.overflow = isOpen ? 'hidden' : '';
    return () => { document.body.style.overflow = ''; };
  }, [isOpen]);

  if (!isOpen) return null;

  // ── Derived stats ─────────────────────────────────────────────────────────
  const nominatingCount = nominations.filter((n) => n.nominating).length;
  const submittedCount  = nominations.filter((n) => n.status === 'SUBMITTED').length;
  const draftCount      = nominations.filter((n) => n.nominating && n.status === 'DRAFT').length;

  const toggleExpand = (id) =>
    setExpandedIds((prev) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });

  // ── Submit to HR ──────────────────────────────────────────────────────────
  const handleSubmitToHR = async () => {
    const draftNoms = nominations.filter((n) => n.nominating && n.status === 'DRAFT');

    if (draftNoms.length === 0) {
      Swal.fire({
        icon: 'info',
        title: 'Nothing to Submit',
        text: 'All nominations are already submitted or you have not nominated for any award.',
        confirmButtonColor: '#1e3a8a',
      });
      return;
    }

    const result = await Swal.fire({
      icon: 'warning',
      title: 'Submit to HR?',
      html: `
        <p style="font-size:14px;color:#374151;margin:0">
          You are about to submit <strong>${draftNoms.length} nomination(s)</strong> to HR.<br/><br/>
          <span style="color:#b91c1c;font-weight:600">Once submitted, you cannot make further changes.</span>
        </p>
      `,
      showCancelButton:   true,
      confirmButtonText:  'Yes, Submit',
      cancelButtonText:   'Cancel',
      confirmButtonColor: '#1e3a8a',
      cancelButtonColor:  '#6b7280',
    });

    if (!result.isConfirmed) return;

    setSubmitting(true);
    try {
      await submitAllNominationsEmployees(currentUser.employeeCode, financialYear);
      // Optimistically flip DRAFT → SUBMITTED in local state
      setNominations((prev) =>
        prev.map((n) =>
          n.nominating && n.status === 'DRAFT' ? { ...n, status: 'SUBMITTED' } : n
        )
      );
      Swal.fire({
        icon:               'success',
        title:              'Submitted Successfully!',
        text:               'Your nominations have been submitted to HR. A confirmation mail has been sent.',
        confirmButtonColor: '#1e3a8a',
      });
    } catch (e) {
      Swal.fire({
        icon:               'error',
        title:              'Submission Failed',
        text:               e.message || 'Something went wrong. Please try again.',
        confirmButtonColor: '#1e3a8a',
      });
    } finally {
      setSubmitting(false);
    }
  };

  // ── Status badge ──────────────────────────────────────────────────────────
  const StatusBadge = ({ status }) => {
    const map = {
      SUBMITTED: { bg: 'bg-green-100',  text: 'text-green-800',  border: 'border-green-300',  label: 'Submitted', Icon: CheckCircle   },
      DRAFT:     { bg: 'bg-yellow-50',  text: 'text-yellow-800', border: 'border-yellow-300', label: 'Draft',     Icon: Clock         },
      APPROVED:  { bg: 'bg-blue-100',   text: 'text-blue-800',   border: 'border-blue-300',   label: 'Approved',  Icon: CheckCircle   },
      REJECTED:  { bg: 'bg-red-100',    text: 'text-red-800',    border: 'border-red-300',    label: 'Rejected',  Icon: AlertTriangle  },
    };
    const cfg = map[status] || map.DRAFT;
    return (
      <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full
                        text-xs font-semibold border ${cfg.bg} ${cfg.text} ${cfg.border}`}>
        <cfg.Icon size={11} />
        {cfg.label}
      </span>
    );
  };

  // ─────────────────────────────────────────────────────────────────────────
  return (
    /* ── Backdrop — click outside panel to close ── */
    <div
      className="fixed inset-0 z-50 flex items-center justify-center"
      style={{ background: 'rgba(0,0,0,0.55)', backdropFilter: 'blur(2px)' }}
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
    >

      {/* ── Modal panel ── */}
      <div
        className="relative bg-white flex flex-col"
        style={{
          width:     '92vw',
          maxWidth:  920,
          maxHeight: '90vh',
          borderRadius: 12,
          boxShadow: '0 24px 64px rgba(0,0,0,0.32)',
          overflow:  'hidden',
        }}
      >

        {/* ══ HEADER ══════════════════════════════════════════════════════════ */}
        <div
          className="flex items-center justify-between px-6 py-4 shrink-0"
          style={{ background: 'linear-gradient(135deg,#7f1d1d 0%,#991b1b 50%,#b91c1c 100%)' }}
        >
          <div className="flex items-center gap-3">
            <div
              className="flex items-center justify-center rounded-full text-lg"
              style={{ width: 36, height: 36, background: 'rgba(255,255,255,0.15)' }}
            >
              🏆
            </div>
            <div>
              <p className="text-white text-sm font-bold tracking-wide uppercase">
                Preview &amp; Submit to HR
              </p>
              <p className="text-xs" style={{ color: 'rgba(255,255,255,0.70)' }}>
                Financial Year {financialYear}
                {currentUser?.name ? ` — ${currentUser.name}` : ''}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            title="Close (Esc)"
            className="rounded-full p-1.5 transition-colors"
            style={{ background: 'rgba(255,255,255,0.15)', color: '#fff' }}
            onMouseEnter={(e) => (e.currentTarget.style.background = 'rgba(255,255,255,0.30)')}
            onMouseLeave={(e) => (e.currentTarget.style.background = 'rgba(255,255,255,0.15)')}
          >
            <X size={17} />
          </button>
        </div>

        {/* ══ STATS STRIP ═════════════════════════════════════════════════════ */}
        <div
          className="flex items-center gap-6 px-6 py-2.5 shrink-0 flex-wrap"
          style={{ background: '#1e3a8a' }}
        >
          <StatChip dot="#facc15" label="Total Awards"  value={nominations.length} />
          <StatChip dot="#a78bfa" label="Nominating"    value={nominatingCount} />
          <StatChip dot="#fbbf24" label="Drafts"        value={draftCount} />
          <StatChip dot="#4ade80" label="Submitted"     value={submittedCount} />
        </div>

        {/* ══ SCROLLABLE BODY ═════════════════════════════════════════════════ */}
        <div className="flex-1 overflow-y-auto px-6 py-5">

          {/* Loading */}
          {loading && (
            <div className="flex items-center justify-center h-40">
              <span className="text-gray-400 text-sm animate-pulse">Loading nominations…</span>
            </div>
          )}

          {/* Empty */}
          {!loading && nominations.length === 0 && (
            <div className="bg-gray-50 border border-gray-200 rounded-lg px-5 py-10 text-center">
              <Award size={36} className="text-gray-300 mx-auto mb-2" />
              <p className="text-gray-500 text-sm">No nominations saved yet.</p>
              <button
                onClick={onClose}
                className="mt-4 bg-blue-900 hover:bg-blue-800 text-white text-xs
                           font-semibold px-4 py-2 rounded transition-colors"
              >
                Close
              </button>
            </div>
          )}

          {/* Content */}
          {!loading && nominations.length > 0 && (
            <>
              {/* Warning banner */}
              <div className="flex items-start gap-3 border-2 border-red-400 bg-red-50
                              rounded-lg px-4 py-3 mb-5 text-sm text-red-800 leading-relaxed">
                <AlertTriangle size={16} className="shrink-0 mt-0.5 text-red-500" />
                <span>
                  Please review all your nominations. Once you click{' '}
                  <strong>Submit to HR</strong>, you will{' '}
                  <strong>not</strong> be able to make any further changes.
                </span>
              </div>

              {/* Award cards */}
              <div className="flex flex-col gap-3">
                {nominations.map((nom) => {
                  const expanded   = expandedIds.has(nom.id);
                  const hasDetails = nom.nominating && nom.nominationDetails?.length > 0;

                  return (
                    <div
                      key={nom.id}
                      className="border border-gray-200 rounded-lg overflow-hidden shadow-sm"
                    >
                      {/* Card header */}
                      <div
                        onClick={() => hasDetails && toggleExpand(nom.id)}
                        className={`flex items-center justify-between px-4 py-3
                                    bg-gradient-to-r from-slate-50 to-white
                                    border-b border-gray-100
                                    ${hasDetails ? 'cursor-pointer select-none' : ''}`}
                      >
                        <div className="flex items-center gap-3 min-w-0">
                          <span style={{
                            width: 8, height: 8, borderRadius: '50%', flexShrink: 0,
                            background: nom.status === 'SUBMITTED' ? '#22c55e' : '#facc15',
                          }} />
                          <div className="min-w-0">
                            <p className="text-sm font-semibold text-gray-800 truncate">
                              {nom.awardTitle}
                            </p>
                            {nom.awardCategory && (
                              <p className="text-xs text-gray-400">{nom.awardCategory}</p>
                            )}
                          </div>
                        </div>

                        <div className="flex items-center gap-2 shrink-0 ml-3">
                          {nom.nominating
                            ? <StatusBadge status={nom.status} />
                            : <span className="text-xs text-gray-400 italic">Not nominating</span>
                          }
                          {hasDetails && (
                            expanded
                              ? <ChevronUp   size={15} className="text-gray-400" />
                              : <ChevronDown size={15} className="text-gray-400" />
                          )}
                        </div>
                      </div>

                      {/* Nominee table */}
                      {hasDetails && expanded && (
                        <div className="overflow-x-auto">
                          <table className="w-full text-xs border-collapse">
                            <thead>
                              <tr className="bg-purple-800 text-white">
                                {['#', 'Nominee', 'Code', 'Department', 'Designation', 'Reason for Nomination']
                                  .map((h) => (
                                    <th key={h}
                                        className="text-left px-3 py-2 border border-purple-700 font-semibold">
                                      {h}
                                    </th>
                                  ))}
                              </tr>
                            </thead>
                            <tbody>
                              {nom.nominationDetails
                                .slice()
                                .sort((a, b) => a.sequenceNo - b.sequenceNo)
                                .map((d, i) => (
                                  <tr key={d.id ?? i}
                                      className={i % 2 === 0 ? 'bg-white' : 'bg-purple-50'}>
                                    <td className="px-3 py-2 border border-gray-200 text-gray-400 text-center w-6">
                                      {d.sequenceNo}
                                    </td>
                                    <td className="px-3 py-2 border border-gray-200">
                                      <div className="flex items-center gap-1.5">
                                        <User size={11} className="text-gray-400 shrink-0" />
                                        <span className="font-medium text-gray-800">{d.nomineeName}</span>
                                      </div>
                                      {d.nomineeEmailId && (
                                        <div className="text-gray-400 text-xs mt-0.5 ml-4">
                                          {d.nomineeEmailId}
                                        </div>
                                      )}
                                    </td>
                                    <td className="px-3 py-2 border border-gray-200 text-gray-600">
                                      {d.nomineeEmployeeCode}
                                    </td>
                                    <td className="px-3 py-2 border border-gray-200 text-gray-600">
                                      {d.department || '—'}
                                    </td>
                                    <td className="px-3 py-2 border border-gray-200 text-gray-600">
                                      {d.nomineeDesignation || '—'}
                                    </td>
                                    <td className="px-3 py-2 border border-gray-200 text-gray-600 max-w-xs">
                                      <p className="whitespace-pre-wrap leading-relaxed">
                                        {d.reasonForNomination || '—'}
                                      </p>
                                    </td>
                                  </tr>
                                ))}
                            </tbody>
                          </table>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </>
          )}
        </div>

        {/* ══ FOOTER ══════════════════════════════════════════════════════════ */}
        {!loading && nominations.length > 0 && (
          <div className="flex items-center justify-between gap-3 px-6 py-4 shrink-0
                          border-t border-gray-200 bg-gray-50">

            <button
              onClick={onClose}
              className="bg-white hover:bg-gray-100 text-gray-700 text-sm font-semibold
                         px-5 py-2.5 rounded border border-gray-300 transition-colors"
            >
              Close
            </button>

            <div className="flex items-center gap-3">
              {draftCount === 0 && submittedCount > 0 && (
                <div className="flex items-center gap-2 bg-green-50 border border-green-300
                                text-green-800 px-4 py-2 rounded text-sm font-semibold">
                  <CheckCircle size={14} />
                  All nominations submitted to HR.
                </div>
              )}

              {draftCount > 0 && (
                <button
                  onClick={handleSubmitToHR}
                  disabled={submitting}
                  className={`flex items-center gap-2 text-white text-sm font-semibold
                              px-5 py-2.5 rounded transition-colors
                              ${submitting
                                ? 'bg-gray-400 cursor-not-allowed'
                                : 'bg-blue-900 hover:bg-blue-800'}`}
                >
                  <Send size={14} />
                  {submitting ? 'Submitting…' : `Submit ${draftCount} Nomination(s) to HR`}
                </button>
              )}
            </div>
          </div>
        )}

      </div>{/* end modal panel */}
    </div>/* end backdrop */
  );
};

// ── Stat chip inside the blue strip ──────────────────────────────────────────
const StatChip = ({ dot, label, value }) => (
  <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
    <span style={{ width: 8, height: 8, borderRadius: '50%', background: dot, flexShrink: 0 }} />
    <span style={{ fontSize: 11, color: '#bfdbfe', fontWeight: 500 }}>{label}</span>
    <strong style={{ fontSize: 14, color: '#fff', fontWeight: 700 }}>{value}</strong>
  </div>
);

export default PreviewAndSubmit;