import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import RnRService from "../RnRService";
import axios from "axios";
import Swal from "sweetalert2";
import {
  getExecutiveCircleDetails,
  checkAnyAwardEligibility,
  fetchCurrentFinancialYear,
  fetchAllAwards,
  getAwardWinners,
} from "./ExecuitiveCircleApi";
import Header from "../../components/Header";
import { ArrowLeft } from "lucide-react";

const fallbackImageUrl =
  "https://militaryhealthinstitute.org/wp-content/uploads/sites/37/2021/08/blank-profile-picture-png.png";

const ExecutiveCircleList = () => {
  const navigate = useNavigate();

  // ----- Financial Year -----
  const [financialYear, setFinancialYear] = useState("");
  const [financialYearOptions, setFinancialYearOptions] = useState([]);
  const [loadingFY, setLoadingFY] = useState(true);

  // ----- Original grid data -----
  const [executiveCircleList, setExecutiveCircleList] = useState([]);
  const [loading, setLoading] = useState(false);

  // ----- Employee data & interactions (for grid) -----
  const [executiveEmpMap, setExecutiveEmpMap] = useState({});
  const [execPage, setExecPage] = useState(0);
  const execPageSize = 10;
  const [execCountsMap, setExecCountsMap] = useState({});
  const [selectedExecNominee, setSelectedExecNominee] = useState(null);
  const [execCommentList, setExecCommentList] = useState([]);
  const [newExecComment, setNewExecComment] = useState("");
  const [loadingExecComments, setLoadingExecComments] = useState(false);
  const [likeList, setLikeList] = useState([]);
  const [showLikesModal, setShowLikesModal] = useState(false);
  const [canNominate, setCanNominate] = useState(false);
  const empCode = localStorage.getItem("empId");

  // ----- Sidebar & winners -----
  const [allAwards, setAllAwards] = useState([]);
  const [selectedAward, setSelectedAward] = useState(null);
  const [winnersMap, setWinnersMap] = useState({});
  const [loadingWinners, setLoadingWinners] = useState(false);
  const [viewMode, setViewMode] = useState("grid");

  // ----- Load financial year options -----
  useEffect(() => {
    const loadFinancialYears = async () => {
      try {
        const response = await fetchCurrentFinancialYear();
        const currentFYLabel = response.label || response;
        const [startStr, endStr] = currentFYLabel.split("-");
        let start = parseInt(startStr);
        let end = parseInt(endStr);
        const options = [];
        for (let i = 0; i <= 2; i++) {
          const yearStart = start - i;
          const yearEnd = end - i;
          const yearEndFormatted = yearEnd.toString().padStart(2, "0");
          options.push(`${yearStart}-${yearEndFormatted}`);
        }
        setFinancialYearOptions(options);
        setFinancialYear(currentFYLabel);
      } catch (error) {
        console.error("Failed to fetch financial year", error);
      } finally {
        setLoadingFY(false);
      }
    };
    loadFinancialYears();
  }, []);

  // ----- Fetch all awards (master list) -----
  useEffect(() => {
    fetchAllAwards()
      .then((res) => setAllAwards(res || []))
      .catch((err) => console.error("Failed to load awards", err));
  }, []);

  // ----- Fetch grid data when FY changes -----
  useEffect(() => {
    if (financialYear) {
      fetchExecutiveCircleAwards(financialYear);
    }
  }, [financialYear]);

  const fetchExecutiveCircleAwards = async (fy) => {
  setLoading(true);
  try {
    const res = await getExecutiveCircleDetails(fy, ["Submitted to HR", "Approved"]);
    setExecutiveCircleList(res || []);
  } catch (error) {
    console.error("Failed to fetch Executive Circle Awards", error);
    setExecutiveCircleList([]);
  } finally {
    setLoading(false);
  }
};

  // ----- Fetch winners when FY changes -----
  useEffect(() => {
    if (financialYear) {
      setLoadingWinners(true);
      getAwardWinners(financialYear)
        .then((res) => {
          const map = {};
          (res.data || []).forEach((item) => {
            map[item.awardTitle] = item.winners;
          });
          setWinnersMap(map);
        })
        .catch((err) => {
          console.error("Failed to load winners", err);
          setWinnersMap({});
        })
        .finally(() => setLoadingWinners(false));
    }
  }, [financialYear]);

  // ----- Check eligibility -----
  useEffect(() => {
    const checkEligibility = async () => {
      if (!empCode) return;
      try {
        const eligible = await checkAnyAwardEligibility(empCode);
        setCanNominate(eligible);
      } catch (error) {
        console.error("Eligibility check failed", error);
        setCanNominate(false);
      }
    };
    checkEligibility();
  }, [empCode]);

  // ----- Employee data fetching for grid -----
  const getExecutiveEmployeeData = async (nomineeName) => {
    if (!nomineeName || executiveEmpMap[nomineeName]) return;
    try {
      const searchRes = await RnRService.searchEmployeeByName(nomineeName);
      const empCode = searchRes.data?.[0]?.empCode || searchRes.data?.empCode;
      if (!empCode) return;
      const res = await RnRService.employeeInfoData(empCode);
      const fileData = res.data?.fileAndObjectTypeBean?.fileAndContentTypeBean?.file;
      const emp = res.data?.fileAndObjectTypeBean?.empResDTO || {};
      const empData = {
        ...emp,
        department: emp?.mainDeptResDTO?.mainDepartment,
        designation: emp?.designationResDTO?.designationName,
        profileImage: fileData ? `data:image/png;base64,${fileData}` : fallbackImageUrl,
      };
      setExecutiveEmpMap((prev) => ({ ...prev, [nomineeName]: empData }));
    } catch (error) {}
  };

  const execKey = (nominationDetailId) => `detail-${nominationDetailId}`;

  const fetchExecCounts = async (nominationDetailId) => {
    const key = execKey(nominationDetailId);
    try {
      const [likesRes, commentsRes] = await Promise.all([
        RnRService.getNominationLikes(nominationDetailId),
        RnRService.getNominationComments(nominationDetailId),
      ]);
      setExecCountsMap((prev) => ({
        ...prev,
        [key]: { likes: likesRes.data?.length || 0, comments: commentsRes.data?.length || 0 },
      }));
    } catch (e) {}
  };

  useEffect(() => {
    executiveCircleList.forEach((nomination) => {
      (nomination.nominationDetails || []).forEach((detail) => {
        getExecutiveEmployeeData(detail.nomineeName);
        fetchExecCounts(detail.id);
      });
    });
  }, [executiveCircleList]);

  // ----- Grid interaction handlers -----
  const handleExecLike = async (nominationDetailId) => {
    const response = await RnRService.likeNomination(nominationDetailId, empCode);
     if (response.data === "Already liked") {
                Swal.fire("Info", "You have already liked this nomination", "info");
                return;
              }
    const key = execKey(nominationDetailId);
    setExecCountsMap((prev) => ({
      ...prev,
      [key]: { ...prev[key], likes: (prev[key]?.likes || 0) + 1 },
    }));
  };

  const openExecLikesModal = async (nominationDetailId) => {
    const res = await RnRService.getNominationLikes(nominationDetailId);
    setLikeList(res.data);
    setShowLikesModal(true);
  };

  const openExecCommentModal = async (nominee) => {
    setSelectedExecNominee(nominee);
    setLoadingExecComments(true);
    const res = await RnRService.getNominationComments(nominee.nominationDetailId);
    setExecCommentList(res.data || []);
    setLoadingExecComments(false);
  };

  const closeExecModal = () => {
    setSelectedExecNominee(null);
    setExecCommentList([]);
    setNewExecComment("");
  };

  const submitExecComment = async () => {
    if (!newExecComment.trim()) {
      Swal.fire("Error", "Comment cannot be empty", "error");
      return;
    }
    const url = RnRService.addNominationComment(selectedExecNominee.nominationDetailId, empCode);
    await axios.post(url, newExecComment, { headers: { "Content-Type": "text/plain;charset=UTF-8" } });
    setNewExecComment("");
    const res = await RnRService.getNominationComments(selectedExecNominee.nominationDetailId);
    setExecCommentList(res.data || []);
    const key = execKey(selectedExecNominee.nominationDetailId);
    setExecCountsMap((prev) => ({ ...prev, [key]: { ...prev[key], comments: res.data?.length || 0 } }));
  };

  // ----- Build nominee list for grid -----
  const allNominees = executiveCircleList.flatMap((nomination) =>
    (nomination.nominationDetails || []).map((detail) => ({
      nominationDetailId: detail.id,
      name: detail.nomineeName,
      dept: detail.department,
      reason: detail.reasonForNomination,
      designation: detail.nomineeDesignation,
      nomineeEmployeeCode: detail.nomineeEmployeeCode,
      awardTitle: nomination.awardTitle,
      category: nomination.category,
      nominationId: nomination.nominationId,
    }))
  );

  const paginatedNominees = allNominees.slice(execPage * execPageSize, (execPage + 1) * execPageSize);
  const execTotalPages = Math.ceil(allNominees.length / execPageSize);

  // ----- Render winners – simple list with rank numbers -----
const renderWinners = () => {
  if (!selectedAward) {
    return <div className="text-gray-500 text-center py-10">Select an award from the sidebar</div>;
  }
  const winners = winnersMap[selectedAward.awardTitle] || [];
  if (loadingWinners) {
    return <div className="text-center py-10 text-gray-500">Loading winners...</div>;
  }
  if (winners.length === 0) {
    return <div className="text-center py-10 text-gray-400">No rankings available for this award yet.</div>;
  }

  const rankMeta = {
    1: {
      emoji: "👑",
      badge: "🥇 1st place",
      bg: "bg-gradient-to-b from-amber-500/40 to-amber-900/30 backdrop-blur-sm",
      topBar: "bg-gradient-to-r from-amber-400 via-yellow-300 to-amber-400",
      ring: "ring-amber-400 ring-[3px] shadow-[0_0_40px_rgba(251,191,36,0.3)]",
      border: "border-amber-400",
      pill: "bg-amber-500/20 text-amber-100 border-amber-400/50 font-bold text-[10px]",
      cardClass: "flex-[1.3] min-h-[340px] -translate-y-3 scale-[1.02]",
      avatarSize: "w-[88px] h-[88px]",
      glow: true,
      sparkles: true,
      textColor: "text-amber-100",
      // new spacing for badge below avatar
      avatarMargin: "mb-7",
      badgeOffset: "-bottom-5",
    },
    2: {
      emoji: "🥈",
      badge: "2nd place",
      bg: "bg-gradient-to-b from-[#3a1c47]/45 to-[#1c0e29]/50 backdrop-blur-sm",
      topBar: "bg-[#5b3568]",
      ring: "ring-[#7a4a8a] ring-2",
      border: "border-[#7a4a8a]",
      pill: "bg-[#3a1c47]/50 text-purple-100 border-[#7a4a8a]/60 text-[9px]",
      cardClass: "flex-1 min-h-[280px]",
      avatarSize: "w-[72px] h-[72px]",
      glow: false,
      sparkles: false,
      textColor: "text-purple-100",
      avatarMargin: "mb-6",
      badgeOffset: "-bottom-4",
    },
    3: {
      emoji: "🥉",
      badge: "3rd place",
      bg: "bg-gradient-to-b from-[#8B1A1A]/40 to-[#3a0d0d]/45 backdrop-blur-sm",
      topBar: "bg-[#8B1A1A]",
      ring: "ring-[#b1453f] ring-2",
      border: "border-[#b1453f]",
      pill: "bg-[#8B1A1A]/45 text-red-100 border-[#b1453f]/60 text-[9px]",
      cardClass: "flex-1 min-h-[250px]",
      avatarSize: "w-[64px] h-[64px]",
      glow: false,
      sparkles: false,
      textColor: "text-red-100",
      avatarMargin: "mb-5",
      badgeOffset: "-bottom-3.5",
    },
  };
  const podiumOrder = [2, 1, 3]
    .map(r => winners.find(w => w.rank === r))
    .filter(Boolean);

  return (
    <div className="py-6">
      {/* Header – unchanged */}
      <div className="flex flex-col items-center gap-1 mb-8">
        <div className="text-xs font-medium text-[#3a1c47]/80 tracking-[0.2em] uppercase mb-1">
          ✦ award ceremony ✦
        </div>
        <h2 className="text-2xl font-bold text-gray-800 flex items-center gap-2.5">
          <span className="text-amber-500 text-2xl">🏆</span>
          <span>{selectedAward.awardTitle} — Winners</span>
        </h2>
        <div className="w-12 h-0.5 bg-[#3a1c47]/50 rounded-full mt-1.5"></div>
      </div>

      {/* Podium cards */}
      <div className="flex items-end justify-center max-w-[600px] mx-auto gap-2.5 md:gap-4">
        {podiumOrder.map((winner, idx) => {
          const meta = rankMeta[winner.rank] || rankMeta[3];
          const emp = executiveEmpMap[winner.nomineeName] || {};
          const profileImg = emp.profileImage || fallbackImageUrl;
          const isFirst = winner.rank === 1;

          return (
            <div
              key={idx}
              className={`flex flex-col items-center text-center relative rounded-2xl px-4 py-5 pb-6 ${meta.bg} ${meta.cardClass} shadow-lg`}
            >
              {/* Top bar */}
              <div className={`absolute top-0 left-0 right-0 h-1.5 rounded-t-2xl ${meta.topBar}`} />

              {/* Sparkles for first place */}
              {isFirst && (
                <>
                  <div className="absolute w-1.5 h-1.5 rounded-full bg-amber-400/70 animate-pulse top-[8%] left-[6%]"></div>
                  <div className="absolute w-1 h-1 rounded-full bg-amber-400/70 animate-pulse top-[15%] right-[8%] [animation-delay:0.6s]"></div>
                  <div className="absolute w-1.5 h-1.5 rounded-full bg-amber-400/70 animate-pulse bottom-[18%] left-[10%] [animation-delay:1.2s]"></div>
                  <div className="absolute w-1 h-1 rounded-full bg-amber-300/80 animate-pulse bottom-[12%] right-[6%] [animation-delay:0.3s]"></div>
                  <div className="absolute w-0.5 h-0.5 rounded-full bg-amber-300/80 animate-pulse top-[40%] left-[4%] [animation-delay:0.9s]"></div>
                  <div className="absolute w-0.5 h-0.5 rounded-full bg-amber-300/80 animate-pulse top-[45%] right-[4%] [animation-delay:1.5s]"></div>
                </>
              )}

              {/* Emoji */}
              <div className="text-3xl mb-1">{meta.emoji}</div>

              {/* Avatar + rank pill – fixed spacing */}
              <div className={`relative ${meta.avatarMargin} ${isFirst ? 'before:content-[""] before:absolute before:inset-[-8px] before:rounded-full before:bg-amber-400/30 before:blur-xl' : ''}`}>
                <img
                  src={profileImg}
                  alt={winner.nomineeName}
                  onError={(e) => { e.target.src = fallbackImageUrl; }}
                  className={`${meta.avatarSize} rounded-full object-cover ring-2 ${meta.ring} shadow-md relative z-10`}
                />
                {/* Rank pill below the avatar, not overlapping */}
                <span className={`absolute ${meta.badgeOffset} left-1/2 -translate-x-1/2 px-2.5 py-0.5 rounded-full border whitespace-nowrap shadow-sm z-20 ${meta.pill}`}>
                  {meta.badge}
                </span>
              </div>

              <p className="mt-1 font-semibold text-gray-900 text-sm">{winner.nomineeName}</p>
              <p className="text-[10px] text-gray-600 uppercase tracking-wider mt-0.5 mb-1">
                {winner.department || emp.department || "—"}
              </p>

              {/* Extra tag for 1st place */}
              {isFirst && (
                <div className="flex items-center gap-1.5 text-[10px] text-amber-800 bg-amber-100/80 px-3 py-1 rounded-full border border-amber-300 shadow-sm mt-1">
                  <span>⭐</span>
                  <span>{winner.rankReason}</span>
                  <span>⭐</span>
                </div>
              )}

              {winner.rankReason && (
                <p className={`text-[10px] text-gray-500 italic border-t ${isFirst ? 'border-amber-300/50' : 'border-gray-300/60'} pt-2 mt-auto leading-relaxed max-w-[92%]`}>
                  {winner.reasonForNomination}
                </p>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};

  // ----- Sidebar click handlers -----
  const handleAwardClick = (award) => {
    setSelectedAward(award);
    setViewMode("winners");
  };

  const handleShowAll = () => {
    setViewMode("grid");
    setSelectedAward(null);
  };

  // ----- Main render -----
  return (
    <>
   
      <Header />
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden mt-16 pt-4">
        {/* Top Banner */}
        <div className=" bg-gradient-to-b from-red-900 to-red-700 px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <button
                onClick={() => navigate("/rewardsHomePage")}
                className="text-white hover:text-gray-200 transition p-1 rounded-full bg-white/20 hover:bg-white/30"
                title="Go back"
              >
                <ArrowLeft size={24} />
              </button>
              <h2 className="text-xl font-semibold text-white">
                <span>👑</span> Executive Circle Awards
              </h2>
            </div>
            <div className="flex items-center gap-4">

               <button
                  onClick={() => navigate("/executive-circle-ranking")}
                  className="px-4 py-2 bg-white/15 hover:bg-green-600/25 border border-white/30 backdrop-blur-sm text-white text-sm font-medium rounded-lg shadow transition flex items-center gap-1"
                >
                   Rankings
                </button>
              <div className="flex items-center gap-2 bg-white/20 rounded-lg px-3 py-1.5">
                <label className="text-sm font-medium text-white">FY:</label>
                <select
                  value={financialYear}
                  onChange={(e) => setFinancialYear(e.target.value)}
                  className="bg-white text-gray-800 rounded-md px-2 py-1 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400"
                  disabled={loadingFY}
                >
                  {loadingFY ? (
                    <option>Loading...</option>
                  ) : (
                    financialYearOptions.map((fy) => (
                      <option key={fy} value={fy}>
                        {fy}
                      </option>
                    ))
                  )}
                </select>
              </div>
              {canNominate && (
                <button
                  onClick={() => navigate("/executive-circle")}
                  className="px-4 py-2 bg-white hover:bg-red-600 text-[#3a1c47] text-sm font-semibold rounded-lg shadow-md transition flex items-center gap-1"
                >
                  <span>+</span> Nominate
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Sidebar + Main */}
        <div className="flex flex-col md:flex-row">
          {/* Sidebar – large text & circle bullets #374255 #6e3984*/}
          <aside className="w-full md:w-72 bg-gray-50 border-r border-gray-200 p-4 md:min-h-[500px]">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-xs font-bold uppercase text-gray-400 tracking-wider">
                Award Categories
              </h3>
              <button
                onClick={handleShowAll}
                className={`text-xs font-medium px-3 py-1 rounded-full ${
                  viewMode === "grid"
                    ? "bg-blue-600 text-white"
                    : "bg-gray-200 text-gray-700 hover:bg-gray-300"
                }`}
              >
                All
              </button>
            </div>
            <ul className="space-y-2">
              {allAwards.map((award) => {
                const hasWinners =
                  (winnersMap[award.awardTitle]?.length || 0) > 0;
                const isActive =
                  viewMode === "winners" && selectedAward?.id === award.id;
                return (
                  <li
                    key={award.id}
                    onClick={() => handleAwardClick(award)}
                    className={`flex items-center gap-3 px-3 py-3 rounded-lg cursor-pointer transition text-base ${
                      isActive
                        ? "bg-blue-900 text-white font-semibold"
                        : "hover:bg-gray-300 text-gray-800"
                    }`}
                  >
                    {/* Circle bullet */}
                    <span
                      className={`inline-block w-3 h-3 rounded-full border-2 flex-shrink-0 ${
                        isActive
                          ? "border-white bg-white"
                          : hasWinners
                          ? "border-green-500 bg-green-500"
                          : "border-gray-400 bg-transparent"
                      }`}
                    />
                    <span className="flex-1">{award.awardTitle}</span>
                    {hasWinners && !isActive && (
                      <span className="text-xs text-green-600 font-bold">✓</span>
                    )}
                  </li>
                );
              })}
            </ul>
          </aside>

          {/* Main Content */}
          <main className="flex-1 p-6 bg-white">
            {viewMode === "grid" ? (
              // ----- ORIGINAL GRID VIEW (unchanged) -----
              <>
                {loading ? (
                  <div className="text-center py-10 text-gray-500">Loading...</div>
                ) : allNominees.length === 0 ? (
                  <div className="text-center py-10 text-gray-400">
                    No nominations found for this financial year.
                  </div>
                ) : (
                  <>
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                      {paginatedNominees.map((nominee, idx) => (
                        <div
                          key={`${nominee.nominationId}-${nominee.name}-${idx}`}
                          className="w-full transition-all duration-300 hover:-translate-y-1"
                          style={{
                            "--card-border": "#8A3B63",
                            "--card-light":  "#F7E8F0",
                            "--card-lightBorder": "#E5C5D5",
                            "--card-text": "#5C1140",
                            "--card-glow": "rgba(138,59,99,0.18)",
                          }}
                        >
                          <div
                            className="bg-white border-l-4 border border-[#E8D5D5] rounded-xl shadow-sm hover:shadow-xl hover:scale-105 p-4 text-center transition-all duration-300 hover:shadow-[0_18px_30px_-10px_var(--card-glow)] hover:border-[var(--card-lightBorder)]"
                            style={{ borderLeftColor: "var(--card-border)" }}
                          >
                            <div className="flex justify-center mb-4">
                              <img
                                src={
                                  executiveEmpMap[nominee.name]?.profileImage ||
                                  fallbackImageUrl
                                }
                                alt="Profile"
                                className="w-28 h-28 rounded-full border-2 shadow-sm object-cover"
                                style={{ borderColor: "var(--card-lightBorder)" }}
                              />
                            </div>
                            <h6 className="font-semibold text-gray-800 text-lg">
                              {nominee.name}
                            </h6>
                            <p className="text-sm text-gray-500 mt-1">
                              {nominee.designation ||
                                executiveEmpMap[nominee.name]?.designation ||
                                nominee.dept ||
                                "—"}
                            </p>
                            <span
                              className="inline-block mt-2 px-3 py-1 text-xs font-medium rounded-full border"
                              style={{
                                backgroundColor: "var(--card-light)",
                                color: "var(--card-text)",
                                borderColor: "var(--card-lightBorder)",
                              }}
                            >
                              {nominee.awardTitle}
                            </span>
                            <div className="mt-2">
                              <span
                                className="inline-block px-3 py-1 text-xs font-medium rounded-full border"
                                style={{
                                  backgroundColor: "var(--card-light)",
                                  color: "var(--card-text)",
                                  borderColor: "var(--card-lightBorder)",
                                }}
                              >
                                {nominee.category}
                              </span>
                            </div>
                            {nominee.reason && (
                              <p className="mt-3 text-xs text-gray-500 italic border-t border-gray-100 pt-2">
                                "{nominee.reason}"
                              </p>
                            )}
                            <div className="flex justify-center gap-8 mt-4 pt-2 border-t border-gray-100">
                              <div className="flex items-center gap-2">
                                <button
                                  onClick={() =>
                                    handleExecLike(nominee.nominationDetailId)
                                  }
                                  className="text-gray-400 hover:text-[var(--card-text)] transition"
                                  title="Like"
                                >
                                  👍
                                </button>
                                <span
                                  onClick={() =>
                                    openExecLikesModal(
                                      nominee.nominationDetailId
                                    )
                                  }
                                  className="text-sm font-medium text-gray-700 cursor-pointer"
                                  title="View likes"
                                >
                                  {execCountsMap[
                                    execKey(nominee.nominationDetailId)
                                  ]?.likes || 0}
                                </span>
                              </div>
                              <div className="flex items-center gap-2">
                                <button
                                  onClick={() =>
                                    openExecCommentModal(nominee)
                                  }
                                  className="text-gray-400 hover:text-[var(--card-text)] transition"
                                  title="Comment"
                                >
                                  💬
                                </button>
                                <span className="text-sm font-medium text-gray-700">
                                  {execCountsMap[
                                    execKey(nominee.nominationDetailId)
                                  ]?.comments || 0}
                                </span>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* Pagination */}
                    <div className="flex justify-between items-center mt-4 flex-wrap gap-3 bg-white p-4 rounded-xl shadow-sm border border-gray-100">
                      <div className="text-sm text-gray-600">
                        Showing {execPage * execPageSize + 1} to{" "}
                        {Math.min(
                          (execPage + 1) * execPageSize,
                          allNominees.length
                        )}{" "}
                        of {allNominees.length}
                      </div>
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() =>
                            setExecPage((p) => Math.max(p - 1, 0))
                          }
                          disabled={execPage === 0}
                          className="px-3 py-1.5 text-sm bg-gray-100 text-gray-700 rounded-lg disabled:opacity-50 hover:bg-gray-200 transition"
                        >
                          Previous
                        </button>
                        <div className="flex gap-1">
                          {Array.from(
                            { length: execTotalPages },
                            (_, i) => i
                          ).map((p) => (
                            <button
                              key={p}
                              onClick={() => setExecPage(p)}
                              className={`w-8 h-8 text-sm rounded-lg transition ${
                                execPage === p
                                  ? "bg-blue-600 text-white"
                                  : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                              }`}
                            >
                              {p + 1}
                            </button>
                          ))}
                        </div>
                        <button
                          onClick={() =>
                            setExecPage((p) =>
                              Math.min(p + 1, execTotalPages - 1)
                            )
                          }
                          disabled={execPage === execTotalPages - 1}
                          className="px-3 py-1.5 text-sm bg-gray-100 text-gray-700 rounded-lg disabled:opacity-50 hover:bg-gray-200 transition"
                        >
                          Next
                        </button>
                      </div>
                    </div>
                  </>
                )}
              </>
            ) : (
              // ----- WINNERS VIEW (simple list) -----
              renderWinners()
            )}
          </main>
        </div>

        {/* Comment Modal (unchanged) */}
        {selectedExecNominee && (
          <div
            className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50"
            onClick={closeExecModal}
          >
            <div
              className="bg-white w-[600px] max-w-[90%] max-h-[80vh] flex flex-col rounded-lg shadow-lg border"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex justify-between items-center px-5 py-4 border-b-2 border-amber-500">
                <div className="flex items-center gap-3">
                  <span
                    onClick={closeExecModal}
                    className="text-xl cursor-pointer text-amber-600"
                  >
                    ←
                  </span>
                  <h4 className="text-lg font-bold text-indigo-900">
                    Comments
                  </h4>
                </div>
                <button
                  onClick={closeExecModal}
                  className="text-2xl text-gray-500 hover:text-black"
                >
                  ×
                </button>
              </div>
              <div className="p-5 overflow-y-auto flex-1">
                <div className="flex items-center gap-4 border-b pb-4 mb-4">
                  <img
                    src={
                      executiveEmpMap[selectedExecNominee.name]
                        ?.profileImage || fallbackImageUrl
                    }
                    alt="Profile"
                    className="w-12 h-12 rounded-full border-2 border-amber-300 shadow-sm object-cover"
                  />
                  <div>
                    <h5 className="font-bold text-base">
                      {selectedExecNominee.name}
                    </h5>
                    <div className="text-sm text-gray-500">
                      {executiveEmpMap[selectedExecNominee.name]?.designation ||
                        selectedExecNominee.dept ||
                        selectedExecNominee.awardTitle}
                    </div>
                  </div>
                </div>
                <div className="max-h-[300px] overflow-y-auto mb-4">
                  {loadingExecComments ? (
                    <div className="text-center py-5">Loading comments...</div>
                  ) : execCommentList.length === 0 ? (
                    <p className="text-center text-gray-500 py-5">
                      No comments yet. Be the first to comment!
                    </p>
                  ) : (
                    execCommentList.map((cmt, idx) => (
                      <div key={idx} className="border-b py-3">
                        <div className="flex flex-wrap items-center gap-2 mb-1">
                          <strong className="text-sm">
                            {cmt.employeeName}
                          </strong>
                          {cmt.department && (
                            <span className="bg-gray-200 text-gray-700 text-xs px-2 py-1 rounded-full font-semibold">
                              {cmt.department}
                            </span>
                          )}
                          {cmt.emailId && (
                            <span className="text-xs text-gray-500">
                              {cmt.emailId}
                            </span>
                          )}
                        </div>
                        <p className="text-sm text-gray-800 mb-1">
                          {cmt.comments}
                        </p>
                        <small className="text-xs text-gray-500">
                          {cmt.commentDateTime}
                        </small>
                      </div>
                    ))
                  )}
                </div>
                <div>
                  <textarea
                    className="w-full border rounded-md p-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400"
                    rows="3"
                    placeholder="Write a comment..."
                    value={newExecComment}
                    onChange={(e) => setNewExecComment(e.target.value)}
                  />
                  <div className="flex justify-end mt-2">
                    <button
                      onClick={submitExecComment}
                      className="bg-amber-500 hover:bg-amber-600 text-white px-4 py-2 rounded font-semibold"
                    >
                      Post Comment
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Likes Modal (unchanged) */}
        {showLikesModal && (
          <div
            className="fixed inset-0 bg-black bg-opacity-40 flex items-center justify-center z-50"
            onClick={() => setShowLikesModal(false)}
          >
            <div
              className="bg-white w-[500px] max-w-[95%] rounded-md shadow-lg border"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex justify-between items-center px-5 py-4 border-b bg-gray-100">
                <h4 className="text-lg font-semibold text-gray-800">
                  All Likes
                </h4>
                <button
                  onClick={() => setShowLikesModal(false)}
                  className="text-xl text-gray-600 hover:text-black"
                >
                  ×
                </button>
              </div>
              <div className="p-4 bg-gray-100 max-h-[400px] overflow-y-auto">
                {likeList.length === 0 ? (
                  <p className="text-center text-gray-500">No likes yet</p>
                ) : (
                  likeList.map((like, index) => (
                    <div
                      key={index}
                      className="bg-white rounded-md shadow-sm p-4 mb-4 border"
                    >
                      <div className="flex items-center gap-3 mb-2">
                        <div className="text-gray-700 text-lg">👍</div>
                        <span className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm font-medium">
                          {like.employeeName}
                        </span>
                      </div>
                      <div className="text-sm text-gray-700 ml-8">
                        {like.emailId}
                      </div>
                      <div className="text-xs text-gray-500 ml-8 mt-1">
                        {like.likedAt}
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </>
  );
};

export default ExecutiveCircleList;