// ExecutiveCircleReport.js

import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import * as XLSX from "xlsx";
import { saveAs } from "file-saver";
import { X, Award, FileSpreadsheet, Search, ChevronLeft, ChevronRight } from "lucide-react";

import Header from "../../components/Header";

import {
  fetchCurrentFinancialYear,
  getExecutiveCircleDetails,
} from "./ExecuitiveCircleApi";

const ExecutiveCircleReport = () => {
  const navigate = useNavigate();

  const [financialYear, setFinancialYear] = useState("");
  const [fyOptions, setFyOptions] = useState([]);
  const [reportData, setReportData] = useState([]);

  const [loading, setLoading] = useState(false);

  const [searchQuery, setSearchQuery] = useState("");
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [currentPage, setCurrentPage] = useState(1);

  // Load Current FY and generate previous 3 FYs
  useEffect(() => {
    loadFinancialYear();
  }, []);

  const loadFinancialYear = async () => {
    try {
      const response = await fetchCurrentFinancialYear();
      const currentFYLabel = response.label || response;
      if (!currentFYLabel) throw new Error("No financial year data");

      let startYearMatch = currentFYLabel.match(/(\d{4})/);
      let startYear = startYearMatch ? parseInt(startYearMatch[1]) : new Date().getFullYear();

      const options = [];
      for (let i = 0; i <= 2; i++) {
        const yearStart = startYear - i;
        const yearEnd = (yearStart + 1).toString().slice(-2);
        const fyString = `${yearStart}-${yearEnd}`;
        options.push(fyString);
      }
      setFyOptions(options);
      setFinancialYear(currentFYLabel);
      fetchReportData(currentFYLabel);
    } catch (err) {
      console.error("Failed to load financial year:", err);
      // const fallback = ["2026-27", "2025-26", "2024-25", "2023-24"];
      // setFyOptions(fallback);
      // setFinancialYear("2026-27");
      // fetchReportData("2026-27");
    }
  };

  const fetchReportData = async (fy) => {
  try {
    setLoading(true);
    const res = await getExecutiveCircleDetails(fy, ["Submitted to HR", "Approved"]);
    setReportData(res || []);
  } catch (err) {
    console.error("Error fetching report:", err);
  } finally {
    setLoading(false);
  }
};

  const filteredData = reportData.filter((r) =>
    JSON.stringify(r).toLowerCase().includes(searchQuery.toLowerCase())
  );

  const totalPages = Math.ceil(filteredData.length / rowsPerPage);
  const paginatedData = filteredData.slice(
    (currentPage - 1) * rowsPerPage,
    currentPage * rowsPerPage
  );

  const handleExcel = () => {
    const exportData = filteredData.map((r) => ({
      "Nomination date": r.createdAt ? new Date(r.createdAt).toLocaleDateString("en-GB") : "",
      "Award Title": r.awardTitle,
      Category: r.category,
      "Financial Year": r.financialYear,
      "Nominated By": r.submittedByName,
      Status: r.status,

      "Nominee Name 1": r.nominationDetails?.[0]?.nomineeName,
      "Nominee 1 Empcode": r.nominationDetails?.[0]?.nomineeEmployeeCode,
      "Nominee Department 1": r.nominationDetails?.[0]?.department,
      "Reason 1": r.nominationDetails?.[0]?.reasonForNomination,

      "Nominee Name 2": r.nominationDetails?.[1]?.nomineeName,
      "Nominee 2 Empcode": r.nominationDetails?.[1]?.nomineeEmployeeCode,
      "Nominee Department 2": r.nominationDetails?.[1]?.department,
      "Reason 2": r.nominationDetails?.[1]?.reasonForNomination,

      "Nominee Name 3": r.nominationDetails?.[2]?.nomineeName,
      "Nominee 3 Empcode": r.nominationDetails?.[2]?.nomineeEmployeeCode,
      "Nominee Department 3": r.nominationDetails?.[2]?.department,
      "Reason 3": r.nominationDetails?.[2]?.reasonForNomination,

      "Nominee Name 4": r.nominationDetails?.[3]?.nomineeName,
      "Nominee 4 Empcode": r.nominationDetails?.[3]?.nomineeEmployeeCode,
      "Nominee Department 4": r.nominationDetails?.[3]?.department,
      "Reason 4": r.nominationDetails?.[3]?.reasonForNomination,
    }));

    const worksheet = XLSX.utils.json_to_sheet(exportData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Executive Circle Report");
    const excelBuffer = XLSX.write(workbook, { bookType: "xlsx", type: "array" });
    const file = new Blob([excelBuffer], { type: "application/octet-stream" });
    saveAs(file, `ExecutiveCircleReport_${financialYear}.xlsx`);
  };

  return (
    <>
      <Header />
      <div className="min-h-screen bg-slate-50 mt-[70px] w-full font-sans pt-6 pb-10 px-4 sm:px-6 lg:px-8">
        <div className="max-w-full mx-auto bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
          {/* Header */}
          <div className="bg-gradient-to-r from-red-900 to-red-700 px-6 py-4 flex items-center justify-between">
            <h2 className="text-white text-lg font-semibold flex items-center gap-2">
              <Award className="w-5 h-5" />
              Executive Circle Report ({financialYear})
            </h2>
            <button
              onClick={() => navigate("/Dashboard")}
              className="bg-white/15 hover:bg-white/25 text-white rounded-full p-2 transition-all duration-200"
              title="Go back"
              aria-label="Close"
            >
              <X size={18} />
            </button>
          </div>

          {/* Content */}
          <div className="p-6">
            {/* Top Controls */}
            <div className="flex flex-wrap justify-between items-center gap-3 mb-5 pb-4 border-b border-slate-200">
              <div className="flex flex-wrap items-center gap-3 text-sm text-slate-700">
                <button
                  onClick={handleExcel}
                  className="inline-flex items-center gap-1.5 rounded-md bg-emerald-500 px-4 py-2 text-xs font-semibold text-white shadow-sm hover:bg-emerald-600 hover:shadow transition"
                >
                  <FileSpreadsheet size={14} />
                  Excel Export
                </button>

                {/* Financial Year Selector */}
                <select
                  value={financialYear}
                  onChange={(e) => {
                    setFinancialYear(e.target.value);
                    setCurrentPage(1);
                    fetchReportData(e.target.value);
                  }}
                  className="border border-red-700 text-red-700 font-semibold rounded-md px-3 py-2 text-sm bg-white cursor-pointer"
                >
                  {fyOptions.map((fy) => (
                    <option key={fy} value={fy}>
                      {fy}
                    </option>
                  ))}
                </select>

                <span>Show</span>
                <select
                  value={rowsPerPage}
                  onChange={(e) => {
                    setRowsPerPage(Number(e.target.value));
                    setCurrentPage(1);
                  }}
                  className="border border-slate-300 rounded-md px-3 py-2 text-sm bg-white"
                >
                  {[5, 10, 25, 50, 100].map((n) => (
                    <option key={n} value={n}>
                      {n}
                    </option>
                  ))}
                </select>
                <span>entries</span>
              </div>

              <div className="relative">
                <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  value={searchQuery}
                  placeholder="Search records..."
                  onChange={(e) => {
                    setSearchQuery(e.target.value);
                    setCurrentPage(1);
                  }}
                  className="border border-slate-300 rounded-md pl-8 pr-3 py-2 text-sm w-full sm:w-64 focus:outline-none focus:ring-2 focus:ring-red-200 focus:border-red-400 transition"
                />
              </div>
            </div>

            {/* Table */}
            <div className="overflow-x-auto rounded-lg border border-slate-200">
              <table className="w-full text-sm border-collapse min-w-[3500px]">
                <thead className="bg-slate-100">
                  <tr>
                    {[
                      "Sr.No",
                      "Nomination date",
                      "Award Title",
                      "Category",
                      "Year",
                      "Nomination Status",
                      "Nominated By",
                      "Nominee Name 1",
                      "Nominee 1 EmpCode",
                      "Nominee Department 1",
                      "Reason 1",
                      "Nominee Name 2",
                      "Nominee 2 EmpCode",
                      "Nominee Department 2",
                      "Reason 2",
                      "Nominee Name 3",
                      "Nominee 3 EmpCode",
                      "Nominee Department 3",
                      "Reason 3",
                      "Nominee Name 4",
                      "Nominee 4 EmpCode",
                      "Nominee Department 4",
                      "Reason 4",
                    ].map((h) => (
                      <th
                        key={h}
                        className="px-3 py-3 text-left whitespace-nowrap text-xs font-semibold uppercase tracking-wide text-slate-500"
                      >
                        {h}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {loading ? (
                    <tr>
                      <td colSpan={30} className="text-center py-10 text-slate-500">
                        Loading...
                      </td>
                    </tr>
                  ) : paginatedData.length === 0 ? (
                    <tr>
                      <td colSpan={30} className="text-center py-10 text-slate-400">
                        No records found
                      </td>
                    </tr>
                  ) : (
                    paginatedData.map((r, i) => (
                      <tr
                        key={r.nominationId}
                        className="odd:bg-white even:bg-slate-50/70 border-b border-slate-100 hover:bg-red-50/60 transition-colors duration-150"
                      >
                        <td className="px-3 py-3 text-slate-500">
                          {(currentPage - 1) * rowsPerPage + i + 1}
                        </td>
                        <td className="px-3 py-3 text-slate-700">
                          {r.createdAt ? new Date(r.createdAt).toLocaleDateString("en-GB") : "-"}
                        </td>
                        <td className="px-3 py-3 text-slate-700 font-medium">{r.awardTitle || "-"}</td>
                        <td className="px-3 py-3 text-slate-700">{r.category || "-"}</td>
                        <td className="px-3 py-3 text-slate-700">{r.financialYear || "-"}</td>
                        <td className="px-3 py-3">
                          <span className={`inline-flex items-center justify-center rounded-full px-3 py-1 text-[11px] font-semibold uppercase ${
                            r.status === "Approved"
                              ? "bg-emerald-50 text-emerald-700"
                              : "bg-amber-50 text-amber-700"
                          }`}>
                            {r.status || "-"}
                          </span>
                        </td>
                        <td className="px-3 py-3 text-slate-700">{r.submittedByName || "-"}</td>

                        {/* Nominee 1 */}
                        <td className="px-3 py-3 text-slate-700">{r.nominationDetails?.[0]?.nomineeName || "-"}</td>
                        <td className="px-3 py-3 text-slate-700">{r.nominationDetails?.[0]?.nomineeEmployeeCode || "-"}</td>
                        <td className="px-3 py-3 text-slate-700">{r.nominationDetails?.[0]?.department || "-"}</td>
                        <td className="px-3 py-3 text-slate-700">{r.nominationDetails?.[0]?.reasonForNomination || "-"}</td>

                        {/* Nominee 2 */}
                        <td className="px-3 py-3 text-slate-700">{r.nominationDetails?.[1]?.nomineeName || "-"}</td>
                        <td className="px-3 py-3 text-slate-700">{r.nominationDetails?.[1]?.nomineeEmployeeCode || "-"}</td>
                        <td className="px-3 py-3 text-slate-700">{r.nominationDetails?.[1]?.department || "-"}</td>
                        <td className="px-3 py-3 text-slate-700">{r.nominationDetails?.[1]?.reasonForNomination || "-"}</td>

                        {/* Nominee 3 */}
                        <td className="px-3 py-3 text-slate-700">{r.nominationDetails?.[2]?.nomineeName || "-"}</td>
                        <td className="px-3 py-3 text-slate-700">{r.nominationDetails?.[2]?.nomineeEmployeeCode || "-"}</td>
                        <td className="px-3 py-3 text-slate-700">{r.nominationDetails?.[2]?.department || "-"}</td>
                        <td className="px-3 py-3 text-slate-700">{r.nominationDetails?.[2]?.reasonForNomination || "-"}</td>

                        {/* Nominee 4 */}
                        <td className="px-3 py-3 text-slate-700">{r.nominationDetails?.[3]?.nomineeName || "-"}</td>
                        <td className="px-3 py-3 text-slate-700">{r.nominationDetails?.[3]?.nomineeEmployeeCode || "-"}</td>
                        <td className="px-3 py-3 text-slate-700">{r.nominationDetails?.[3]?.department || "-"}</td>
                        <td className="px-3 py-3 text-slate-700">{r.nominationDetails?.[3]?.reasonForNomination || "-"}</td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>

            {/* Pagination */}
            <div className="mt-5 flex flex-col md:flex-row items-center justify-between gap-3 text-sm text-slate-600">
              <span>
                Showing {(currentPage - 1) * rowsPerPage + 1} to{" "}
                {Math.min(currentPage * rowsPerPage, filteredData.length)} of{" "}
                {filteredData.length} entries
              </span>
              <div className="flex flex-wrap items-center gap-2">
                <button
                  onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
                  disabled={currentPage === 1}
                  className="inline-flex items-center gap-1 rounded-md border border-slate-300 bg-white px-3 py-1.5 text-xs transition disabled:opacity-50 disabled:cursor-not-allowed hover:bg-slate-50"
                >
                  <ChevronLeft size={14} />
                  Previous
                </button>
                {Array.from({ length: totalPages }, (_, i) => (
                  <button
                    key={i}
                    onClick={() => setCurrentPage(i + 1)}
                    className={`rounded-md px-3 py-1.5 text-xs transition ${
                      currentPage === i + 1
                        ? "border border-red-700 bg-red-700 text-white font-semibold"
                        : "border border-slate-300 bg-white text-slate-700 hover:bg-slate-50"
                    }`}
                  >
                    {i + 1}
                  </button>
                ))}
                <button
                  onClick={() => setCurrentPage((prev) => Math.min(prev + 1, totalPages))}
                  disabled={currentPage === totalPages || totalPages === 0}
                  className="inline-flex items-center gap-1 rounded-md border border-slate-300 bg-white px-3 py-1.5 text-xs transition disabled:opacity-50 disabled:cursor-not-allowed hover:bg-slate-50"
                >
                  Next
                  <ChevronRight size={14} />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default ExecutiveCircleReport;