import React from "react";
import { useNavigate } from "react-router-dom";
import Header from "../components/Header";

/**
 * A2B ("Above and Beyond") welcome / splash screen.
 *
 * Updated gradient: Blue at top, Maroon at bottom (vice versa of current)
 * Warm gold accents maintained with glitter/sparkle effects
 */
const FLECKS = [
    "absolute rounded-full w-1.5 h-1.5 bg-[#FFD700] opacity-80 top-[12%] left-[6%] motion-safe:animate-pulse [animation-delay:0s]",
    "absolute rounded-full w-1 h-1 bg-[#FFA500] opacity-80 top-[28%] left-[14%] motion-safe:animate-pulse [animation-delay:0.6s]",
    "absolute rounded-full w-2 h-2 bg-[#FFD700] opacity-80 top-[8%] left-[22%] motion-safe:animate-pulse [animation-delay:1.2s]",
    "absolute rounded-full w-1 h-1 bg-[#FF6B35] opacity-80 top-[22%] left-[33%] motion-safe:animate-pulse [animation-delay:1.8s]",
    "absolute rounded-full w-1.5 h-1.5 bg-[#FFD700] opacity-80 top-[5%] left-[41%] motion-safe:animate-pulse [animation-delay:2.4s]",
    "absolute rounded-full w-1 h-1 bg-[#FFA500] opacity-80 top-[18%] left-[52%] motion-safe:animate-pulse [animation-delay:0.3s]",
    "absolute rounded-full w-2 h-2 bg-[#FFD700] opacity-80 top-[9%] left-[63%] motion-safe:animate-pulse [animation-delay:0.9s]",
    "absolute rounded-full w-1 h-1 bg-[#FF6B35] opacity-80 top-[24%] left-[71%] motion-safe:animate-pulse [animation-delay:1.5s]",
    "absolute rounded-full w-1.5 h-1.5 bg-[#FFD700] opacity-80 top-[6%] left-[82%] motion-safe:animate-pulse [animation-delay:2.1s]",
    "absolute rounded-full w-1 h-1 bg-[#FFA500] opacity-80 top-[20%] left-[91%] motion-safe:animate-pulse [animation-delay:0.4s]",
    "absolute rounded-full w-1.5 h-1.5 bg-[#FFA500] opacity-80 top-[82%] left-[8%] motion-safe:animate-pulse [animation-delay:1.1s]",
    "absolute rounded-full w-1 h-1 bg-[#FFD700] opacity-80 top-[90%] left-[18%] motion-safe:animate-pulse [animation-delay:1.7s]",
    "absolute rounded-full w-2 h-2 bg-[#FF6B35] opacity-80 top-[78%] left-[29%] motion-safe:animate-pulse [animation-delay:2.3s]",
    "absolute rounded-full w-1 h-1 bg-[#FFA500] opacity-80 top-[94%] left-[38%] motion-safe:animate-pulse [animation-delay:0.2s]",
    "absolute rounded-full w-1.5 h-1.5 bg-[#FFD700] opacity-80 top-[84%] left-[47%] motion-safe:animate-pulse [animation-delay:0.8s]",
    "absolute rounded-full w-1 h-1 bg-[#FFA500] opacity-80 top-[92%] left-[58%] motion-safe:animate-pulse [animation-delay:1.4s]",
    "absolute rounded-full w-2 h-2 bg-[#FFD700] opacity-80 top-[80%] left-[68%] motion-safe:animate-pulse [animation-delay:2s]",
    "absolute rounded-full w-1 h-1 bg-[#FF6B35] opacity-80 top-[96%] left-[77%] motion-safe:animate-pulse [animation-delay:0.5s]",
    "absolute rounded-full w-1.5 h-1.5 bg-[#FFA500] opacity-80 top-[86%] left-[88%] motion-safe:animate-pulse [animation-delay:1s]",
    "absolute rounded-full w-1 h-1 bg-[#FFD700] opacity-80 top-[76%] left-[96%] motion-safe:animate-pulse [animation-delay:1.6s]",
    // Sparkle dots
    "absolute rounded-full w-0.5 h-0.5 bg-white opacity-90 top-[15%] left-[45%] motion-safe:animate-ping [animation-delay:0.5s]",
    "absolute rounded-full w-0.5 h-0.5 bg-white opacity-90 top-[85%] left-[55%] motion-safe:animate-ping [animation-delay:1.3s]",
    "absolute rounded-full w-1 h-1 bg-white opacity-70 top-[45%] left-[75%] motion-safe:animate-pulse [animation-delay:0.7s]",
    "absolute rounded-full w-0.5 h-0.5 bg-white opacity-90 top-[35%] left-[20%] motion-safe:animate-ping [animation-delay:1.9s]",
    "absolute rounded-full w-1 h-1 bg-white opacity-70 top-[65%] left-[40%] motion-safe:animate-pulse [animation-delay:0.1s]",
];

// Glitter sparkle shapes (star-like)
const SPARKLES = [
    "absolute text-[#FFD700] text-2xl opacity-60 top-[3%] left-[15%] motion-safe:animate-pulse [animation-delay:0.2s]",
    "absolute text-[#FF6B35] text-xl opacity-50 top-[2%] right-[20%] motion-safe:animate-pulse [animation-delay:0.8s]",
    "absolute text-[#FFD700] text-3xl opacity-40 bottom-[5%] left-[25%] motion-safe:animate-pulse [animation-delay:1.4s]",
    "absolute text-[#FFA500] text-xl opacity-50 bottom-[3%] right-[15%] motion-safe:animate-pulse [animation-delay:2s]",
    "absolute text-[#FFD700] text-2xl opacity-30 top-[45%] left-[5%] motion-safe:animate-pulse [animation-delay:0.6s]",
    "absolute text-[#FF6B35] text-2xl opacity-30 top-[40%] right-[4%] motion-safe:animate-pulse [animation-delay:1.6s]",
];

const A2BWelcomeScreen = () => {
    const navigate = useNavigate();

    return (
        <>
            <Header />
            <div className="min-h-screen px-2 py-10 mt-[70px] flex items-center justify-center">
                <div className="w-full max-w-7xl">
                    {/* outer gold frame */}
                    <div className="rounded-[1.4rem] p-[3px] shadow-2xl shadow-black/30 bg-[linear-gradient(135deg,#FF6B35_0%,#FF7559_35%,#FFD700_50%,#FF7559_65%,#FF6B35_100%)]">
                        <div className="relative overflow-hidden rounded-[1.2rem] ring-1 ring-[#FFD700]/40 bg-[linear-gradient(180deg,#1a2a6c_0%,#3a1c47_40%,#7a1b2e_70%,#b91c1c_100%)]">
                            {/* ambient gold flecks */}
                            <div className="pointer-events-none absolute inset-0">
                                {FLECKS.map((cls, i) => (
                                    <span key={i} className={cls} />
                                ))}
                            </div>

                            {/* Sparkle/star shapes */}
                            <div className="pointer-events-none absolute inset-0">
                                {SPARKLES.map((cls, i) => (
                                    <span key={`sparkle-${i}`} className={cls}>
                                        ✦
                                    </span>
                                ))}
                            </div>

                            {/* soft spotlight glow behind the medal */}
                            <div className="pointer-events-none absolute -top-16 -left-16 w-56 h-56 rounded-full bg-[#FFD700]/20 blur-3xl" />
                            <div className="pointer-events-none absolute -bottom-20 -right-20 w-72 h-72 rounded-full bg-[#FF6B35]/15 blur-3xl" />

                            {/* corner flourishes - warm gold */}
                            <span className="pointer-events-none absolute top-3 right-3 w-6 h-6 border-t border-r border-[#FFD700]/60 rounded-tr-md" />
                            <span className="pointer-events-none absolute bottom-3 right-3 w-6 h-6 border-b border-r border-[#FFD700]/60 rounded-br-md" />
                            <span className="pointer-events-none absolute bottom-3 left-3 w-6 h-6 border-b border-l border-[#FFD700]/60 rounded-bl-md" />
                            <span className="pointer-events-none absolute top-3 left-3 w-6 h-6 border-t border-l border-[#FFD700]/60 rounded-tl-md" />

                            {/* medal + ribbon badge */}
                            <div className="relative z-10 flex items-start pt-8 pl-8">
                                <svg width="56" height="72" viewBox="0 0 56 72" fill="none" xmlns="http://www.w3.org/2000/svg" className="shrink-0 drop-shadow-md">
                                    <path d="M14 30L4 66L28 56L52 66L42 30Z" fill="#CC5500" />
                                    <path d="M14 30L4 66L28 56L20 30Z" fill="#FF6B35" />
                                    <path d="M42 30L52 66L28 56L36 30Z" fill="#E85D2C" />
                                    <circle cx="28" cy="26" r="20" fill="#CC5500" />
                                    <circle cx="28" cy="26" r="17" fill="#FF6B35" />
                                    <circle cx="28" cy="26" r="12.5" fill="#FFD700" />
                                    <circle cx="28" cy="26" r="12.5" stroke="#CC5500" strokeWidth="1.2" fill="none" />
                                    <path d="M28 19L29.9 23.6L35 24.1L31.2 27.4L32.4 32.4L28 29.8L23.6 32.4L24.8 27.4L21 24.1L26.1 23.6Z" fill="#CC5500" />
                                </svg>
                                <div className="relative -ml-1 mt-3 pl-6 pr-8 py-2.5 rounded-r-full shadow-lg bg-[linear-gradient(90deg,#E85D2C_0%,#FF6B35_55%,#FFD700_100%)]">
                                    <span className="font-serif text-white text-lg md:text-xl font-semibold tracking-wide drop-shadow-sm">
                                        Above and Beyond (A2B)
                                    </span>
                                    <span className="absolute -right-3 top-1/2 -translate-y-1/2 w-0 h-0 border-t-[18px] border-b-[18px] border-l-[12px] border-t-transparent border-b-transparent border-l-[#E85D2C]" />
                                </div>
                            </div>



                            {/* copy */}
                            <div className="relative z-10 px-6 md:px-16 pt-10 pb-12 text-center">
                                <p className="font-serif italic text-[#FFF5E6] text-lg md:text-xl leading-relaxed max-w-3xl mx-auto drop-shadow-sm">
                                    "Appreciation is a wonderful thing; it makes what is excellent in others belong to us as well."
                                </p>
                                <p className="mt-2 text-[#FFD700] text-sm md:text-base font-bold tracking-wide max-w-3xl mx-auto drop-shadow-sm">
                                    SO IF YOU APPRECIATE SOMEONE, DON'T KEEP IT AS A PRIVATE THOUGHT &ndash; A2B HELPS YOU EXPRESS THAT!
                                </p>

                                <div className="w-16 h-px bg-[#FFD700]/60 mx-auto my-8" />

                                <div className="space-y-6 max-w-3xl mx-auto text-[#FFF5E6] text-[15px] md:text-base leading-relaxed drop-shadow-sm">
                                    <p>
                                        CMS's new A2B program has <span className="text-[#FFD700] font-bold">THREE</span> elements: Instant Appreciation (HATS OFF), Annual &ldquo;Executive Circle&rdquo; Awards (Given during Annual Meet) and Service &ldquo;Honor Club&rdquo; awards (Given out during Founders Day).
                                    </p>
                                    <p>
                                        &ldquo;Hats Off&rdquo; &ndash; is a part of CMS Rewards and Recognition program &ldquo;Above &amp; Beyond&rdquo; (A2B), which will provide a seamless employee recognition solution for CMSites through the Digital Lounge platform. HATS OFF is fully de-centralized and timely.
                                    </p>
                                    <p>
                                        Linking recognition to current rather than past events gets everyone focused on ongoing performance and the company's goals with HATS OFF. Every day is an opportunity to recognize our colleagues, co-workers and managers. The revised program is effective and helps us show immediate appreciation and recognition of individuals or teams for exceptional contributions.
                                    </p>
                                </div>


                                {/* Bottom Buttons */}
                                <div className="absolute bottom-6 left-0 right-0 px-6 md:px-8 flex justify-between items-center z-20">
                                    {/* Back Button */}
                                    <button
                                        onClick={() => navigate(-1)}
                                        className="inline-flex items-center z-20 px-6 py-2 rounded-full
                                         bg-white/10 border border-[#FFD700] text-[#FFD700] font-semibold hover:bg-[#FFD700] hover:text-[#7a1b2e] transition-all duration-300"
                                    >
                                        ← Back
                                    </button>

                                    {/* Enter Button */}
                                    <button
                                        onClick={() => navigate("/rewardsHomePage")}
                                        className="group inline-flex items-center gap-2 px-10 py-3 rounded-full
                                                        bg-gradient-to-r from-[#FF6B35] to-[#FFD700]
                                                        text-white font-bold tracking-wide shadow-lg
                                                        hover:shadow-2xl hover:shadow-[#FF6B35]/50
                                                        transition-all duration-300 hover:scale-105"
                                    >
                                        Enter
                                        <span className="transition-transform duration-300 group-hover:translate-x-1">
                                            &raquo;
                                        </span>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
};

export default A2BWelcomeScreen;