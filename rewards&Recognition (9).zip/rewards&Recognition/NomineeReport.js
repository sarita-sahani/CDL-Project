import { useNavigate, useLocation } from "react-router-dom";
import * as XLSX from "xlsx";
import { saveAs } from "file-saver";
import { useState, useEffect, Fragment } from "react";
import { BASE_URL } from "../config/Config";
import { simpleEncrypt } from "../simpleEncrypt";
import Header from "../components/Header";
import { X, Users, FileSpreadsheet, Search, ChevronLeft, ChevronRight, Eye } from "lucide-react";

const NomineeReport = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { data = [], fromDate = "", toDate = "" } = location.state || {};

  const [searchQuery, setSearchQuery] = useState("");
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [currentPage, setCurrentPage] = useState(1);

  const dmsAccessURL = `${BASE_URL}:9023`;

  const displayData = data.filter((r) =>
    Object.values(r).some((v) =>
      String(v).toLowerCase().includes(searchQuery.toLowerCase())
    )
  );

  const handleExcel = () => {
    const exportData = displayData.map((r) => ({
      "Nomination Date": r.createdDate,
      Category: r.recognitionType,
      "Sub Category": r.categoryName,
      "Nominee Name": r.employeeName,
      "Nominee Department": r.nomineeDepartment,
      "Certificate Type": r.certificateType,
      "Card Type": r.recognitionMode,
      "Nominator Name": r.recognizedByName,
    }));

    const worksheet = XLSX.utils.json_to_sheet(exportData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Nominee Report");

    const excelBuffer = XLSX.write(workbook, { bookType: "xlsx", type: "array" });
    const file = new Blob([excelBuffer], { type: "application/octet-stream" });
    saveAs(file, "NomineeReport.xlsx");
  };

  const totalPages = Math.ceil(displayData.length / rowsPerPage);
  const paginatedData = displayData.slice(
    (currentPage - 1) * rowsPerPage,
    currentPage * rowsPerPage
  );

  useEffect(() => {
    if (currentPage > totalPages) {
      setCurrentPage(totalPages || 1);
    }
  }, [rowsPerPage, displayData, totalPages, currentPage]);

  const openUrl = async (docId) => {
    try {
      const response = await fetch(`${dmsAccessURL}/documents/access`, {
        method: "GET",
        headers: {
          "X-DOC-TOKEN": simpleEncrypt(docId),
        },
      });

      if (!response.ok) {
        throw new Error("Failed to fetch document");
      }

      const blob = await response.blob();
      const fileURL = window.URL.createObjectURL(blob);
      window.open(fileURL, "_blank", "noopener,noreferrer");
      setTimeout(() => {
        window.URL.revokeObjectURL(fileURL);
      }, 1000);
    } catch (error) {
      console.error("Error opening document:", error);
      alert("Unable to open document");
    }
  };

  const formatDate = (str) => {
    if (!str) return "";
    const date = new Date(str);
    const day = String(date.getDate()).padStart(2, "0");
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const year = date.getFullYear();
    return `${day}/${month}/${year}`;
  };

  return (
    <>
      <Header />
      <div className="min-h-screen bg-slate-50 mt-[70px] w-full font-sans pt-6 pb-10 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">

          {/* Header */}
          <div className="bg-gradient-to-r from-red-900 to-red-700 px-6 py-4 flex items-center justify-between">
            <h2 className="text-white text-lg font-semibold flex items-center gap-2">
              <Users className="w-5 h-5" />
              Nominee Report (Employee)
            </h2>
            <button
              onClick={() => navigate("/rrReport")}
              className="bg-white/15 hover:bg-white/25 text-white rounded-full p-2 transition-all duration-200"
              title="Go back"
              aria-label="Close"
            >
              <X size={18} />
            </button>
          </div>

          {/* Content */}
          <div className="p-6">
            {/* Toolbar */}
            <div className="flex flex-wrap justify-between items-center gap-3 mb-5 pb-4 border-b border-slate-200">
              {/* Left side */}
              <div className="flex flex-wrap items-center gap-3 text-sm text-slate-700">
                <button
                  onClick={handleExcel}
                  className="inline-flex items-center gap-1.5 rounded-md bg-emerald-500 px-4 py-2 text-xs font-semibold text-white shadow-sm hover:bg-emerald-600 hover:shadow transition"
                >
                  <FileSpreadsheet size={14} />
                  Excel Export
                </button>
                <span>Show</span>
                <select
                  value={rowsPerPage}
                  onChange={(e) => {
                    setRowsPerPage(Number(e.target.value));
                    setCurrentPage(1);
                  }}
                  className="border border-slate-300 rounded-md px-3 py-2 text-sm bg-white"
                >
                  {[5, 10, 25, 50, 100].map((n) => (
                    <option key={n} value={n}>
                      {n}
                    </option>
                  ))}
                </select>
                <span>entries</span>
              </div>

              {/* Right side */}
              <div className="relative">
                <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  value={searchQuery}
                  placeholder="Search records..."
                  onChange={(e) => {
                    setSearchQuery(e.target.value);
                    setCurrentPage(1);
                  }}
                  className="border border-slate-300 rounded-md pl-8 pr-3 py-2 text-sm w-full sm:w-64 focus:outline-none focus:ring-2 focus:ring-red-200 focus:border-red-400 transition"
                />
              </div>
            </div>

            {/* Table */}
            <div className="overflow-x-auto rounded-lg border border-slate-200">
              <table className="w-full text-sm border-collapse">
                <thead className="bg-slate-100">
                  <tr>
                    {[
                      "Sr.No",
                      "Nomination Date",
                      "Category",
                      "Sub Category",
                      "Nominee Name",
                      "Nominee Department",
                      "Certificate Type",
                      "Card Type",
                      "Nominator Name",
                      "View",
                    ].map((h) => (
                      <th
                        key={h}
                        className="px-3 py-3 text-left font-semibold text-xs uppercase tracking-wide text-slate-500 whitespace-nowrap"
                      >
                        {h}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {paginatedData.length === 0 ? (
                    <tr>
                      <td
                        colSpan={10}
                        className="text-center text-slate-400 py-10"
                      >
                        No records found
                      </td>
                    </tr>
                  ) : (
                    paginatedData.map((r, i) => (
                      <tr
                        key={i}
                        className="odd:bg-white even:bg-slate-50/70 border-b border-slate-100 hover:bg-red-50/60 transition-colors duration-150"
                      >
                        <td className="px-3 py-3 text-slate-500">
                          {(currentPage - 1) * rowsPerPage + i + 1}
                        </td>
                        <td className="px-3 py-3 text-slate-700">{formatDate(r.createdDate)}</td>
                        <td className="px-3 py-3 text-slate-700">{r.recognitionType}</td>
                        <td className="px-3 py-3 text-slate-700">{r.categoryName}</td>
                        <td className="px-3 py-3 text-slate-700 font-medium">{r.employeeName}</td>
                        <td className="px-3 py-3 text-slate-700">{r.nomineeDepartment}</td>
                        <td className="px-3 py-3 text-slate-700">{r.certificateType || "—"}</td>
                        <td className="px-3 py-3 text-slate-700">{r.recognitionMode}</td>
                        <td className="px-3 py-3 text-slate-700">{r.recognizedByName}</td>
                        <td className="px-3 py-3">
                          <button
                            onClick={() => openUrl(r.docId)}
                            className="inline-flex items-center gap-1 text-red-700 hover:text-red-800 font-semibold text-xs"
                          >
                            <Eye size={13} />
                            View
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>

            {/* Pagination */}
            <div className="mt-5 flex flex-col md:flex-row items-center justify-between gap-3 text-sm text-slate-600">
              <span>
                Showing {(currentPage - 1) * rowsPerPage + 1} to{" "}
                {Math.min(currentPage * rowsPerPage, displayData.length)} of{" "}
                {displayData.length} entries
              </span>
              <div className="flex flex-wrap items-center gap-2">
                <button
                  onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
                  disabled={currentPage === 1}
                  className="inline-flex items-center gap-1 rounded-md border border-slate-300 bg-white px-3 py-1.5 text-xs transition disabled:opacity-50 disabled:cursor-not-allowed hover:bg-slate-50"
                >
                  <ChevronLeft size={14} />
                  Previous
                </button>

                {Array.from({ length: totalPages }, (_, i) => (
                  <button
                    key={i}
                    onClick={() => setCurrentPage(i + 1)}
                    className={`rounded-md px-3 py-1.5 text-xs transition ${
                      currentPage === i + 1
                        ? "border border-red-700 bg-red-700 text-white font-semibold"
                        : "border border-slate-300 bg-white text-slate-700 hover:bg-slate-50"
                    }`}
                  >
                    {i + 1}
                  </button>
                ))}

                <button
                  onClick={() =>
                    setCurrentPage((prev) => Math.min(prev + 1, totalPages))
                  }
                  disabled={currentPage === totalPages || totalPages === 0}
                  className="inline-flex items-center gap-1 rounded-md border border-slate-300 bg-white px-3 py-1.5 text-xs transition disabled:opacity-50 disabled:cursor-not-allowed hover:bg-slate-50"
                >
                  Next
                  <ChevronRight size={14} />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default NomineeReport;