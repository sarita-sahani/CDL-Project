import axios from "axios";

const SCHOLARSHIP_BASE_API = "http://localhost:9035/api/scholarship";

// ─── Utility: convert File → base64 string ────────────────────────────────────
const toBase64 = (file) =>
  new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result.split(",")[1]); // strip "data:*/*;base64,"
    reader.onerror = reject;
  });

const ScholarshipApi = {

  saveScholarship: async (payload) => {
    const { empInfo, children, classType, awardYear } = payload;

    // ─── Convert each child's files to base64 ──────────────────────────────
    const convertedChildren = await Promise.all(
      children.map(async (child) => {
        const converted = {
          title:           child.title,
          studentName:     child.studentName,
          academicYear:    child.academicYear,
          marksPercentage: child.marksPercentage,
          percentile:      child.percentile,
          rankObtained:    child.rankObtained || null,
          schoolName:      child.schoolName,
          photoFile:           null,
          photoFileName:       null,
          certificateFile:     null,
          certificateFileName: null,
        };

        if (child.photoFile) {
          converted.photoFile     = await toBase64(child.photoFile);
          converted.photoFileName = child.photoFile.name;
        }

        if (child.certFile) {
          converted.certificateFile     = await toBase64(child.certFile);
          converted.certificateFileName = child.certFile.name;
        }

        return converted;
      })
    );

    // ─── Build pure JSON payload ────────────────────────────────────────────
    const jsonPayload = {
      ...empInfo,
      awardYear,
      scholarshipType: classType,
      children: convertedChildren,
    };

    // ─── Send as application/json — bypasses Nginx multipart size limit ─────
    return axios.post(
      `${SCHOLARSHIP_BASE_API}/saveScholarshipdata`,
      jsonPayload,
      {
        headers: {
          "Content-Type": "application/json",
        },
      }
    );
  },

  getByYear: async (awardYear) => {
    return axios.get(`${SCHOLARSHIP_BASE_API}/year/${awardYear}`);
  },

  getByType: async (scholarshipType) => {
    return axios.get(`${SCHOLARSHIP_BASE_API}/type/${scholarshipType}`);
  },

  getByYearAndType: async (awardYear, scholarshipType) => {
    return axios.get(`${SCHOLARSHIP_BASE_API}/filter`, {
      params: { awardYear, scholarshipType },
    });
  },
};

export default ScholarshipApi;