import React, { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../../components/Header';
import RnRService from '../RnRService';
import { fetchCurrentFinancialYear } from '../ExecutiveCircle/ExecuitiveCircleApi';
import { X } from 'lucide-react';
import ScholarshipApi from "./ScholarshipApi";

const TITLES = ['Mr.', 'Ms.', 'Master', 'Miss', 'Dr.'];

// ─── Helper: generate academic year options based on awardYear ──────────────
const getAcademicYearOptions = (awardYear) => {
  if (!awardYear) return [];
  const parts = awardYear.split('-');
  const start = parseInt(parts[0]);
  if (isNaN(start)) return [];
  const options = [];
  for (let i = 0; i < 3; i++) {
    const yearStart = start - i;
    const yearEnd = yearStart + 1;
    options.push(`${yearStart}-${String(yearEnd).slice(-2)}`);
  }
  return options;
};

// ─── blank factory ───────────────────────────────────────────────────────────
const blankChild = (awardYear = '') => ({
  _id: Math.random(),
  title: 'Mr.',
  studentName: '',
  academicYear: awardYear,
  marksPercentage: '',
  percentile: '',
  schoolName: '',
  photoFile: null,
  photoPreview: null,
  certFile: null,
  certName: '',
});

// ─── Shared components ────────────────────────────────────────────────────────
const Label = ({ children }) => (
  <label className="block text-xs font-semibold text-gray-600 mb-1">{children}</label>
);

const Input = ({ className = '', ...props }) => (
  <input
    {...props}
    className={`w-full border border-gray-300 rounded-lg px-3 py-2 text-sm
      focus:outline-none focus:ring-1 focus:ring-red-800 focus:border-red-800
      ${props.readOnly ? 'bg-gray-50 text-gray-500 cursor-default' : 'bg-white'}
      ${className}`}
  />
);

const Select = ({ children, ...props }) => (
  <select
    {...props}
    className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm bg-white
      focus:outline-none focus:ring-1 focus:ring-red-800 focus:border-red-800"
  >
    {children}
  </select>
);

const EmpDropdown = ({ list, onSelect }) => (
  <ul className="absolute top-full left-0 right-0 z-50 bg-white border border-gray-200
    rounded-lg shadow-lg mt-1 max-h-48 overflow-y-auto list-none p-0 m-0">
    {list.map(emp => (
      <li
        key={emp.empCode}
        onMouseDown={e => e.preventDefault()}
        onClick={() => onSelect(emp)}
        className="px-3 py-2 hover:bg-red-50 cursor-pointer border-b border-gray-100 last:border-0"
      >
        <div className="font-semibold text-sm text-gray-800">{emp.employeeName}</div>
        <div className="text-xs text-gray-400 mt-0.5">
          {emp.empCode}{emp.department ? ` · ${emp.department}` : ''}
        </div>
      </li>
    ))}
  </ul>
);

// ─── Landing Screen ───────────────────────────────────────────────────────────
function LandingScreen({ onNavigate, awardYear }) {
  const navigate = useNavigate();
  const tiles = [
    { key: 'scholar-10', label: 'Class 10 Scholarship', sub: "Submit child's Class 10 board result", icon: '📚', color: 'bg-gradient-to-br from-[#270e85] to-[#3a1c47]' },
    { key: 'scholar-12', label: 'Class 12 Scholarship', sub: "Submit child's Class 12 board result", icon: '🎓', color: 'bg-gradient-to-br from-[#8B1A1A] to-[#b91c1c]' },
  ];

  return (
    <div>
      <div className=" bg-gradient-to-b from-red-900 to-red-700 text-white text-lg font-bold px-5 py-3 shadow-md flex justify-between items-center mt-16 pt-4">
        <span>🏆 Scholarship Award {awardYear}</span>
        
        <button onClick={() => navigate("/scholarshipsList")} className="bg-white/20 hover:bg-white/30 text-white rounded-full p-2 transition-all duration-200 backdrop-blur-sm" title="Back" aria-label="Close">
                                <X size={18} />
                            </button>
      </div>

      <div className="bg-white rounded-xl shadow-lg overflow-hidden border border-gray-100 mt-6">
        <div className="bg-gray-50 border-b border-gray-100 px-6 py-3">
          <h2 className="text-md font-bold text-gray-700">Apply for Scholarship</h2>
          <p className="text-xs text-gray-500 mt-0.5">Choose the appropriate category below</p>
        </div>
        <div className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {tiles.map(t => (
              <button
                key={t.key}
                onClick={() => onNavigate(t.key)}
                className={`${t.color} text-white rounded-xl p-6 hover:scale-[1.02] transition-all duration-200 shadow-md hover:shadow-xl border-0 cursor-pointer text-left`}
              >
                <div className="text-3xl mb-3">{t.icon}</div>
                <div className="font-bold text-lg mb-1">{t.label}</div>
                <div className="text-xs opacity-80 mb-3">{t.sub}</div>
                <div className="text-xs font-medium inline-block border-b border-white/40 pb-0.5">
                  Continue →
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Scholarship Form ─────────────────────────────────────────────────────────
function ScholarshipForm({ classType, onBack, onSubmit, awardYear }) {
  const navigate = useNavigate();
  const classLabel = classType === '10' ? 'Class 10' : 'Class 12';
  const academicYearOptions = getAcademicYearOptions(awardYear);

  const [empSearchTerm, setEmpSearchTerm] = useState('');
  const [empList,       setEmpList]       = useState([]);
  const [empLoading,    setEmpLoading]    = useState(false);
  const [selectedEmp,   setSelectedEmp]   = useState(null);
  const [empInfo,       setEmpInfo]       = useState({
    empCode: '', employeeName: '', department: '', subDepartment: '',
    location: '', project: '', r1ECode: '', r1Name: '', buHeadName: '',
  });
  const empDebounce = useRef(null);

  const [children, setChildren] = useState([blankChild(awardYear)]);
  const [saving,   setSaving]   = useState(false);

  const searchEmployees = async (searchValue) => {
    setEmpLoading(true);
    try {
      const res  = await RnRService.searchEmployee(searchValue);
      const data = res.data || [];
      const mapped = data.map(item => ({
        empCode:       item.empResDTO?.empCode,
        employeeName:  item.empResDTO?.fullNameAsAadhaar ||
                       `${item.empResDTO?.firstName} ${item.empResDTO?.lastName}`.trim() ||
                       item.empResDTO?.emailId,
        employeeEmail: item.empResDTO?.emailId,
        department:    item.empResDTO?.mainDeptResDTO?.mainDepartment,
        subDepartment: item.empResDTO?.subDeptResDTO?.subDept       || '',
        designation:   item.empResDTO?.designationResDTO?.designationName,
        location:      item.empResDTO?.locationResDTO?.locationName  || '',
        project:       item.empResDTO?.projectResDTO?.projectName    || '',
        r1ECode:       item.empResDTO?.reportTo                      || '',
        r1Name:        item.empResDTO?.reportingManager              || '',
        buHeadName:    item.empResDTO?.buHeadName                    || '',
      }));
      setEmpList(mapped);
    } catch (err) {
      console.error('Error searching employees', err);
      setEmpList([]);
    } finally { setEmpLoading(false); }
  };

  const handleEmpSearchChange = (e) => {
    const val = e.target.value;
    setEmpSearchTerm(val);
    setSelectedEmp(null);
    setEmpInfo({ empCode: '', employeeName: '', department: '', subDepartment: '',
                 location: '', project: '', r1ECode: '', r1Name: '', buHeadName: '' });
    if (val.trim().length < 2) { setEmpList([]); return; }
    if (empDebounce.current) clearTimeout(empDebounce.current);
    empDebounce.current = setTimeout(() => searchEmployees(val), 300);
  };

  const handleEmpSelect = (emp) => {
    setSelectedEmp(emp);
    setEmpSearchTerm(emp.employeeName || '');
    setEmpList([]);
    setEmpInfo({
      empCode:       emp.empCode       || '',
      employeeName:  emp.employeeName  || '',
      department:    emp.department    || '',
      subDepartment: emp.subDepartment || '',
      location:      emp.location      || '',
      project:       emp.project       || '',
      r1ECode:       emp.r1ECode       || '',
      r1Name:        emp.r1Name        || '',
      buHeadName:    emp.buHeadName    || '',
    });
  };

  const updateChild = (i, field, value) =>
    setChildren(prev => prev.map((c, idx) => idx === i ? { ...c, [field]: value } : c));

  const addChild    = () => setChildren(prev => [...prev, blankChild(awardYear)]);
  const removeChild = (i) => setChildren(prev => prev.filter((_, idx) => idx !== i));

  const handlePhotoChange = (e, i) => {
    const file = e.target.files?.[0]; if (!file) return;
    updateChild(i, 'photoFile', file);
    const r = new FileReader();
    r.onload = ev => updateChild(i, 'photoPreview', ev.target.result);
    r.readAsDataURL(file);
  };

  const handleCertChange = (e, i) => {
    const file = e.target.files?.[0]; if (!file) return;
    updateChild(i, 'certFile', file);
    updateChild(i, 'certName', file.name);
  };

  const resetEmp = () => {
    setEmpSearchTerm(''); setSelectedEmp(null); setEmpList([]);
    setEmpInfo({ empCode: '', employeeName: '', department: '', subDepartment: '',
                 location: '', project: '', r1ECode: '', r1Name: '', buHeadName: '' });
  };

  const handleSubmit = async () => {
    if (!empInfo.empCode) { alert('Please search and select an employee.'); return; }
    const valid = children.filter(c => c.studentName.trim());
    if (!valid.length) { alert('Add at least one student record.'); return; }
    setSaving(true);
    try {
      await onSubmit({
        empInfo,
        children: valid,
        classType: classType === '10' ? 'CLASS_10' : 'CLASS_12',
        awardYear,
      });
      resetEmp();
      setChildren([blankChild(awardYear)]);
    } finally { setSaving(false); }
  };

  return (
    <div>
      <div className="  bg-gradient-to-b from-red-900 to-red-700 text-white text-sm font-bold px-5 py-3 shadow-md flex justify-between items-center mt-16 pt-4">
        <div className="flex items-center gap-4">
          <span>Scholarship Award {awardYear} — {classLabel}</span>
        </div>
        <button
          onClick={() => navigate(-1)}
          className="bg-white/20 hover:bg-white/30 text-white rounded-full p-2 transition-all duration-200 backdrop-blur-sm"
          aria-label="Close"
          title="Close"
        >
          <X size={18} />
        </button>
      </div>

      {/* Employee Details */}
      <div className="bg-white rounded-xl shadow-lg border border-gray-100 mt-6 overflow-hidden">
        <div className="bg-gray-50 border-b border-gray-100 px-5 py-3">
          <h3 className="text-sm font-bold text-gray-700">Employee Details</h3>
        </div>
        <div className="p-5">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
            <div className="md:col-span-2">
              <Label>Employee Name *</Label>
              <div className="relative">
                <Input
                  type="text"
                  autoComplete="off"
                  value={empSearchTerm}
                  onChange={handleEmpSearchChange}
                  placeholder="Type name or code..."
                />
                {empLoading && (
                  <span className="absolute right-2 top-1/2 -translate-y-1/2 text-xs text-gray-400">
                    Searching...
                  </span>
                )}
                {empList.length > 0 && (
                  <EmpDropdown list={empList} onSelect={handleEmpSelect} />
                )}
              </div>
              {selectedEmp && (
                <p className="text-xs text-gray-400 mt-1">Code: {selectedEmp.empCode}</p>
              )}
            </div>
            <div>
              <Label>Department</Label>
              <Input value={empInfo.department} readOnly placeholder="Auto-filled" />
            </div>
          </div>

          {empInfo.empCode && (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 bg-gray-50 rounded-lg p-4 mt-2 border border-gray-100">
              {[
                ['Emp Code',    empInfo.empCode],
                ['Sub-Dept',    empInfo.subDepartment],
                ['Location',    empInfo.location],
                ['Project',     empInfo.project],
                ['R1 Emp Code', empInfo.r1ECode],
                ['R1 Name',     empInfo.r1Name],
                ['BU Head',     empInfo.buHeadName],
              ].map(([lbl, val]) => (
                <div key={lbl}>
                  <div className="text-[10px] font-bold text-gray-400 uppercase tracking-wide mb-0.5">{lbl}</div>
                  <div className="text-sm font-medium text-gray-700">{val || '—'}</div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Children Records */}
      <div className="bg-white rounded-xl shadow-lg border border-gray-100 mt-6 overflow-hidden">
        <div className="bg-gray-50 border-b border-gray-100 px-5 py-3 flex justify-between items-center">
          <h3 className="text-sm font-bold text-gray-700">Student / Child Records — {classLabel}</h3>
          <button
            onClick={addChild}
            className="text-xs bg-red-900 text-white px-3 py-1.5 rounded-lg hover:bg-red-800 transition-colors font-semibold shadow-sm"
          >
            + Add Child
          </button>
        </div>

        <div className="p-5 space-y-5">
          {children.map((child, i) => (
            <div key={child._id} className="border border-gray-200 rounded-xl p-5 bg-gray-50/50 shadow-sm">
              <div className="flex justify-between items-center mb-4">
                <div className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded-full bg-red-900 text-white text-xs font-bold flex items-center justify-center">
                    {i + 1}
                  </span>
                  <span className="text-xs font-semibold text-gray-600">Student Record</span>
                </div>
                {children.length > 1 && (
                  <button
                    onClick={() => removeChild(i)}
                    className="text-xs text-gray-400 border border-gray-300 px-2 py-0.5 rounded hover:text-red-600 hover:border-red-300 transition-colors"
                  >
                    Remove
                  </button>
                )}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
                <div>
                  <Label>Title *</Label>
                  <Select value={child.title} onChange={e => updateChild(i, 'title', e.target.value)}>
                    {TITLES.map(t => <option key={t}>{t}</option>)}
                  </Select>
                </div>
                <div className="md:col-span-2">
                  <Label>Student's Name *</Label>
                  <Input
                    value={child.studentName}
                    onChange={e => updateChild(i, 'studentName', e.target.value)}
                    placeholder="Full name of student"
                  />
                </div>
                <div>
                  <Label>Class</Label>
                  <Input value={classLabel} readOnly />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
                <div>
                  <Label>Academic Year</Label>
                  <Select
                    value={child.academicYear}
                    onChange={e => updateChild(i, 'academicYear', e.target.value)}
                  >
                    {academicYearOptions.map(year => (
                      <option key={year} value={year}>{year}</option>
                    ))}
                  </Select>
                </div>
                <div>
                  <Label>Marks</Label>
                  <Input
                    type="number" step=".01" min="0" max="100"
                    value={child.marksPercentage}
                    onChange={e => updateChild(i, 'marksPercentage', e.target.value)}
                    placeholder="e.g. 95.4"
                  />
                </div>
                <div>
                  <Label>Percentile</Label>
                  <Input
                    type="number" step=".01" min="0" max="100"
                    value={child.percentile}
                    onChange={e => updateChild(i, 'percentile', e.target.value)}
                    placeholder="e.g. 99.2"
                  />
                </div>
              </div>

              <div className="mb-4">
                <Label>School / College Name</Label>
                <Input
                  value={child.schoolName}
                  onChange={e => updateChild(i, 'schoolName', e.target.value)}
                  placeholder="Name of the institution"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Photo Upload */}
                <div>
                  <Label>Student's Photograph *</Label>
                  <div
                    className="border-2 border-dashed border-gray-300 rounded-lg p-3 text-center cursor-pointer hover:border-red-700 hover:bg-red-50 transition-colors"
                    onClick={() => document.getElementById(`photo-${child._id}`).click()}
                  >
                    <input
                      id={`photo-${child._id}`}
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={e => handlePhotoChange(e, i)}
                    />
                    {child.photoPreview ? (
                      <img src={child.photoPreview} alt="preview" className="h-14 max-w-full mx-auto object-cover rounded" />
                    ) : (
                      <div className="text-gray-400 text-xs">
                        <div className="text-xl mb-1">📷</div>
                        <span className="font-semibold text-gray-600">Choose File</span>
                        <br />
                        <span className="text-gray-400">{child.photoFile ? child.photoFile.name : 'No file chosen'}</span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Certificate Upload */}
                <div>
                  <Label>Final Marksheet / Certificate *</Label>
                  <div
                    className="border-2 border-dashed border-gray-300 rounded-lg p-3 text-center cursor-pointer hover:border-red-700 hover:bg-red-50 transition-colors"
                    onClick={() => document.getElementById(`cert-${child._id}`).click()}
                  >
                    <input
                      id={`cert-${child._id}`}
                      type="file"
                      accept=".pdf,image/*"
                      className="hidden"
                      onChange={e => handleCertChange(e, i)}
                    />
                    <div className="text-gray-400 text-xs">
                      <div className="text-xl mb-1">📄</div>
                      <span className="font-semibold text-gray-600">Choose File</span>
                      <br />
                      <span className="text-gray-400">{child.certName || 'No file chosen'}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="px-5 pb-5 flex justify-end gap-3 bg-gray-50 border-t border-gray-100 pt-4">
          <button
            onClick={() => { resetEmp(); setChildren([blankChild(awardYear)]); }}
            className="text-sm border border-gray-300 text-gray-600 px-4 py-1.5 rounded-lg hover:bg-gray-100 transition-colors"
          >
            Reset
          </button>
          <button
            onClick={handleSubmit}
            disabled={saving}
            className="text-sm bg-red-900 text-white px-6 py-1.5 rounded-lg font-semibold hover:bg-red-800 disabled:opacity-50 transition-colors shadow-sm"
          >
            {saving ? 'Submitting...' : 'Submit Application'}
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── ROOT ─────────────────────────────────────────────────────────────────────
const AddScholarship = ({ onScholarshipSubmit }) => {
  const [screen,      setScreen]      = useState('home');
  const [awardYear,   setAwardYear]   = useState('');
  const [loadingYear, setLoadingYear] = useState(true);

  useEffect(() => {
    const loadFinancialYear = async () => {
      try {
        const response = await fetchCurrentFinancialYear();
        const yearLabel = response?.label || response?.financialYear;
        setAwardYear(yearLabel);
      } catch (error) {
        console.error('Error fetching financial year:', error);
      } finally {
        setLoadingYear(false);
      }
    };
    loadFinancialYear();
  }, []);

  // ─── Pure JSON submit — files converted to base64 inside ScholarshipApi ───
  const handleScholarshipSubmit = async (payload) => {
    try {
      await ScholarshipApi.saveScholarship(payload);
      if (onScholarshipSubmit) await onScholarshipSubmit(payload);
      alert('Scholarship submitted successfully!');
      setScreen('home');
    } catch (error) {
      console.error('Error submitting scholarship:', error);
      alert('Failed to submit scholarship. Please try again.');
    }
  };

  if (loadingYear) {
    return (
      <div className="min-h-screen bg-gray-100 flex flex-col">
        <Header />
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center">Loading financial year...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col">
      <Header />
      <div className="flex-1 pt-4 px-6">
        {screen === 'home'       && <LandingScreen onNavigate={setScreen} awardYear={awardYear} />}
        {screen === 'scholar-10' && <ScholarshipForm classType="10" onBack={() => setScreen('home')} onSubmit={handleScholarshipSubmit} awardYear={awardYear} />}
        {screen === 'scholar-12' && <ScholarshipForm classType="12" onBack={() => setScreen('home')} onSubmit={handleScholarshipSubmit} awardYear={awardYear} />}
      </div>
    </div>
  );
};

export default AddScholarship;