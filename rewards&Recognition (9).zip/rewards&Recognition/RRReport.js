import { useState } from "react";
import { useNavigate } from "react-router-dom";
import Header from "../components/Header";
import { X, ClipboardList } from "lucide-react";

const reports = [
  {
    id: "user",
    label: "User Report",
    desc: "View all user nominations",
    badge: "USER",
    route: "/userReports",
    state: {},
    iconBg: "bg-indigo-200 text-indigo-700",
    badgeClass: "bg-indigo-200 text-indigo-800",
    btnClass:
      "bg-indigo-50 border border-indigo-200 hover:bg-indigo-100 hover:border-indigo-400 text-indigo-900",
    icon: (
      <svg width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
        <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" />
        <circle cx="12" cy="7" r="4" />
      </svg>
    ),
  },
  // {
  //   id: "admin",
  //   label: "Admin Report",
  //   desc: "View all admin nominations",
  //   badge: "ADMIN",
  //   route: "/adminReport",
  //   state: {},
  //   iconBg: "bg-violet-200 text-violet-700",
  //   badgeClass: "bg-violet-200 text-violet-800",
  //   btnClass:
  //     "bg-violet-50 border border-violet-200 hover:bg-violet-100 hover:border-violet-400 text-violet-900",
  //   icon: (
  //     <svg width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
  //       <path d="M12 2l3 7h7l-5.5 4 2 7L12 17l-6.5 3 2-7L2 9h7z" />
  //     </svg>
  //   ),
  // },
  // {
  //   id: "r1manager",
  //   label: "R1 / Manager Report",
  //   desc: "View all manager nominations",
  //   badge: "R1/MGR",
  //   route: "/nomineeReport",
  //   state: { type: "manager" },
  //   iconBg: "bg-emerald-200 text-emerald-700",
  //   badgeClass: "bg-emerald-200 text-emerald-800",
  //   btnClass:
  //     "bg-emerald-50 border border-emerald-200 hover:bg-emerald-100 hover:border-emerald-400 text-emerald-900",
  //   icon: (
  //     <svg width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
  //       <rect x="2" y="7" width="20" height="14" rx="2" />
  //       <path d="M16 7V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v2" />
  //       <line x1="12" y1="12" x2="12" y2="16" />
  //       <line x1="10" y1="14" x2="14" y2="14" />
  //     </svg>
  //   ),
  // },
  // {
  //   id: "bu",
  //   label: "BU Report",
  //   desc: "View all business unit nominations",
  //   badge: "BU",
  //   route: "/buReport",
  //   state: {},
  //   iconBg: "bg-amber-200 text-amber-700",
  //   badgeClass: "bg-amber-200 text-amber-800",
  //   btnClass:
  //     "bg-amber-50 border border-amber-200 hover:bg-amber-100 hover:border-amber-400 text-amber-900",
  //   icon: (
  //     <svg width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
  //       <rect x="3" y="3" width="18" height="18" rx="2" />
  //       <path d="M3 9h18M9 21V9" />
  //     </svg>
  //   ),
  // },
  {
    id: "executive",
    label: "Executive Circle Award Report (BU)",
    desc: "View executive circle award nominations",
    badge: "EXEC",
    route: "/executive-circle-report",
    state: {},
    iconBg: "bg-rose-200 text-rose-700",
    badgeClass: "bg-rose-200 text-rose-800",
    btnClass:
      "bg-rose-50 border border-rose-200 hover:bg-rose-100 hover:border-rose-400 text-rose-900",
    icon: (
      <svg width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
        <circle cx="12" cy="8" r="6" />
        <path d="M15.477 12.89L17 22l-5-3-5 3 1.523-9.11" />
      </svg>
    ),
  },
];

const RRReport = () => {
  const navigate = useNavigate();
  const [active, setActive] = useState(null);

  const handleClick = (r) => {
    setActive(r.id);
    navigate(r.route, { state: r.state });
  };

  return (
    <>
      <Header />
      <div className="min-h-screen bg-slate-50 mt-[70px] w-full font-sans pt-6 pb-10 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">

          {/* Top bar */}
          <div className="bg-gradient-to-r from-red-900 to-red-700 px-6 py-4 flex items-center justify-between">
            <h2 className="text-white text-lg font-semibold flex items-center gap-2">
              <ClipboardList className="w-5 h-5" />
              RR Report
            </h2>
            <button
              onClick={() => navigate("/Dashboard")}
              className="bg-white/15 hover:bg-white/25 text-white rounded-full p-2 transition-all duration-200"
              aria-label="Close"
            >
              <X size={18} />
            </button>
          </div>

          {/* Content */}
          <div className="p-6">
            <p className="text-sm text-slate-500 mb-5">
              Choose a report below to view detailed recognition and nomination records.
            </p>

            <div className="flex flex-col gap-3">
              {reports.map((r, i) => (
                <div key={r.id}>
                  <button
                    onClick={() => handleClick(r)}
                    className={`
                      w-full flex items-center gap-3 px-4 py-3.5 rounded-lg
                      transition-all duration-200 cursor-pointer text-left
                      hover:-translate-y-0.5 hover:shadow-md
                      ${r.btnClass}
                      ${active === r.id ? "ring-2 ring-offset-1 ring-current" : ""}
                    `}
                  >
                    {/* Icon */}
                    <div className={`w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0 ${r.iconBg}`}>
                      {r.icon}
                    </div>

                    {/* Text */}
                    <div className="flex-1 min-w-0">
                      <span className="block text-sm font-semibold">{r.label}</span>
                      <span className="block text-xs opacity-55 mt-0.5 font-normal">{r.desc}</span>
                    </div>

                    {/* Badge */}
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full tracking-widest uppercase flex-shrink-0 ${r.badgeClass}`}>
                      {r.badge}
                    </span>

                    {/* Arrow */}
                    <span className="text-lg opacity-30 flex-shrink-0">›</span>
                  </button>

                  {/* Divider between items (not after last) */}
                  {i < reports.length - 1 && (
                    <div className="h-px bg-gray-200 mx-1 mt-3" />
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default RRReport;