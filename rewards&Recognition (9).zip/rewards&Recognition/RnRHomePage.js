import { useNavigate } from "react-router-dom";
import Header from "../components/Header";
import { useEffect } from "react";
import { ArrowLeft, X } from "lucide-react";

const RnRHomePage = () => {
  const navigate = useNavigate();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <>
      <Header />

     <div className="ml-2 relative mt-24">
  {/* Breadcrumb */}
  <div className="ml-8 flex items-center justify-between mb-8">
    <div className="text-sm text-[#777] font-medium">
      <span
        onClick={() => navigate('/Dashboard')}
        className="text-black cursor-pointer hover:underline"
      >
        Home
      </span>
      <span className="mx-1">/</span>
      <span className="text-black">Committee</span>
    </div>

    <button
      onClick={() => navigate("/r-r")}
      className="flex items-center gap-2 text-back bg-white text-[#D93646] border-2 border-[#D93646] hover:bg-[#D93646] hover:text-white px-4 py-2 rounded-full shadow-sm transition-all duration-200 font-medium text-sm mr-8"
    >
      {/* <ArrowLeft size={16} /> */}
       <X size={18} />
      
    </button>

  </div>

        {/* Header Section */}
        <div className="text-center px-4">
          <h1 className="text-2xl md:text-3xl font-bold mb-1 flex items-center justify-center gap-4">
            <span>🥇</span>
            Welcome to Our World of
            <span>🏆</span>
          </h1>
          <h2 className="text-xl md:text-2xl font-medium">
            Rewards & Recognition ABOVE AND BEYOND
          </h2>
          <p className="text-[#555] max-w-3xl mx-auto text-sm mt-2">
            At CMS, we believe recognition fuels motivation, strengthens teamwork and builds a culture where everyone thrives.
          </p>
        </div>

        {/* Cards Section: First card sticky, rest scrollable */}
        <div className="mt-8 mb-10 flex px-8 gap-5 overflow-hidden">

          {/* Sticky First Card */}
          <div
            className="bg-[#ff7559] shadow-xl cursor-pointer hover:scale-105 transition-transform duration-200 flex flex-col justify-between flex-shrink-0 sticky left-0 z-10"
            style={{ width: 220, height: 290, borderRadius: 32 }}
            onClick={() =>
              navigate("/r-r", {
                state: {
                  category: "HATS_OFF",
                  destination: "/rr-category",
                  committee: "Canteen Committee",
                },
              })
            }
          >
            <div className="h-[70%] flex items-center justify-center">
              <img
                src="/RnRImages/HatsOff.png"
                alt="Hats Off"
                className="h-full object-contain"
              />
            </div>
            <div className="flex justify-center items-center pb-4 hover:text-yellow-200">
              <span className="font-bold text-base">🎩 Hats OFF</span>
            </div>
          </div>

          {/* Scrollable remaining cards */}
          <div className="flex gap-5 overflow-x-auto scrollbar-hide pb-2">

            {/* Card 2 */}
            <div
              className="bg-[#d93646] shadow-xl cursor-pointer hover:scale-105 transition-transform duration-200 flex flex-col justify-between flex-shrink-0"
              style={{ width: 220, height: 290, borderRadius: 32 }}
              onClick={() =>
                navigate("/r-r", {
                  state: {
                    category: "EXECUTIVE_CIRCLE",
                    destination: "/executive-circle-list",
                    committee: "HR Committee",
                  },
                })
              }
            >
              <div className="h-[70%] flex items-center justify-center">
                <img
                  src="/RnRImages/ExecutiveCircle.png"
                  alt="Executive Circle"
                  className="h-full object-contain"
                />
              </div>
              <div className="flex justify-center items-center pb-4 hover:text-yellow-200">
                <span className="font-bold text-base">👑 Executive Circle</span>
              </div>
            </div>

            {/* Card 3 */}
            <div
              className="bg-[#FF755A] shadow-xl cursor-pointer hover:scale-105 transition-transform duration-200 flex flex-col justify-between flex-shrink-0"
              style={{ width: 220, height: 290, borderRadius: 32 }}
              onClick={() =>
                navigate("/r-r", {
                  state: {
                    category: "HONOR_CLUB",
                    destination: "/honor-club-list",
                    committee: "Tech Committee",
                  },
                })
              }
            >
              <div className="h-[70%] flex items-center justify-center">
                <img
                  src="/RnRImages/HonorClub.png"
                  alt="Honor Club"
                  className="h-full object-contain"
                />
              </div>
              <div className="flex justify-center items-center pb-4 hover:text-yellow-200">
                <span className="font-bold text-base">🏅 Honor Club</span>
              </div>
            </div>
             {/* Card 4 */}

            <div
               className="bg-[#d93646] shadow-xl cursor-pointer hover:scale-105 transition-transform duration-200 flex flex-col justify-between flex-shrink-0"
              style={{ width: 220, height: 290, borderRadius: 32 }}
              onClick={() =>
                navigate("/scholarshipsList", {
                  state: { committee: "Tech Committee" },
                })
              }
            >
              <div className="h-[70%] flex items-center justify-center">
                <img
                  src="/RnRImages/scholarships.jpg"
                  alt="Scholarships"
                  className="h-full object-contain"
                />
              </div>
              <div className="flex justify-center items-center pb-4 hover:text-yellow-200">
                <span className="font-bold text-base">🎓Scholarships</span>
              </div>
            </div>

            {/* Card 5 */}
            <div
              className="bg-[#FF755A] shadow-xl cursor-pointer hover:scale-105 transition-transform duration-200 flex flex-col justify-between flex-shrink-0"
              style={{ width: 220, height: 290, borderRadius: 32 }}
              onClick={() =>
                navigate("/point-bank-campaign", {
                  state: { committee: "Cultural Committee" },
                })
              }
            >
              <div className="h-[70%] flex items-center justify-center">
                <img
                  src="/RnRImages/PointBankCampaign.png"
                  alt="Point Bank Campaign"
                  className="h-full object-contain"
                />
              </div>
              <div className="flex justify-center items-center pb-4 hover:text-yellow-200">
                <span className="font-bold text-base">💰 Point Bank Campaign</span>
              </div>
            </div>

            {/* Card 6 */}
            <div
              className="bg-[#DC3545] shadow-xl cursor-pointer hover:scale-105 transition-transform duration-200 flex flex-col justify-between flex-shrink-0"
              style={{ width: 220, height: 290, borderRadius: 32 }}
              onClick={() =>
                navigate("/rrReport", {
                  state: { committee: "Innovation Committee" },
                })
              }
            >
              <div className="h-[70%] flex items-center justify-center">
                <img
                  src="/RnRImages/Dashboard.png"
                  alt="Dashboard"
                  className="h-full object-contain"
                />
              </div>
              <div className="flex justify-center items-center pb-4 hover:text-yellow-200">
                <span className="font-bold text-base">📊 Reports</span>
              </div>
            </div>

            {/* Card 7 */}
            <div
              className="bg-[#FFE9F8] shadow-xl cursor-pointer hover:scale-105 transition-transform duration-200 flex flex-col justify-between flex-shrink-0"
              style={{ width: 220, height: 290, borderRadius: 32 }}
              onClick={() =>
                navigate("/recognitionDashboard", {
                  state: { committee: "Management Committee" },
                })
              }
            >
              <div className="flex items-end justify-center h-full pb-5 hover:text-red-700">
                <span className="font-bold text-base">📘 Know More</span>
              </div>
            </div>

          </div>
        </div>

        {/* Footer */}
        <div className="text-center px-6 pb-10">
          <h2 className="text-xl md:text-2xl font-bold mb-3 flex items-center justify-center gap-2">
            🥇 At CMS, great work never goes unnoticed.
          </h2>
          <p className="max-w-4xl mx-auto text-sm text-gray-600 leading-relaxed">
            Above & Beyond (A2B) is our in-house Rewards & Recognition program designed to celebrate the people who make CMS
            exceptional every day. Whether it's delivering outstanding results, delighting our clients, supporting teammates, or living our
            core values — A2B is here to shine the spotlight on you. This program is built to be simple, social and spontaneous. No long
            approvals. No waiting around. Just genuine appreciation from colleagues, managers and leaders who recognize the impact
            you create. Because recognition shouldn't be complicated — it should be fun, fast and meaningful.
          </p>
          <p className="max-w-3xl mx-auto text-sm font-semibold mt-3">
            ✨ Appreciate a colleague &nbsp;&nbsp; 🏆 Celebrate achievements &nbsp;&nbsp; 🎯 Earn points and rewards
          </p>
          <p className="max-w-4xl mx-auto text-sm text-gray-600 mt-2">
            At CMS, we believe recognition fuels motivation, strengthens teamwork and builds a culture where everyone thrives.
          </p>
        </div>
      </div>
    </>
  );
};

export default RnRHomePage;