import React, { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";
import RnRService from "./RnRService";

const HatsOffPage = () => {

  const location = useLocation();
  const employee = location.state;

  const [categories, setCategories] = useState([]);
  const [templates, setTemplates] = useState([]);

  const [formData, setFormData] = useState({
    employeeCode: employee?.code || "",
    employeeName: employee?.name || "",
    categoryId: "",
    templateId: "",
    comment: ""
  });

  // Load categories
  useEffect(() => {
    RnRService.getCategories()
      .then(res => {
        setCategories(res.data);
      })
      .catch(err => {
        console.error("Error loading categories", err);
      });
  }, []);

  // Category change
  const handleCategoryChange = (e) => {

    const categoryId = e.target.value;

    setFormData({
      ...formData,
      categoryId: categoryId,
      templateId: ""
    });

    if (categoryId) {
      RnRService.getTemplates(categoryId)
        .then(res => {
          setTemplates(res.data);
        })
        .catch(err => {
          console.error("Error loading templates", err);
        });
    }
  };

  // Template change
  const handleTemplateChange = (e) => {
    setFormData({
      ...formData,
      templateId: e.target.value
    });
  };

  // Comment change
  const handleCommentChange = (e) => {
    setFormData({
      ...formData,
      comment: e.target.value
    });
  };

  // Submit recognition
  const handleSubmit = () => {

    if (!formData.categoryId || !formData.templateId) {
      alert("Please select category and template");
      return;
    }

    RnRService.submitRecognition(formData)
      .then(() => {
        alert("Recognition submitted successfully!");
      })
      .catch(err => {
        console.error("Error submitting recognition", err);
      });
  };

  return (
    <div className="container">

      <h2>Recognise Employee</h2>

      {/* Employee Info */}
      <div className="employee-info">
        <p><strong>Employee Code:</strong> {formData.employeeCode}</p>
        <p><strong>Employee Name:</strong> {formData.employeeName}</p>
      </div>

      {/* Category */}
      <div>
        <label>Category</label>
        <select
          value={formData.categoryId}
          onChange={handleCategoryChange}
        >
          <option value="">-- Select Category --</option>

          {categories.map(cat => (
            <option key={cat.id} value={cat.id}>
              {cat.categoryName}
            </option>
          ))}

        </select>
      </div>

      {/* Template */}
      <div>
        <label>Template</label>
        <select
          value={formData.templateId}
          onChange={handleTemplateChange}
        >
          <option value="">-- Select Template --</option>

          {templates.map(temp => (
            <option key={temp.id} value={temp.id}>
              {temp.templateName}
            </option>
          ))}

        </select>
      </div>

      {/* Comment */}
      <div>
        <label>Comment</label>

        <textarea
          placeholder="Enter appreciation message"
          value={formData.comment}
          onChange={handleCommentChange}
          rows="4"
        />
      </div>

      {/* Submit */}
      <div style={{ marginTop: "20px" }}>
        <button onClick={handleSubmit}>
          Submit Recognition
        </button>
      </div>

    </div>
  );
};

export default HatsOffPage;