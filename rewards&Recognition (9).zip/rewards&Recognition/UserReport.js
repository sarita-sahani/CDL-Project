import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import Header from "../components/Header";
import { X, Calendar, Search, ArrowRight } from "lucide-react";

const UserReport = () => {
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [allData, setData] = useState([]);
  const [tableData, setTableData] = useState(allData);

  const parseDate = (str) => {
    if (!str) return null;
    return new Date(str);
  };

  const navigate = useNavigate();

  const handleOkay = () => {
    let filtered = allData.filter((r) => {
      if (!fromDate && !toDate) return true;
      const d = parseDate(r.createdDate);
      let pass = true;
      if (fromDate) pass = pass && d >= parseDate(fromDate);
      if (toDate) pass = pass && d <= parseDate(toDate);
      return pass;
    });
    navigate("/nomineeReport", { state: { data: filtered, fromDate, toDate } });
  };

  useEffect(() => {
    fetch("http://localhost:9035/api/recognition/getAllRecognitions")
      .then((res) => res.json())
      .then((result) => {
        const combinedData = Object.values(result).flat();
        setData(combinedData);
      });
  }, []);

  return (
    <>
      <Header />
      <div className="min-h-screen bg-slate-50 mt-[70px] w-full font-sans pt-6 pb-10 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
          {/* Top bar */}
          <div className="bg-gradient-to-r from-red-900 to-red-700 px-6 py-4 flex items-center justify-between">
            <h2 className="text-white text-lg font-semibold flex items-center gap-2">
              <Calendar className="w-5 h-5" />
              User Report
            </h2>
            <button
              onClick={() => navigate("/rrReport")}
              className="bg-white/15 hover:bg-white/25 text-white rounded-full p-2 transition-all duration-200"
              aria-label="Close"
            >
              <X size={18} />
            </button>
          </div>

          <div className="p-6">
            {/* Filter card */}
            <div className="bg-slate-100 border border-slate-200 rounded-xl p-5 mb-6">
              <div className="flex flex-col lg:flex-row lg:items-end gap-4">
                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-semibold uppercase tracking-wide text-slate-500">From Date</label>
                  <input
                    type="date"
                    value={fromDate}
                    onChange={(e) => setFromDate(e.target.value)}
                    className="border border-slate-300 rounded-md px-3 py-2 text-sm w-full sm:w-40 bg-white focus:outline-none focus:ring-2 focus:ring-red-200 focus:border-red-400 transition"
                  />
                </div>

                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-semibold uppercase tracking-wide text-slate-500">To Date</label>
                  <input
                    type="date"
                    value={toDate}
                    onChange={(e) => setToDate(e.target.value)}
                    className="border border-slate-300 rounded-md px-3 py-2 text-sm w-full sm:w-40 bg-white focus:outline-none focus:ring-2 focus:ring-red-200 focus:border-red-400 transition"
                  />
                </div>

                <button
                  onClick={handleOkay}
                  className="inline-flex items-center justify-center gap-2 rounded-md bg-red-700 px-5 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-red-800 hover:shadow transition"
                >
                  <Search size={15} />
                  View Report
                </button>

                <span className="lg:ml-auto flex items-center gap-1.5 text-xs font-medium text-slate-500 italic">
                  <ArrowRight size={12} className="text-red-600 shrink-0" />
                  Select a date range and click <span className="not-italic font-semibold text-red-700 mx-0.5">View Report</span> to generate the report below
                </span>
              </div>
            </div>

            {/* Empty state / placeholder for the report table */}
            <div className="flex flex-col items-center justify-center gap-3 py-20 text-slate-400 border border-dashed border-slate-200 rounded-xl">
              <Calendar size={36} className="opacity-40" />
              <p className="text-sm font-medium">No report generated yet</p>
              <p className="text-xs text-slate-400">Choose a date range above and click "View Report" to see results here.</p>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default UserReport;