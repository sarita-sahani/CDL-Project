import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import Header from '../../components/Header';
import { fetchCurrentFinancialYear } from '../ExecutiveCircle/ExecuitiveCircleApi';
import { ArrowLeft } from 'lucide-react';
import HonorClubApi from "./HonorclubApi";
import RnRService from "../RnRService";
import axios from "axios";
import Swal from "sweetalert2";
import { simpleEncrypt } from "../../simpleEncrypt";
import { BASE_URL } from "../../config/Config";

const dmsAccessURL = `${BASE_URL}:9023`;

const fallbackImageUrl = "https://militaryhealthinstitute.org/wp-content/uploads/sites/37/2021/08/blank-profile-picture-png.png";

// ─── Single color config for all categories ──────────────────────────────
const sectionColor = {
  gradient: "from-[#3a1c47] to-[#5a2a6a]",
  bg: "bg-[#F0EAF5]",
  border: "border-[#D5C8E0]",
  text: "text-[#3a1c47]",
  hover: "hover:bg-[#E8DCF0]",
  badge: "bg-purple-100 text-purple-700 border-purple-200",
  borderLeft: "#5a2a6a",
  shadowColor: "rgba(58,28,71,0.25)",
};

const PAGE_SIZE = 10;

// ─── Image cache ─────────────────────────────────────────────────────────────
const imageCache = new Map();

const fetchImage = async (docId) => {
  if (!docId) return null;
  if (imageCache.has(docId)) return imageCache.get(docId);

  try {
    const response = await fetch(`${dmsAccessURL}/documents/access`, {
      method: "GET",
      headers: {
        "X-DOC-TOKEN": simpleEncrypt(docId.toString()),
      },
    });

    if (!response.ok) throw new Error("Failed to fetch image");

    const blob = await response.blob();
    const url = URL.createObjectURL(blob);
    imageCache.set(docId, url);
    return url;
  } catch (error) {
    console.error("Error fetching image for docId:", docId, error);
    return null;
  }
};

// ─── Member Card ────────────────────────────────────────────────────────────
const MemberCard = ({ member, idx, onLike, onComment, onViewLikes, counts }) => {
  const key = member.id;
  const likeCount = counts[key]?.likes || 0;
  const commentCount = counts[key]?.comments || 0;

  const [imageUrl, setImageUrl] = useState(null);
  const [loadingImage, setLoadingImage] = useState(false);

  useEffect(() => {
    if (member.docId) {
      setLoadingImage(true);
      fetchImage(member.docId)
        .then((url) => {
          setImageUrl(url);
          setLoadingImage(false);
        })
        .catch(() => setLoadingImage(false));
    }
  }, [member.docId]);

  return (
    <div
      className={`bg-white rounded-lg shadow-sm border ${sectionColor.border} border-l-4 hover:shadow-xl hover:-translate-y-1 hover:scale-[1.02] transition-all duration-300 p-4 text-center group`}
      style={{ borderLeftColor: sectionColor.borderLeft }}
    >
      <div className="flex justify-center mb-3">
        {loadingImage ? (
          <div className="w-16 h-16 rounded-full bg-gray-200 animate-pulse" />
        ) : (
          <img
            src={imageUrl || fallbackImageUrl}
            alt={member.name}
            className="w-16 h-16 rounded-full object-cover border-2 border-gray-200 shadow-sm group-hover:border-[#D5C8E0] transition-all"
            onError={(e) => (e.target.src = fallbackImageUrl)}
          />
        )}
      </div>
      <h6 className="font-bold text-gray-800 text-xs leading-tight group-hover:text-gray-900 transition-colors">{member.name}</h6>
      <p className="text-xs text-gray-500 mt-0.5 truncate">{member.dept}</p>
      <span className={`inline-block mt-1.5 px-2 py-0.5 text-xs font-medium rounded-full border ${sectionColor.badge}`}>
        {member.badge}
      </span>
      <div className="flex justify-center gap-4 mt-3 pt-2 border-t border-gray-100">
        <div className="flex items-center gap-1">
          <button
            onClick={() => onLike(member.id)}
            className="text-gray-500 hover:text-[#5a2a6a] transition text-sm"
          >
            👍
          </button>
          <span
            onClick={() => onViewLikes(member.id)}
            className="text-xs text-gray-600 cursor-pointer hover:underline"
          >
            ({likeCount})
          </span>
        </div>
        <div className="flex items-center gap-1">
          <button
            onClick={() => onComment(member)}
            className="text-gray-500 hover:text-[#5a2a6a] transition text-sm"
          >
            💬
          </button>
          <span className="text-xs text-gray-600">({commentCount})</span>
        </div>
      </div>
    </div>
  );
};

const Pagination = ({ page, total, pageSize, onChange }) => {
  const totalPages = Math.ceil(total / pageSize);
  if (totalPages <= 1) return null;
  return (
    <div className="flex justify-between items-center mt-4 flex-wrap gap-3 bg-white p-4 rounded-xl shadow-sm border border-gray-100">
      <div className="text-sm text-gray-600">
        Showing {page * pageSize + 1} to {Math.min((page + 1) * pageSize, total)} of {total} entries
      </div>
      <div className="flex items-center gap-2">
        <button
          onClick={() => onChange(Math.max(page - 1, 0))}
          disabled={page === 0}
          className="px-3 py-1.5 text-sm bg-gray-100 text-gray-700 rounded-lg disabled:opacity-50 hover:bg-gray-200 transition"
        >
          Previous
        </button>
        <div className="flex gap-1">
          {Array.from({ length: totalPages }, (_, i) => i).map(p => (
            <button
              key={p}
              onClick={() => onChange(p)}
              className={`w-8 h-8 text-sm rounded-lg transition ${page === p ? "bg-[#5a2a6a] text-white" : "bg-gray-100 text-gray-700 hover:bg-gray-200"}`}
            >
              {p + 1}
            </button>
          ))}
        </div>
        <button
          onClick={() => onChange(Math.min(page + 1, totalPages - 1))}
          disabled={page === totalPages - 1}
          className="px-3 py-1.5 text-sm bg-gray-100 text-gray-700 rounded-lg disabled:opacity-50 hover:bg-gray-200 transition"
        >
          Next
        </button>
      </div>
    </div>
  );
};

const HonorClubList = () => {
  const navigate = useNavigate();
  const empCode = localStorage.getItem("empId");

  const [page, setPage] = useState(0);
  const [awardYear, setAwardYear] = useState('');
  const [loadingYear, setLoadingYear] = useState(true);
  const [honorClubData, setHonorClubData] = useState([]);
  const [loading, setLoading] = useState(true);

  // ─── Like & Comment states ────────────────────────────────────────────────
  const [countsMap, setCountsMap] = useState({});
  const [selectedMember, setSelectedMember] = useState(null);
  const [commentList, setCommentList] = useState([]);
  const [newComment, setNewComment] = useState("");
  const [loadingComments, setLoadingComments] = useState(false);
  const [showLikesModal, setShowLikesModal] = useState(false);
  const [likeList, setLikeList] = useState([]);

  // ─── Load financial year ──────────────────────────────────────────────────
  useEffect(() => {
    const loadFinancialYear = async () => {
      try {
        const response = await fetchCurrentFinancialYear();
        const yearLabel = response?.label || response?.financialYear || '2026-27';
        setAwardYear(yearLabel);
      } catch (error) {
        console.error('Failed to fetch financial year:', error);
        setAwardYear('2026-27');
      } finally {
        setLoadingYear(false);
      }
    };
    loadFinancialYear();
  }, []);

  // ─── Load Honor Club data ─────────────────────────────────────────────────
  const loadHonorClubData = async () => {
    try {
      setLoading(true);
      const response = await HonorClubApi.getByYear(awardYear);
      const data = response?.data?.data || [];

      const groupedData = [
        {
          category: "Long Service – 10 Years",
          members: data
            .filter(item => item.honorClubType === "TEN_YEARS")
            .map(item => ({
              id: item.id,
              name: item.employeeName,
              dept: item.department,
              badge: "10 Years",
              docId: item.docId,
            })),
        },
        {
          category: "Long Service – 20 Years",
          members: data
            .filter(item => item.honorClubType === "TWENTY_YEARS")
            .map(item => ({
              id: item.id,
              name: item.employeeName,
              dept: item.department,
              badge: "20 Years",
              docId: item.docId,
            })),
        },
        {
          category: "Long Service – 25 Years",
          members: data
            .filter(item => item.honorClubType === "TWENTY_FIVE_YEARS")
            .map(item => ({
              id: item.id,
              name: item.employeeName,
              dept: item.department,
              badge: "25 Years",
              docId: item.docId,
            })),
        },
      ];

      setHonorClubData(groupedData);
    } catch (error) {
      console.error("Error loading Honor Club data:", error);
      setHonorClubData([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (!awardYear) return;
    loadHonorClubData();
  }, [awardYear]);

  // ─── Fetch counts for all members ────────────────────────────────────────
  useEffect(() => {
    const allMembers = honorClubData.flatMap(s => s.members);
    const fetchCounts = async () => {
      const newCounts = {};
      for (const member of allMembers) {
        try {
          const [likesRes, commentsRes] = await Promise.all([
            RnRService.getHonorClubLikes(member.id),
            RnRService.getAllHonorClubComments(member.id),
          ]);
          newCounts[member.id] = {
            likes: likesRes.data?.length || 0,
            comments: commentsRes.data?.length || 0,
          };
        } catch (e) {
          // ignore
        }
      }
      setCountsMap(newCounts);
    };
    if (allMembers.length) fetchCounts();
  }, [honorClubData]);

  // ─── Handlers ─────────────────────────────────────────────────────────────
  const handleLike = async (honorClubId) => {
    if (!empCode) {
      Swal.fire("Error", "Employee code not found.", "error");
      return;
    }
    try {
      const response = await RnRService.likeHonorClub(honorClubId, empCode);
      if (response.data === "Already liked") {
        Swal.fire("Info", "You already liked this.", "info");
        return;
      }
      setCountsMap(prev => ({
        ...prev,
        [honorClubId]: {
          ...prev[honorClubId],
          likes: (prev[honorClubId]?.likes || 0) + 1,
        },
      }));
    } catch (error) {
      console.error("Like failed", error);
      Swal.fire("Error", "Unable to like. Please try again.", "error");
    }
  };

  const openCommentModal = async (member) => {
    setSelectedMember(member);
    setLoadingComments(true);
    try {
      const res = await RnRService.getAllHonorClubComments(member.id);
      setCommentList(res.data || []);
    } catch (e) {
      setCommentList([]);
    } finally {
      setLoadingComments(false);
    }
  };

  const closeCommentModal = () => {
    setSelectedMember(null);
    setCommentList([]);
    setNewComment("");
  };

  const submitComment = async () => {
    if (!newComment.trim()) {
      Swal.fire("Error", "Comment cannot be empty", "error");
      return;
    }
    if (!empCode) {
      Swal.fire("Error", "Employee code not found.", "error");
      return;
    }

    const alreadyCommented = commentList.some(c => c.empCode === empCode);
    if (alreadyCommented) {
      Swal.fire("Info", "You have already commented on this.", "info");
      return;
    }

    try {
      const url = RnRService.addHonorClubComments(selectedMember.id, empCode);
      await axios.post(url, newComment, {
        headers: { "Content-Type": "text/plain;charset=UTF-8" },
      });
      setNewComment("");
      const res = await RnRService.getAllHonorClubComments(selectedMember.id);
      setCommentList(res.data || []);
      setCountsMap(prev => ({
        ...prev,
        [selectedMember.id]: {
          ...prev[selectedMember.id],
          comments: res.data?.length || 0,
        },
      }));
    } catch (error) {
      console.error("Comment failed", error);
      Swal.fire("Error", "Unable to post comment.", "error");
    }
  };

  const openLikesModal = async (honorClubId) => {
    try {
      const res = await RnRService.getHonorClubLikes(honorClubId);
      setLikeList(res.data || []);
      setShowLikesModal(true);
    } catch (e) {
      setLikeList([]);
      setShowLikesModal(true);
    }
  };

  const allMembers = honorClubData.flatMap(s => s.members);
  const pagedIds = new Set(
    allMembers.slice(page * PAGE_SIZE, (page + 1) * PAGE_SIZE).map(m => m.id)
  );

  if (loading || loadingYear) {
    return (
      <>
        <Header />
        <div className="flex items-center justify-center h-screen">
          <div>Loading Honor Club Data...</div>
        </div>
      </>
    );
  }

  return (
    <>
      <Header />
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden mt-16 pt-4">
        {/* Header - Blue to Red gradient matching WallOfFame */}
        <div className="bg-gradient-to-b from-red-900 to-red-700 px-6 py-4">
          <div className="max-w-9xl mx-auto flex items-center justify-between">
            <div className="flex items-center gap-3">
              <button
                onClick={() => navigate('/rewardsHomePage')}
                className="text-white hover:text-gray-200 transition p-1 rounded-full bg-white/20 hover:bg-white/30"
                title="Go back"
              >
                <ArrowLeft size={24} />
              </button>
              <h2 className="text-xl font-semibold text-white">
                <span>🏅</span> HONOR CLUB AWARDS ({awardYear})
              </h2>
            </div>
            <button
              onClick={() => navigate("/addhonorclub")}
              className="px-4 py-2 bg-white hover:bg-red-600 text-[#3a1c47] text-sm font-semibold rounded-lg shadow-md transition flex items-center gap-1"
            >
              <span>+</span> Nominate Honor Club
            </button>
          </div>
        </div>

        {/* Body */}
        <div className="p-6 space-y-10">
          {honorClubData.map(section => {
            const visible = section.members.filter(m => pagedIds.has(m.id));
            if (visible.length === 0) return null;
            
            return (
              <div key={section.category}>
                <h3 className={`text-lg font-bold ${sectionColor.text} mb-3 flex items-center gap-2`}>
                  <span className={`w-1.5 h-5 rounded-full bg-gradient-to-b ${sectionColor.gradient}`}></span>
                  {section.category}
                  <span className="text-xs font-normal text-gray-400">({section.members.length})</span>
                </h3>
                <div className="rounded-xl overflow-hidden border border-gray-200">
                  <div className="bg-gray-200 border-b border-gray-200 px-5 py-2 flex items-center justify-between">
                    <h4 className="text-gray-700 font-semibold text-sm tracking-wide">Employee Name</h4>
                    {/* Show count instead of + */}
                    <span className="text-gray-600 text-sm font-medium bg-white px-3 py-1 rounded-full border border-gray-200">
                      {section.members.length} Members
                    </span>
                  </div>
                  <div className="p-4 bg-white">
                    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
                      {visible.map((member, idx) => (
                        <MemberCard
                          key={member.id}
                          member={member}
                          idx={idx}
                          onLike={handleLike}
                          onComment={openCommentModal}
                          onViewLikes={openLikesModal}
                          counts={countsMap}
                        />
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
          <Pagination
            page={page}
            total={allMembers.length}
            pageSize={PAGE_SIZE}
            onChange={setPage}
          />
        </div>
      </div>

      {/* ─── Comment Modal ─────────────────────────────────────────────────── */}
      {selectedMember && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50"
          onClick={closeCommentModal}
        >
          <div
            className="bg-white w-[600px] max-w-[90%] max-h-[80vh] flex flex-col rounded-lg shadow-lg border"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex justify-between items-center px-5 py-4 border-b-2 border-amber-500">
              <div className="flex items-center gap-3">
                <span
                  onClick={closeCommentModal}
                  className="text-xl cursor-pointer text-amber-600"
                >
                  ←
                </span>
                <h4 className="text-lg font-bold text-indigo-900">Comments</h4>
              </div>
              <button
                onClick={closeCommentModal}
                className="text-2xl text-gray-500 hover:text-black"
              >
                ×
              </button>
            </div>
            <div className="p-5 overflow-y-auto flex-1">
              <div className="flex items-center gap-4 border-b pb-4 mb-4">
                <img
                  src={selectedMember.profileImage || fallbackImageUrl}
                  alt="Profile"
                  className="w-12 h-12 rounded-full border-2 border-amber-300 shadow-sm object-cover"
                />
                <div>
                  <h5 className="font-bold text-base">{selectedMember.name}</h5>
                  <div className="text-sm text-gray-500">{selectedMember.dept}</div>
                </div>
              </div>
              <div className="max-h-[300px] overflow-y-auto mb-4">
                {loadingComments ? (
                  <div className="text-center py-5">Loading comments...</div>
                ) : commentList.length === 0 ? (
                  <p className="text-center text-gray-500 py-5">No comments yet.</p>
                ) : (
                  commentList.map((cmt, idx) => (
                    <div key={idx} className="border-b py-3">
                      <div className="flex flex-wrap items-center gap-2 mb-1">
                        <strong className="text-sm">{cmt.employeeName}</strong>
                        {cmt.department && (
                          <span className="bg-gray-200 text-gray-700 text-xs px-2 py-1 rounded-full font-semibold">
                            {cmt.department}
                          </span>
                        )}
                        {cmt.emailId && (
                          <span className="text-xs text-gray-500">{cmt.emailId}</span>
                        )}
                      </div>
                      <p className="text-sm text-gray-800 mb-1">{cmt.comments}</p>
                      <small className="text-xs text-gray-500">{cmt.commentDateTime}</small>
                    </div>
                  ))
                )}
              </div>
              <div>
                <textarea
                  className="w-full border rounded-md p-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400"
                  rows="3"
                  placeholder="Write a comment..."
                  value={newComment}
                  onChange={(e) => setNewComment(e.target.value)}
                />
                <div className="flex justify-end mt-2">
                  <button
                    onClick={submitComment}
                    className="bg-amber-500 hover:bg-amber-600 text-white px-4 py-2 rounded font-semibold"
                  >
                    Post Comment
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ─── Likes Modal ──────────────────────────────────────────────────── */}
      {showLikesModal && (
        <div
          className="fixed inset-0 bg-black bg-opacity-40 flex items-center justify-center z-50"
          onClick={() => setShowLikesModal(false)}
        >
          <div
            className="bg-white w-[500px] max-w-[95%] rounded-md shadow-lg border"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex justify-between items-center px-5 py-4 border-b bg-gray-100">
              <h4 className="text-lg font-semibold text-gray-800">All Likes</h4>
              <button
                onClick={() => setShowLikesModal(false)}
                className="text-xl text-gray-600 hover:text-black"
              >
                ×
              </button>
            </div>
            <div className="p-4 bg-gray-100 max-h-[400px] overflow-y-auto">
              {likeList.length === 0 ? (
                <p className="text-center text-gray-500">No likes yet</p>
              ) : (
                likeList.map((like, index) => (
                  <div key={index} className="bg-white rounded-md shadow-sm p-4 mb-4 border">
                    <div className="flex items-center gap-3 mb-2">
                      <div className="text-gray-700 text-lg">👍</div>
                      <span className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm font-medium">
                        {like.employeeName}
                      </span>
                    </div>
                    <div className="text-sm text-gray-700 ml-8">{like.emailId}</div>
                    <div className="text-xs text-gray-500 ml-8 mt-1">{like.likedAt}</div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default HonorClubList;