// /**
//  * MarketingScreen.jsx
//  *
//  * Marketing team view for Honor Club.
//  * Reuses:
//  *   RnRService.employeeInfoData  → photo/profile preview
//  *   RnRService.likeRecognition / getRecognitionLikes  → engagement stats
//  *
//  * New:
//  *   getMarketingDashboard / toggleHonorDisplay / bulkSubmitToMarketing / exportHonorExcel
//  */
// import React, { useState, useEffect } from "react";
// import RnRService from "../RnRService";
// import {
//   getMarketingDashboard,
//   toggleHonorDisplay,
//   bulkSubmitToMarketing,
//   exportHonorExcel,
//   createHonorEntry,
// } from "./HonorclubApi";

// const FALLBACK = "https://militaryhealthinstitute.org/wp-content/uploads/sites/37/2021/08/blank-profile-picture-png.png";

// const TYPE_META = {
//   TENURE_10:            { label: "10 Yrs Service",  icon: "🥇", color: "#0369a1", bg: "#e0f2fe" },
//   TENURE_20:            { label: "20 Yrs Service",  icon: "🏅", color: "#92400e", bg: "#fef3c7" },
//   SCHOLARSHIP_CLASS_10: { label: "Class 10 Scholar", icon: "📚", color: "#065f46", bg: "#d1fae5" },
//   SCHOLARSHIP_CLASS_12: { label: "Class 12 Scholar", icon: "🎓", color: "#5b21b6", bg: "#ede9fe" },
// };

// function Avatar({ src, name, size = 42 }) {
//   const [err, setErr] = useState(false);
//   const imgSrc = !err && src ? `/uploads/${src}` : FALLBACK;
//   return (
//     <img src={imgSrc} alt={name} onError={() => setErr(true)}
//          style={{ width: size, height: size, borderRadius: "50%", objectFit: "cover",
//                   border: "2px solid #ede9fe", flexShrink: 0 }} />
//   );
// }

// // ── Template Upload ────────────────────────────────────────────────────
// function TemplateModal({ financialYear, onClose }) {
//   const [file,      setFile]      = useState(null);
//   const [rows,      setRows]      = useState([]);
//   const [uploading, setUploading] = useState(false);
//   const [done,      setDone]      = useState(0);

//   const TEMPLATE_HEADERS =
//     "Emp Code,Employee Name,Department,Location,Project Name,Entry Type,Financial Year," +
//     "Student Title,Student Name,Student Class,Academic Year,Marks %,Rank,School/College Name";
//   const SAMPLE_ROW =
//     "EMP001,John Doe,IT,Mumbai,CMS Portal,TENURE_10,2025-26,,,,,,, ";

//   const downloadTemplate = () => {
//     const blob = new Blob([TEMPLATE_HEADERS + "\n" + SAMPLE_ROW], { type: "text/csv" });
//     const a = document.createElement("a");
//     a.href = URL.createObjectURL(blob);
//     a.download = "honor-club-template.csv";
//     a.click();
//   };

//   const parseCSV = (text) => {
//     const [headerLine, ...lines] = text.trim().split("\n");
//     const headers = headerLine.split(",").map(h => h.trim());
//     return lines.filter(l => l.trim()).map(line => {
//       const vals = line.split(",");
//       return headers.reduce((o, h, i) => ({ ...o, [h]: (vals[i] || "").trim() }), {});
//     });
//   };

//   const handleFile = async (e) => {
//     const f = e.target.files[0];
//     if (!f) return;
//     setFile(f);
//     const text = await f.text();
//     setRows(parseCSV(text));
//   };

//   const upload = async () => {
//     setUploading(true);
//     let count = 0;
//     for (const r of rows) {
//       try {
//         const fd = new FormData();
//         fd.append("entryRequest", new Blob([JSON.stringify({
//           empCode:         r["Emp Code"],
//           employeeName:    r["Employee Name"],
//           department:      r["Department"],
//           location:        r["Location"],
//           projectName:     r["Project Name"],
//           entryType:       r["Entry Type"] || "TENURE_10",
//           financialYear:   r["Financial Year"] || financialYear,
//           studentTitle:    r["Student Title"],
//           studentName:     r["Student Name"],
//           studentClass:    r["Student Class"],
//           academicYear:    r["Academic Year"],
//           marksPercentage: r["Marks %"] ? parseFloat(r["Marks %"]) : null,
//           rankObtained:    r["Rank"],
//           schoolCollegeName: r["School/College Name"],
//         })], { type: "application/json" }));
//         await createHonorEntry(fd);
//         count++;
//       } catch { /* skip bad rows */ }
//     }
//     setDone(count);
//     setUploading(false);
//   };

//   return (
//     <div style={MS.overlay} onClick={onClose}>
//       <div style={MS.modal} onClick={e => e.stopPropagation()}>
//         <div style={MS.modalHead}>
//           <span style={MS.modalTitle}>📂 Upload Template</span>
//           <button onClick={onClose} style={MS.xBtn}>✕</button>
//         </div>
//         <div style={{ padding: 24 }}>
//           <p style={{ color: "#4b5563", fontSize: 14, marginBottom: 16 }}>
//             Download the CSV template, fill employee data, then upload here.
//           </p>
//           <button onClick={downloadTemplate} style={MS.dlBtn}>⬇ Download Template CSV</button>

//           <div style={{ marginTop: 20 }}>
//             <label style={MS.fileBtn}>
//               Choose CSV File
//               <input type="file" accept=".csv" hidden onChange={handleFile} />
//             </label>
//             {file && <p style={{ fontSize: 13, color: "#7c3aed", marginTop: 8 }}>
//               ✓ {file.name} · {rows.length} rows detected
//             </p>}
//           </div>

//           {rows.length > 0 && (
//             <div style={{ marginTop: 14, overflowX: "auto", maxHeight: 200, overflowY: "auto", borderRadius: 8, border: "1px solid #e5e7eb" }}>
//               <table style={{ width: "100%", fontSize: 11, borderCollapse: "collapse" }}>
//                 <thead>
//                   <tr style={{ background: "#ede9fe" }}>
//                     {Object.keys(rows[0]).map(k => (
//                       <th key={k} style={{ padding: "6px 8px", textAlign: "left", color: "#5b21b6", whiteSpace: "nowrap" }}>{k}</th>
//                     ))}
//                   </tr>
//                 </thead>
//                 <tbody>
//                   {rows.slice(0, 5).map((r, i) => (
//                     <tr key={i} style={{ borderBottom: "1px solid #f3f4f6" }}>
//                       {Object.values(r).map((v, j) => (
//                         <td key={j} style={{ padding: "5px 8px", color: "#374151" }}>{v || "—"}</td>
//                       ))}
//                     </tr>
//                   ))}
//                 </tbody>
//               </table>
//               {rows.length > 5 && <p style={{ fontSize: 12, color: "#9ca3af", padding: "6px 8px" }}>…and {rows.length - 5} more rows</p>}
//             </div>
//           )}

//           {done > 0 && <p style={{ color: "#22c55e", fontWeight: 700, marginTop: 12 }}>✓ {done} entries uploaded successfully!</p>}

//           <div style={{ display: "flex", justifyContent: "flex-end", gap: 10, marginTop: 20 }}>
//             <button onClick={onClose} style={MS.cancelBtn}>Cancel</button>
//             <button onClick={upload} disabled={!rows.length || uploading} style={MS.saveBtn}>
//               {uploading ? "Uploading…" : `Upload ${rows.length} Rows`}
//             </button>
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// }

// // ── Main Marketing Screen ──────────────────────────────────────────────
// export default function MarketingScreen({ financialYear = "2025-26" }) {
//   const [rows,     setRows]     = useState([]);
//   const [loading,  setLoading]  = useState(true);
//   const [selected, setSelected] = useState([]);
//   const [typeFilter, setTypeFilter] = useState("ALL");
//   const [search,   setSearch]   = useState("");
//   const [showTemplate, setShowTemplate] = useState(false);

//   const fetchData = async () => {
//     setLoading(true);
//     try {
//       const res = await getMarketingDashboard(financialYear);
//       setRows(res.data || []);
//     } finally { setLoading(false); }
//   };

//   useEffect(() => { fetchData(); }, [financialYear]);

//   const toggleSelect = id =>
//     setSelected(p => p.includes(id) ? p.filter(x => x !== id) : [...p, id]);

//   const filtered = rows.filter(r => {
//     const tMatch = typeFilter === "ALL" || r.entryType === typeFilter;
//     const sMatch = !search ||
//       r.employeeName?.toLowerCase().includes(search.toLowerCase()) ||
//       r.department?.toLowerCase().includes(search.toLowerCase()) ||
//       r.empCode?.toLowerCase().includes(search.toLowerCase());
//     return tMatch && sMatch;
//   });

//   const allSelected = filtered.length > 0 && selected.length === filtered.length;
//   const toggleAll   = () => setSelected(allSelected ? [] : filtered.map(r => r.id));

//   const handleDisplayToggle = async (id, current) => {
//     await toggleHonorDisplay(id, !current);
//     setRows(p => p.map(r => r.id === id ? { ...r, selectedForDisplay: !current } : r));
//   };

//   const handleBulkSubmit = async () => {
//     if (!selected.length) { alert("Select at least one entry."); return; }
//     await bulkSubmitToMarketing(selected, financialYear);
//     alert(`✅ ${selected.length} entries published to Honor Club display!`);
//     setSelected([]);
//     fetchData();
//   };

//   const handleExport = async () => {
//     const res  = await exportHonorExcel(financialYear);
//     const url  = URL.createObjectURL(new Blob([res.data]));
//     const a    = document.createElement("a");
//     a.href     = url;
//     a.download = `honor-club-${financialYear}.xlsx`;
//     a.click();
//   };

//   // Stats
//   const counts = {
//     total:     rows.length,
//     tenure10:  rows.filter(r => r.entryType === "TENURE_10").length,
//     tenure20:  rows.filter(r => r.entryType === "TENURE_20").length,
//     scholars:  rows.filter(r => r.entryType?.startsWith("SCHOLARSHIP")).length,
//     published: rows.filter(r => r.selectedForDisplay).length,
//   };

//   const topScholar = [...rows]
//     .filter(r => r.entryType?.startsWith("SCHOLARSHIP") && r.marksPercentage)
//     .sort((a, b) => b.marksPercentage - a.marksPercentage)[0];

//   return (
//     <div style={MS.root}>

//       {/* ── HEADER ── */}
//       <div style={MS.header}>
//         <div style={MS.headerInner}>
//           <div>
//             <div style={MS.title}>📊 MARKETING SCREEN</div>
//             <div style={MS.subtitle}>Honor Club Award {financialYear} · Review & Publish</div>
//           </div>
//           <div style={{ display: "flex", gap: 10, flexWrap: "wrap", alignItems: "center" }}>
//             <button onClick={() => setShowTemplate(true)} style={MS.outlineBtn}>
//               📂 Upload Template
//             </button>
//             <button onClick={handleExport} style={MS.outlineBtn}>
//               📥 Export Excel
//             </button>
//             <button onClick={handleBulkSubmit} disabled={!selected.length} style={MS.primaryBtn}>
//               ✅ Publish Selected ({selected.length})
//             </button>
//           </div>
//         </div>
//       </div>

//       {/* ── STATS ── */}
//       <div style={MS.statsBar}>
//         {[
//           { label: "Total Entries", val: counts.total,    icon: "📋", color: "#7c3aed" },
//           { label: "10 Yrs",        val: counts.tenure10,  icon: "🥇", color: "#0369a1" },
//           { label: "20 Yrs",        val: counts.tenure20,  icon: "🏅", color: "#92400e" },
//           { label: "Scholars",      val: counts.scholars,  icon: "🎓", color: "#065f46" },
//           { label: "Published",     val: counts.published, icon: "✅", color: "#22c55e" },
//         ].map(s => (
//           <div key={s.label} style={MS.statCard}>
//             <span style={{ fontSize: 22 }}>{s.icon}</span>
//             <span style={{ fontSize: 26, fontWeight: 900, color: s.color }}>{s.val}</span>
//             <span style={{ fontSize: 11, color: "#6b7280" }}>{s.label}</span>
//           </div>
//         ))}
//       </div>

//       {/* ── TOP SCHOLAR ── */}
//       {topScholar && (
//         <div style={MS.highlight}>
//           <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
//             <Avatar src={topScholar.profileImagePath} name={topScholar.employeeName} size={52} />
//             <div>
//               <div style={{ fontSize: 11, color: "#7c3aed", fontWeight: 800, letterSpacing: 1, textTransform: "uppercase" }}>
//                 🏆 Top Performer
//               </div>
//               <div style={{ fontWeight: 800, fontSize: 16, color: "#1a1a2e" }}>
//                 {topScholar.studentName}
//               </div>
//               <div style={{ fontSize: 13, color: "#4b5563" }}>
//                 {topScholar.employeeName} · {topScholar.department} ·{" "}
//                 <span style={{ fontWeight: 700, color: "#7c3aed" }}>{topScholar.marksPercentage}%</span>
//                 {topScholar.rankObtained && ` · Rank ${topScholar.rankObtained}`}
//               </div>
//             </div>
//           </div>
//           <span style={{ ...MS.pill, color: "#5b21b6", background: "#ede9fe", alignSelf: "center" }}>
//             {TYPE_META[topScholar.entryType]?.label}
//           </span>
//         </div>
//       )}

//       {/* ── FILTERS ── */}
//       <div style={MS.toolbar}>
//         <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
//           {["ALL", ...Object.keys(TYPE_META)].map(k => (
//             <button key={k} onClick={() => setTypeFilter(k)}
//                     style={{ ...MS.filterBtn, ...(typeFilter === k ? MS.filterActive : {}) }}>
//               {k === "ALL" ? "All" : TYPE_META[k]?.icon + " " + TYPE_META[k]?.label}
//             </button>
//           ))}
//         </div>
//         <input value={search} onChange={e => setSearch(e.target.value)}
//                placeholder="🔍  Search name, department, emp code…"
//                style={MS.searchBox} />
//         <label style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 13, cursor: "pointer" }}>
//           <input type="checkbox" checked={allSelected} onChange={toggleAll}
//                  style={{ width: 16, height: 16 }} />
//           Select All ({filtered.length})
//         </label>
//       </div>

//       {/* ── TABLE ── */}
//       <div style={MS.tableWrap}>
//         {loading ? (
//           <div style={{ textAlign: "center", padding: "60px 0", color: "#7c3aed" }}>Loading…</div>
//         ) : filtered.length === 0 ? (
//           <div style={{ textAlign: "center", padding: "60px 0", color: "#9ca3af" }}>No entries found.</div>
//         ) : (
//           <table style={MS.table}>
//             <thead>
//               <tr style={MS.thead}>
//                 <th style={MS.th}></th>
//                 <th style={MS.th}>Employee</th>
//                 <th style={MS.th}>Department</th>
//                 <th style={MS.th}>Category</th>
//                 <th style={MS.th}>Child Details</th>
//                 <th style={MS.th}>Documents</th>
//                 <th style={MS.th}>Display</th>
//               </tr>
//             </thead>
//             <tbody>
//               {filtered.map((row, i) => {
//                 const meta = TYPE_META[row.entryType] || { label: row.entryType, color: "#374151", bg: "#f3f4f6", icon: "" };
//                 const isScholar = row.entryType?.startsWith("SCHOLARSHIP");
//                 const checked   = selected.includes(row.id);
//                 return (
//                   <tr key={row.id} style={{
//                     ...MS.tr,
//                     background: checked ? "#faf5ff" : i % 2 === 0 ? "#fff" : "#fafafa",
//                   }}>
//                     {/* Checkbox */}
//                     <td style={MS.td}>
//                       <input type="checkbox" checked={checked} onChange={() => toggleSelect(row.id)}
//                              style={{ width: 16, height: 16, cursor: "pointer" }} />
//                     </td>

//                     {/* Employee */}
//                     <td style={MS.td}>
//                       <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
//                         <Avatar src={row.profileImagePath} name={row.employeeName} />
//                         <div>
//                           <div style={{ fontWeight: 700, fontSize: 13, color: "#1a1a2e" }}>{row.employeeName}</div>
//                           <div style={{ fontSize: 11, color: "#9ca3af" }}>{row.empCode}</div>
//                         </div>
//                       </div>
//                     </td>

//                     {/* Department */}
//                     <td style={MS.td}>
//                       <span style={{ fontSize: 13, color: "#374151" }}>{row.department || "—"}</span>
//                     </td>

//                     {/* Category badge */}
//                     <td style={MS.td}>
//                       <span style={{ ...MS.pill, color: meta.color, background: meta.bg }}>
//                         {meta.icon} {meta.label}
//                       </span>
//                     </td>

//                     {/* Child details (scholarships only) */}
//                     <td style={MS.td}>
//                       {isScholar ? (
//                         <div style={{ fontSize: 12 }}>
//                           <div style={{ fontWeight: 600, color: "#1a1a2e" }}>{row.studentName}</div>
//                           <div style={{ color: "#7c3aed" }}>
//                             {row.marksPercentage}%
//                             {row.rankObtained ? ` · Rank ${row.rankObtained}` : ""}
//                           </div>
//                         </div>
//                       ) : <span style={{ color: "#d1d5db", fontSize: 13 }}>—</span>}
//                     </td>

//                     {/* Document links */}
//                     <td style={MS.td}>
//                       <div style={{ display: "flex", gap: 5, flexWrap: "wrap" }}>
//                         {row.profileImagePath && (
//                           <a href={`/uploads/${row.profileImagePath}`} target="_blank" rel="noreferrer" style={MS.docLink}>📷</a>
//                         )}
//                         {row.marksheetPath && (
//                           <a href={`/uploads/${row.marksheetPath}`} target="_blank" rel="noreferrer" style={MS.docLink}>📄</a>
//                         )}
//                         {row.certificatePath && (
//                           <a href={`/uploads/${row.certificatePath}`} target="_blank" rel="noreferrer" style={MS.docLink}>📜</a>
//                         )}
//                       </div>
//                     </td>

//                     {/* Display toggle */}
//                     <td style={MS.td}>
//                       <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
//                         <div onClick={() => handleDisplayToggle(row.id, row.selectedForDisplay)}
//                              style={{ ...MS.toggle, background: row.selectedForDisplay ? "#7c3aed" : "#d1d5db" }}>
//                           <div style={{ ...MS.toggleThumb, left: row.selectedForDisplay ? 22 : 3 }} />
//                         </div>
//                         <span style={{ fontSize: 11, color: row.selectedForDisplay ? "#7c3aed" : "#9ca3af", fontWeight: 600 }}>
//                           {row.selectedForDisplay ? "On" : "Off"}
//                         </span>
//                       </div>
//                     </td>
//                   </tr>
//                 );
//               })}
//             </tbody>
//           </table>
//         )}
//       </div>

//       {showTemplate && (
//         <TemplateModal financialYear={financialYear}
//                        onClose={() => { setShowTemplate(false); fetchData(); }} />
//       )}
//     </div>
//   );
// }

// // ── Styles ────────────────────────────────────────────────────────────
// const MS = {
//   root: { minHeight: "100vh", background: "#f6f5ff", fontFamily: "'Segoe UI',system-ui,sans-serif" },
//   header: { background: "linear-gradient(135deg,#1a1a2e 0%,#6d28d9 100%)", boxShadow: "0 4px 28px rgba(109,40,217,.4)" },
//   headerInner: { maxWidth: 1280, margin: "0 auto", padding: "20px 24px", display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 12 },
//   title: { fontSize: 24, fontWeight: 900, color: "#fbbf24", letterSpacing: 3, textTransform: "uppercase" },
//   subtitle: { fontSize: 12, color: "rgba(255,255,255,.6)", marginTop: 3 },
//   outlineBtn: { padding: "9px 16px", borderRadius: 8, border: "1.5px solid rgba(255,255,255,.35)", background: "transparent", color: "#fff", cursor: "pointer", fontWeight: 600, fontSize: 13 },
//   primaryBtn: { padding: "9px 18px", borderRadius: 8, border: "none", background: "#fbbf24", color: "#1a1a2e", cursor: "pointer", fontWeight: 800, fontSize: 13, boxShadow: "0 3px 12px rgba(251,191,36,.4)" },
//   statsBar: { maxWidth: 1280, margin: "0 auto", padding: "18px 24px", display: "flex", gap: 14, flexWrap: "wrap" },
//   statCard: { flex: 1, minWidth: 120, background: "#fff", borderRadius: 12, padding: "14px 18px", display: "flex", flexDirection: "column", alignItems: "center", gap: 4, boxShadow: "0 2px 12px rgba(0,0,0,.06)", border: "1px solid #ede9fe" },
//   highlight: { maxWidth: 1280, margin: "0 auto", marginBottom: 8, padding: "14px 24px 0", display: "flex", justifyContent: "space-between", background: "#fff", borderBottom: "1px solid #ede9fe" },
//   pill: { padding: "3px 10px", borderRadius: 20, fontSize: 11, fontWeight: 700 },
//   toolbar: { maxWidth: 1280, margin: "0 auto", padding: "12px 24px", display: "flex", gap: 10, flexWrap: "wrap", alignItems: "center" },
//   filterBtn: { padding: "7px 12px", borderRadius: 8, border: "1.5px solid #e5e7eb", background: "#fff", color: "#374151", cursor: "pointer", fontWeight: 600, fontSize: 12, whiteSpace: "nowrap" },
//   filterActive: { background: "#7c3aed", color: "#fff", borderColor: "#7c3aed" },
//   searchBox: { flex: 1, minWidth: 200, padding: "9px 14px", borderRadius: 8, border: "1.5px solid #e5e7eb", fontSize: 13, outline: "none", background: "#fff" },
//   tableWrap: { maxWidth: 1280, margin: "0 auto", padding: "0 24px 40px", overflowX: "auto" },
//   table: { width: "100%", borderCollapse: "collapse", background: "#fff", borderRadius: 14, overflow: "hidden", boxShadow: "0 2px 24px rgba(0,0,0,.07)" },
//   thead: { background: "linear-gradient(90deg,#6d28d9,#a855f7)" },
//   th: { padding: "13px 16px", textAlign: "left", fontSize: 11, fontWeight: 800, color: "#fff", letterSpacing: 0.5, textTransform: "uppercase", whiteSpace: "nowrap" },
//   tr: { borderBottom: "1px solid #f3f4f6", transition: "background .15s" },
//   td: { padding: "12px 16px", verticalAlign: "middle" },
//   docLink: { padding: "4px 8px", borderRadius: 6, border: "1px solid #e5e7eb", color: "#7c3aed", fontSize: 14, textDecoration: "none" },
//   toggle: { width: 44, height: 24, borderRadius: 12, cursor: "pointer", position: "relative", transition: "background .2s", flexShrink: 0 },
//   toggleThumb: { position: "absolute", top: 3, width: 18, height: 18, borderRadius: "50%", background: "#fff", boxShadow: "0 1px 4px rgba(0,0,0,.2)", transition: "left .2s" },

//   // Modal
//   overlay: { position: "fixed", inset: 0, background: "rgba(0,0,0,.65)", backdropFilter: "blur(4px)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 1000, padding: 20 },
//   modal: { background: "#fff", borderRadius: 16, width: "100%", maxWidth: 600, maxHeight: "88vh", overflow: "hidden", display: "flex", flexDirection: "column", boxShadow: "0 24px 80px rgba(0,0,0,.35)" },
//   modalHead: { display: "flex", justifyContent: "space-between", alignItems: "center", padding: "16px 20px", background: "linear-gradient(90deg,#1a1a2e,#6d28d9)" },
//   modalTitle: { fontSize: 16, fontWeight: 800, color: "#fff" },
//   xBtn: { width: 32, height: 32, borderRadius: "50%", border: "none", background: "rgba(255,255,255,.2)", color: "#fff", cursor: "pointer", fontSize: 15 },
//   dlBtn: { padding: "10px 18px", borderRadius: 8, border: "none", background: "#7c3aed", color: "#fff", fontWeight: 700, cursor: "pointer", fontSize: 14 },
//   fileBtn: { padding: "9px 16px", borderRadius: 8, border: "1.5px dashed #7c3aed", color: "#7c3aed", fontWeight: 600, fontSize: 13, cursor: "pointer", background: "#faf5ff" },
//   cancelBtn: { padding: "10px 18px", borderRadius: 8, border: "1.5px solid #e5e7eb", background: "#fff", color: "#374151", cursor: "pointer", fontWeight: 600 },
//   saveBtn: { padding: "10px 20px", borderRadius: 8, border: "none", background: "linear-gradient(90deg,#6d28d9,#a855f7)", color: "#fff", cursor: "pointer", fontWeight: 700 },
// };