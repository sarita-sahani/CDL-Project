import axios from "axios";

const Honor_Club_Base_Api = "http://localhost:9035/api/honor-club";

const HonorClubApi = {

  saveHonorClubData: async (formData) => {
    return axios.post(
      `${Honor_Club_Base_Api}/saveHonorClubData`,
      formData,
      {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      }
    );
  },

  getByYear: async (awardYear) => {
    return axios.get(
      `${Honor_Club_Base_Api}/year/${awardYear}`
    );
  },

  getByType: async (honorClubType) => {
    return axios.get(
      `${Honor_Club_Base_Api}/type/${honorClubType}`
    );
  },

  getByYearAndType: async (
    awardYear,
    honorClubType
  ) => {
    return axios.get(
      `${Honor_Club_Base_Api}/filter`,
      {
        params: {
          awardYear,
          honorClubType,
        },
      }
    );
  },
};

export default HonorClubApi;