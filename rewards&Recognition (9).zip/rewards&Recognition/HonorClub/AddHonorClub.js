import React, { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../../components/Header';
import RnRService from '../RnRService';
import { fetchCurrentFinancialYear } from '../ExecutiveCircle/ExecuitiveCircleApi';
import { X } from 'lucide-react';
import HonorClubApi from "./HonorclubApi";

const blankRow = (seq) => ({
  seq,
  searchTerm: '', employee: null, department: '',
  employeesList: [], loadingEmployees: false,
  profileFile: null, profilePreview: null,
});

const Label = ({ children }) => (
  <label className="block text-xs font-semibold text-gray-600 mb-1">{children}</label>
);

const Input = ({ className = '', ...props }) => (
  <input
    {...props}
    className={`w-full border border-gray-300 rounded-lg px-3 py-2 text-sm
      focus:outline-none focus:ring-1 focus:ring-red-800 focus:border-red-800
      ${props.readOnly ? 'bg-gray-50 text-gray-500 cursor-default' : 'bg-white'}
      ${className}`}
  />
);

const EmpDropdown = ({ list, onSelect }) => (
  <ul className="absolute top-full left-0 right-0 z-50 bg-white border border-gray-200
    rounded-lg shadow-lg mt-1 max-h-48 overflow-y-auto list-none p-0 m-0">
    {list.map(emp => (
      <li
        key={emp.empCode}
        onMouseDown={e => e.preventDefault()}
        onClick={() => onSelect(emp)}
        className="px-3 py-2 hover:bg-red-50 cursor-pointer border-b border-gray-100 last:border-0"
      >
        <div className="font-semibold text-sm text-gray-800">{emp.employeeName}</div>
        <div className="text-xs text-gray-400 mt-0.5">
          {emp.empCode}{emp.department ? ` · ${emp.department}` : ''}
        </div>
      </li>
    ))}
  </ul>
);

const TENURE_META = {
  '10': { label: '10 Years of Service', type: 'TEN_YEARS',          icon: '🏅', color: 'bg-gradient-to-br from-red-800 to-red-900'    },
  '20': { label: '20 Years of Service', type: 'TWENTY_YEARS',       icon: '🥇', color: 'bg-gradient-to-br from-orange-700 to-orange-800' },
  '25': { label: '25 Years of Service', type: 'TWENTY_FIVE_YEARS',  icon: '🏆', color: 'bg-gradient-to-br from-yellow-700 to-yellow-800' },
};

function LandingScreen({ onNavigate, awardYear }) {
  const navigate = useNavigate();
  const tiles = [
    { key: 'tenure-10', label: '10 Year Tenure Award', sub: 'Employees completing 10 years of service', icon: '🏅', color: 'bg-gradient-to-br from-red-800 to-red-900'    },
    { key: 'tenure-20', label: '20 Year Tenure Award', sub: 'Employees completing 20 years of service', icon: '🥇', color: 'bg-gradient-to-br from-orange-700 to-orange-800' },
    { key: 'tenure-25', label: '25 Year Tenure Award', sub: 'Employees completing 25 years of service', icon: '🏆', color: 'bg-gradient-to-br from-yellow-700 to-yellow-800' },
  ];

  const handleBack = () => {
    navigate('/honor-club-list');
  };

  return (
    <div>
      <div className=" bg-gradient-to-b from-red-900 to-red-700 text-white text-lg font-bold px-5 py-3 shadow-md flex justify-between items-center mt-16 pt-4">
        <span>🎖️ Honor Club Award {awardYear}</span>
       
 <button onClick={handleBack} className="bg-white/20 hover:bg-white/30 text-white rounded-full p-2 transition-all duration-200 backdrop-blur-sm">
                                <X size={18} />
                            </button>
        
      </div>

      <div className="bg-white rounded-xl shadow-lg overflow-hidden border border-gray-100 mt-6">
        <div className="bg-gray-50 border-b border-gray-100 px-6 py-3">
          <h2 className="text-md font-bold text-gray-700">Nominate for Tenure Award</h2>
          <p className="text-xs text-gray-500 mt-0.5">Select the completion milestone below</p>
        </div>
        <div className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {tiles.map(t => (
              <button
                key={t.key}
                onClick={() => onNavigate(t.key)}
                className={`${t.color} text-white rounded-xl p-6 hover:scale-[1.02] transition-all duration-200 shadow-md hover:shadow-xl border-0 cursor-pointer text-left`}
              >
                <div className="text-3xl mb-3">{t.icon}</div>
                <div className="font-bold text-lg mb-1">{t.label}</div>
                <div className="text-xs opacity-80 mb-3">{t.sub}</div>
                <div className="text-xs font-medium inline-block border-b border-white/40 pb-0.5">
                  Continue →
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function TenureForm({ tenureType, onBack, onSubmit, awardYear }) {
  const navigate = useNavigate();
  const meta = TENURE_META[tenureType];

  const [rows,   setRows]   = useState([blankRow(1)]);
  const [saving, setSaving] = useState(false);
  const debounceTimers = useRef([null]);

  const updateRow = (index, field, value) =>
    setRows(prev => {
      const next = [...prev];
      next[index] = { ...next[index], [field]: value };
      return next;
    });

  const searchEmployees = async (searchValue, index) => {
    updateRow(index, 'loadingEmployees', true);
    try {
      const res  = await RnRService.searchEmployee(searchValue);
      const data = res.data || [];
      const mapped = data.map(item => ({
        empCode:       item.empResDTO?.empCode,
        employeeName:  item.empResDTO?.fullNameAsAadhaar ||
                       `${item.empResDTO?.firstName} ${item.empResDTO?.lastName}`.trim() ||
                       item.empResDTO?.emailId,
        employeeEmail: item.empResDTO?.emailId,
        department:    item.empResDTO?.mainDeptResDTO?.mainDepartment,
        designation:   item.empResDTO?.designationResDTO?.designationName,
      }));
      updateRow(index, 'employeesList', mapped);
    } catch (err) {
      console.error('Error searching employees', err);
      updateRow(index, 'employeesList', []);
    } finally {
      updateRow(index, 'loadingEmployees', false);
    }
  };

  const handleSearchChange = (e, index) => {
    const val = e.target.value;
    setRows(prev => {
      const next = [...prev];
      next[index] = {
        ...next[index],
        searchTerm:    val,
        employee:      null,
        department:    '',
        employeesList: val.trim().length < 2 ? [] : next[index].employeesList,
      };
      return next;
    });
    if (debounceTimers.current[index]) clearTimeout(debounceTimers.current[index]);
    if (val.trim().length >= 2)
      debounceTimers.current[index] = setTimeout(() => searchEmployees(val, index), 300);
  };

  const handleEmployeeSelect = (emp, index) => {
    setRows(prev => {
      const next = [...prev];
      next[index] = {
        ...next[index],
        employee:      emp,
        searchTerm:    emp.employeeName || '',
        department:    emp.department   || '',
        employeesList: [],
      };
      return next;
    });
  };

  const addRow = () => {
    debounceTimers.current.push(null);
    setRows(prev => [...prev, blankRow(prev.length + 1)]);
  };

  const removeRow = (index) => {
    debounceTimers.current.splice(index, 1);
    setRows(prev => prev.filter((_, i) => i !== index).map((r, i) => ({ ...r, seq: i + 1 })));
  };

  const handleFileChange = (e, index) => {
    const file = e.target.files?.[0]; if (!file) return;
    updateRow(index, 'profileFile', file);
    const reader = new FileReader();
    reader.onload = ev => updateRow(index, 'profilePreview', ev.target.result);
    reader.readAsDataURL(file);
  };

  const handleSubmit = async () => {
    const valid = rows.filter(r => r.employee);
    if (!valid.length) { alert('Please select at least one employee.'); return; }
    setSaving(true);
    try {
      await onSubmit(valid.map(r => ({
        awardYear:    awardYear,
        tenureType:   meta.type,
        empCode:      r.employee.empCode,
        employeeName: r.employee.employeeName,
        department:   r.department || '',
        profileFile:  r.profileFile,
      })));
      setRows([blankRow(1)]);
      debounceTimers.current = [null];
    } finally { setSaving(false); }
  };

  const handleClose = () => {
    navigate(-1);
  };

  return (
    <div>
     <div className=" bg-gradient-to-b from-red-900 to-red-700 text-white text-lg font-bold px-5 py-3 shadow-md flex justify-between items-center mt-16 pt-4">
        <div className="flex items-center gap-4">
          <span>Honor Club Award {awardYear} — {meta.label}</span>
        </div>
        <button
          onClick={handleClose}
          className="bg-white/20 hover:bg-white/30 text-white rounded-full p-2 transition-all duration-200 backdrop-blur-sm"
          aria-label="Close"
          title="Close"
        >
          <X size={18} />
        </button>
      </div>

      <div className="bg-white rounded-xl shadow-lg border border-gray-100 mt-6 overflow-hidden">
        <div className="bg-gray-50 border-b border-gray-100 px-5 py-3 flex justify-between items-center">
          <h3 className="text-sm font-bold text-gray-700">Nominees — {meta.label}</h3>
          <button
            onClick={addRow}
            className="text-xs bg-red-900 text-white px-3 py-1.5 rounded-lg hover:bg-red-800 transition-colors font-semibold shadow-sm"
          >
            + Add Employee
          </button>
        </div>

        <div className="p-5 space-y-4">
          {rows.map((row, index) => (
            <div key={row.seq} className="border border-gray-200 rounded-xl p-5 bg-gray-50/50 shadow-sm">
              <div className="flex justify-between items-center mb-4">
                <span className="text-xs font-semibold text-gray-500">Employee #{row.seq}</span>
                {rows.length > 1 && (
                  <button
                    onClick={() => removeRow(index)}
                    className="text-xs text-gray-400 border border-gray-300 px-2 py-0.5 rounded hover:text-red-600 hover:border-red-300 transition-colors"
                  >
                    Remove
                  </button>
                )}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="md:col-span-2">
                  <Label>Employee Name *</Label>
                  <div className="relative">
                    <Input
                      type="text"
                      autoComplete="off"
                      value={row.searchTerm}
                      onChange={e => handleSearchChange(e, index)}
                      placeholder="Type name or code..."
                    />
                    {row.loadingEmployees && (
                      <span className="absolute right-2 top-1/2 -translate-y-1/2 text-xs text-gray-400">
                        Searching...
                      </span>
                    )}
                    {row.employeesList.length > 0 && (
                      <EmpDropdown
                        list={row.employeesList}
                        onSelect={emp => handleEmployeeSelect(emp, index)}
                      />
                    )}
                  </div>
                  {row.employee && (
                    <p className="text-xs text-gray-400 mt-1">Code: {row.employee.empCode}</p>
                  )}
                </div>

                <div>
                  <Label>Department</Label>
                  <Input
                    value={row.department}
                    onChange={e => updateRow(index, 'department', e.target.value)}
                    placeholder="Auto-filled"
                    readOnly={!!row.employee?.department}
                  />
                </div>

                <div className="md:col-span-3">
                  <Label>Profile Image *</Label>
                  <div
                    className="border-2 border-dashed border-gray-300 rounded-lg p-3 text-center cursor-pointer hover:border-red-700 hover:bg-red-50 transition-colors"
                    onClick={() => document.getElementById(`pf-${index}`).click()}
                  >
                    <input
                      id={`pf-${index}`}
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={e => handleFileChange(e, index)}
                    />
                    {row.profilePreview ? (
                      <img src={row.profilePreview} alt="preview" className="h-16 max-w-full mx-auto object-cover rounded" />
                    ) : (
                      <div className="text-gray-400 text-xs">
                        <div className="text-2xl mb-1">📷</div>
                        <span className="font-semibold text-gray-600">Choose File</span>
                        <span className="ml-2 text-gray-400">{row.profileFile ? row.profileFile.name : 'No file chosen'}</span>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="px-5 pb-5 flex justify-end gap-3 bg-gray-50 border-t border-gray-100 pt-4">
          <button
            onClick={() => { setRows([blankRow(1)]); debounceTimers.current = [null]; }}
            className="text-sm border border-gray-300 text-gray-600 px-4 py-1.5 rounded-lg hover:bg-gray-100 transition-colors"
          >
            Reset
          </button>
          <button
            onClick={handleSubmit}
            disabled={saving}
            className="text-sm bg-red-900 text-white px-6 py-1.5 rounded-lg font-semibold hover:bg-red-800 disabled:opacity-50 transition-colors shadow-sm"
          >
            {saving ? 'Submitting...' : 'Submit Nomination'}
          </button>
        </div>
      </div>
    </div>
  );
}

const AddHonorClub = ({ onTenureSubmit }) => {
  const [screen, setScreen] = useState('home');
  const [awardYear, setAwardYear] = useState('');
  const [loadingYear, setLoadingYear] = useState(true);

  useEffect(() => {
    const loadFinancialYear = async () => {
      try {
        const response = await fetchCurrentFinancialYear();
        const yearLabel = response?.label || response?.financialYear || '2026-27';
        setAwardYear(yearLabel);
      } catch (error) {
        console.error('Failed to fetch financial year:', error);
        setAwardYear('2026-27');
      } finally {
        setLoadingYear(false);
      }
    };
    loadFinancialYear();
  }, []);

 const handleTenureSubmit = async (rows) => {

  try {

    for (const row of rows) {

      const formData = new FormData();

      formData.append(
        "awardYear",
        row.awardYear
      );

      formData.append(
        "honorClubType",
        row.tenureType
      );

      formData.append(
        "empCode",
        row.empCode
      );

      formData.append(
        "employeeName",
        row.employeeName
      );

      formData.append(
        "department",
        row.department
      );

      if (row.profileFile) {
        formData.append(
          "file",
          row.profileFile
        );
      }

      await HonorClubApi.saveHonorClubData(
        formData
      );
    }

    alert("Honor Club records saved successfully");

    setScreen("home");

  } catch (error) {

    console.error(error);

    alert(
      "Failed to save Honor Club data"
    );
  }
};

  if (loadingYear) {
    return (
      <div className="min-h-screen bg-gray-100 flex flex-col">
        <Header />
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center">Loading financial year...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col">
      <Header />
      <div className="flex-1 pt-4 px-6">
        {screen === 'home'      && <LandingScreen onNavigate={setScreen} awardYear={awardYear} />}
        {screen === 'tenure-10' && <TenureForm tenureType="10" onBack={() => setScreen('home')} onSubmit={handleTenureSubmit} awardYear={awardYear} />}
        {screen === 'tenure-20' && <TenureForm tenureType="20" onBack={() => setScreen('home')} onSubmit={handleTenureSubmit} awardYear={awardYear} />}
        {screen === 'tenure-25' && <TenureForm tenureType="25" onBack={() => setScreen('home')} onSubmit={handleTenureSubmit} awardYear={awardYear} />}
      </div>
    </div>
  );
};

export default AddHonorClub;