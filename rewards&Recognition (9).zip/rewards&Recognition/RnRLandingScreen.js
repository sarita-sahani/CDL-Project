import React, { useMemo } from "react";
import { useNavigate } from "react-router-dom";
import Header from "../components/Header";
import { Trophy, Star, ArrowRight } from "lucide-react";

// Deterministic starfield so it doesn't reshuffle on every re-render
const STARS = Array.from({ length: 90 }, (_, i) => {
  const seed = (i * 137.5) % 100;
  return {
    top: `${(seed * 3.7) % 100}%`,
    left: `${(seed * 5.3 + i * 2) % 100}%`,
    size: i % 7 === 0 ? 2 : 1,
    delay: `${(i % 10) * 0.4}s`,
    duration: `${3 + (i % 4)}s`,
  };
});

const RnRLandingScreen = () => {
  const navigate = useNavigate();
  const stars = useMemo(() => STARS, []);

  return (
    <>
      <Header />
      <div className="relative min-h-screen bg-[linear-gradient(180deg,#1a2a6c_0%,#3a1c47_40%,#7a1b2e_70%,#b91c1c_100%)] overflow-hidden mt-[70px]">
        {/* Starfield */}
        <div className="pointer-events-none absolute inset-0">
          {stars.map((s, i) => (
            <span
              key={i}
              className="absolute rounded-full bg-white motion-safe:animate-pulse"
              style={{
                top: s.top,
                left: s.left,
                width: s.size,
                height: s.size,
                opacity: 0.5,
                animationDelay: s.delay,
                animationDuration: s.duration,
              }}
            />
          ))}
        </div>

        {/* Ambient glows */}
        <div className="pointer-events-none absolute -top-24 -left-24 w-[420px] h-[420px] rounded-full bg-[#FFD700]/20 blur-[100px]" />
        <div className="pointer-events-none absolute -bottom-32 -right-24 w-[480px] h-[480px] rounded-full bg-[#FF6B35]/15 blur-[110px]" />

        <div className="relative z-10 flex flex-col items-center justify-center px-4 pt-20 pb-16 text-center">
          {/* Trophy badge */}
          <div className="relative w-[140px] h-[140px] mb-6">
            <div className="absolute inset-0 rounded-full border border-white/10" />
            <div className="absolute inset-[15px] rounded-full border border-dashed border-white/15" />
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="w-[88px] h-[88px] rounded-full bg-[#FFF9EE] shadow-[0_0_40px_rgba(251,191,36,0.25)] flex items-center justify-center">
                <Trophy size={34} className="text-amber-600" strokeWidth={1.75} />
              </div>
            </div>
            <div className="absolute inset-0 motion-safe:animate-[spin_7s_linear_infinite]">
              <span className="absolute top-1/2 left-full w-2.5 h-2.5 -translate-x-1/2 -translate-y-1/2 rounded-full bg-amber-400 shadow-[0_0_10px_2px_rgba(251,191,36,0.7)]" />
            </div>
          </div>

          {/* <p className="text-[11px] tracking-[0.25em] text-[#FFD700] font-semibold mb-3">
            CMS &middot; SIMPLIFYING LIFE
          </p> */}

          <h1 className="text-2xl md:text-4xl font-bold text-white leading-tight max-w-2xl">
            Welcome to your world of{" "}
            <span className="bg-clip-text text-transparent bg-gradient-to-r from-[#FFD700] to-[#FF6B35]">
              Rewards &amp;
            </span>
            <br className="hidden md:block" />{" "}
            <span className="bg-clip-text text-transparent bg-gradient-to-r from-[#FF6B35] to-rose-500">
              Recognition
            </span>
          </h1>

          <p className="mt-4 text-sm text-[#FFF5E6] max-w-md">
            One home for every way CMS says thank you &mdash; instant shout-outs, annual honours, and the milestones worth celebrating.
          </p>

          {/* Cards */}
          <div className="mt-10 flex flex-wrap justify-center gap-5">
            {/* Card 1 - Rewards & Recognition */}
            <div
              onClick={() => navigate("/rewards-and-recognition")}
              className="group cursor-pointer w-[290px] rounded-2xl bg-[linear-gradient(135deg,#FCE8DE_0%,#FBDCE8_55%,#E9E0F8_100%)] shadow-lg shadow-black/20 hover:shadow-[0_0_25px_rgba(255,107,53,0.35)] px-5 py-6 transition-all duration-300 hover:-translate-y-1"
            >
              <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-[#FF6B35] to-[#E85D2C] flex items-center justify-center shadow-md shadow-black/40 mb-4 group-hover:scale-110 transition-transform duration-300 mx-auto md:mx-0">
                <Trophy size={20} className="text-white" />
              </div>
              <h3 className="text-[#b91c1c] font-bold text-[16px] mb-2 md:text-left">Rewards &amp; Recognition</h3>
              <p className="text-gray-700 text-[13px] leading-relaxed mb-4 md:text-left">
                Start the A2B journey &mdash; program guidelines, your recognition dashboard, and instant appreciation, all in one flow.
              </p>
              <div className="flex items-center justify-center md:justify-start">
                <span className="inline-flex items-center gap-1.5 text-[13px] font-bold text-[#FF6B35] group-hover:text-[#E85D2C] transition-colors">
                  Start Journey
                  <ArrowRight size={14} className="transition-transform duration-300 group-hover:translate-x-1.5" />
                </span>
              </div>
            </div>

            {/* Card 2 - Wall of Fame */}
            <div
              onClick={() => navigate("/wallOfFame")}
              className="group cursor-pointer w-[290px] rounded-2xl bg-[linear-gradient(135deg,#FCE8DE_0%,#FBDCE8_55%,#E9E0F8_100%)] shadow-lg shadow-black/20 hover:shadow-[0_0_25px_rgba(255,107,53,0.35)] px-5 py-6 transition-all duration-300 hover:-translate-y-1"
            >
              <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-[#7a1b2e] to-[#b91c1c] border border-[#FF6B35]/50 flex items-center justify-center shadow-md shadow-black/40 mb-4 group-hover:scale-110 transition-transform duration-300 mx-auto md:mx-0">
                <Star size={20} className="text-[#FFD700]" />
              </div>
              <h3 className="text-[#b91c1c] font-bold text-[16px] mb-2 md:text-left">Wall of Fame</h3>
              <p className="text-gray-700 text-[13px] leading-relaxed mb-4 md:text-left">
                See who&apos;s shining this year &mdash; across World of Thanks, Bravo, Executive Circle and Honor Club.
              </p>
              <div className="flex items-center justify-center md:justify-start">
                <span className="inline-flex items-center gap-1.5 text-[13px] font-bold text-[#FF6B35] group-hover:text-[#E85D2C] transition-colors">
                  View Wall
                  <ArrowRight size={14} className="transition-transform duration-300 group-hover:translate-x-1.5" />
                </span>
              </div>
            </div>
          </div>
        </div>

        <div className="relative z-10 border-t border-white/5 py-4 text-center mt-6">
          <p className="text-[11px] text-[#FFF5E6]/50">
            CMS &middot; Above &amp; Beyond &mdash; a prototype reimagining of the Rewards &amp; Recognition experience
          </p>
        </div>
      </div>
    </>
  );
};

export default RnRLandingScreen;