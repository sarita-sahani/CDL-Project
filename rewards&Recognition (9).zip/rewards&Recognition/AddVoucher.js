import { useNavigate, useLocation } from "react-router-dom";
import * as XLSX from "xlsx";
import { saveAs } from "file-saver";

import { useState, useEffect,useRef, Fragment } from "react";
import { createPortal } from "react-dom";
import { Pencil, Trash2, PlusCircle, UploadCloud, FileSpreadsheet, X, Ticket, CheckCircle2, Archive, FileUp } from "lucide-react";
import Header from "../components/Header";
import RnRService from "./RnRService";
import Swal from "sweetalert2";
import "sweetalert2/dist/sweetalert2.min.css";


// --- Lightweight replacement for semantic-ui-react's Modal ---
// Renders via a portal straight into document.body so it always appears as a
// centered overlay popup, regardless of where it's placed in the page markup.
const SimpleModal = ({ open, onClose, size = "tiny", closeIcon = false, className = "", children }) => {
    if (!open) return null;

    const sizeClasses = {
        tiny: "max-w-sm",
        small: "max-w-md",
        large: "max-w-3xl",
    };

    return createPortal(
        <div
            className="fixed inset-0 z-[1000] flex items-center justify-center bg-black/50 p-4"
            onClick={onClose}
        >
            <div
                className={`relative w-full ${sizeClasses[size] || sizeClasses.tiny} bg-white rounded-xl shadow-2xl max-h-[90vh] overflow-y-auto ${className}`}
                onClick={(e) => e.stopPropagation()}
            >
                {closeIcon && (
                    <button
                        type="button"
                        onClick={onClose}
                        className="absolute top-3 right-3 text-slate-400 hover:text-slate-600 text-xl leading-none"
                        aria-label="Close"
                    >
                        &times;
                    </button>
                )}
                {children}
            </div>
        </div>,
        document.body
    );
};

const ModalContent = ({ className = "", children }) => (
    <div className={`px-6 ${className}`}>{children}</div>
);

const ModalActions = ({ className = "", children }) => (
    <div className={`flex justify-end gap-2 ${className}`}>{children}</div>
);

const AddVoucher = () => {
    const navigate = useNavigate();
    const location = useLocation();

    // --- State Management ---
    const [searchQuery, setSearchQuery] = useState("");
    const [columnFilters, setColumnFilters] = useState({});
    const [openFilterColumn, setOpenFilterColumn] = useState("");
    const [rowsPerPage, setRowsPerPage] = useState(10);
    const [currentPage, setCurrentPage] = useState(1);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [isBulkModalOpen, setIsBulkModalOpen] = useState(false);
    const [selectedFile, setSelectedFile] = useState(null);
    const [isEditModalOpen, setIsEditModalOpen] = useState(false);
    const [editFormData, setEditFormData] = useState({});
    const filterRef = useRef(null);

    // Initialize with empty array instead of hardcoded data
    const [data, setData] = useState([]);

    const [formData, setFormData] = useState({
        voucherCompany: "",
        voucherCode: "",
        voucherId: "",
        voucherValue: "",        
        expiryDate: ""
    });

    // --- 1. Fetch Data from Backend on Load ---
    const fetchVouchers = async () => {
        try {
            const response = await RnRService.getAllVouchers();
            setData(response.data);
        } catch (error) {
            console.error("Error fetching vouchers:", error);
            alert("Failed to load vouchers. Please check if the server is running.");
        }
    };

    useEffect(() => {
        fetchVouchers();
    }, []); // Empty dependency array means it runs once on mount


    // --- Logic for Display and Pagination ---
    const columnsMeta = [
        { value: "voucherCompany", label: "Company" },
       // { value: "voucherNumber", label: "Voucher No" },
        { value: "voucherCode", label: "Voucher Code" },
        { value: "voucherId", label: "Voucher ID" },
        { value: "voucherValue", label: "Value (₹)" },
        { value: "expiryDate", label: "Expiry Date" },
        { value: "usedBy", label: "Used By" },
        { value: "managerName", label: "Manager" },
        { value: "department", label: "Department" },
        { value: "voucherStatus", label: "Voucher Status" },
        { value: "usageStatus", label: "Usage Status" },
        { value: "Actions", label: "Actions" }
    ];

    useEffect(() => {
    const handleClickOutside = (e) => {
        if (filterRef.current && !filterRef.current.contains(e.target)) {
            setOpenFilterColumn("");
        }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
}, []);

   const displayData = data.filter((r) => {
    const query = searchQuery.trim().toLowerCase();
    const matchesSearch = !query || Object.values(r).some((v) =>
        String(v || "").toLowerCase().includes(query)
    );
    const matchesFilters = Object.entries(columnFilters).every(([key, values]) => {
        if (!values || values.length === 0) return true;
       // return values.includes(String(r[key] || ""));
        return values.some(v => v.toLowerCase() === String(r[key] || "").toLowerCase());
    });
    return matchesSearch && matchesFilters;
}).sort((a, b) => {
    const order = (row) => {
        if (row.usageStatus === "Unused" && row.voucherStatus === "Active") return 0;
        if (row.usageStatus === "Used") return 2;
        if (row.voucherStatus === "Expired") return 3;
        return 1;
    };
    return order(a) - order(b);
});

    const totalPages = Math.ceil(displayData.length / rowsPerPage);
    const paginatedData = displayData.slice(
        (currentPage - 1) * rowsPerPage,
        currentPage * rowsPerPage
    );

    const totalInventory = data.length;
    const activeVouchersCount = data.filter(v => v.voucherStatus === 'Active' && v.usageStatus === 'Unused').length;
    const redeemedVouchersCount = data.filter(v => v.usageStatus === 'Used').length;

    useEffect(() => {
        if (currentPage > totalPages) {
            setCurrentPage(totalPages || 1);
        }
    }, [rowsPerPage, displayData, totalPages, currentPage]);

    const getVoucherStatusStyle = (status) => {
        switch (status) {
            case "Active": return { background: "#e6fffa", color: "#2d6a4f" };
            case "Expired": return { background: "#fff5f5", color: "#c53030" };
            default: return {};
        }
    };

    const getUsageStatusStyle = (status) => {
        switch (status) {
            case "Used": return { background: "#e2e3e5", color: "#383d41" };
            case "Unused": return { background: "#ebf8ff", color: "#2b6cb0" };
            default: return {};
        }
    };

    const renderDataCell = (row, column, index) => {
        const baseClass = "py-3 px-2 text-slate-700";
        switch (column) {
            case "voucherValue":
                return (
                    <td key={index} className={baseClass + " font-semibold"}>
                        ₹{Number(row.voucherValue || 0).toLocaleString()}
                    </td>
                );
            case "voucherStatus":
                return (
                    <td key={index} className={baseClass}>
                        <span className="inline-flex items-center justify-center rounded-full px-3 py-1 text-[11px] font-semibold uppercase" style={getVoucherStatusStyle(row.voucherStatus)}>
                            {row.voucherStatus}
                        </span>
                    </td>
                );
            case "usageStatus":
                return (
                    <td key={index} className={baseClass}>
                        <span className="inline-flex items-center justify-center rounded-full px-3 py-1 text-[11px] font-semibold uppercase" style={getUsageStatusStyle(row.usageStatus)}>
                            {row.usageStatus}
                        </span>
                    </td>
                );
            
            case "voucherCode":
                return <td key={index} className={baseClass + " font-mono"}>{row.voucherCode}</td>;
                 case "voucherId":
                return <td key={index} className={baseClass + " font-mono"}>{row.voucherId}</td>
            case "Actions":
                return (
                    <td key={index} className="py-3 px-2">
                        <div className="flex items-center justify-center gap-2 whitespace-nowrap">
                            <button
                                onClick={() => {
                                    const formatted = row.expiryDate
                                        ? row.expiryDate.split("/").reverse().join("-")  // "31/12/2025" → "2025-12-31"
                                        : "";
                                    setEditFormData({ ...row, expiryDate: formatted });
                                    setIsEditModalOpen(true);
                                }}
                                className="inline-flex items-center justify-center h-8 w-8 rounded-md text-blue-600 hover:bg-blue-50 hover:text-blue-800 transition"
                                title="Edit"
                            >
                                <Pencil size={15} />
                            </button>
                            <button
                                onClick={() => handleDelete(row.id)}
                                className="inline-flex items-center justify-center h-8 w-8 rounded-md text-red-600 hover:bg-red-50 hover:text-red-800 transition"
                                title="Delete"
                            >
                                <Trash2 size={15} />
                            </button>
                        </div>
                    </td>
                );
            default:
                return <td key={index} className={baseClass}>{row[column] || '—'}</td>;
        }
    };

    const handleDelete = async (id) => {

    const result = await Swal.fire({
        title: "Are you sure?",
        text: "This voucher will be permanently deleted!",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#d33",
        cancelButtonColor: "#3085d6",
        confirmButtonText: "Yes, delete it!"
    });

    if (!result.isConfirmed) return;

    try {
        await RnRService.deleteVoucher(id);

        Swal.fire({
            icon: "success",
            title: "Deleted!",
            text: "Voucher has been deleted.",
            timer: 1500,
            showConfirmButton: false
        });

        fetchVouchers();
    } catch (error) {
        Swal.fire("Error", "Failed to delete voucher", "error");
    }
};
    const handleEditSubmit = async () => {
    const result = await Swal.fire({
        title: "Update Voucher?",
        text: `Do you want to update voucher ${editFormData.voucherCode}?`,
        icon: "question",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        confirmButtonText: "Yes, update it!"
    });

    
    if (!result.isConfirmed) return;
    const formatDate = (dateStr) => {
    const [year, month, day] = dateStr.split("-");
    return `${day}/${month}/${year}`;
};

    try {
        await RnRService.updateVoucher(editFormData.id, {
            voucherCompany: editFormData.voucherCompany,
            voucherCode: editFormData.voucherCode,
            voucherId: editFormData.voucherId,
            voucherValue: Number(editFormData.voucherValue),
            expiryDate: formatDate(editFormData.expiryDate),
        });
        fetchVouchers();
        setIsEditModalOpen(false);
        Swal.fire("Updated!", "Voucher has been updated successfully.", "success");
    } catch (error) {
        console.error("Error updating voucher:", error);
        Swal.fire("Error", "Failed to update voucher.", "error");
    }
};
  const toggleColumnFilterValue = (column, value) => {
    setColumnFilters((prev) => {
        const existing = prev[column] || [];
        const updated = existing.includes(value)
            ? existing.filter((v) => v !== value)
            : [...existing, value];
        return { ...prev, [column]: updated };
    });
    setOpenFilterColumn("");
    setCurrentPage(1);
};

const clearColumnFilter = (column) => {
    setColumnFilters((prev) => {
        const next = { ...prev };
        delete next[column];
        return next;
    });
    setOpenFilterColumn("");
    setCurrentPage(1);
};

    const handleFormChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    // --- 2. Post Single Voucher to Backend ---
   const handleAddVoucherSubmit = async () => {
    if (!formData.voucherCode ||!formData.voucherId || !formData.voucherValue || !formData.expiryDate) {
        Swal.fire("Missing Fields", "Please fill all required fields", "warning");
        return;
    }

    const result = await Swal.fire({
        title: "Add Voucher?",
        text: `Do you want to add voucher ${formData.voucherCode}?`,
        icon: "question",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        confirmButtonText: "Yes, add it!"
    });

    if (!result.isConfirmed) return;
    const formatDate = (dateStr) => {
    const [year, month, day] = dateStr.split("-");
    return `${day}/${month}/${year}`;
};

    const payload = {
        voucherCode: formData.voucherCode,
        voucherValue: Number(formData.voucherValue),
        voucherId: formData.voucherId, 
        expiryDate: formatDate(formData.expiryDate),
        voucherCompany: formData.voucherCompany || "N/A"
    };

    try {
        await RnRService.addVoucher(payload);
        fetchVouchers();
        setIsModalOpen(false);
        setFormData({ voucherCompany: "", voucherCode: "",voucherId: "", voucherValue: "", expiryDate: "" });
        Swal.fire("Added!", "Voucher has been added successfully.", "success");
    } catch (error) {
        console.error("Error saving voucher:", error);
        Swal.fire("Error", "Failed to save voucher.", "error");
    }
};

    // --- Excel Handling (Export rows filtered by column/filter criteria, but include all columns) ---
    const handleExcelExport = () => {
        const exportData = displayData.map((r) => ({
            "Voucher Company": r.voucherCompany,
            // "Voucher Number": r.voucherNumber,
            "Voucher Code": r.voucherCode,
            "Voucher ID": r.voucherId,
            "Value": r.voucherValue,
            "Expiry Date": r.expiryDate,
            "Used By": r.usedBy,
            "Manager": r.managerName,
            "Department": r.department,
            "Voucher Status": r.voucherStatus,
            "Usage Status": r.usageStatus,
        }));

        const worksheet = XLSX.utils.json_to_sheet(exportData);
        const workbook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(workbook, worksheet, "VoucherInventory");

        const excelBuffer = XLSX.write(workbook, { bookType: "xlsx", type: "array" });
        const file = new Blob([excelBuffer], { type: "application/octet-stream" });
        saveAs(file, `Voucher_Inventory_Report_${new Date().toLocaleDateString()}.xlsx`);
    };

    // --- 3. Post Bulk Vouchers to Backend ---
   const handleBulkUploadSubmit = async () => {
    if (!selectedFile) {
        Swal.fire("No File Selected", "Please select an Excel file to upload.", "warning");
        return;
    }

    const result = await Swal.fire({
        title: "Upload Vouchers?",
        text: `Are you sure you want to bulk upload "${selectedFile.name}"?`,
        icon: "question",
        showCancelButton: true,
        confirmButtonColor: "#0284c7",
        cancelButtonColor: "#d33",
        confirmButtonText: "Yes, upload it!"
    });

    if (!result.isConfirmed) return;

    const reader = new FileReader();
    reader.onload = async (evt) => {
        try {
            const dataBuffer = new Uint8Array(evt.target.result);
            const workbook = XLSX.read(dataBuffer, { type: "array" });
            const sheet = workbook.Sheets[workbook.SheetNames[0]];
            const jsonData = XLSX.utils.sheet_to_json(sheet);

            const formattedData = jsonData.map((row) => ({
                voucherCode: row["Voucher Code"] || "",
                voucherId: row["Voucher ID"] || "",
                voucherCompany: row["Voucher Company"] || "",
                voucherValue: Number(row["Value"]) || 0,
                expiryDate: row["Expiry Date"] || ""
            }));

            await RnRService.addBulkVouchers(formattedData);

            fetchVouchers();
            setCurrentPage(1);
            setIsBulkModalOpen(false);
            setSelectedFile(null);

            Swal.fire({
                icon: "success",
                title: "Upload Successful!",
                text: `${formattedData.length} vouchers have been uploaded.`,
                timer: 2000,
                showConfirmButton: false
            });
        } catch (error) {
            console.error("Error processing bulk upload:", error);
            Swal.fire("Error", "Failed to process Excel upload. Please check the file format.", "error");
        }
    };
    reader.readAsArrayBuffer(selectedFile);
};

    return (
        <Fragment>
            <div className="bg-slate-50 min-h-screen font-sans pt-[70px]">
                <Header />

                {/* Second fixed red header bar (below the main header) */}
            <div
  className="w-full bg-gradient-to-b from-red-900 to-red-700 text-white px-6 py-3 flex items-center justify-between shadow-sm mb-6"
  style={{ minHeight: "48px" }}
>
  <span className="text-sm font-semibold">Voucher Records</span>

  <button
    onClick={() => navigate(-1)}
    className="border border-white px-3 py-1 text-xs rounded-md text-white bg-transparent hover:bg-white/10 transition"
  >
    Back
  </button>
</div>
                {/* Main page content area */}
               <main className="w-full px-4 sm:px-6 lg:px-8 pb-10">

                    {/* QUICK STATS CARDS (Dynamicized from data) */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-5 mb-6">
                        <div className="bg-white p-5 rounded-xl shadow-sm border-l-4 border-blue-500 hover:shadow-md transition-shadow flex items-center justify-between">
                            <div>
                                <div className="text-[11px] font-semibold uppercase tracking-[0.4em] mb-2 text-blue-600">TOTAL VOUCHERS</div>
                                <div className="text-3xl font-bold text-slate-900">{totalInventory}</div>
                            </div>
                            <div className="h-11 w-11 rounded-full bg-blue-50 flex items-center justify-center">
                                <Ticket size={20} className="text-blue-500" />
                            </div>
                        </div>
                        <div className="bg-white p-5 rounded-xl shadow-sm border-l-4 border-emerald-500 hover:shadow-md transition-shadow flex items-center justify-between">
                            <div>
                                <div className="text-[11px] font-semibold uppercase tracking-[0.4em] mb-2 text-emerald-700">ACTIVE VOUCHERS</div>
                                <div className="text-3xl font-bold text-slate-900">{activeVouchersCount}</div>
                            </div>
                            <div className="h-11 w-11 rounded-full bg-emerald-50 flex items-center justify-center">
                                <CheckCircle2 size={20} className="text-emerald-600" />
                            </div>
                        </div>
                        <div className="bg-white p-5 rounded-xl shadow-sm border-l-4 border-amber-400 hover:shadow-md transition-shadow flex items-center justify-between">
                            <div>
                                <div className="text-[11px] font-semibold uppercase tracking-[0.4em] mb-2 text-amber-700">REDEEMED/USED</div>
                                <div className="text-3xl font-bold text-slate-900">{redeemedVouchersCount}</div>
                            </div>
                            <div className="h-11 w-11 rounded-full bg-amber-50 flex items-center justify-center">
                                <Archive size={20} className="text-amber-600" />
                            </div>
                        </div>
                    </div>

                    {/* MAIN INVENTORY CARD SECTION */}
                    <div className="bg-white rounded-xl shadow-sm p-6 mb-6">

                        {/* Control Bar */}
                        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 mb-5 pb-4 border-b border-slate-200">
                            {/* Left Side: Entries & Excel Export */}
                            <div className="flex flex-wrap items-center gap-3 text-sm text-slate-700">
                                <span>Show</span>
                                <select
                                    value={rowsPerPage}
                                    onChange={(e) => { setRowsPerPage(Number(e.target.value)); setCurrentPage(1); }}
                                    className="px-3 py-2 text-sm border border-slate-300 rounded-md bg-white"
                                >
                                    {[10, 25, 50, 100].map(n => <option key={n} value={n}>{n}</option>)}
                                </select>
                                <span>entries</span>
                                <button
                                    onClick={handleExcelExport}
                                    className="inline-flex items-center gap-1.5 justify-center rounded-md bg-emerald-500 px-4 py-2 text-xs font-semibold text-white shadow-sm hover:bg-emerald-600 hover:shadow transition"
                                >
                                    <FileSpreadsheet size={14} />
                                    Excel Export
                                </button>
                            </div>

                            {/* Right Side: Search and action buttons */}
                            <div className="flex flex-wrap items-center gap-3">
                                <input
                                    type="search"
                                    value={searchQuery}
                                    placeholder="Search vouchers..."
                                    onChange={(e) => { setSearchQuery(e.target.value); setCurrentPage(1); }}
                                    className="px-3 py-2 border border-slate-300 rounded-md text-sm w-full sm:w-auto focus:outline-none focus:ring-2 focus:ring-red-200 focus:border-red-400 transition"
                                />
                                <button
                                    type="button"
                                    onClick={() => setIsModalOpen(true)}
                                    className="inline-flex items-center gap-1.5 rounded-md bg-red-700 px-4 py-2 text-xs font-semibold text-white shadow-sm hover:bg-red-800 hover:shadow transition"
                                >
                                    <PlusCircle size={14} />
                                    Add Voucher
                                </button>
                                <button
                                    onClick={() => setIsBulkModalOpen(true)}
                                    className="inline-flex items-center gap-1.5 rounded-md bg-sky-600 px-4 py-2 text-xs font-semibold text-white shadow-sm hover:bg-sky-700 hover:shadow transition"
                                >
                                    <UploadCloud size={14} />
                                    Bulk Upload
                                </button>
                            </div>
                        </div>

                        {/* DATA TABLE */}
                        <div className="overflow-x-auto rounded-lg border border-slate-200" ref={filterRef}>
                            <table className="w-full min-w-[900px] text-xs text-slate-700">
                                <thead className="bg-slate-100">
                                    <tr>
                                        <th className="py-3 px-2 text-xs font-semibold uppercase tracking-wide text-slate-500 text-center">Sr.No</th>
                                        {columnsMeta.map((col) => (
                                            <th key={col.value} className="py-3 px-2 text-xs font-semibold uppercase tracking-wide text-slate-500 text-left relative">
                                               <div className="flex items-center gap-2">
    <span>{col.label}</span>
    {col.value !== "Actions" && (
        <button
            type="button"
            className="text-slate-500 hover:text-slate-900"
            onClick={() => setOpenFilterColumn(openFilterColumn === col.value ? "" : col.value)}
        >
            <svg className="h-3.5 w-3.5" viewBox="0 0 10 6" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M1 1L5 5L9 1" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
        </button>
    )}
</div>
                                               {openFilterColumn === col.value && (
    <div className="absolute top-full left-0 z-50 mt-2 w-56 rounded-xl border border-slate-200 bg-white p-3 shadow-lg">
        <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-slate-500">Filter {col.label}</span>
            <button
                type="button"
                onClick={() => clearColumnFilter(col.value)}
                className="text-xs text-red-500 hover:text-red-700 font-medium"
            >
                Clear
            </button>
        </div>
        <div className="space-y-1 max-h-48 overflow-y-auto">
            {Array.from(new Set(data.map((row) => String(row[col.value] || ""))))
                .filter((v) => v !== "" && v !== "null")
                .sort((a, b) => a.localeCompare(b))
                .map((value) => {
                    const selected = (columnFilters[col.value] || []).includes(value);
                    return (
                        <label
                            key={value}
                            className="flex items-center gap-2 px-2 py-1 rounded-md hover:bg-slate-100 cursor-pointer text-sm text-slate-700"
                        >
                            <input
                                type="checkbox"
                                checked={selected}
                                onChange={() => toggleColumnFilterValue(col.value, value)}
                                className="accent-sky-600 w-3.5 h-3.5"
                            />
                            {value}
                        </label>
                    );
                })}
        </div>
    </div>
)}
                                            </th>
                                        ))}
                                    </tr>
                                </thead>
                                <tbody>
                                    {paginatedData.length === 0 ? (
                                        <tr><td colSpan={columnsMeta.length + 1} className="py-10 text-center text-slate-500">No records found</td></tr>
                                    ) : (
                                        paginatedData.map((r, i) => (
                                            <tr key={i} className="odd:bg-white even:bg-slate-50/70 border-b border-slate-100 hover:bg-red-50/60 transition-colors duration-150">
                                                <td className="py-3 px-2 text-center text-slate-500">{(currentPage - 1) * rowsPerPage + i + 1}</td>
                                                {columnsMeta.map((col) => renderDataCell(r, col.value, col.value))}
                                            </tr>
                                        ))
                                    )}
                                </tbody>
                            </table>
                        </div>

                        {/* PAGINATION SECTION */}
                        <div className="mt-5 flex flex-col md:flex-row items-center justify-between gap-3 text-sm text-slate-600">
                            <span>Showing {(currentPage - 1) * rowsPerPage + 1} to {Math.min(currentPage * rowsPerPage, displayData.length)} of {displayData.length} entries</span>
                            <div className="flex flex-wrap items-center gap-2">
                                <button
                                    onClick={() => setCurrentPage(1)}
                                    disabled={currentPage === 1}
                                    className="rounded-md border border-slate-300 bg-white px-3 py-1 text-xs transition disabled:opacity-50 disabled:cursor-not-allowed"
                                >&lt;&lt;</button>
                                {Array.from({ length: totalPages }, (_, i) => (
                                    <button
                                        key={i}
                                        onClick={() => setCurrentPage(i + 1)}
                                        className={`rounded-md px-3 py-1 text-xs transition ${currentPage === i + 1 ? 'border border-sky-600 bg-sky-600 text-white font-semibold' : 'border border-slate-300 bg-white text-slate-700'}`}
                                    >
                                        {i + 1}
                                    </button>
                                ))}
                                <button
                                    onClick={() => setCurrentPage(totalPages)}
                                    disabled={currentPage === totalPages || totalPages === 0}
                                    className="rounded-md border border-slate-300 bg-white px-3 py-1 text-xs transition disabled:opacity-50 disabled:cursor-not-allowed"
                                >&gt;&gt;</button>
                            </div>
                        </div>
                    </div>
                </main>

                {/* <footer className="bg-red-700 border-t border-red-800 text-white text-center py-3 text-[11px]">
                    Copyright &copy; 2025 CMS Computers Limited. All Rights Reserved.
                </footer> */}
            </div>

            {/* --- MODAL 1: ADD VOUCHER --- */}
            <SimpleModal open={isModalOpen} onClose={() => setIsModalOpen(false)} size="small" className="rounded-xl overflow-hidden">
                <div className="flex items-center justify-between gap-3 bg-gradient-to-r from-red-900 to-red-700 px-6 py-4">
                    <div className="flex items-center gap-3">
                        <div className="h-9 w-9 rounded-full bg-white/15 flex items-center justify-center">
                            <PlusCircle size={18} className="text-white" />
                        </div>
                        <div>
                            <h3 className="text-white text-base font-semibold leading-tight">Add Voucher</h3>
                            <p className="text-white/70 text-xs">Create a new voucher record</p>
                        </div>
                    </div>
                    <button
                        type="button"
                        onClick={() => setIsModalOpen(false)}
                        className="text-white/80 hover:text-white hover:bg-white/10 rounded-full p-1 transition"
                        aria-label="Close"
                    >
                        <X size={18} />
                    </button>
                </div>
                <ModalContent className="py-5">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-5 gap-y-4">
                        <div>
                            <label className="block text-xs font-semibold text-slate-600 mb-1.5">Company</label>
                            <input
                                name="voucherCompany"
                                value={formData.voucherCompany}
                                onChange={handleFormChange}
                                placeholder="Enter Company"
                                className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-red-200 focus:border-red-400 transition"
                            />
                        </div>

                        <div>
                            <label className="block text-xs font-semibold text-slate-600 mb-1.5">Voucher Code</label>
                            <input
                                name="voucherCode"
                                value={formData.voucherCode}
                                onChange={handleFormChange}
                                placeholder="Enter Voucher Code"
                                className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-red-200 focus:border-red-400 transition"
                            />
                        </div>

                        <div>
                            <label className="block text-xs font-semibold text-slate-600 mb-1.5">Voucher ID</label>
                            <input
                                name="voucherId"
                                value={formData.voucherId}
                                onChange={handleFormChange}
                                placeholder="Enter Voucher ID"
                                className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-red-200 focus:border-red-400 transition"
                            />
                        </div>

                        <div>
                            <label className="block text-xs font-semibold text-slate-600 mb-1.5">Voucher Value</label>
                            <select
                                name="voucherValue"
                                value={formData.voucherValue}
                                onChange={handleFormChange}
                                className="w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-red-200 focus:border-red-400 transition"
                            >
                                <option value="">Select value</option>
                                <option value="500">500</option>
                                <option value="1000">1000</option>
                                <option value="1500">1500</option>
                            </select>
                        </div>

                        <div className="sm:col-span-2">
                            <label className="block text-xs font-semibold text-slate-600 mb-1.5">Expiry Date</label>
                            <input
                                type="date"
                                name="expiryDate"
                                value={formData.expiryDate}
                                onChange={handleFormChange}
                                className="w-full sm:w-1/2 rounded-md border border-slate-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-red-200 focus:border-red-400 transition"
                            />
                        </div>
                    </div>
                </ModalContent>
                <ModalActions className="border-t border-slate-200 bg-slate-50 px-6 py-4">
                    <button className="rounded-md border border-slate-300 bg-white px-4 py-2 text-sm font-semibold text-slate-700 hover:bg-slate-100 transition" onClick={() => setIsModalOpen(false)}>Cancel</button>
                    <button className="rounded-md bg-red-700 px-4 py-2 text-sm font-semibold text-white hover:bg-red-800 transition" onClick={handleAddVoucherSubmit}>Save Voucher</button>
                </ModalActions>
            </SimpleModal>

            {/* --- MODAL 2: BULK UPLOAD (Working Excel Import) --- */}
            <SimpleModal open={isBulkModalOpen} onClose={() => setIsBulkModalOpen(false)} size="small" className="rounded-xl overflow-hidden">
                <div className="flex items-center justify-between gap-3 bg-gradient-to-r from-sky-700 to-sky-600 px-6 py-4">
                    <div className="flex items-center gap-3">
                        <div className="h-9 w-9 rounded-full bg-white/15 flex items-center justify-center">
                            <UploadCloud size={18} className="text-white" />
                        </div>
                        <div>
                            <h3 className="text-white text-base font-semibold leading-tight">Bulk Upload Vouchers</h3>
                            <p className="text-white/70 text-xs">Import multiple vouchers from Excel</p>
                        </div>
                    </div>
                    <button
                        type="button"
                        onClick={() => setIsBulkModalOpen(false)}
                        className="text-white/80 hover:text-white hover:bg-white/10 rounded-full p-1 transition"
                        aria-label="Close"
                    >
                        <X size={18} />
                    </button>
                </div>
                <ModalContent className="py-5">
                    <div className="flex flex-col gap-4">
                        <p className="text-sm text-slate-600">Select an Excel (.xlsx) file containing voucher data. The file should have columns for 'Voucher Code', 'Value', and 'Expiry Date'.</p>
                        <label
                            htmlFor="bulkVoucherFile"
                            className="flex flex-col items-center justify-center gap-2 rounded-xl border-2 border-dashed border-sky-300 bg-sky-50/60 px-4 py-8 text-center cursor-pointer hover:bg-sky-50 hover:border-sky-400 transition"
                        >
                            <FileUp size={26} className="text-sky-500" />
                            <span className="text-sm font-medium text-slate-700">
                                {selectedFile ? selectedFile.name : "Click to select or drop an Excel file"}
                            </span>
                            <span className="text-xs text-slate-400">.xlsx or .xls</span>
                            <input
                                id="bulkVoucherFile"
                                type="file"
                                accept=".xlsx, .xls"
                                onChange={(e) => setSelectedFile(e.target.files[0])}
                                className="hidden"
                            />
                        </label>
                        {selectedFile && <div className="text-sm font-semibold text-emerald-700">Ready to upload: {selectedFile.name}</div>}
                    </div>
                </ModalContent>
                <ModalActions className="border-t border-slate-200 bg-slate-50 px-6 py-4">
                    <button className="rounded-md border border-slate-300 bg-white px-4 py-2 text-sm font-semibold text-slate-700 hover:bg-slate-100 transition" onClick={() => setIsBulkModalOpen(false)}>Close</button>
                    <button
                        className={`rounded-md px-4 py-2 text-sm font-semibold text-white transition ${selectedFile ? 'bg-sky-600 hover:bg-sky-700' : 'bg-slate-300 cursor-not-allowed'}`}
                        onClick={handleBulkUploadSubmit}
                        disabled={!selectedFile}
                    >
                        Process Upload
                    </button>
                </ModalActions>
            </SimpleModal>
            <SimpleModal open={isEditModalOpen} onClose={() => setIsEditModalOpen(false)} size="small" className="rounded-xl overflow-hidden">
                <div className="flex items-center justify-between gap-3 bg-gradient-to-r from-slate-800 to-slate-700 px-6 py-4">
                    <div className="flex items-center gap-3">
                        <div className="h-9 w-9 rounded-full bg-white/15 flex items-center justify-center">
                            <Pencil size={16} className="text-white" />
                        </div>
                        <div>
                            <h3 className="text-white text-base font-semibold leading-tight">Edit Voucher</h3>
                            <p className="text-white/70 text-xs">Update voucher details</p>
                        </div>
                    </div>
                    <button
                        type="button"
                        onClick={() => setIsEditModalOpen(false)}
                        className="text-white/80 hover:text-white hover:bg-white/10 rounded-full p-1 transition"
                        aria-label="Close"
                    >
                        <X size={18} />
                    </button>
                </div>
                <ModalContent className="py-5">
                    <div>
                        <div className="flex items-center gap-4 mb-4">
                            <label className="w-40 text-sm font-semibold text-slate-700">Company:</label>
                            <input
                                value={editFormData.voucherCompany || ""}
                                onChange={(e) => setEditFormData(p => ({ ...p, voucherCompany: e.target.value }))}
                                className="flex-1 rounded-md border border-slate-300 px-3 py-2 text-sm"
                            />
                        </div>
                        <div className="flex items-center gap-4 mb-4">
                            <label className="w-40 text-sm font-semibold text-slate-700">Voucher Code:</label>
                            <input
                                value={editFormData.voucherCode || ""}
                                onChange={(e) => setEditFormData(p => ({ ...p, voucherCode: e.target.value }))}
                                className="flex-1 rounded-md border border-slate-300 px-3 py-2 text-sm"
                            />
                        </div>
                         <div className="flex items-center gap-4 mb-4">
                            <label className="w-40 text-sm font-semibold text-slate-700">Voucher ID:</label>
                            <input
                                value={editFormData.voucherId || ""}
                                onChange={(e) => setEditFormData(p => ({ ...p, voucherId: e.target.value }))}
                                className="flex-1 rounded-md border border-slate-300 px-3 py-2 text-sm"
                            />
                        </div>
                        <div className="flex items-center gap-4 mb-4">
                            <label className="w-40 text-sm font-semibold text-slate-700">Voucher Value:</label>
                            <select
                                value={editFormData.voucherValue || ""}
                                onChange={(e) => setEditFormData(p => ({ ...p, voucherValue: e.target.value }))}
                                className="flex-1 rounded-md border border-slate-300 bg-white px-3 py-2 text-sm"
                            >
                                <option value="500">500</option>
                                <option value="1000">1000</option>
                                <option value="1500">1500</option>
                            </select>
                        </div>
                        <div className="flex items-center gap-4 mb-4">
                            <label className="w-40 text-sm font-semibold text-slate-700">Expiry Date:</label>
                            <input
                                type="date"
                                value={editFormData.expiryDate || ""}
                                onChange={(e) => setEditFormData(p => ({ ...p, expiryDate: e.target.value }))}
                                className="flex-1 rounded-md border border-slate-300 px-3 py-2 text-sm"
                            />
                        </div>
                    </div>
                </ModalContent>
                <ModalActions className="border-t bg-slate-50 px-6 py-4">
                    <button className="rounded-md border px-4 py-2 text-sm font-semibold text-slate-700 hover:bg-slate-100" onClick={() => setIsEditModalOpen(false)}>Cancel</button>
                    <button className="rounded-md bg-sky-600 px-4 py-2 text-sm font-semibold text-white hover:bg-sky-700 ml-2" onClick={handleEditSubmit}>Update</button>
                </ModalActions>
            </SimpleModal>
        </Fragment>
    );
};

export default AddVoucher;