////deepseek////

import React, { useState, useEffect } from "react";
import { useNavigate,useLocation } from "react-router-dom";
import Header from "../components/Header";
import RnRService from "./RnRService";
import { fetchCurrentFinancialYear, getAwardWinners } from "./ExecutiveCircle/ExecuitiveCircleApi";
import HonorClubApi from "./HonorClub/HonorclubApi";
import { ArrowLeft, Trophy, Star, Medal, Award, Crown, ChevronRight, ExternalLink, Heart, Zap } from "lucide-react";
import { simpleEncrypt } from "../simpleEncrypt";
import { BASE_URL } from "../config/Config";

const dmsAccessURL = `${BASE_URL}:9023`;

const fallbackImageUrl = "https://militaryhealthinstitute.org/wp-content/uploads/sites/37/2021/08/blank-profile-picture-png.png";

// ─── Image cache for Honor Club docId-based photos (same DMS lookup as HonorClubList) ──
const honorClubImageCache = new Map();

const fetchHonorClubImage = async (docId) => {
  if (!docId) return null;
  if (honorClubImageCache.has(docId)) return honorClubImageCache.get(docId);

  try {
    const response = await fetch(`${dmsAccessURL}/documents/access`, {
      method: "GET",
      headers: {
        "X-DOC-TOKEN": simpleEncrypt(docId.toString()),
      },
    });

    if (!response.ok) throw new Error("Failed to fetch image");

    const blob = await response.blob();
    const url = URL.createObjectURL(blob);
    honorClubImageCache.set(docId, url);
    return url;
  } catch (error) {
    console.error("Error fetching Honor Club image for docId:", docId, error);
    return null;
  }
};

const WallOfFame = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const empCode = localStorage.getItem("empId");

  // ─── State ──────────────────────────────────────────────────────────────
  const [activeCategory, setActiveCategory] = useState("worldOfThanks");
  const [loading, setLoading] = useState(false);
  const [financialYear, setFinancialYear] = useState("");
  
  // World of Thanks & Bravo
  const [worldOfThanksList, setWorldOfThanksList] = useState([]);
  const [bravoList, setBravoList] = useState([]);
  const [employeeMap, setEmployeeMap] = useState({});
  const [countsMap, setCountsMap] = useState({});

  // Executive Circle - Category wise
  const [executiveCategories, setExecutiveCategories] = useState([]);
  const [selectedExecCategory, setSelectedExecCategory] = useState(null);
  const [executiveEmpMap, setExecutiveEmpMap] = useState({});

  // Honor Club
  const [honorClubMembers, setHonorClubMembers] = useState([]);
  const [honorClubSections, setHonorClubSections] = useState([]);
  const [honorClubImageMap, setHonorClubImageMap] = useState({});

  // ─── Load Financial Year ──────────────────────────────────────────────
  useEffect(() => {
    const loadFY = async () => {
      try {
        const response = await fetchCurrentFinancialYear();
        setFinancialYear(response?.label || response || "2026-27");
      } catch (error) {
        setFinancialYear("2026-27");
      }
    };
    loadFY();
  }, []);

  // ─── Load World of Thanks & Bravo ─────────────────────────────────────
  useEffect(() => {
    const fetchAwards = async () => {
      setLoading(true);
      try {
        const res = await RnRService.getAllRecognitionsList(0, 100);
        setWorldOfThanksList(res.data?.worldofthanks || []);
        setBravoList(res.data?.bravo || []);
      } catch (error) {
        console.error("Error fetching recognitions:", error);
      } finally {
        setLoading(false);
      }
    };
    fetchAwards();
  }, []);

  // ─── Fetch employee data ──────────────────────────────────────────────
  const getEmployeeData = async (empCode) => {
    if (employeeMap[empCode]) return;
    try {
      const res = await RnRService.employeeInfoData(empCode);
      const fileData = res.data?.fileAndObjectTypeBean?.fileAndContentTypeBean?.file;
      const emp = res.data?.fileAndObjectTypeBean?.empResDTO || {};
      const empData = {
        ...emp,
        department: emp?.mainDeptResDTO?.mainDepartment,
        designation: emp?.designationResDTO?.designationName,
        profileImage: fileData ? `data:image/png;base64,${fileData}` : fallbackImageUrl,
      };
      setEmployeeMap((prev) => ({ ...prev, [empCode]: empData }));
    } catch (error) {}
  };

  useEffect(() => {
    [...worldOfThanksList, ...bravoList].forEach((item) => {
      getEmployeeData(item.empCode);
    });
  }, [worldOfThanksList, bravoList]);

  // ─── Load Executive Circle Winners - Category Wise ────────────────────
  useEffect(() => {
    if (!financialYear) return;
    const loadExecutiveWinners = async () => {
      try {
        const res = await getAwardWinners(financialYear);
        const winners = res?.data || [];

        const categoryMap = {};
        winners.forEach((item) => {
          const categoryName = item.awardTitle || "Uncategorized";
          if (!categoryMap[categoryName]) {
            categoryMap[categoryName] = {
              awardTitle: categoryName,
              winners: [],
            };
          }
          (item.winners || []).forEach((winner) => {
            categoryMap[categoryName].winners.push({
              ...winner,
              rank: winner.rank || null,
              reasonForNomination: winner.reasonForNomination || winner.reason || "",
            });
          });
        });

        const categories = Object.values(categoryMap).map((cat) => ({
          ...cat,
          winners: cat.winners.sort((a, b) => (a.rank || 999) - (b.rank || 999)),
        }));

        setExecutiveCategories(categories);
        
        if (categories.length > 0) {
          setSelectedExecCategory(categories[0]);
        }

        categories.forEach((cat) => {
          cat.winners.forEach((winner) => {
            if (winner.nomineeEmployeeCode) {
              getExecutiveEmployeeData(winner.nomineeEmployeeCode, winner.nomineeName);
            }
          });
        });
      } catch (error) {
        console.error("Error loading executive winners:", error);
      }
    };
    loadExecutiveWinners();
  }, [financialYear]);

  // ─── Executive employee data ──────────────────────────────────────────
  const getExecutiveEmployeeData = async (empCode, name) => {
    if (executiveEmpMap[empCode]) return;
    try {
      const res = await RnRService.employeeInfoData(empCode);
      const fileData = res.data?.fileAndObjectTypeBean?.fileAndContentTypeBean?.file;
      const emp = res.data?.fileAndObjectTypeBean?.empResDTO || {};
      const empData = {
        ...emp,
        department: emp?.mainDeptResDTO?.mainDepartment,
        designation: emp?.designationResDTO?.designationName,
        profileImage: fileData ? `data:image/png;base64,${fileData}` : fallbackImageUrl,
      };
      setExecutiveEmpMap((prev) => ({ ...prev, [empCode]: empData }));
    } catch (error) {}
  };

  // ─── Load Honor Club ──────────────────────────────────────────────────
  useEffect(() => {
    if (!financialYear) return;
    const loadHonorClub = async () => {
      try {
        const response = await HonorClubApi.getByYear(financialYear);
        const data = response?.data?.data || [];

        const sections = [
          {
            id: "ten_years",
            label: "Long Service – 10 Years",
            members: data
              .filter((item) => item.honorClubType === "TEN_YEARS")
              .map((item) => ({
                id: item.id,
                name: item.employeeName,
                dept: item.department,
                badge: "10 Years",
                docId: item.docId,
              })),
          },
          {
            id: "twenty_years",
            label: "Long Service – 20 Years",
            members: data
              .filter((item) => item.honorClubType === "TWENTY_YEARS")
              .map((item) => ({
                id: item.id,
                name: item.employeeName,
                dept: item.department,
                badge: "20 Years",
                docId: item.docId,
              })),
          },
          {
            id: "twenty_five_years",
            label: "Long Service – 25 Years",
            members: data
              .filter((item) => item.honorClubType === "TWENTY_FIVE_YEARS")
              .map((item) => ({
                id: item.id,
                name: item.employeeName,
                dept: item.department,
                badge: "25 Years",
                docId: item.docId,
              })),
          },
        ];

        setHonorClubSections(sections);
        setHonorClubMembers(data);
      } catch (error) {
        console.error("Error loading honor club:", error);
      }
    };
    loadHonorClub();
  }, [financialYear]);

  // ─── Resolve Honor Club nomination photos by docId ────────────────────
  useEffect(() => {
    honorClubMembers.forEach((item) => {
      const docId = item.docId;
      if (!docId || honorClubImageMap[docId] !== undefined) return;
      fetchHonorClubImage(docId).then((url) => {
        setHonorClubImageMap((prev) => ({ ...prev, [docId]: url || fallbackImageUrl }));
      });
    });
  }, [honorClubMembers]);

  // ─── Fetch counts ─────────────────────────────────────────────────────
  useEffect(() => {
    const fetchCounts = async () => {
      const allItems = [...worldOfThanksList, ...bravoList];
      const newCounts = {};
      for (const item of allItems) {
        try {
          const [likesRes, commentsRes] = await Promise.all([
            RnRService.getRecognitionLikes(item.id),
            RnRService.getRecognitionComments(item.id),
          ]);
          newCounts[item.id] = {
            likes: likesRes.data?.length || 0,
            comments: commentsRes.data?.length || 0,
          };
        } catch (e) {}
      }
      setCountsMap(newCounts);
    };
    if (worldOfThanksList.length || bravoList.length) {
      fetchCounts();
    }
  }, [worldOfThanksList, bravoList]);

  // ─── Category config - Blue to Red theme from A2B page ──────────────
  // Inspired by: from-[#1a2a6c] via-[#3a1c47] to-[#b91c1c] #072f6c
  const categoryConfigs = {
    worldOfThanks: {
      id: "worldOfThanks",
      label: "World of Thanks",
      emoji: "🌍",
      gradient: "from-[#3a1c47] to-[#2a4a7f]", 
      bgColor: "bg-[#E8EEF8]",
      borderColor: "border-[#B8C8E8]",
      textColor: "text-[#1a2a6c]",
      route: "/recognitionDashboard?tab=worldOfThanks",
      cardBg: "hover:bg-[#DCE4F5]",
      cardBorder: "hover:border-[#2a4a7f]",
      badgeBg: "bg-[#E8EEF8]",
      badgeHover: "group-hover:bg-[#D0DCF0]",
      badgeText: "text-[#1a2a6c]",
      borderLeft: "#2a4a7f",
      shadowColor: "rgba(26,42,108,0.25)",
      accentColor: "#1a2a6c",
      highlightBg: "from-[#1a2a6c] to-[#2a4a7f]",
    },
    bravo: {
      id: "bravo",
      label: "BRAVO",
      emoji: "👏",
      gradient: "from-[#3a1c47] to-[#5a2a6a]", // Purple/Plum
      bgColor: "bg-[#F0EAF5]",
      borderColor: "border-[#D5C8E0]",
      textColor: "text-[#3a1c47]",
      route: "/recognitionDashboard?tab=bravo",
      cardBg: "hover:bg-[#E8DCF0]",
      cardBorder: "hover:border-[#5a2a6a]",
      badgeBg: "bg-[#F0EAF5]",
      badgeHover: "group-hover:bg-[#DDD0E8]",
      badgeText: "text-[#3a1c47]",
      borderLeft: "#5a2a6a",
      shadowColor: "rgba(58,28,71,0.25)",
      accentColor: "#3a1c47",
      highlightBg: "from-[#3a1c47] to-[#5a2a6a]",
    },
    executiveCircle: {
      id: "executiveCircle",
      label: "Executive Circle",
      emoji: "👑",
      gradient: "from-[#7a1b2e] to-[#a02235]", // Deep Red
      bgColor: "bg-[#F8EDEF]",
      borderColor: "border-[#E8C8CD]",
      textColor: "text-[#7a1b2e]",
      route: "/executive-circle-list",
      cardBg: "hover:bg-[#F5E0E3]",
      cardBorder: "hover:border-[#a02235]",
      badgeBg: "bg-[#F8EDEF]",
      badgeHover: "group-hover:bg-[#F0D0D5]",
      badgeText: "text-[#7a1b2e]",
      borderLeft: "#a02235",
      shadowColor: "rgba(122,27,46,0.25)",
      accentColor: "#7a1b2e",
      highlightBg: "from-[#7a1b2e] to-[#a02235]",
    },
    honorClub: {
      id: "honorClub",
      label: "Honor Club",
      emoji: "🏅",
      gradient: "from-[#b91c1c] to-[#D93646]", // Bright Red (matching header)
      bgColor: "bg-[#FEF0ED]",
      borderColor: "border-[#F5C8C0]",
      textColor: "text-[#b91c1c]",
      route: "/honor-club-list",
      cardBg: "hover:bg-[#FCE8E3]",
      cardBorder: "hover:border-[#D93646]",
      badgeBg: "bg-[#FEF0ED]",
      badgeHover: "group-hover:bg-[#FCD8D0]",
      badgeText: "text-[#b91c1c]",
      borderLeft: "#D93646",
      shadowColor: "rgba(217,54,70,0.25)",
      accentColor: "#b91c1c",
      highlightBg: "from-[#b91c1c] to-[#D93646]",
    },
  };

  const categories = Object.values(categoryConfigs);

  const getCategoryCount = (id) => {
    switch (id) {
      case "worldOfThanks": return worldOfThanksList.length;
      case "bravo": return bravoList.length;
      case "executiveCircle": return executiveCategories.reduce((sum, cat) => sum + cat.winners.length, 0);
      case "honorClub": return honorClubMembers.length;
      default: return 0;
    }
  };

  // ─── Handle category click - show data below ──────────────────────────
  const handleCategoryClick = (categoryId) => {
    setActiveCategory(categoryId);
  };

  // ─── Handle navigation to respective dashboard ────────────────────────
  const handleNavigateToDashboard = (categoryId) => {
    const category = categories.find(c => c.id === categoryId);
    if (category?.route) {
      navigate(category.route);
    }
  };

  // ─── Render World of Thanks / Bravo with enhanced hover ──────────────
  const renderRecognitionGrid = (list, type, categoryId) => {
    const config = categoryConfigs[categoryId];
    
    if (list.length === 0) {
      return (
        <div className="text-center py-16 text-gray-400">
          <div className="text-5xl mb-4">🎯</div>
          <p className="text-lg font-medium">No {type} recipients yet</p>
          <p className="text-sm mt-1">Check back later for updates</p>
        </div>
      );
    }

    return (
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3">
        {list.map((item) => {
          const emp = employeeMap[item.empCode] || {};
          const counts = countsMap[item.id] || { likes: 0, comments: 0 };
          return (
            <div
              key={item.id}
              className={`bg-white rounded-xl shadow-sm border ${config.borderColor} border-l-4 hover:shadow-xl hover:-translate-y-1 hover:scale-[1.02] transition-all duration-300 p-3 text-center group`}
              style={{ 
                borderLeftColor: config.borderLeft,
                boxShadow: `0 1px 3px rgba(0,0,0,0.08)`
              }}
            >
              <div className="flex justify-center mb-2">
                <div className="relative">
                  <img
                    src={emp.profileImage || fallbackImageUrl}
                    alt={item.employeeName}
                    className="w-16 h-16 rounded-full border-2 border-gray-200 shadow-sm object-cover transition-all duration-300 group-hover:border-[${config.borderLeft}]"
                  />
                </div>
              </div>
              <h6 className="font-semibold text-gray-800 text-xs line-clamp-1 group-hover:text-gray-900 transition-colors">{item.employeeName}</h6>
              <p className="text-[10px] text-gray-500 mt-0.5 line-clamp-1">{emp.department || item.nomineeDepartment || "-"}</p>
              <span className={`inline-block mt-1.5 px-2 py-0.5 ${config.bgColor} ${config.textColor} text-[10px] font-medium rounded-full truncate max-w-full border ${config.borderColor} transition-colors group-hover:${config.badgeHover}`}>
                {item.categoryName}
              </span>
              <div className="flex justify-center gap-4 mt-2 pt-1.5 border-t border-gray-100">
                <div className="flex items-center gap-1">
                  <span className="text-xs group-hover:scale-110 transition-transform">👍</span>
                  <span className="text-[10px] text-gray-600">{counts.likes}</span>
                </div>
                <div className="flex items-center gap-1">
                  <span className="text-xs group-hover:scale-110 transition-transform">💬</span>
                  <span className="text-[10px] text-gray-600">{counts.comments}</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    );
  };

  // ─── Render Executive Circle with enhanced hover ──────────────────────
  const renderExecutiveCircle = () => {
    const config = categoryConfigs.executiveCircle;
    
    if (executiveCategories.length === 0) {
      return (
        <div className="text-center py-16 text-gray-400">
          <div className="text-5xl mb-4">👑</div>
          <p className="text-lg font-medium">No Executive Circle winners yet</p>
          <p className="text-sm mt-1">Check back later for updates</p>
        </div>
      );
    }

    const getRankBadge = (rank) => {
      if (!rank) return null;
      const styles = {
        1: { bg: "bg-gradient-to-r from-amber-400 to-yellow-500", label: "🥇" },
        2: { bg: "bg-gradient-to-r from-gray-400 to-gray-500", label: "🥈" },
        3: { bg: "bg-gradient-to-r from-amber-600 to-orange-600", label: "🥉" },
      };
      return styles[rank] || { bg: "bg-gray-300", label: `#${rank}` };
    };

    return (
      <div>
        {/* Category/Award Selector */}
        <div className="flex flex-wrap gap-2 mb-4">
          {executiveCategories.map((category) => (
            <button
              key={category.awardTitle}
              onClick={() => setSelectedExecCategory(category)}
              className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all duration-300 flex items-center gap-1.5 ${
                selectedExecCategory?.awardTitle === category.awardTitle
                  ? `bg-gradient-to-r ${config.gradient} text-white shadow-lg`
                  : "bg-gray-100 text-gray-700 hover:bg-gray-200"
              }`}
            >
              <Award size={14} />
              {category.awardTitle}
              <span className={`ml-1 px-1.5 py-0.5 rounded-full text-[10px] ${
                selectedExecCategory?.awardTitle === category.awardTitle
                  ? "bg-white/20 text-white"
                  : "bg-gray-200 text-gray-600"
              }`}>
                {category.winners.length}
              </span>
            </button>
          ))}
        </div>

        {/* Winners for selected category */}
        {selectedExecCategory && (
          <div>
            <div className="flex items-center gap-2 mb-3">
              <Crown className={config.textColor} size={18} />
              <h3 className="text-base font-semibold text-gray-800">{selectedExecCategory.awardTitle}</h3>
              <span className="text-xs text-gray-400">({selectedExecCategory.winners.length} winners)</span>
            </div>

            {selectedExecCategory.winners.length === 0 ? (
              <div className="text-center py-8 text-gray-400">
                No winners for this award yet
              </div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3">
                {selectedExecCategory.winners.map((winner, idx) => {
                  const emp = executiveEmpMap[winner.nomineeEmployeeCode] || {};
                  const rankInfo = getRankBadge(winner.rank);
                  const isTop3 = winner.rank && winner.rank <= 3;

                  return (
                    <div
                      key={idx}
                      className={`bg-white rounded-xl shadow-sm border ${config.borderColor} border-l-4 hover:shadow-xl hover:-translate-y-1 hover:scale-[1.02] transition-all duration-300 p-3 text-center group`}
                      style={{ borderLeftColor: config.borderLeft }}
                    >
                      <div className="flex justify-center mb-2 relative">
                        <img
                          src={emp.profileImage || fallbackImageUrl}
                          alt={winner.nomineeName}
                          className="w-16 h-16 rounded-full border-2 border-gray-200 shadow-sm object-cover transition-all duration-300 group-hover:border-[#E8D5D5]"
                        />
                        {rankInfo && (
                          <div className={`absolute -top-1 -right-1 ${rankInfo.bg} text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full shadow-md`}>
                            {rankInfo.label}
                          </div>
                        )}
                      </div>
                      <h6 className="font-semibold text-gray-800 text-xs line-clamp-1 group-hover:text-gray-900 transition-colors">{winner.nomineeName}</h6>
                      <p className="text-[10px] text-gray-500 mt-0.5 line-clamp-1">{winner.department || emp.department || "-"}</p>
                      {winner.reasonForNomination && (
                        <p className="text-[10px] text-gray-400 mt-1.5 italic line-clamp-2 border-t border-gray-100 pt-1.5 group-hover:border-[#F5D0D0] transition-colors">
                          "{winner.reasonForNomination}"
                        </p>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}
      </div>
    );
  };

  // ─── Render Honor Club with enhanced hover ────────────────────────────
  const renderHonorClub = () => {
    const config = categoryConfigs.honorClub;
    const hasMembers = honorClubSections.some((s) => s.members.length > 0);
    
    if (!hasMembers) {
      return (
        <div className="text-center py-16 text-gray-400">
          <div className="text-5xl mb-4">🏅</div>
          <p className="text-lg font-medium">No Honor Club members yet</p>
          <p className="text-sm mt-1">Check back later for updates</p>
        </div>
      );
    }

    return (
      <div className="space-y-6">
        {honorClubSections.map((section) => {
          if (section.members.length === 0) return null;
          return (
            <div key={section.id}>
              <h3 className="text-base font-semibold text-gray-800 mb-2.5 flex items-center gap-2">
                <span className={`w-1 h-5 bg-gradient-to-b ${config.gradient} rounded-full`}></span>
                {section.label}
                <span className="text-xs font-normal text-gray-400">({section.members.length})</span>
              </h3>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3">
                {section.members.map((member) => (
                  <div
                    key={member.id}
                    className={`bg-white rounded-xl shadow-sm border ${config.borderColor} border-l-4 hover:shadow-xl hover:-translate-y-1 hover:scale-[1.02] transition-all duration-300 p-3 text-center group`}
                    style={{ borderLeftColor: config.borderLeft }}
                  >
                    <div className="flex justify-center mb-2">
                      <img
                        src={honorClubImageMap[member.docId] || fallbackImageUrl}
                        alt={member.name}
                        onError={(e) => { e.target.src = fallbackImageUrl; }}
                        className="w-16 h-16 rounded-full border-2 border-gray-200 shadow-sm object-cover transition-all duration-300 group-hover:border-[#E8D5D5]"
                      />
                    </div>
                    <h6 className="font-semibold text-gray-800 text-xs line-clamp-1 group-hover:text-gray-900 transition-colors">{member.name}</h6>
                    <p className="text-[10px] text-gray-500 mt-0.5 line-clamp-1">{member.dept || "-"}</p>
                    <span className={`inline-block mt-1.5 px-2 py-0.5 ${config.bgColor} ${config.textColor} text-[10px] font-medium rounded-full border ${config.borderColor} transition-colors group-hover:${config.badgeHover}`}>
                      {member.badge}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>
    );
  };

  // ─── Main Render ──────────────────────────────────────────────────────
  return (
    <>
      <Header />
      <div className="min-h-screen bg-gray-50 px-2 py-4 mt-[70px]">
        <div className="w-full max-w-8xl mx-auto">
          {/* Header - Blue to Red gradient from A2B page #1a2a6c #270e85 */}
          <div className="bg-gradient-to-b from-red-900 to-red-700 rounded-xl shadow-lg p-4 mb-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <button
                  onClick={() => navigate("/rnr-landing")}
                  className="text-white hover:text-gray-200 transition p-1 rounded-full bg-white/20 hover:bg-white/30"
                >
                  <ArrowLeft size={22} />
                </button>
                <div>
                  <h1 className="text-xl font-bold text-white flex items-center gap-2">
                    <Trophy size={24} />
                    Wall of Fame
                  </h1>
                  <p className="text-white/80 text-xs mt-0.5">
                    Celebrating excellence across all recognition programs
                  </p>
                </div>
              </div>
              <div className="text-white/80 text-xs bg-white/20 px-3 py-1.5 rounded-lg">
                FY: {financialYear}
              </div>
            </div>
          </div>

          {/* Category Cards - Blue to Red spectrum */}
          <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-3 mb-6">
            {categories.map((cat) => {
              const count = getCategoryCount(cat.id);
              const isActive = activeCategory === cat.id;
              return (
                <div
                  key={cat.id}
                  className={`relative overflow-hidden rounded-lg border border-l-4 transition-all duration-300 cursor-pointer ${
                    isActive 
                      ? 'shadow-lg ring-2 ring-opacity-40 scale-[1.02]' 
                      : 'shadow-sm hover:shadow-md hover:scale-[1.01]'
                  }`}
                  style={{ 
                    borderLeftColor: cat.borderLeft,
                    boxShadow: isActive ? `0 10px 25px -6px ${cat.shadowColor}` : undefined,
                    borderColor: isActive ? cat.borderLeft : '#E5E7EB'
                  }}
                  onClick={() => handleCategoryClick(cat.id)}
                >
                  <div className={`bg-gradient-to-r ${cat.gradient} px-3 py-2.5`}>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="text-xl">{cat.emoji}</span>
                        <h3 className="text-white font-semibold text-xs">{cat.label}</h3>
                      </div>
                      <ChevronRight size={16} className="text-white/70" />
                    </div>
                  </div>
                  <div className="bg-white px-3 py-2.5">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-xl font-bold text-gray-800">{count}</p>
                        <p className="text-[10px] text-gray-500">
                          {cat.id === "executiveCircle" ? "winners" : "members"}
                        </p>
                      </div>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleNavigateToDashboard(cat.id);
                        }}
                        className={`px-2.5 py-1 rounded-full text-[10px] font-medium flex items-center gap-1 transition-all hover:scale-105 ${cat.bgColor} ${cat.textColor} border ${cat.borderColor}`}
                      >
                        <ExternalLink size={10} />
                        {isActive ? "View Dashboard" : "Click to view"}
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Content Area */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4">
            {activeCategory === "worldOfThanks" && (
              <>
                <div className="flex items-center justify-between mb-3 pb-2 border-b border-gray-100">
                  <h2 className="text-lg font-bold text-gray-800 flex items-center gap-2">
                    <span className="text-2xl">🌍</span>
                    World of Thanks
                    <span className={`ml-2 px-2 py-0.5 ${categoryConfigs.worldOfThanks.bgColor} ${categoryConfigs.worldOfThanks.textColor} text-[10px] font-medium rounded-full`}>
                      {worldOfThanksList.length} recipients
                    </span>
                  </h2>
                </div>
                {renderRecognitionGrid(worldOfThanksList, "World of Thanks", "worldOfThanks")}
              </>
            )}

            {activeCategory === "bravo" && (
              <>
                <div className="flex items-center justify-between mb-3 pb-2 border-b border-gray-100">
                  <h2 className="text-lg font-bold text-gray-800 flex items-center gap-2">
                    <span className="text-2xl">👏</span>
                    BRAVO Awards
                    <span className={`ml-2 px-2 py-0.5 ${categoryConfigs.bravo.bgColor} ${categoryConfigs.bravo.textColor} text-[10px] font-medium rounded-full`}>
                      {bravoList.length} recipients
                    </span>
                  </h2>
                </div>
                {renderRecognitionGrid(bravoList, "BRAVO", "bravo")}
              </>
            )}

            {activeCategory === "executiveCircle" && (
              <>
                <div className="flex items-center justify-between mb-3 pb-2 border-b border-gray-100">
                  <h2 className="text-lg font-bold text-gray-800 flex items-center gap-2">
                    <span className="text-2xl">👑</span>
                    Executive Circle Winners
                    <span className={`ml-2 px-2 py-0.5 ${categoryConfigs.executiveCircle.bgColor} ${categoryConfigs.executiveCircle.textColor} text-[10px] font-medium rounded-full`}>
                      {executiveCategories.reduce((sum, cat) => sum + cat.winners.length, 0)} winners
                    </span>
                  </h2>
                </div>
                {renderExecutiveCircle()}
              </>
            )}

            {activeCategory === "honorClub" && (
              <>
                <div className="flex items-center justify-between mb-3 pb-2 border-b border-gray-100">
                  <h2 className="text-lg font-bold text-gray-800 flex items-center gap-2">
                    <span className="text-2xl">🏅</span>
                    Honor Club Members
                    <span className={`ml-2 px-2 py-0.5 ${categoryConfigs.honorClub.bgColor} ${categoryConfigs.honorClub.textColor} text-[10px] font-medium rounded-full`}>
                      {honorClubMembers.length} members
                    </span>
                  </h2>
                </div>
                {renderHonorClub()}
              </>
            )}
          </div>
        </div>
      </div>
    </>
  );
};

export default WallOfFame;