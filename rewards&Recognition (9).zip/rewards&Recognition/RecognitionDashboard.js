import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import RnRService from "./RnRService";
import Header from "../components/Header";
import axios from "axios";
import Swal from "sweetalert2";
import { X } from 'lucide-react';
import { useSearchParams } from "react-router-dom";

function RecognitionDashboard() {

  const [worldOfThanksList, setWorldOfThanksList] = useState([]);
  const [bravoList, setBravoList] = useState([]);

  // Hardcoded data for Special Recognition tab
  const [specialRecognitionList, setSpecialRecognitionList] = useState([
    {
      id: "sr1",
      empCode: "EMP001",
      employeeName: "Aarav Mehta",
      nomineeDepartment: "Product Development",
      categoryName: "Star Performer",
      likes: 24,
      comments: 5,
      profileImage: null
    },
    {
      id: "sr2",
      empCode: "EMP002",
      employeeName: "Neha Verma",
      nomineeDepartment: "Marketing",
      categoryName: "Innovation Award",
      likes: 18,
      comments: 3,
      profileImage: null
    },
    {
      id: "sr3",
      empCode: "EMP003",
      employeeName: "Rohan Desai",
      nomineeDepartment: "Engineering",
      categoryName: "Team Excellence",
      likes: 32,
      comments: 7,
      profileImage: null
    },
    {
      id: "sr4",
      empCode: "EMP004",
      employeeName: "Priya Singh",
      nomineeDepartment: "Customer Support",
      categoryName: "Customer First",
      likes: 15,
      comments: 2,
      profileImage: null
    },
    {
      id: "sr5",
      empCode: "EMP005",
      employeeName: "Vikram Sharma",
      nomineeDepartment: "Safety & Compliance",
      categoryName: "Safety Champion",
      likes: 9,
      comments: 1,
      profileImage: null
    }
  ]);

  const [loading, setLoading] = useState(false);
  const [employeeMap, setEmployeeMap] = useState({});

  const [selectedRecognition, setSelectedRecognition] = useState(null);
  const [newComment, setNewComment] = useState("");
  const [commentList, setCommentList] = useState([]);
  const [loadingComments, setLoadingComments] = useState(false);

  const [likeList, setLikeList] = useState([]);
  const [showLikesModal, setShowLikesModal] = useState(false);

  // For special recognition like/comment counts (since they are hardcoded)
  const [specialCountsMap, setSpecialCountsMap] = useState({});

const navigate = useNavigate();
const [searchParams] = useSearchParams();

const empCode = localStorage.getItem("empId");

const roles = JSON.parse(sessionStorage.getItem("role") || "[]");
const isManager = roles.includes("CMS Manager");

const [activeTab, setActiveTab] = useState(
  searchParams.get("tab") || "worldOfThanks"
);

const [page, setPage] = useState(0);
const [size] = useState(10);
const [totalPages, setTotalPages] = useState(0);
const [totalElements, setTotalElements] = useState(0);
  const [countsMap, setCountsMap] = useState({});

  const fallbackImageUrl = "https://militaryhealthinstitute.org/wp-content/uploads/sites/37/2021/08/blank-profile-picture-png.png";

  useEffect(() => {
    setPage(0);
  }, [activeTab]);

  const fetchAwards = async () => {
    setLoading(true);
    try {
      const res = await RnRService.getAllRecognitionsList(page, size);
      setWorldOfThanksList(res.data.worldofthanks || []);
      setBravoList(res.data.bravo || []);
      setTotalPages(res.data.totalPages);
      setTotalElements(res.data.totalElements);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const getEmployeeData = async (empCode) => {
    if (employeeMap[empCode]) return;
    try {
      const res = await RnRService.employeeInfoData(empCode);
      const fileData = res.data?.fileAndObjectTypeBean?.fileAndContentTypeBean?.file;
      const emp = res.data?.fileAndObjectTypeBean?.empResDTO || {};
      const empData = {
        ...emp,
        department: emp?.mainDeptResDTO?.mainDepartment,
        designation: emp?.designationResDTO?.designationName,
        profileImage: fileData ? `data:image/png;base64,${fileData}` : fallbackImageUrl,
      };
      setEmployeeMap((prev) => ({ ...prev, [empCode]: empData }));
    } catch (error) {}
  };

  useEffect(() => {
    fetchAwards();
  }, [page]);

  useEffect(() => {
    [...worldOfThanksList, ...bravoList].forEach((item) => {
      getEmployeeData(item.empCode);
    });
  }, [worldOfThanksList, bravoList]);

  // For special recognition, also fetch employee images
  useEffect(() => {
    specialRecognitionList.forEach((item) => {
      if (item.empCode) getEmployeeData(item.empCode);
      // Initialize counts
      setSpecialCountsMap(prev => ({
        ...prev,
        [item.id]: { likes: item.likes, comments: item.comments }
      }));
    });
  }, [specialRecognitionList]);

  const fetchComments = async (id, type) => {
    setLoadingComments(true);
    try {
      if (type === 'special') {
        await new Promise(resolve => setTimeout(resolve, 500));
        setCommentList([
          { employeeName: "Admin", comments: "Great work!", commentDateTime: new Date().toLocaleString(), department: "HR", emailId: "admin@example.com" }
        ]);
      } else {
        const res = await RnRService.getRecognitionComments(id);
        setCommentList(res.data || []);
      }
    } catch (error) {}
    setLoadingComments(false);
  };

  const fetchCounts = async (id) => {
    try {
      const [likesRes, commentsRes] = await Promise.all([
        RnRService.getRecognitionLikes(id),
        RnRService.getRecognitionComments(id),
      ]);
      setCountsMap((prev) => ({
        ...prev,
        [id]: {
          likes: likesRes.data?.length || 0,
          comments: commentsRes.data?.length || 0,
        },
      }));
    } catch (e) {}
  };

  useEffect(() => {
    [...worldOfThanksList, ...bravoList].forEach((item) => {
      fetchCounts(item.id);
    });
  }, [worldOfThanksList, bravoList]);

  const submitComment = async () => {
    if (!newComment.trim()) {
      Swal.fire("Error", "Comment cannot be empty", "error");
      return;
    }
    const url = RnRService.addRecognitionComment(selectedRecognition.id, empCode);
    await axios.post(url, newComment, {
      headers: { "Content-Type": "text/plain;charset=UTF-8" },
    });
    setNewComment("");
    fetchComments(selectedRecognition.id, 'normal');
  };

  const openCommentModal = (rec, type = 'normal') => {
    setSelectedRecognition({ ...rec, recognitionType: type });
    fetchComments(rec.id, type);
  };

  const closeModal = () => {
    setSelectedRecognition(null);
    setCommentList([]);
    setNewComment("");
  };

  const handleLike = async (id, type, itemType) => {
    if (type === 'special') {
      setSpecialCountsMap(prev => ({
        ...prev,
        [id]: { ...prev[id], likes: (prev[id]?.likes || 0) + 1 }
      }));
      return;
    }
    
    const response = await RnRService.likeRecognition(id, empCode);
     if (response.data === "Already liked") {
            Swal.fire("Info", "You have already liked this recognition", "info");
            return;
          }
    if (itemType === "WORLDOFTHANKS") {
      setWorldOfThanksList((prev) =>
        prev.map((a) => (a.id === id ? { ...a, likes: (a.likes || 0) + 1 } : a))
      );
    } else {
      setBravoList((prev) =>
        prev.map((a) => (a.id === id ? { ...a, likes: (a.likes || 0) + 1 } : a))
      );
    }
  };

  const openLikesModal = async (id, type) => {
    if (type === 'special') {
      setLikeList([
        { employeeName: "User1", emailId: "user1@example.com", likedAt: new Date().toLocaleString() },
        { employeeName: "User2", emailId: "user2@example.com", likedAt: new Date().toLocaleString() }
      ]);
      setShowLikesModal(true);
      return;
    }
    const res = await RnRService.getRecognitionLikes(id);
    setLikeList(res.data);
    setShowLikesModal(true);
  };

  const handlePrevious = () => {
    if (page > 0) setPage(page - 1);
  };

  const handleNext = () => {
    if (page < totalPages - 1) setPage(page + 1);
  };

  const getPageNumbers = () => {
    return Array.from({ length: totalPages }, (_, i) => i);
  };

  const isPageButtonDisabled = (pageIndex) => {
    const currentList = activeTab === "worldOfThanks" ? worldOfThanksList : bravoList;
    if (pageIndex < 0 || pageIndex >= totalPages) return true;
    if (pageIndex === page) return false;
    if (pageIndex === page - 1) return false;
    if (pageIndex === page + 1) return currentList.length < size;
    return true;
  };

  // Card color themes — each matches its section's header color
  const cardThemes = {
    WORLDOFTHANKS: {
      border: "#8A3B63",
  light: "#F7E8F0",
  lightBorder: "#E5C5D5",
  text: "#5C1140",
  glow: "rgba(138,59,99,0.18)",
    },
  BRAVO: {
  border: "#8A3B63",
  light: "#F7E8F0",
  lightBorder: "#E5C5D5",
  text: "#5C1140",
  glow: "rgba(138,59,99,0.18)",
},
    SPECIAL: {
      border: "#6B2D5C",
      light: "#F3E6F0",
      lightBorder: "#E0BFDA",
      text: "#6B2D5C",
      glow: "rgba(107,45,92,0.28)",
    },
  };

  // Card Component — colors are themed to match the active section's header
  const Card = ({ item, type, cardType }) => {
    const isSpecial = cardType === 'special';
    const counts = isSpecial ? specialCountsMap[item.id] : countsMap[item.id];
    const profileImg = employeeMap[item.empCode]?.profileImage || fallbackImageUrl;
    const theme = cardThemes[type] || cardThemes.WORLDOFTHANKS;
    const themeVars = {
      "--card-border": theme.border,
      "--card-light": theme.light,
      "--card-lightBorder": theme.lightBorder,
      "--card-text": theme.text,
      "--card-glow": theme.glow,
    };

    return (
      <div className="w-full transition-all duration-300 hover:-translate-y-1" style={themeVars}>
        <div
          className="relative overflow-hidden bg-white border-l-4 border border-[#E8D5D5] rounded-xl shadow-sm hover:shadow-xl hover:scale-105 p-4 text-center transition-all duration-300 hover:shadow-[0_18px_30px_-10px_var(--card-glow)] hover:border-[var(--card-lightBorder)]"
          style={{ borderLeftColor: "var(--card-border)" }}
        >
          <div className="flex justify-center mb-4">
            <img
              src={profileImg}
              alt="Profile"
              className="w-28 h-28 rounded-full border-2 shadow-sm object-cover"
              style={{ borderColor: "var(--card-lightBorder)" }}
            />
          </div>
          <h6 className="font-semibold text-gray-800 text-lg">{item.employeeName}</h6>
          <p className="text-sm text-gray-600 mt-1">{item.nomineeDepartment || "-"}</p>
          <span
            className="inline-block mt-2 px-3 py-1 text-xs font-medium rounded-full border"
            style={{
              backgroundColor: "var(--card-light)",
              color: "var(--card-text)",
              borderColor: "var(--card-lightBorder)",
            }}
          >
            {item.categoryName}
          </span>
          <div className="flex justify-center gap-8 mt-4 pt-2 border-t border-[#E8D5D5]">
            <div className="flex items-center gap-2">
              <button
                onClick={() => handleLike(item.id, isSpecial ? 'special' : 'normal', type)}
                className="text-gray-400 hover:text-[var(--card-text)] transition"
              >
                ❤️
              </button>
              <span
                onClick={() => openLikesModal(item.id, isSpecial ? 'special' : 'normal')}
                className="text-sm font-medium text-gray-800 cursor-pointer"
              >
                {counts?.likes || 0}
              </span>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => openCommentModal(item, isSpecial ? 'special' : 'normal')}
                className="text-gray-400 hover:text-[var(--card-text)] transition"
              >
                💬
              </button>
              <span className="text-sm font-medium text-gray-800">
                {counts?.comments || 0}
              </span>
            </div>
          </div>
        </div>
      </div>
    );
  };

  return (
    <>
      <Header />
      <div className="min-h-screen bg-white px-3 py-6 mt-[70px]">
        <div className="max-w-[1500px] mx-auto">
          {/* Tabs Header - Maroon/Red Theme */}
          <div className="bg-white rounded-2xl shadow-sm border border-[#E8D5D5] overflow-hidden mb-8">
            <div className="px-4 py-3 border-b border-[#E8D5D5]">
              <div className="flex items-center justify-between">
                <div className="flex gap-3 flex-wrap">
                  <button
                    onClick={() => setActiveTab("worldOfThanks")}
                    className={`flex items-center gap-2 px-5 py-2 rounded-full text-sm font-medium transition-all duration-200 ${
                      activeTab === "worldOfThanks"
                        ? "bg-gradient-to-r from-red-900 to-red-700 text-white shadow-md"
                        : "bg-white border border-[#E8D5D5] text-[#6B3A3A] hover:bg-[#FFF0ED] shadow-sm"
                    }`}
                  >
                    <span>🌍</span> World of Thanks
                  </button>
                  <button
                    onClick={() => setActiveTab("bravo")}
                    className={`flex items-center gap-2 px-5 py-2 rounded-full text-sm font-medium transition-all duration-200 ${
                      activeTab === "bravo"
                        ? "bg-gradient-to-r from-red-900 to-red-700 text-white shadow-md"
                        : "bg-white border border-[#E8D5D5] text-[#6B3A3A] hover:bg-[#FFF0ED] shadow-sm"
                    }`}
                  >
                    <span>👏</span> BRAVO
                  </button>
                  <button
                    onClick={() =>
                      Swal.fire({
                        icon: "info",
                        title: "Coming Soon",
                        text: "Special Recognition is on its way. Stay tuned!",
                        confirmButtonColor: "#8B1A1A",
                      })
                    }
                    className="relative flex items-center gap-2 px-5 py-2 rounded-full text-sm font-medium bg-white border border-[#E8D5D5] text-[#B8A0A0] cursor-not-allowed shadow-sm"
                    title="Coming soon"
                  >
                    <span>🏅</span> Special Recognition
                    <span className="ml-1 px-2 py-0.5 rounded-full bg-[#FFF0ED] text-[#8B1A1A] text-[10px] font-semibold tracking-wide">
                      Coming Soon
                    </span>
                  </button>
                </div>
                <button
                  onClick={() => navigate("/rewardsHomePage")}
                  className="bg-white hover:bg-[#FFF0ED] text-[#6B3A3A] rounded-full p-2 transition-all duration-200 border border-[#E8D5D5]"
                  title="back"
                >
                  <X size={18} />
                </button>
              </div>
            </div>
          </div>

          {activeTab === "worldOfThanks" && (
            <div className="bg-white rounded-2xl shadow-sm border border-[#E8D5D5] overflow-hidden">
              <div className="bg-gradient-to-b from-red-900 to-red-700 px-4 py-4 text-center">
                <h2 className="text-xl font-semibold text-white flex items-center justify-center gap-2">
                  <span>🏆</span> World Of Thanks
                </h2>
              </div>
              
              {/* RECOGNISE NOW BUTTON */}
              <div className="flex justify-end px-4 pt-4">
                <button
                  onClick={() => navigate("/recognise-now/WORLDOFTHANKS")}
                  className="px-6 py-2.5 font-semibold text-white rounded-lg bg-gradient-to-r from-red-900 via-red-700 to-red-900 hover:from-red-900 hover:via-red-800 hover:to-red-700 transition-all shadow-md shadow-red-700/30 hover:shadow-lg hover:shadow-red-700/40 flex items-center gap-2"
                >
                  <span>✨</span> RECOGNISE NOW <span>✨</span>
                </button>
              </div>
              
              <div className="px-0 py-4">
                {loading ? (
                  <div className="text-center py-10 text-gray-500">Loading...</div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3 px-3">
                    {worldOfThanksList.map((item) => (
                      <Card key={item.id} item={item} type="WORLDOFTHANKS" cardType="normal" />
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {activeTab === "bravo" && (
            <div className="bg-white rounded-2xl shadow-sm border border-[#E8D5D5] overflow-hidden">
              <div className="bg-gradient-to-b from-red-900 to-red-700 px-4 py-4 text-center">
                <h2 className="text-xl font-semibold text-white flex items-center justify-center gap-2">
                  <span>⭐</span> BRAVO
                </h2>
              </div>
              
              {/* RECOGNISE NOW BUTTON */}
              {isManager && (
                <div className="flex justify-end px-4 pt-4">
                  <button
                    onClick={() => navigate("/recognise-now/BRAVO")}
                  className="px-6 py-2.5 font-semibold text-white rounded-lg bg-gradient-to-r from-red-900 via-red-700 to-red-900 hover:from-red-900 hover:via-red-800 hover:to-red-700 transition-all shadow-md shadow-red-700/30 hover:shadow-lg hover:shadow-red-700/40 flex items-center gap-2"
                  >
                    <span>✨</span> RECOGNISE NOW <span>✨</span>
                  </button>
                </div>
              )}
              
              <div className="px-0 py-4">
                {loading ? (
                  <div className="text-center py-10 text-gray-500">Loading...</div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3 px-3">
                    {bravoList.map((item) => (
                      <Card key={item.id} item={item} type="BRAVO" cardType="normal" />
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {activeTab === "specialRecognition" && (
            <div className="bg-white rounded-2xl shadow-sm border border-[#E8D5D5] overflow-hidden">
              <div className="bg-[#6B2D5C] px-4 py-4 text-center">
                <h2 className="text-xl font-semibold text-white flex items-center justify-center gap-2">
                  <span>🏅</span> Special Recognition
                </h2>
              </div>
              
              <div className="px-0 py-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3 px-3">
                  {specialRecognitionList.map((item) => (
                    <Card key={item.id} item={item} type="SPECIAL" cardType="special" />
                  ))}
                </div>
              </div>
            </div>
          )}

          {activeTab !== "specialRecognition" && totalPages > 0 && (
            <div className="flex justify-between items-center mt-6 flex-wrap gap-3 bg-white p-4 rounded-xl shadow-sm border border-[#E8D5D5]">
              <div className="text-sm text-gray-600">
                Showing {page * size + 1} to {Math.min((page + 1) * size, totalElements)} of {totalElements}
              </div>
              <div className="flex items-center gap-2">
                <button onClick={handlePrevious} disabled={isPageButtonDisabled(page - 1)} className="px-3 py-1.5 text-sm bg-[#FFF0ED] text-[#6B3A3A] rounded-lg disabled:opacity-50 hover:bg-[#F5D0D0] transition">
                  Previous
                </button>
                <div className="flex gap-1">
                  {getPageNumbers().map((p) => {
                    const disabled = isPageButtonDisabled(p);
                    return (
                      <button key={p} onClick={() => !disabled && setPage(p)} disabled={disabled} className={`w-8 h-8 text-sm rounded-lg transition ${page === p ? "bg-[#8B1A1A] text-white" : "bg-[#FFF0ED] text-[#6B3A3A] hover:bg-[#F5D0D0]"} ${disabled ? "opacity-50 cursor-not-allowed pointer-events-none" : ""}`}>
                        {p + 1}
                      </button>
                    );
                  })}
                </div>
                <button onClick={handleNext} disabled={isPageButtonDisabled(page + 1)} className="px-3 py-1.5 text-sm bg-[#FFF0ED] text-[#6B3A3A] rounded-lg disabled:opacity-50 hover:bg-[#F5D0D0] transition">
                  Next
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Comment Modal */}
        {selectedRecognition && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50" onClick={closeModal}>
            <div className="bg-white w-[600px] max-w-[90%] max-h-[80vh] flex flex-col rounded-lg shadow-lg border" onClick={(e) => e.stopPropagation()}>
              <div className="flex justify-between items-center px-5 py-4 border-b-2 border-[#8B1A1A]">
                <div className="flex items-center gap-3">
                  <span onClick={closeModal} className="text-xl cursor-pointer text-[#8B1A1A]">←</span>
                  <h4 className="text-lg font-bold text-[#6B3A3A]">Comments</h4>
                </div>
                <button onClick={closeModal} className="text-2xl text-gray-500 hover:text-black">×</button>
              </div>
              <div className="p-5 overflow-y-auto flex-1">
                <div className="flex items-center gap-4 border-b pb-4 mb-4">
                  <div className="w-12 h-12 flex items-center justify-center bg-gray-100 rounded-full border">
                    <img src={employeeMap[selectedRecognition.empCode]?.profileImage || fallbackImageUrl} alt="Profile" className="w-12 h-12 rounded-full border-2 border-[#E8D5D5] shadow-sm object-cover" />
                  </div>
                  <div>
                    <h5 className="font-bold text-base">{selectedRecognition.employeeName}</h5>
                    <div className="text-sm text-gray-500">{employeeMap[selectedRecognition.empCode]?.designation || employeeMap[selectedRecognition.empCode]?.department || selectedRecognition.categoryName}</div>
                  </div>
                </div>
                <div className="max-h-[300px] overflow-y-auto mb-4">
                  {loadingComments ? (
                    <div className="text-center py-5">Loading comments...</div>
                  ) : commentList.length === 0 ? (
                    <p className="text-center text-gray-500 py-5">No comments yet. Be the first to comment!</p>
                  ) : (
                    commentList.map((cmt, idx) => (
                      <div key={idx} className="border-b py-3">
                        <div className="flex flex-wrap items-center gap-2 mb-1">
                          <strong className="text-sm">{cmt.employeeName}</strong>
                          {cmt.department && <span className="bg-[#FFF0ED] text-[#8B1A1A] text-xs px-2 py-1 rounded-full font-semibold">{cmt.department}</span>}
                          {cmt.emailId && <span className="text-xs text-gray-500">{cmt.emailId}</span>}
                        </div>
                        <p className="text-sm text-gray-800 mb-1">{cmt.comments}</p>
                        <small className="text-xs text-gray-500">{cmt.commentDateTime}</small>
                      </div>
                    ))
                  )}
                </div>
                <div>
                  <textarea className="w-full border border-[#E8D5D5] rounded-md p-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#8B1A1A]" rows="3" placeholder="Write a comment..." value={newComment} onChange={(e) => setNewComment(e.target.value)} />
                  <div className="flex justify-end mt-2">
                    <button onClick={submitComment} className="bg-[#8B1A1A] hover:bg-[#6B1515] text-white px-4 py-2 rounded font-semibold">Post Comment</button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Likes Modal */}
        {showLikesModal && (
          <div className="fixed inset-0 bg-black bg-opacity-40 flex items-center justify-center z-50" onClick={() => setShowLikesModal(false)}>
            <div className="bg-white w-[500px] max-w-[95%] rounded-md shadow-lg border" onClick={(e) => e.stopPropagation()}>
              <div className="flex justify-between items-center px-5 py-4 border-b bg-white">
                <h4 className="text-lg font-semibold text-[#6B3A3A]">All Likes</h4>
                <button onClick={() => setShowLikesModal(false)} className="text-xl text-gray-600 hover:text-black">×</button>
              </div>
              <div className="p-4 bg-[#FFF9F8] max-h-[400px] overflow-y-auto">
                {likeList.length === 0 ? (
                  <p className="text-center text-gray-500">No likes yet</p>
                ) : (
                  likeList.map((like, index) => (
                    <div key={index} className="bg-white rounded-md shadow-sm p-4 mb-4 border border-[#E8D5D5]">
                      <div className="flex items-center gap-3 mb-2">
                        <div className="text-gray-700 text-lg">👍</div>
                        <span className="bg-[#FFF0ED] text-[#8B1A1A] px-3 py-1 rounded-full text-sm font-medium">{like.employeeName}</span>
                      </div>
                      <div className="text-sm text-gray-700 ml-8">{like.emailId}</div>
                      <div className="text-xs text-gray-500 ml-8 mt-1">{like.likedAt}</div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </>
  );
}

export default RecognitionDashboard;