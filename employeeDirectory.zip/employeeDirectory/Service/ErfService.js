
import config, { BASE_URL } from "../config";
import { createAxiosInstance } from "../ERF/http-form";

const appClientEmployeeRequisition = createAxiosInstance(
  // `${config.empolyeeRequisitionUrl}`
  `${BASE_URL}:9024/api/employeeRequisition`
);

const appClientWorkflow = createAxiosInstance(
  `${BASE_URL}:9028/api/workflow`
);

const getAllEmployeerequisition = async () => {
  try {
    const response = await appClientEmployeeRequisition.get(
      "/getAllEmployeeRequisition"
    );
    return response;
  } catch (error) {
    console.error("Error during fetching :", error);
    throw error;
  }
};

const getAllRequisitionType = async () => {
  try {
    const response = await appClientEmployeeRequisition.get(
      "/getAllRequisitionType"
    );
    return response;
  } catch (error) {
    console.error("Error during fetching :", error);
    throw error;
  }
};

const getAllEmploymentType = async () => {
  try {
    const response = await appClientEmployeeRequisition.get(
      "/getAllEmploymentType"
    );
    return response;
  } catch (error) {
    console.error("Error during fetching :", error);
    throw error;
  }
};

const getAllBillingType = async () => {
  try {
    const response = await appClientEmployeeRequisition.get(
      "/getAllBillingType"
    );
    return response;
  } catch (error) {
    console.error("Error during fetching :", error);
    throw error;
  }
};

const getAllJobDescription = async () => {
  try {
    const response = await appClientEmployeeRequisition.get(
      "/getAllJobDescription"
    );
    return response;
  } catch (error) {
    console.error("Error during fetching :", error);
    throw error;
  }
};

const getAllITAsset = async () => {
  try {
    const response = await appClientEmployeeRequisition.get(
      "/getAllITAsset"
    );
    return response;
  } catch (error) {
    console.error("Error during fetching :", error);
    throw error;
  }
};

const getAllITConfigurations = async () => {
  try {
    const response = await appClientEmployeeRequisition.get(
      "/getAllITConfigurations"
    );
    return response;
  } catch (error) {
    console.error("Error during fetching :", error);
    throw error;
  }
};

const getAllJobPriorityList = async () => {
  try {
    const response = await appClientEmployeeRequisition.get(
      "/getAllJobPriorityList"
    );
    return response;
  } catch (error) {
    console.error("Error during fetching :", error);
    throw error;
  }
};

const getAllPublishType = async () => {
  try {
    const response = await appClientEmployeeRequisition.get(
      "/getAllPublishType"
    );
    return response;
  } catch (error) {
    console.error("Error during fetching :", error);
    throw error;
  }
};

const getAllJobLocations = async () => {
  try {
    const response = await appClientEmployeeRequisition.get(
      "/getAllJobLocations"
    );
    return response;
  } catch (error) {
    console.error("Error during fetching :", error);
    throw error;
  }
};

const getAllCdlDepartments = async () => {
  try {
    const response = await appClientEmployeeRequisition.get(
      "/getAllDepartments"
    );
    return response;
  } catch (error) {
    console.error("Error during fetching :", error);
    throw error;
  }
};



const getSearchData = async (search) => {
  try {
    const response = await appClientEmployeeRequisition.get(
      `/getValue/${search}`
    );
    return response;
  } catch (error) {
    console.error("Error during fetching :", error);
    throw error;
  }
};

const savingRequistionWFInItemAndMainStatusTable = async (data) => {
  try {
    const response = await appClientWorkflow.post(
      "/savingMainStatus",
      data
    );
    return response;
  } catch (error) {
    console.error("Error during posting :", error);
    throw error;
  }
};

const ErfService = {
  getAllEmployeerequisition,
  getAllRequisitionType,
  getAllEmploymentType,
  getAllBillingType,
  getAllJobDescription,
  
  getSearchData,
  savingRequistionWFInItemAndMainStatusTable,
  getAllITAsset,
  getAllITConfigurations,
  getAllJobPriorityList,
  getAllPublishType,
  getAllJobLocations,
  getAllCdlDepartments,
};

export default ErfService;