import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { FileText, Briefcase, X } from 'lucide-react';
import { CiSearch } from 'react-icons/ci';
import ERFApprovalDetailsPage from './ERFApprovalDetailsPage';
import {BASE_URL } from "../config";
import Header from '../../components/Header';
import briefcaseSvg from '../../assets/briefcase.svg';

const ERFApprovaldashboard = () => {
  const navigate = useNavigate();
  const [erfData, setErfData] = useState([]);
  const [filteredErfData, setFilteredErfData] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(true);
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 5;
 // const empCode = '9085389';
 const empCode = localStorage.getItem('empId');
  const [selectedErf, setSelectedErf] = useState(null);
  const [showDetailsModal, setShowDetailsModal] = useState(false);
  // Fetch ERF data from API
  useEffect(() => {
    const fetchErfData = async () => {
      try {
        setLoading(true);
        const response = await axios.get(
          `${BASE_URL}:9024/api/employeeRequisition/getEmpRequisitionPendingList/${empCode}`
        );
        console.log('ERF Approval Data:', response.data);
        if (response.data && Array.isArray(response.data)) {
          const filteredData = response.data.filter((erf) => erf !== null);
          setErfData(filteredData);
          setFilteredErfData(filteredData);
        }
        setLoading(false);
      } catch (error) {
        console.error('Error fetching ERF data:', error);
        setLoading(false);
      }
    };

    if (empCode) {
      fetchErfData();
    }
  }, [empCode]);

  // Handle search
  useEffect(() => {
    const results = erfData.filter(
      (erf) =>
        erf.requisitionNumber?.toString().includes(searchTerm.toLowerCase()) ||
        erf.position?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        erf.department?.toLowerCase().includes(searchTerm.toLowerCase())
    );
    setFilteredErfData(results);
  }, [searchTerm, erfData]);


  const handleViewDetails = (erfData) => {
    console.log('View details:', erfData);
    
    if (!erfData.requisitionNumber) {
      console.error('Requisition number is missing');
      return;
    }
    
    // Pass entire ERF object to details page
    setSelectedErf(erfData);
    setShowDetailsModal(true);
  };

  const handleGoBack = () => {
    navigate(-1); // Go back to previous page
    // Or navigate to specific page: navigate('/irfdashboard');
  };

  const totalPages = Math.max(1, Math.ceil(filteredErfData.length / itemsPerPage));

  return (
    <div className="min-h-screen bg-gray-50 flex mt-20">
      <Header/>

      {/* Main Content */}
      <div className="flex-1 w-full">
        {/* Header Bar */}
        <div className="flex justify-between items-center px-6 py-6 bg-gradient-to-r from-red-800 to-red-700">
          <div>
            <h1 className="text-xl font-bold text-white tracking-tight">All Pending Requisitions</h1>
            {/* <p className="text-sm text-red-100 mt-0.5">
              {!loading && `${filteredErfData.length} requisition${filteredErfData.length !== 1 ? 's' : ''} awaiting your approval`}
            </p> */}
          </div>
          <button
            onClick={handleGoBack}
            className="group flex items-center justify-center w-9 h-9 rounded-full hover:bg-white/10 transition-colors"
            title="Go back"
          >
            <X size={20} className="text-red-100 group-hover:text-white transition-colors" />
          </button>
        </div>

        <div className="px-8 py-6">

        {/* Search Bar and Pagination */}
        <div className="flex flex-wrap justify-between items-center gap-4 mb-6">
          {/* Search Input */}
          <div className="relative flex-1 min-w-[240px] max-w-md">
            <CiSearch className="absolute top-1/2 left-3.5 -translate-y-1/2 text-gray-400 text-lg" />
            <input
              type="text"
              placeholder="Search in requisitions"
              className="w-full pl-10 pr-4 py-2.5 text-sm bg-white border border-gray-200 rounded-lg shadow-sm placeholder-gray-400 text-gray-800 focus:outline-none focus:ring-2 focus:ring-red-500/30 focus:border-red-400 transition-all"
              value={searchTerm}
              onChange={(e) => {
                setSearchTerm(e.target.value);
                setCurrentPage(1);
              }}
            />
          </div>

          {/* Pagination */}
          {!loading && filteredErfData.length > 0 && (
            <div className="flex items-center gap-3">
              <p className="text-sm text-gray-500 font-medium">
                {`${Math.min((currentPage - 1) * itemsPerPage + 1, filteredErfData.length)}-${Math.min(currentPage * itemsPerPage, filteredErfData.length)}`}
                <span className="text-gray-400"> of {filteredErfData.length}</span>
              </p>
              <div className="flex items-center gap-1">
                <button
                  className="w-8 h-8 flex items-center justify-center rounded-md border border-gray-200 bg-white text-gray-500 hover:bg-gray-100 hover:text-gray-800 disabled:opacity-40 disabled:hover:bg-white disabled:cursor-not-allowed transition-colors"
                  onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
                  disabled={currentPage === 1}
                  aria-label="Previous page"
                >
                  &#8249;
                </button>
                <button
                  className="w-8 h-8 flex items-center justify-center rounded-md border border-gray-200 bg-white text-gray-500 hover:bg-gray-100 hover:text-gray-800 disabled:opacity-40 disabled:hover:bg-white disabled:cursor-not-allowed transition-colors"
                  onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
                  disabled={currentPage === totalPages}
                  aria-label="Next page"
                >
                  &#8250;
                </button>
              </div>
            </div>
          )}
        </div>

        {/* ERF Data Cards */}
        {loading ? (
          <div className="flex flex-col justify-center items-center h-64 bg-white rounded-xl border border-gray-100 shadow-sm">
            <div className="animate-spin rounded-full h-10 w-10 border-2 border-gray-200 border-t-red-600"></div>
            <span className="mt-4 text-sm text-gray-500">Loading requisitions…</span>
          </div>
        ) : filteredErfData.length === 0 ? (
          <div className="bg-white rounded-xl p-16 text-center shadow-sm border border-gray-100">
            <FileText size={44} className="mx-auto text-gray-300 mb-4" />
            <p className="text-gray-600 text-base font-medium">No pending ERF requests found</p>
            <p className="text-gray-400 text-sm mt-1">Try adjusting your search terms</p>
          </div>
        ) : (
          <div className="space-y-4">
            {filteredErfData
              .slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage)
              .map((erf) => (
                <div
                  key={erf.requisitionNumber}
                  className="group bg-white border border-gray-200 border-l-4 border-l-red-600 rounded-xl shadow-sm hover:shadow-md transition-all duration-200 overflow-hidden"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center gap-5 p-6">
                    {/* Icon */}
                    <div className="w-16 h-16 rounded-xl overflow-hidden flex items-center justify-center flex-shrink-0 bg-gray-50 border border-gray-200">
                      <img src={erf.imageUrl || briefcaseSvg} alt={erf.position || 'requisition'} className="h-8 w-8 object-contain" />
                    </div>

                    {/* Main info */}
                    <div className="flex-grow min-w-0">
                      <div className="flex flex-wrap items-center gap-x-3 gap-y-1 mb-3">
                        <span className="inline-flex items-center px-2.5 py-1 rounded-md bg-red-50 text-red-700 text-xs font-bold tracking-wide">
                          ERF{erf.requisitionNumber}
                        </span>
                        <span className="inline-flex items-center px-2.5 py-1 rounded-md bg-gray-100 text-gray-700 text-xs font-semibold">
                          {erf.department || 'N/A'}
                        </span>
                        <span className="text-xs text-gray-400">
                          Created by <span className="font-semibold text-gray-600">{erf.initiatorName || 'N/A'}</span>
                          {' '}<span className="text-gray-400">({erf.initiatorEmployeeCode || 'N/A'})</span>
                        </span>
                      </div>

                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 sm:gap-6">
                        <div>
                          <p className="text-[11px] uppercase tracking-wide text-gray-400 font-semibold">Requisition Type</p>
                          <p className="text-gray-900 text-sm font-medium mt-0.5">{erf.requisitionType || 'N/A'}</p>
                        </div>
                        <div>
                          <p className="text-[11px] uppercase tracking-wide text-gray-400 font-semibold">Date</p>
                          <p className="text-gray-900 text-sm font-medium mt-0.5">{erf.appliedOn || erf.createdDate || 'N/A'}</p>
                        </div>
                        <div>
                          <p className="text-[11px] uppercase tracking-wide text-gray-400 font-semibold">Position</p>
                          <p className="text-gray-900 text-sm font-medium mt-0.5">{erf.position || 'N/A'}</p>
                        </div>
                        <div>
                          <p className="text-[11px] uppercase tracking-wide text-gray-400 font-semibold">No. of Positions</p>
                          <p className="text-gray-900 text-sm font-medium mt-0.5">{erf.noOfPositions || 0}</p>
                        </div>
                      </div>
                    </div>

                    {/* Action */}
                    <div className="flex-shrink-0 sm:self-center">
                      <button
                        onClick={() => handleViewDetails(erf)}
                        className="px-5 py-2.5 bg-red-700 hover:bg-red-800 text-white rounded-lg font-semibold text-sm transition-colors whitespace-nowrap shadow-sm shadow-red-700/20"
                      >
                        View in Detail
                      </button>
                    </div>
                  </div>
                </div>
              ))}
          </div>
        )}
        </div>
      </div>
      {showDetailsModal && selectedErf && (
        <ERFApprovalDetailsPage
          erfData={selectedErf}
          onClose={() => setShowDetailsModal(false)}
        />
      )}
    </div>
  );
};

export default ERFApprovaldashboard;