import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, ChevronRight } from 'lucide-react';

const ERFHRDashboard = () => {
  const [intRefData, setIntRefData] = useState('');
  const navigate = useNavigate();

  const handleSearch = (e) => {
    e.preventDefault();
    if (intRefData.trim()) {
      navigate(`/jobdashboard/${intRefData}`);
    }
  };

  return (
<div className="w-full bg-slate-50 min-h-[calc(100vh-64px)]"> 
       <div className="flex flex-col items-center justify-center p-8">
        <div className="max-w-2xl w-full">
          <div className="text-center mb-10">
            <h1 className="text-4xl font-bold text-blue-900 mb-4">
              Internal Resource Lookup
            </h1>
            <p className="text-slate-500">
              Enter the reference number to search.
            </p>
          </div>

          <section className="bg-white p-2 rounded-2xl shadow-2xl border border-slate-200 overflow-hidden">
            <form onSubmit={handleSearch} className="flex">
              <div className="flex-grow flex items-center px-6 py-4">
                <Search className="text-blue-900 mr-4" size={24} />
                <input
                  type="text"
                  value={intRefData}
                  onChange={(e) => setIntRefData(e.target.value)}
                  placeholder="Enter internal reference number..."
                  className="w-full outline-none text-sm font-medium"
                />
              </div>

              <button
                type="submit"
                className="bg-blue-900 hover:bg-blue-800 text-white px-10 py-4 font-bold transition-all flex items-center gap-2"
              >
                Search <ChevronRight size={18} />
              </button>
            </form>
          </section>
        </div>
      </div>
    </div>
  );
};

export default ERFHRDashboard;