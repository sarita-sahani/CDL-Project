import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { X } from 'lucide-react';
import Swal from 'sweetalert2';
import { IoEnterOutline } from "react-icons/io5";
import { Item } from 'semantic-ui-react';
import {BASE_URL } from "../config";

const Field = ({ label, value }) => (
  <div className="flex text-sm">
    <div className="min-w-[200px] flex text-slate-500 font-semibold">{label}</div>
    <div className="font-semibold text-black">{value || "-"}</div>
  </div>
);

const ERFApprovalDetailsPage = ({ erfData, onClose }) => {
  const [requisition, setRequisition] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const wfSeqId = erfData?.wfSeqId;
  const requisitionNumber = erfData?.requisitionNumber;
  
  const [wfLevelActions, setWfLevelActions] = useState([]);
  const [actorRemark, setActorRemark] = useState(null);
  const [popupVisible, setPopupVisible] = useState(false);
  const [filteredAction, setFilteredAction] = useState('');
  const [selectedAction, setSelectedAction] = useState(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
   const [comment, setComment] = useState("");
 // const empCode = '9085174';
  const empCode = localStorage.getItem('empId');
  const [commentFetched, setCommentFetched] = useState([]);

  const fetchMgrComment = async () => {
    try {
      const response = await axios.get(
        `${BASE_URL}:9028/api/workflow/getAllComments/${wfSeqId}`
      );
      setCommentFetched(response.data);
    } catch (error) {
      console.error("Error fetching comments:", error);
    }
  };

  useEffect(() => {
    if (wfSeqId) {
      fetchMgrComment();
    }
  }, [wfSeqId]);

  const submitMgrComment = () => {
  if (!comment.trim()) {
    alert("Comment cannot be empty");
    return;
  }

  const url = `${BASE_URL}:9028/api/workflow/sendComments/${wfSeqId}/${empCode}`;

  axios.post(url,comment)
    .then(() => {
      setComment("");
      fetchMgrComment();
    })
    .catch((error) => {
      console.error(error);
      alert("Failed to post comment");
    });
};

  useEffect(() => {
    if (erfData) {
      console.log('ERF Data received:', erfData);
      setRequisition(erfData);
      setLoading(false);
      setError(null);
    } else {
      setError('No ERF data provided');
      setLoading(false);
    }
  }, [erfData]);

  const fetchActions = async () => {
    if (requisition && wfSeqId) {
      try {
        const wfItemSeqNum = requisition.wfItemSeqNum || '';
        console.log('Fetching actions with wfSeqId:', wfSeqId, 'wfItemSeqNum:', wfItemSeqNum);

        const response = await axios.get(
          `${BASE_URL}:9028/api/workflow/getWfLevelActions/${wfSeqId}/${empCode}/${wfItemSeqNum}`
        );
        setWfLevelActions(response.data);
      } catch (error) {
        console.error('Error fetching workflow level actions:', error);
      }
    }
  };

  useEffect(() => {
    fetchActions();
  }, [requisition, wfSeqId, empCode]);

  const handleActionClick = (action) => {
    const filtered = action.replace(/[^a-zA-Z]/g, '');
    setFilteredAction(filtered);
     setSelectedAction(action);
    setPopupVisible(true);
  };

  const handleActionConfirmation = () => {
    if (isSubmitting) return; // guard against double-clicks
    setIsSubmitting(true);

    const url = `${BASE_URL}:9028/api/workflow/getActions/${wfSeqId}/${empCode}/${actorRemark}/${erfData.wfItemSeqNum}?selectedOption=${selectedAction}`;

    axios
      .get(url)
      .then((response) => {
        console.log('response<>>>>>', response);

        Swal.fire({
          icon: 'success',
          title: `Successfully ${selectedAction}!`,
          text: `Employee requisition has been ${
            selectedAction && selectedAction.toLowerCase().includes('reject')
              ? 'rejected'
              : 'approved'
          } successfully.`,
        });

        setPopupVisible(false);
        window.location.reload();
      })
      .catch((error) => {
        console.error('Error handling action confirmation:', error);
        Swal.fire({
          icon: 'error',
          title: 'Error',
          text: 'An error occurred while processing your request. Please try again.',
        });
        setIsSubmitting(false);
      });
  };

  const handleClosePopup = () => {
    setPopupVisible(false);
  };



  const handleCancel = () => {
    onClose();
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div>
        <span className="ml-4 text-gray-600">Loading requisition details...</span>
      </div>
    );
  }

  if (!requisition) {
    return (
      <div className="flex justify-center items-center h-screen">
        <div className="text-center">
          <p className="text-gray-600 text-lg mb-4">No requisition details found</p>
          {error && <p className="text-red-600 text-sm">{error}</p>}
          {requisitionNumber && <p className="text-gray-500 text-xs">Req#: {requisitionNumber}</p>}
          {wfSeqId && <p className="text-gray-500 text-xs">WF Seq#: {wfSeqId}</p>}
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center bg-black bg-opacity-50 p-6">
      <div className="bg-white w-[95%] max-w-5xl rounded-lg shadow-xl border border-gray-300 mt-8 overflow-hidden">
        {/* Close Button */}
        <div className="relative">
          <button
            onClick={handleCancel}
            className="absolute top-4 right-4 text-red-500 border border-red-500 rounded-full p-1 hover:bg-red-100"
            title="Close"
          >
            <X size={20} />
          </button>
        </div>

        {/* Scrollable content */}
        <div className="p-6 max-h-[85vh] overflow-y-auto">
          {/* Header with Request Number */}
          <div className="mb-4">
            <h2 className="text-xl font-semibold text-gray-800">
              Request No:{' '}
              <span className="text-green-600">
              {requisition.requisitionNumber}
              </span>
            </h2>
          </div>

          {/* Approval & Overall Status */}
          <div className="flex justify-between items-center mb-6">
            <div className="w-1/3" />
            <div className="w-1/3 text-center text-base font-medium text-gray-700">
              Approval Status:{' '}
              <span className="text-red-500">Pending</span>
            </div>
            <div className="w-1/3 text-right text-base font-medium text-gray-700">
              Overall Status:{' '}
              <span className="text-blue-600">{requisition.requisitionStatus}</span>
            </div>
          </div>

          <div className="border border-gray-300 rounded px-6 py-4 mb-6">
            {/* Requisition Type and Action Dropdown */}
            <div className="flex justify-between items-center mb-4">
              <div className="text-slate-500 font-semibold flex">
                <div className="min-w-[200px]">Requisition Type</div>
                <div className="font-semibold text-black">
                  {requisition.requisitionType || '-'}
                </div>
              </div>
            </div>

            <div className="w-[50%] h-px bg-gray-200 mt-1 mb-4" />

            <div className="flex text-slate-500 font-semibold mb-2">
              <div className="min-w-[200px]">Date</div>
              <div className="font-semibold text-black">{requisition.appliedOn || '-'}</div>
            </div>

            <div className="w-[50%] h-px bg-gray-200 mt-2 mb-4" />

            <div className="flex text-slate-500 font-semibold mb-2">
              <div className="min-w-[200px]">Employment Type</div>
              <div className="font-semibold text-black">{requisition.employmentType || '-'}</div>
            </div>

            <div className="w-[50%] h-px bg-gray-200 mt-2 mb-4" />

            <div className="flex text-slate-500 font-semibold mb-2">
              <div className="min-w-[200px]">Billing Type</div>
              <div className="font-semibold text-black">{requisition.billingType || '-'}</div>
            </div>

            {/* Grid Columns for Details */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-6 pb-6 text-semibold">
              {/* Replacement */}
              <div>
                <h3 className="text-md font-semibold text-gray-700 mb-4">Replacement</h3>
                <div className="space-y-4">
                  <Field label="Name of Replacement" value={requisition.replacementType} />
                  <Field label="Employee Code" value={requisition.employeeCode} />
                  <Field label="Project" value={requisition.replacementProject} />
                  <Field label="Department" value={requisition.replacementDepartment} />
                  <Field label="Replacement Location" value={requisition.replacementLocation} />
                  <Field label="CTC" value={requisition.ctc} />
                </div>
              </div>

              {/* Position Details */}
              <div>
                <h3 className="text-md font-semibold text-gray-700 mb-4">Position Details</h3>
                <div className="space-y-4">
                  <Field label="Department" value={requisition.department} />
                  <Field label="Position" value={requisition.position} />
                  <Field label="No of Positions" value={requisition.noOfPositions} />
                  <Field
                    label="Experience Range"
                    value={`${requisition.minimumExperienceRange} to ${requisition.maximumExperienceRange}`}
                  />
                  <Field label="Education" value={requisition.education} />
                  <Field label="Certification(s)" value={requisition.certifications} />
                  <Field label="Job Location" value={requisition.jobLocation} />
                  <Field label="Reporting To" value={requisition.reportingTo} />
                  <Field label="Budget" value={requisition.budget} />
                </div>
              </div>

              {/* Timeline Section */}
               <div className="border-l-[1px] border-gray-300 pl-6 mt-6">
                <h3 className="text-md font-semibold text-gray-700 mb-4 -mt-6">Timeline</h3>

                {/* Pending + Withdraw */}
               <div className="border-l-[2px] border-gray-300">
                    <div className="justify-between items-center p-4">
                      <h2 className="text-sm font-medium text-red-500">
                        Pending
                      </h2>
                      <div className="flex">
                        <div className="text-gray-400 font-medium mr-2">
                          With
                        </div>
                        <div className="text-gray-700 font-medium">Manager</div>
                      </div>
                    </div>

                    <div className="flex p-4">
                      <input
                        className="border border-gray-300 w-full text-xs p-2"
                        placeholder="Enter your text..."
                        value={comment}
                        onChange={(e) => setComment(e.target.value)}
                      />
                      <IoEnterOutline
                        className="ml-[-2rem] mt-1 text-sm cursor-pointer"
                        onClick={submitMgrComment}
                      />
                    </div>
                    <div className="mt-3 p-4 text-base">
                      {commentFetched.length > 0 ? (
                        <ul>
                          {commentFetched.map((comment, index) => (
                            <li key={index}>
                              <p className="text-gray-600 font-normal">
                                <strong>{comment.employeeName}</strong> added a{" "}
                                <strong>Comment</strong>
                              </p>
                              <p className="text-gray-500">
                                {comment.comments}
                              </p>
                              <p className="text-gray-400 font-medium mb-4">
                                {comment.commentDateTime}
                              </p>
                            </li>
                          ))}
                        </ul>
                      ) : (
                        <p>No comments available.</p>
                      )}
                    </div>
                  </div>

                
              </div>
             
            </div>

            {/* IT & Initiator Section */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-6 pb-6 text-semibold">
              {/* IT Asset Requirements */}
              <div>
                <h3 className="text-md font-semibold text-gray-700 mb-4">IT Asset Requirements</h3>
                <div className="space-y-4">
                  <Field label="IT Asset" value={requisition.itAsset} />
                  <Field label="Configurations" value={requisition.configuartions} />
                  <Field label="Additional Informations" value={requisition.additionalInformations} />
                 
                  {/* <Field label="First Level Approver" value={requisition.firstLevelApprover} />
                  <Field label="Second Level Approver" value={requisition.secondLevelApprover} /> */}
                </div>
              </div>

              {/* Initiator Details */}
              <div>
                <h3 className="text-md font-semibold text-gray-700 mb-4">Initiator Details</h3>
                <div className="space-y-4">
                  <Field label="Name" value={requisition.initiatorName} />
                  <Field label="Employee Code" value={requisition.initiatorEmployeeCode} />
                  <Field label="BU Head" value={requisition.buHead} />
                  <Field label="Initialtor Location" value={requisition.initiatorLocation} />
                   <Field label="Initiated by (Hiring manager)" value={requisition.initiatorName} />
                </div>
              </div>
            </div>

            {/* Selected JD - Above Job Description */}
            <div className="mb-6">
              <h3 className="text-md font-semibold mb-2">Selected JD</h3>
              <div className="text-slate-700 font-semibold pl-2">{requisition.selectedJob || '-'}</div>
            </div>
           

            {/* Job Description */}
            <div className="mb-6">
              <h3 className="text-md font-semibold mb-2">Job Description</h3>
              <div className="text-slate-500 font-semibold text-black whitespace-pre-line pl-2">
                {requisition.jobDescription
                  ? requisition.jobDescription
                    .split('\n')
                    .map((line, index) => (
                      <div key={index}>
                        {line.trim() !== '' ? `• ${line}` : ''}
                      </div>
                    ))
                  : "-"}
              </div>
            </div>

            {/* Required Skills */}
            <div className="mb-6">
              <h3 className="text-md font-semibold mb-2">Required Skills</h3>
              <div className="text-slate-500 font-semibold text-black pl-2">
                {requisition.requiredSkills
                  ? requisition.requiredSkills.split('\n').map((line, index) => (
                    <div key={index}>{line.trim() ? `• ${line}` : ''}</div>
                  ))
                  : "-"}
              </div>
            </div>

            {/* Additional Skills */}
            <div className="mb-6">
              <h3 className="text-md font-semibold mb-2">Additional Skills</h3>
              <div className="text-slate-500 font-semibold text-black pl-2">
                {requisition.additionalSkills
                  ? requisition.additionalSkills.split('\n').map((line, index) => (
                    <div key={index}>{line.trim() ? `• ${line}` : ''}</div>
                  ))
                  : "-"}
              </div>
            </div>
          </div>

          {/* Action Buttons - Cancel and Approve */}
         <div className="flex justify-center items-center h-full mt-4">
                <div className="flex flex-wrap gap-2">
                  {wfLevelActions &&
                    wfLevelActions.map((action, index) => {
                      // Remove any non-alphabet characters
                      const filteredAction = action.replace(/[^a-zA-Z]/g, "");

                      // Only display buttons for "Reject" and "Approve"
                      if (
                        filteredAction === "Reject" ||
                        filteredAction === "Approve"
                      ) {
                        return (
                          <button
                            key={index}
                            className={`py-2 px-4 rounded-md ${
                              filteredAction === "Reject"
                                ? "bg-red-500"
                                : "bg-blue-500"
                            } text-white`}
                            onClick={() => handleActionClick(action)}
                          >
                            {filteredAction}
                          </button>
                        );
                      }

                      return null;
                    })}
                </div>
              </div>

              {popupVisible && (
                <div className="fixed inset-0 flex items-center justify-center bg-gray-800 bg-opacity-50 p-4">
                  <div className="bg-white p-4 rounded-lg w-full md:w-1/3">
                    <h2 className="text-sm font-semibold">
                      {filteredAction} Request
                    </h2>
                    <textarea
                      value={actorRemark}
                      onChange={(e) => setActorRemark(e.target.value)}
                      className="w-full h-24 border border-gray-300 mt-2 p-2"
                      placeholder="Add your remarks here"
                    />
                    <div className="flex justify-end mt-4">
                      <button
                        className={`bg-blue-500 text-white py-2 px-4 rounded-md flex items-center justify-center gap-2 min-w-[100px] ${
                          isSubmitting ? 'opacity-70 cursor-not-allowed' : ''
                        }`}
                        onClick={handleActionConfirmation}
                        disabled={isSubmitting}
                      >
                        {isSubmitting && (
                          <span className="h-4 w-4 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                        )}
                        {isSubmitting ? 'Submitting...' : 'Confirm'}
                      </button>
                      <button
                        className={`bg-gray-500 text-white py-2 px-4 rounded-md ml-2 ${
                          isSubmitting ? 'opacity-70 cursor-not-allowed' : ''
                        }`}
                        onClick={handleClosePopup}
                        disabled={isSubmitting}
                      >
                        Cancel
                      </button>
                    </div>
                  </div>
                </div>
              )}
        </div>
      </div>
    </div>
  );
};

export default ERFApprovalDetailsPage;