import React, { useEffect, useState, useRef } from "react";
import Dropdown from "react-dropdown";
import "react-dropdown/style.css";
import Select from "react-select";
import { IoIosArrowDown } from "react-icons/io";
import { CiExport, CiSearch } from "react-icons/ci";
import { FaSquarePlus, FaRegCircleXmark } from "react-icons/fa6";
import { Box, Modal } from "@mui/material";
import Swal from "sweetalert2";
import * as XLSX from "xlsx";
import { LuFilter } from "react-icons/lu";
import axios from "axios";
import "../ERF/ERFComponent.css";
import ViewRequisitionModal from "./ViewRequisitionModal";
import ErfService from "../Service/ErfService";
import { FaUserTie } from "react-icons/fa";
import Header from "../../components/Header";

// SweetAlert2 popups use a lower default z-index than MUI's <Modal>
// (z-index: 1300), so a Swal.fire() call made while the "Create New
// Employee Requisition" modal is open gets added to the DOM but rendered
// underneath the modal's backdrop — completely invisible, even though the
// alert genuinely fired. This forces every Swal2 popup above that layer.
if (typeof document !== "undefined" && !document.getElementById("swal2-zindex-fix")) {
  const style = document.createElement("style");
  style.id = "swal2-zindex-fix";
  style.textContent = `.swal2-container { z-index: 20000 !important; }`;
  document.head.appendChild(style);
}

const BASE_URL = "http://localhost";

// Pulls a human-readable message out of an axios error, whatever shape the
// backend's error body happens to be in (JSON with "message", JSON with
// "error"/"detail", a plain-text body, or nothing at all).
const extractErrorMessage = (error, fallback) => {
  const data = error?.response?.data;

  if (typeof data === "string" && data.trim()) {
    return data;
  }
  if (data && typeof data === "object") {
    const candidate =
      data.message || data.error || data.errorMessage || data.detail || data.msg;
    if (candidate) return candidate;
  }
  return error?.message || fallback;
};

function EmployeeRequisition() {
  const [modalOpen, setModalOpen] = useState(false);
  const [filterOpen, setFilterOpen] = useState(false);
  const [billingType, setBillingType] = useState([]);
  const [jobDescriptionType, setJobDescriptionType] = useState([]);

  const [itAssetOptions, setItAssetOptions] = useState([]);
  const [configurationsOptions, setConfigurationsOptions] = useState([]);
  const [jobPriorityOptions, setJobPriorityOptions] = useState([]);
  const [publishTypeOptions, setPublishTypeOptions] = useState([]);
  const [jobLocationOptions, setJobLocationOptions] = useState([]);
  const [departmentOptions, setDepartmentOptions] = useState([]);

  // Dropdown lists coming from the external item-values API
  const [jobTypeOptions, setJobTypeOptions] = useState([]); // used for "Employment Type"
  const [jobRoleOptions, setJobRoleOptions] = useState([]);
  const [requisitionTypeOptions, setRequisitionTypeOptions] = useState([]);

  const [searchTerm, setSearchTerm] = useState("");
  const [filterTerm, setFilterTerm] = useState("");
  const [filterRequisition, setFilterRequisition] = useState("");

  const [employeeRequisition, setEmployeeRequisition] = useState({});
  const [newEmployeeRequisition, setNewEmployeeRequisition] = useState([]);

  const [resolvedCount, setResolvedCount] = useState(0);
  const [resolvedRequestsCount, setResolvedRequestsCount] = useState(null);
  const [openCount, setOpenCount] = useState(0);
  const [openRequestsCount, setOpenRequestsCount] = useState(null);

  const [viewModalOpen, setViewModalOpen] = useState(false);
  const [selectedRequisition, setSelectedRequisition] = useState(null);
  const [requisitions, setRequisitions] = useState([]);

  const [filteredRequisitions, setFilteredRequisitions] = useState([]);
  const [year, setYear] = useState("All");
  const [month, setMonth] = useState("All");
  const [status, setStatus] = useState("All");
  const [overallStatusList, setOverallStatusList] = useState([]);
  const [locationName, setLocationName] = useState("");
  const [initiatorDepartment, setInitiatorDepartment] = useState("");
  const defaultsAppliedRef = useRef(false);

  const currentYear = new Date().getFullYear();
  const years = Array.from({ length: 5 }, (_, i) => currentYear - i);
  const months = ["All", ...Array.from({ length: 12 }, (_, i) =>
    new Date(0, i).toLocaleString("default", { month: "long" })
  )];

  const empCode = localStorage.getItem("empId");
  const workFlowName = "EmployeeRequisition";

  const [empData, setEmpData] = useState(null);
  const [wbsId, setWbsId] = useState("");

  const jobLocationSelectOptions = jobLocationOptions.map((item) => ({
    value: item.value ?? item.jobLocationName ?? item.name ?? item,
    label: item.label ?? item.jobLocationName ?? item.name ?? item,
  }));

  const getSelectedJobLocations = () => {
    if (!employeeRequisition.jobLocation) return [];
    const values = employeeRequisition.jobLocation.split(";").filter(Boolean);
    return jobLocationSelectOptions.filter((opt) => values.includes(opt.value));
  };

  useEffect(() => {
    if (!empCode) return;
    axios
      .get(`${BASE_URL}:9024/api/employeeRequisition/getEmployeeInfo/${empCode}`)
      .then((response) => {
        const fetched = response.data.fileAndObjectTypeBean?.empResDTO;
        setEmpData(fetched);
        setWbsId(fetched?.projectResDTO?.projectId || "");
        const dept = fetched?.subDeptResDTO?.subDept || "";
      setInitiatorDepartment(dept)
        const loc = response.data.userDTO?.locationResDTO?.locationName || "";
        setLocationName(loc);
      })
      .catch((error) => console.error("Error fetching data:", error));
  }, [empCode]);

  useEffect(() => {
    fetch(`${BASE_URL}:9024/api/employeeRequisition/getAllEmployeeRequisition`)
      .then((res) => res.json())
      .then((data) => {
        setRequisitions(data);
        setFilteredRequisitions(data);
      })
      .catch((err) => console.error("Failed to fetch requisitions", err));
  }, []);

  // Generic fetch for the external item-values dropdowns.
  // itemListName is the only thing that changes between calls
  // (JOB_TYPE, JOB_PRIORITY, JOB_ROLE, ...).
  // Returns null (instead of []) on failure so the caller can tell
  // "failed" apart from "genuinely empty".
  const fetchItemValues = async (itemListName) => {
    try {
      const res = await axios.get(
        `${BASE_URL}:9024/api/employeeRequisition/getItemValues/${itemListName}`
      );
      return res.data || [];
    } catch (err) {
      console.error(`Failed to fetch ${itemListName}`, err);
      return null;
    }
  };

  // Tracks which dropdown fields failed to load (any error), keyed by
  // itemListName. Checked at click time so the alert shows the instant the
  // user opens that specific field, not just once right after the batch load.
  const [dropdownFetchFailed, setDropdownFetchFailed] = useState({});

  // Wire this to a dropdown's onClick/onMenuOpen. Shows the fixed
  // "service is down" alert immediately if that field's data failed to load.
  const notifyFieldServiceDown = (itemListName) => {
    console.log("[dropdown click]", itemListName, "failed?", dropdownFetchFailed[itemListName], "full map:", dropdownFetchFailed);
    if (dropdownFetchFailed[itemListName]) {
      Swal.fire({
        icon: "error",
        title: "Service Unavailable",
        text: "E-recruitment service is down. Please try again later.",
      });
    }
  };

  // Fire all dropdown lookups together so the backend reuses a single
  // cached session instead of logging in per dropdown.
  // Triggered ONLY when the "Add Employee Requisition" modal opens —
  // never on dashboard mount/refresh.
  // NOTE: item_list_name suffixes below are my best guess for
  // PUBLISH_TYPE — confirm the exact def.JobPost_XXX name with a
  // Postman call before relying on it, the same way we confirmed JOB_ROLE.
  useEffect(() => {
    if (!modalOpen) return;
    const loadExternalDropdowns = async () => {
      const itemListNames = {
        jobType: "JOB_TYPE",
        jobPriority: "JOB_PRIORITY",
        jobRole: "JOB_ROLE",
        publishType: "PUBLISH_TYPE",
        department: "HIRING_DEPT&item_map_caption=true",
        jobLocation: "JOB_LOCATIONS",
        requisitionType: "HIRING_TYPE",
      };

      const [
        jobTypeList,
        jobPriorityList,
        jobRoleList,
        publishTypeList,
        departmentList,
        jobLocationList,
        requisitionTypeList,
      ] = await Promise.all([
        fetchItemValues(itemListNames.jobType), // used for "Employment Type"
        fetchItemValues(itemListNames.jobPriority),
        fetchItemValues(itemListNames.jobRole),
        fetchItemValues(itemListNames.publishType),
        fetchItemValues(itemListNames.department),
        fetchItemValues(itemListNames.jobLocation),
        fetchItemValues(itemListNames.requisitionType),
      ]);

      const resultsByName = {
        [itemListNames.jobType]: jobTypeList,
        [itemListNames.jobPriority]: jobPriorityList,
        [itemListNames.jobRole]: jobRoleList,
        [itemListNames.publishType]: publishTypeList,
        [itemListNames.department]: departmentList,
        [itemListNames.jobLocation]: jobLocationList,
        [itemListNames.requisitionType]: requisitionTypeList,
      };
      const failedMap = {};
      Object.entries(resultsByName).forEach(([name, result]) => {
        failedMap[name] = result === null;
      });
      console.log("[dropdown load] failedMap:", failedMap);
      setDropdownFetchFailed(failedMap);

      setJobTypeOptions(jobTypeList || []);
      setJobPriorityOptions(jobPriorityList || []);
      setJobRoleOptions(jobRoleList || []);
      setPublishTypeOptions(publishTypeList || []);
      setDepartmentOptions(departmentList || []);
      setJobLocationOptions(jobLocationList || []);
      setRequisitionTypeOptions(requisitionTypeList || []);
    };
    loadExternalDropdowns();
  }, [modalOpen]);


  useEffect(() => {
    if (modalOpen && empData && !defaultsAppliedRef.current) {
      const fullName = (empData.firstName || "") + " " + (empData.lastName || "");
      setEmployeeRequisition((prev) => ({
        ...prev,
        initiatorName: fullName.trim(),
        initiatorEmployeeCode: empData.empCode || "",
        initiatorDepartmentName: initiatorDepartment || "",
        buHead: empData.buHeadName || "",
        initiatorLocation: locationName || "",
        initiatorEmailId:
          empData.email ||
          empData.emailId ||
          localStorage.getItem("email") ||
          "",
      }));
      defaultsAppliedRef.current = true;
    }
    if (!modalOpen) {
      defaultsAppliedRef.current = false;
    }
  }, [modalOpen, empData, locationName]);

  useEffect(() => {
    let data = [...requisitions];
    if (year !== "All") {
      data = data.filter((r) => {
        const reqYear = new Date(r.createdDate).getFullYear().toString();
        return reqYear === year;
      });
    }
    if (month !== "All") {
      data = data.filter((r) => {
        const reqMonth = (new Date(r.createdDate).getMonth() + 1).toString();
        return reqMonth === month;
      });
    }
    if (status !== "All") {
      data = data.filter((r) => {
        const overallStatus = overallStatusList[r.wfSeqId];
        return overallStatus === status;
      });
    }
    if (searchTerm.trim() !== "") {
      const term = searchTerm.toLowerCase();
      data = data.filter(
        (r) =>
          r.position?.toLowerCase().includes(term) ||
          String(r.requisitionNumber || "").toLowerCase().includes(term)
      );
    }
    setFilteredRequisitions(data);
  }, [year, month, status, searchTerm, requisitions, overallStatusList]);

  const daysOptions = ["Last 30 Days", "Last 60 Days", "Last 90 Days", "Last 120 Days"];
  const defaultDays = daysOptions[0];

  const [createRequest, setCreateRequest] = useState(defaultDays);
  const [resolvedRequest, setResolvedRequest] = useState(defaultDays);
  const [openRequest, setOpenRequest] = useState(defaultDays);
  const [totalRequestsCreated, setTotalRequestsCreated] = useState(null);

  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");

  const [validationErrors, setValidationErrors] = useState({
    requisitionType: "",
    appliedOn: "",
    employmentType: "",
    billingType: "",
    selectedJob: "",
    jobDescription: "",
    requiredSkills: "",
    additionalSkills: "",
    replacementType: "",
    employeeCode: "",
    replacementProject: "",
    replacementDepartment: "",
    replacementLocation: "",
    ctc: "",
    department: "",
    erecDeptCode: "",
    position: "",
    minimumExperienceRange: "",
    maximumExperienceRange: "",
    education: "",
    certifications: "",
    jobLocation: "",
    otherJobLocation: "",
    reportingTo: "",
    budget: "",
    noOfPositions: "",
    itAsset: "",
    configurations: "",
    additionalInformations: "",
    initiatorName: "",
    initiatorEmployeeCode: "",
    buHead: "",
    initiatorLocation: "",
    initiatorEmailId: "",
    initiatorDepartmentName: "",
    salaryMin: "",
    salaryMax: "",
    projectName: "",
    projectManager: "",
    requirementName: "",
    reportingManager: "",
    jobPriority: "",
    leadTime: "",
    publishType: "",
  });

  const [currentPage, setCurrentPage] = useState(1);
  const ItemsPerPage = 5;

  useEffect(() => {
    ErfService.getAllEmployeerequisition()
      .then((res) => {
        setNewEmployeeRequisition(res.data);
        const openStatuses = ["Rejected", "Pending", "In Progress"];
        calculateRequestsCounts(
          res.data,
          openStatuses,
          openRequest,
          setOpenCount,
          setOpenRequestsCount
        );
        calculateRequestsCounts(
          res.data,
          ["Approved"],
          resolvedRequest,
          setResolvedCount,
          setResolvedRequestsCount
        );
        calculateRequestsCounts(
          res.data,
          [],
          createRequest,
          null,
          setTotalRequestsCreated
        );
      })
      .catch((error) => {
        console.error("Fetching error", error);
      });
  }, [createRequest, resolvedRequest, openRequest]);

  function calculateRequestsCounts(
    newEmployeeRequisition,
    statuses,
    option,
    setStatusCount,
    setRequestsCount
  ) {
    let filteredRequests;
    if (Array.isArray(statuses) && statuses.length > 0) {
      filteredRequests = newEmployeeRequisition.filter((request) =>
        statuses.includes(request.overallStatus)
      );
    } else if (statuses.length === 0) {
      filteredRequests = newEmployeeRequisition;
    } else {
      filteredRequests = newEmployeeRequisition.filter(
        (request) => request.overallStatus === statuses
      );
    }
    const requestRaisedDate = filteredRequests.map(
      (request) => new Date(request.appliedOn)
    );
    const currentDate = new Date();
    const dateDifferences = requestRaisedDate.map((appliedOn) =>
      Math.floor((currentDate - appliedOn) / (1000 * 60 * 60 * 24))
    );
    if (option === "Last 30 Days") {
      setRequestsCount(
        getRequestsWithinNDays(filteredRequests, dateDifferences, 30)
      );
    } else if (option === "Last 60 Days") {
      setRequestsCount(
        getRequestsWithinNDays(filteredRequests, dateDifferences, 60)
      );
    } else if (option === "Last 90 Days") {
      setRequestsCount(
        getRequestsWithinNDays(filteredRequests, dateDifferences, 90)
      );
    } else if (option === "Last 120 Days") {
      setRequestsCount(
        getRequestsWithinNDays(filteredRequests, dateDifferences, 120)
      );
    }
    if (setStatusCount) {
      setStatusCount(filteredRequests.length);
    }
  }

  function getRequestsWithinNDays(
    newEmployeeRequisition,
    dateDifferences,
    days
  ) {
    return newEmployeeRequisition.filter(
      (_, index) => dateDifferences[index] <= days
    ).length;
  }

  const handleCreateRequest = (option) => {
    setCreateRequest(option.value);
  };

  const handleResolvedRequest = (option) => {
    setResolvedRequest(option.value);
  };

  const handleOpenRequest = (option) => {
    setOpenRequest(option.value);
  };

  const handlePageChange = (pageNumber) => {
    setCurrentPage(pageNumber);
  };

  const filteredData = filteredRequisitions.filter((item) => {
    const searchMatch =
      item.requisitionNumber ||
      item.requisitionType.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.position.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.approvalStatus.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.overallStatus.toLowerCase().includes(searchTerm.toLowerCase());
    const positionMatch =
      !filterTerm || item.position.toLowerCase() === filterTerm.toLowerCase();
    const requisitionTypeMatch =
      !filterRequisition ||
      item.requisitionType.toLowerCase() === filterRequisition.toLowerCase();
    const fromDateMatch =
      !fromDate || new Date(item.appliedOn) >= new Date(fromDate);
    const toDateMatch = !toDate || new Date(item.appliedOn) <= new Date(toDate);
    return (
      searchMatch &&
      positionMatch &&
      requisitionTypeMatch &&
      fromDateMatch &&
      toDateMatch
    );
  });

  const totalItems = filteredData.length;
  const totalPages = Math.ceil(totalItems / ItemsPerPage);
  const startIndex = (currentPage - 1) * ItemsPerPage;
  const endIndex = startIndex + ItemsPerPage;
  const paginatedData = filteredData.slice(startIndex, endIndex);

  useEffect(() => {
    ErfService.getAllBillingType()
      .then((response) => setBillingType(response.data))
      .catch((error) => console.error(error));

    ErfService.getAllJobDescription()
      .then((response) => setJobDescriptionType(response.data))
      .catch((error) => console.error(error));

    ErfService.getAllITAsset()
      .then((response) => setItAssetOptions(response.data))
      .catch((error) => console.error(error));

    ErfService.getAllITConfigurations()
      .then((response) => setConfigurationsOptions(response.data))
      .catch((error) => console.error(error));

    fetchData();
  }, []);

  const requisitionOptions = requisitionTypeOptions.map(
    (item) => item.label ?? item.value ?? item
  );
  const employmentOptions = jobTypeOptions.map(
    (item) => item.label ?? item.value ?? item
  );
  const billingOptions = billingType.map((bill) => bill.billingTypeName);
  const departmentNames = departmentOptions
    .map((item) => item.label ?? item.value ?? item)
    .filter(Boolean);
  const jobDescriptionOptions = jobDescriptionType.map(
    (jobDescription) => jobDescription.jobDescriptionName
  );

  const itAssetNames = itAssetOptions.map(
    (item) => item.itAssetName || item.name || item
  );
  const configNames = configurationsOptions.map(
    (item) => item.itConfigurationsName || item.name || item
  );
  const jobPriorityNames = jobPriorityOptions.map(
    (item) => item.label ?? item.value ?? item
  );
  const publishTypeNames = publishTypeOptions.map(
    (item) => item.label ?? item.value ?? item
  );
  const jobRoleNames = jobRoleOptions.map(
    (item) => item.label ?? item.value ?? item
  );

  const positions = newEmployeeRequisition.map((item) => item.position);
  const role1 = {
    positions: positions,
    requisitionTypes: requisitionOptions,
  };

  const fetchData = () => {
    ErfService.getAllEmployeerequisition()
      .then((response) => {
        setNewEmployeeRequisition([]);
        setNewEmployeeRequisition(response.data);
      })
      .catch((error) => {
        console.error("Error fetching data:", error);
      });
  };

  const searchTermValue = (search) => {
    if (search === "") {
      fetchData();
    } else {
      return ErfService.getSearchData(search)
        .then((res) => {
          setNewEmployeeRequisition([]);
          setNewEmployeeRequisition(res.data);
        })
        .catch((err) => {
          alert("Your searching data not found");
        });
    }
  };

  const handleFilterChangePosition = (selectedOption) => {
    setFilterTerm(selectedOption.value);
  };

  const handleFilterChangeRequisition = (selectedOption) => {
    setFilterRequisition(selectedOption.value);
  };

  const handleFromDateChange = (event) => {
    setFromDate(event.target.value);
  };

  const handleToDateChange = (event) => {
    setToDate(event.target.value);
  };

  const exportToExcel = () => {
    const dataToExport =
      filteredData.length > 0 ? filteredData : newEmployeeRequisition;
    const worksheet = XLSX.utils.json_to_sheet(dataToExport);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Employee Requisition");
    XLSX.writeFile(workbook, "employee_requisition.xlsx");
  };

  const style = {
    position: "absolute",
    top: "50%",
    left: "50%",
    transform: "translate(-50%, -50%)",
    width: "90%",
    maxWidth: "1200px",
    bgcolor: "background.paper",
    boxShadow: 24,
    borderRadius: "8px",
    p: 0,
    maxHeight: "90vh",
    overflowY: "auto",
  };

  const filterStyle = {
    position: "absolute",
    top: "50%",
    left: "50%",
    transform: "translate(-50%, -50%)",
    width: "90%",
    maxWidth: "500px",
    bgcolor: "background.paper",
    boxShadow: 24,
    borderRadius: "8px",
    p: 0,
    maxHeight: "90vh",
    overflowY: "auto",
  };

  const handleSelectRequisitionType = (selectedOption) => {
    setEmployeeRequisition({
      ...employeeRequisition,
      requisitionType: selectedOption.value,
    });
  };

  const handleSelectAppliedOn = (e) => {
    setEmployeeRequisition({
      ...employeeRequisition,
      appliedOn: e.target.value,
    });
  };

  const handleSelectEmploymentType = (selectedOption) => {
    setEmployeeRequisition({
      ...employeeRequisition,
      employmentType: selectedOption.value,
    });
  };

  const handleSelectBillingType = (selectedOption) => {
    setEmployeeRequisition({
      ...employeeRequisition,
      billingType: selectedOption.value,
    });
  };

  const handleSelectReplacementType = (e) => {
    setEmployeeRequisition({
      ...employeeRequisition,
      replacementType: e.target.value,
    });
  };

  const handleSelectEmployeeCode = (e) => {
    setEmployeeRequisition({
      ...employeeRequisition,
      employeeCode: e.target.value,
    });
  };

  const handleSelectReplacementProject = (e) => {
    setEmployeeRequisition({
      ...employeeRequisition,
      replacementProject: e.target.value,
    });
  };

  const handleSelectReplacementDepartment = (e) => {
    setEmployeeRequisition({
      ...employeeRequisition,
      replacementDepartment: e.target.value,
    });
  };

  const handleSelectReplacementLocation = (e) => {
    setEmployeeRequisition({
      ...employeeRequisition,
      replacementLocation: e.target.value,
    });
  };

  // ----- Numeric input validators (non-restrictive) -----
  // These do NOT strip or block characters — the person can type anything.
  // They just flag validationErrors when the value isn't a valid integer/float,
  // and clear the message once it is.
  const isValidInteger = (value) => value.trim() === "" || /^[0-9]+$/.test(value.trim());
  const isValidFloat = (value) => value.trim() === "" || /^[0-9]+(\.[0-9]+)?$/.test(value.trim());

  // On blur, format valid decimal fields to 2 decimal places (e.g. "22" -> "22.00")
  // so what's stored/sent matches how it should be saved. Leaves invalid/empty
  // values untouched so the live "should be float only" message still applies.
  const formatFloatField = (field) => {
    setEmployeeRequisition((prev) => {
      const raw = (prev[field] ?? "").toString().trim();
      if (raw === "" || isNaN(Number(raw))) return prev;
      return { ...prev, [field]: Number(raw).toFixed(2) };
    });
  };

  const handleSelectCtc = (e) => {
    const value = e.target.value;
    setEmployeeRequisition({ ...employeeRequisition, ctc: value });
    setValidationErrors((prev) => ({
      ...prev,
      ctc: isValidFloat(value) ? "" : "This field should be float only",
    }));
  };

  const handleSelectDepartment = (selectedOption) => {
    // departmentOptions holds the raw {value: code, label: caption} items
    // from the item-values API, e.g. { value: "cms.bsd", label: "Business
    // Solution Division" }. The dropdown displays/returns the caption, so
    // look up the matching item to get its code back.
    const matchedDepartment = departmentOptions.find(
      (item) => (item.label ?? item.value ?? item) === selectedOption.value
    );
    setEmployeeRequisition({
      ...employeeRequisition,
      department: selectedOption.value, // caption, e.g. "Business Solution Division"
      erecDeptCode: matchedDepartment?.value || "", // code, e.g. "cms.bsd"
    });
  };

  const handleSelectPosition = (e) => {
    setEmployeeRequisition({
      ...employeeRequisition,
      position: e.target.value,
    });
  };

  const handleSelectMinimumExperienceRange = (e) => {
    const value = e.target.value;
    setEmployeeRequisition({
      ...employeeRequisition,
      minimumExperienceRange: value,
    });
    setValidationErrors((prev) => ({
      ...prev,
      minimumExperienceRange: isValidInteger(value) ? "" : "This field should be integer only",
    }));
  };

  const handleSelectMaximumExperienceRange = (e) => {
    const value = e.target.value;
    setEmployeeRequisition({
      ...employeeRequisition,
      maximumExperienceRange: value,
    });
    setValidationErrors((prev) => ({
      ...prev,
      maximumExperienceRange: isValidInteger(value) ? "" : "This field should be integer only",
    }));
  };

  const handleSelectEducation = (e) => {
    setEmployeeRequisition({
      ...employeeRequisition,
      education: e.target.value,
    });
  };

  const handleSelectCertifications = (e) => {
    setEmployeeRequisition({
      ...employeeRequisition,
      certifications: e.target.value,
    });
  };

  const handleJobLocationChange = (selectedOptions) => {
    const values = selectedOptions ? selectedOptions.map((opt) => opt.value) : [];
    const joined = values.join(";");
    setEmployeeRequisition({
      ...employeeRequisition,
      jobLocation: joined,
    });
  };

  const handleSelectOtherJobLocation = (e) => {
    setEmployeeRequisition({
      ...employeeRequisition,
      otherJobLocation: e.target.value,
    });
  };

  const handleSelectReportingTo = (e) => {
    setEmployeeRequisition({
      ...employeeRequisition,
      reportingTo: e.target.value,
    });
  };

  const handleSelectBudget = (e) => {
    const value = e.target.value;
    setEmployeeRequisition({ ...employeeRequisition, budget: value });
    setValidationErrors((prev) => ({
      ...prev,
      budget: isValidFloat(value) ? "" : "This field should be float only",
    }));
  };

  const handleSelectSalaryMin = (e) => {
    const value = e.target.value;
    setEmployeeRequisition({ ...employeeRequisition, salaryMin: value });
    setValidationErrors((prev) => ({
      ...prev,
      salaryMin: isValidFloat(value) ? "" : "This field should be float only",
    }));
  };

  const handleSelectSalaryMax = (e) => {
    const value = e.target.value;
    setEmployeeRequisition({ ...employeeRequisition, salaryMax: value });
    setValidationErrors((prev) => ({
      ...prev,
      salaryMax: isValidFloat(value) ? "" : "This field should be float only",
    }));
  };

  const handleSelectNoOfPositions = (e) => {
    const value = e.target.value;
    setEmployeeRequisition({
      ...employeeRequisition,
      noOfPositions: value,
    });
    setValidationErrors((prev) => ({
      ...prev,
      noOfPositions: isValidInteger(value) ? "" : "This field should be integer only",
    }));
  };

  const handleSelectJob = async (selectedOption) => {
    const role = selectedOption.value;
    
    // Optimistically set the selected job
    setEmployeeRequisition(prev => ({
      ...prev,
      selectedJob: role,
    }));

    try {
      // Call your backend endpoint which routes to the external API
      const res = await axios.get(
        `${BASE_URL}:9024/api/employeeRequisition/getJobRoleDetails/${role}`
      );
      
      const roleDetails = res.data;
      
      // Auto-fill the fields based on the response
      setEmployeeRequisition(prev => ({
        ...prev,
        jobDescription: roleDetails.jobDescription || "",
        requiredSkills: roleDetails.mandatorySkills || "",
        jdTemplate: roleDetails.jdTemplate || "",
        keyRoles: roleDetails.keyRoles || ""
      }));
      
    } catch (error) {
      console.error("Error fetching job role details:", error);
      if (error?.response?.status === 500) {
        Swal.fire({
          icon: "error",
          title: "Service Unavailable",
          text: "E-recruitment service is down. Please try again later.",
        });
      }
    }
  };

  const handleSelectJobDescription = (e) => {
    setEmployeeRequisition({
      ...employeeRequisition,
      jobDescription: e.target.value,
    });
  };

  const handleSelectRequiredSkills = (e) => {
    setEmployeeRequisition({
      ...employeeRequisition,
      requiredSkills: e.target.value,
    });
  };

  const handleSelectAdditionalSkills = (e) => {
    setEmployeeRequisition({
      ...employeeRequisition,
      additionalSkills: e.target.value,
    });
  };

  const handleSelectItAsset = (selectedOption) => {
    setEmployeeRequisition({
      ...employeeRequisition,
      itAsset: selectedOption.value,
    });
  };

  const handleSelectConfigurations = (selectedOption) => {
    setEmployeeRequisition({
      ...employeeRequisition,
      configuartions: selectedOption.value,
    });
  };

  const handleSelectJobPriority = (selectedOption) => {
    setEmployeeRequisition({
      ...employeeRequisition,
      jobPriority: selectedOption.value,
    });
  };

  const handleSelectLeadTime = (e) => {
    setEmployeeRequisition({
      ...employeeRequisition,
      leadTime: e.target.value,
    });
  };

  const handleSelectPublishType = (selectedOption) => {
    setEmployeeRequisition({
      ...employeeRequisition,
      publishType: selectedOption.value,
    });
  };

  const handleSelectAdditionalInformations = (e) => {
    setEmployeeRequisition({
      ...employeeRequisition,
      additionalInformations: e.target.value,
    });
  };

  const handleSelectInitiatorName = (e) => {
    setEmployeeRequisition({
      ...employeeRequisition,
      initiatorName: e.target.value,
    });
  };

  const handleSelectInitiatorEmployeeCode = (e) => {
    setEmployeeRequisition({
      ...employeeRequisition,
      initiatorEmployeeCode: e.target.value,
    });
  };

  const handleSelectBuhead = (e) => {
    setEmployeeRequisition({ ...employeeRequisition, buHead: e.target.value });
  };

  const handleSelectInitiatorLocation = (e) => {
    setEmployeeRequisition({
      ...employeeRequisition,
      initiatorLocation: e.target.value,
    });
  };

  const handleSelectProjectName = (e) => {
    setEmployeeRequisition({
      ...employeeRequisition,
      projectName: e.target.value,
    });
  };

  const handleSelectProjectManager = (e) => {
    setEmployeeRequisition({
      ...employeeRequisition,
      projectManager: e.target.value,
    });
  };

  const handleSelectRequirementName = (e) => {
    setEmployeeRequisition({
      ...employeeRequisition,
      requirementName: e.target.value,
    });
  };

  const handleSelectReportingManager = (e) => {
    setEmployeeRequisition({
      ...employeeRequisition,
      reportingManager: e.target.value,
    });
  };

  const validateFields = () => {
    let isValid = true;
    const errors = { ...validationErrors };

    Object.keys(errors).forEach((key) => (errors[key] = ""));

    if (!employeeRequisition.requisitionType) {
      errors.requisitionType = "Requisition type is required";
      isValid = false;
    }
    if (!employeeRequisition.appliedOn) {
      errors.appliedOn = "Date is required";
      isValid = false;
    }
    if (!employeeRequisition.employmentType) {
      errors.employmentType = "Employment type is required";
      isValid = false;
    }
    if (!employeeRequisition.billingType) {
      errors.billingType = "Billing type is required";
      isValid = false;
    }
    if (!employeeRequisition.leadTime) {
      errors.leadTime = "Lead Time is required";
      isValid = false;
    }
    if (!employeeRequisition.department) {
      errors.department = "Department is required";
      isValid = false;
    }
    if (!employeeRequisition.position) {
      errors.position = "Position is required";
      isValid = false;
    }
    if (
      employeeRequisition.minimumExperienceRange === undefined ||
      employeeRequisition.minimumExperienceRange === null ||
      employeeRequisition.minimumExperienceRange === ""
    ) {
      errors.minimumExperienceRange = "Minimum Experience is required";
      isValid = false;
    } else if (
      !Number.isInteger(Number(employeeRequisition.minimumExperienceRange)) ||
      Number(employeeRequisition.minimumExperienceRange) < 0
    ) {
      errors.minimumExperienceRange = "Minimum Experience must be a whole number (0 or more)";
      isValid = false;
    }
    if (
      employeeRequisition.maximumExperienceRange === undefined ||
      employeeRequisition.maximumExperienceRange === null ||
      employeeRequisition.maximumExperienceRange === ""
    ) {
      errors.maximumExperienceRange = "Maximum Experience is required";
      isValid = false;
    } else if (
      !Number.isInteger(Number(employeeRequisition.maximumExperienceRange)) ||
      Number(employeeRequisition.maximumExperienceRange) < 0
    ) {
      errors.maximumExperienceRange = "Maximum Experience must be a whole number (0 or more)";
      isValid = false;
    }
    if (
      !errors.minimumExperienceRange &&
      !errors.maximumExperienceRange &&
      Number(employeeRequisition.minimumExperienceRange) > Number(employeeRequisition.maximumExperienceRange)
    ) {
      errors.maximumExperienceRange = "Maximum Experience must be greater than or equal to Minimum Experience";
      isValid = false;
    }
    if (!employeeRequisition.education) {
      errors.education = "Education is required";
      isValid = false;
    }
    if (!employeeRequisition.certifications) {
      errors.certifications = "Certifications is required";
      isValid = false;
    }
    if (!employeeRequisition.jobLocation || employeeRequisition.jobLocation.trim() === "") {
      errors.jobLocation = "At least one Job Location is required";
      isValid = false;
    }
    if (!employeeRequisition.otherJobLocation) {
      errors.otherJobLocation = "Other Job Location is required";
      isValid = false;
    }
    if (!employeeRequisition.reportingTo) {
      errors.reportingTo = "Reporting To is required";
      isValid = false;
    }
    if (
      employeeRequisition.budget === undefined ||
      employeeRequisition.budget === null ||
      employeeRequisition.budget === ""
    ) {
      errors.budget = "Budget is required";
      isValid = false;
    } else if (isNaN(Number(employeeRequisition.budget)) || Number(employeeRequisition.budget) <= 0) {
      errors.budget = "Budget must be a valid positive number";
      isValid = false;
    }
    if (
      employeeRequisition.salaryMin === undefined ||
      employeeRequisition.salaryMin === null ||
      employeeRequisition.salaryMin === ""
    ) {
      errors.salaryMin = "Salary Min is required";
      isValid = false;
    } else if (isNaN(Number(employeeRequisition.salaryMin)) || Number(employeeRequisition.salaryMin) < 0) {
      errors.salaryMin = "Salary Min must be a valid non-negative number";
      isValid = false;
    }
    if (
      employeeRequisition.salaryMax === undefined ||
      employeeRequisition.salaryMax === null ||
      employeeRequisition.salaryMax === ""
    ) {
      errors.salaryMax = "Salary Max is required";
      isValid = false;
    } else if (isNaN(Number(employeeRequisition.salaryMax)) || Number(employeeRequisition.salaryMax) < 0) {
      errors.salaryMax = "Salary Max must be a valid non-negative number";
      isValid = false;
    }
    if (
      !errors.salaryMin &&
      !errors.salaryMax &&
      Number(employeeRequisition.salaryMin) > Number(employeeRequisition.salaryMax)
    ) {
      errors.salaryMax = "Salary Max must be greater than or equal to Salary Min";
      isValid = false;
    }
    if (
      employeeRequisition.noOfPositions === undefined ||
      employeeRequisition.noOfPositions === null ||
      employeeRequisition.noOfPositions === ""
    ) {
      errors.noOfPositions = "No of Positions is required";
      isValid = false;
    } else if (
      !Number.isInteger(Number(employeeRequisition.noOfPositions)) ||
      Number(employeeRequisition.noOfPositions) <= 0
    ) {
      errors.noOfPositions = "No of Positions must be a whole number greater than 0";
      isValid = false;
    }
    // CTC is only collected/required for Replacement requisitions — matches the
    // backend's JobPostPublishServiceImpl#validateMandatoryFields conditional check.
    if (employeeRequisition.requisitionType === "Replacement") {
      if (
        employeeRequisition.ctc === undefined ||
        employeeRequisition.ctc === null ||
        employeeRequisition.ctc === ""
      ) {
        errors.ctc = "CTC is required";
        isValid = false;
      } else if (isNaN(Number(employeeRequisition.ctc)) || Number(employeeRequisition.ctc) <= 0) {
        errors.ctc = "CTC must be a valid positive number";
        isValid = false;
      }
    } else if (
      employeeRequisition.ctc !== undefined &&
      employeeRequisition.ctc !== null &&
      employeeRequisition.ctc !== "" &&
      (isNaN(Number(employeeRequisition.ctc)) || Number(employeeRequisition.ctc) <= 0)
    ) {
      errors.ctc = "CTC must be a valid positive number";
      isValid = false;
    }
    if (!employeeRequisition.selectedJob) {
      errors.selectedJob = "Job Role is required";
      isValid = false;
    }
    if (!employeeRequisition.jobDescription) {
      errors.jobDescription = "Job Description is required";
      isValid = false;
    }
    if (!employeeRequisition.requiredSkills) {
      errors.requiredSkills = "Required skills is required";
      isValid = false;
    }
    if (!employeeRequisition.additionalSkills) {
      errors.additionalSkills = "Additional skills is required";
      isValid = false;
    }
    
    if (!employeeRequisition.initiatorName) {
      errors.initiatorName = "Name is required";
      isValid = false;
    }
    if (!employeeRequisition.initiatorEmployeeCode) {
      errors.initiatorEmployeeCode = "Employee Code is required";
      isValid = false;
    }
    if (!employeeRequisition.buHead) {
      errors.buHead = "BU Head is required";
      isValid = false;
    }
    if (!employeeRequisition.initiatorLocation) {
      errors.initiatorLocation = "Location is required";
      isValid = false;
    }

    // if (employeeRequisition.requisitionType === "New Recruitment (Approved Head count)") {
    //   if (!employeeRequisition.requirementName) {
    //     errors.requirementName = "Requirement Name is required";
    //     isValid = false;
    //   }
    //   if (!employeeRequisition.reportingManager) {
    //     errors.reportingManager = "Reporting Manager is required";
    //     isValid = false;
    //   }
    // }

    if (employeeRequisition.requisitionType === "New") {
      if (!employeeRequisition.projectName) {
        errors.projectName = "Project Name is required";
        isValid = false;
      }
      if (!employeeRequisition.projectManager) {
        errors.projectManager = "Project Manager is required";
        isValid = false;
      }
    }

    setValidationErrors(errors);
    return isValid;
  };

  const handleSubmit = () => {
    if (!validateFields()) {
      return;
    }

    const payload = {
      ...employeeRequisition,
      minimumExperienceRange: parseInt(employeeRequisition.minimumExperienceRange, 10) || 0,
      maximumExperienceRange: parseInt(employeeRequisition.maximumExperienceRange, 10) || 0,
      noOfPositions: parseInt(employeeRequisition.noOfPositions, 10) || 0,
      // salaryMin/salaryMax/budget are Float on the entity — round to 2 decimals
      // (e.g. 22 -> 22.00) so what's saved matches what's shown in the field.
      salaryMin: Number(parseFloat(employeeRequisition.salaryMin || 0).toFixed(2)),
      salaryMax: Number(parseFloat(employeeRequisition.salaryMax || 0).toFixed(2)),
      budget: Number(parseFloat(employeeRequisition.budget || 0).toFixed(2)),
      // ctc is now a String on the entity, not a Float — send the formatted
      // string itself (e.g. "22.00") instead of parsing it into a number.
      ctc:
        employeeRequisition.ctc !== undefined &&
        employeeRequisition.ctc !== null &&
        employeeRequisition.ctc !== "" &&
        !isNaN(Number(employeeRequisition.ctc))
          ? Number(employeeRequisition.ctc).toFixed(2)
          : employeeRequisition.ctc || "",
      initiatorEmailId: employeeRequisition.initiatorEmailId || "",
      initiatorDepartmentName: employeeRequisition.initiatorDepartmentName || "",

    };

    // Remove obsolete 'experienceRange' if present
    delete payload.experienceRange;
    delete payload.experienceRange;      
  delete payload.initiatedBy;           
  delete payload.firstLevelApprover;    
  delete payload.secondLevelApprover;  

    axios
      .post(
        `${BASE_URL}:9024/api/employeeRequisition/saveNewEmployeeRequisitionReq/${empCode}/${workFlowName}`,
        payload
      )
      .then((response) => {
        console.log("response<>>>>>", response);
        Swal.fire({
          icon: "success",
          title: "Successfully Submitted!",
          text: "Employee requisition form has been submitted successfully.",
        });

        axios
          .post(
            `${BASE_URL}:9028/api/workflow/savingMainStatus/${empCode}/${workFlowName}/${wbsId}`
          )
          .then((workflowRes) => {
            console.log("Workflow status saved:", workflowRes);
          })
          .catch((workflowErr) => {
            console.error("Error saving workflow status:", workflowErr);
          });

        setModalOpen(false);
        window.location.reload();
      })
      .catch((error) => {
        console.error("Error during submission:", error);
        Swal.fire({
          icon: "error",
          title: "Error",
          text: "Error during submission. Please try again.",
        });
      });
    console.log("Employee Requisition Data: ", employeeRequisition);
  };

  const handleModalClose = () => {
    setValidationErrors({
      requisitionType: "",
      appliedOn: "",
      employmentType: "",
      billingType: "",
      selectedJob: "",
      jobDescription: "",
      requiredSkills: "",
      additionalSkills: "",
      replacementType: "",
      employeeCode: "",
      replacementProject: "",
      replacementDepartment: "",
      replacementLocation: "",
      ctc: "",
      department: "",
      erecDeptCode: "",
      position: "",
      minimumExperienceRange: "",
      maximumExperienceRange: "",
      education: "",
      certifications: "",
      jobLocation: "",
      otherJobLocation: "",
      reportingTo: "",
      budget: "",
      noOfPositions: "",
      itAsset: "",
      configurations: "",
      additionalInformations: "",
      initiatorName: "",
      initiatorEmployeeCode: "",
      buHead: "",
      initiatorLocation: "",
      initiatorEmailId: "",
      initiatorDepartmentName: "",
      salaryMin: "",
      salaryMax: "",
      projectName: "",
      projectManager: "",
      jobPriority: "",
      publishType: "",
      leadTime: "",
    });
    setEmployeeRequisition({});
    setModalOpen(false);
    defaultsAppliedRef.current = false;
  };

  // const fetchOverallStatus = () => {
  //   axios
  //     .get(
  //       `${BASE_URL}:9028/api/workflow/getOverallClaimMainStatus/${empCode}/${workFlowName}`
  //     )
  //     .then((res) => {
  //       const statusMap = res.data.reduce((acc, item) => {
  //         const [wfSeqIdPart, overallStatusPart] = item.split(", overallStatus: ");
  //         const wfSeqId = wfSeqIdPart.split("wfSeqId: ")[1];
  //         const overallStatus = overallStatusPart.trim();
  //         acc[wfSeqId] = overallStatus;
  //         return acc;
  //       }, {});
  //       setOverallStatusList(statusMap);
  //     })
  //     .catch((error) => {
  //       console.log(error);
  //       alert("Error fetching overall statuses");
  //     });
  // };

  // useEffect(() => {
  //   fetchOverallStatus();
  // }, []);

 const fetchOverallStatus = async () => {
  try {
    const statusMap = {};

    await Promise.all(
      requisitions.map(async (item) => {
        try {
          const res = await axios.get(
            `${BASE_URL}:9028/api/workflow/getOverallMainStatusBySeq/${workFlowName}/${item.wfSeqId}`
          );

          statusMap[item.wfSeqId] = res.data ?? "No Status";
        } catch (error) {
          console.error(
            `Error fetching status for wfSeqId ${item.wfSeqId}`,
            error
          );

          statusMap[item.wfSeqId] = "No Status";
        }
      })
    );

    setOverallStatusList(statusMap);

  } catch (error) {
    console.error("Error fetching overall statuses:", error);
  }
};

useEffect(() => {
  if (requisitions.length > 0) {
    fetchOverallStatus();
  }
}, [requisitions]);



  const getTypeBackgroundColor = (status) => {
    switch (status) {
      case "Pending": return "#b2d8f5";
      case "Rejected": return "#fbafa3";
      case "Approved": return "#bdfd9b";
      case "withdrawn": return "#eb7b7b";
      case "Open": return "#c7f9d4";
      case "Closed": return "#e2e8f0";
      case "In Progress": return "#fff3bf";
      default: return "#f3f4f6";
    }
  };


  return (
    <div className="w-full min-h-screen m-0 p-0 bg-gray-50 font-sans mt-20">
      <Header />
      <div className="w-full bg-[#800000] text-white shadow-md px-6 py-4 flex flex-col md:flex-row justify-between items-center sticky top-0 z-10">
        <div className="flex items-center space-x-4">
          <FaUserTie title="Employee Icon" />
          <h2 className="text-2xl font-bold tracking-wide">Employee Requisition</h2>
        </div>
        <div className="flex items-center space-x-4 mt-4 md:mt-0">
          <button
            onClick={exportToExcel}
            className="flex items-center space-x-2 bg-white/10 hover:bg-white/20 transition-colors px-4 py-2 rounded-md"
          >
            <CiExport className="text-xl" />
            <span className="font-medium">Export</span>
          </button>
          <button
            onClick={() => setModalOpen(true)}
            className="flex items-center space-x-2 bg-[#e11d48] hover:bg-red-700 transition-colors text-white px-5 py-2 rounded-md shadow-lg"
          >
            <FaSquarePlus className="text-xl" />
            <span className="font-semibold">Add Requisition</span>
          </button>
        </div>
      </div>

      <div className="p-6 md:px-10 max-w-[1600px] mx-auto">
        <div className="bg-white p-5 rounded-lg shadow-sm border border-gray-200 mb-6 flex flex-col lg:flex-row justify-between items-center gap-6">
          <div className="flex space-x-6 items-center">
            <div className="flex flex-col">
              <span className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-1">Year</span>
              <select
                value={year}
                onChange={(e) => setYear(e.target.value)}
                className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-md focus:ring-[#0f172a] focus:border-[#0f172a] block w-full p-2 outline-none cursor-pointer"
              >
                <option value="All">All</option>
                {years.map((y) => (
                  <option key={y} value={String(y)}>
                    {y}
                  </option>
                ))}
              </select>
            </div>
            <div className="flex flex-col">
              <span className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-1">Month</span>
              <select
                value={month}
                onChange={(e) => setMonth(e.target.value)}
                className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-md focus:ring-[#0f172a] focus:border-[#0f172a] block w-full p-2 outline-none cursor-pointer"
              >
                {months.map((m, idx) => (
                  <option key={idx} value={idx === 0 ? "All" : String(idx)}>
                    {m}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="flex border border-[#0f172a] rounded-md overflow-hidden bg-white">
            {["Pending", "Approved", "Closed", "All"].map((tab) => (
              <button
                key={tab}
                className={`px-6 py-2 text-sm font-semibold transition-colors duration-200 ${
                  status === tab
                    ? "bg-[#0f172a] text-white"
                    : "text-[#0f172a] hover:bg-gray-100"
                } border-r border-[#0f172a] last:border-r-0`}
                onClick={() => setStatus(tab)}
              >
                {tab}
              </button>
            ))}
          </div>
        </div>

        <div className="flex flex-col md:flex-row justify-between items-center mb-6 bg-white p-4 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center space-x-4 w-full md:w-auto">
            <div className="relative w-full md:w-80">
              <CiSearch className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 text-xl" />
              <input
                type="text"
                placeholder="Search Requisitions..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                onKeyUp={() => searchTermValue(searchTerm)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:ring-1 focus:ring-[#0f172a] focus:border-[#0f172a] outline-none transition-all"
              />
            </div>
            <button
              onClick={() => setFilterOpen(true)}
              className="flex items-center px-4 py-2 text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-md transition-colors border border-gray-200"
            >
              <LuFilter className="mr-2" />
              <span className="font-medium">Filters</span>
            </button>
          </div>

          <div className="flex items-center space-x-4 mt-4 md:mt-0 text-sm text-gray-600 font-medium">
            <span>
              {`${totalItems === 0 ? 0 : startIndex + 1}-${Math.min(
                endIndex,
                totalItems
              )} of ${totalItems}`}
            </span>
            <div className="flex space-x-2">
              <button
                className={`p-1 rounded-md ${
                  currentPage === 1
                    ? "text-gray-300 cursor-not-allowed"
                    : "text-[#0f172a] hover:bg-gray-200"
                }`}
                onClick={() => handlePageChange(currentPage - 1)}
                disabled={currentPage === 1}
              >
                &lt; Prev
              </button>
              <button
                className={`p-1 rounded-md ${
                  currentPage === totalPages || totalPages === 0
                    ? "text-gray-300 cursor-not-allowed"
                    : "text-[#0f172a] hover:bg-gray-200"
                }`}
                onClick={() => handlePageChange(currentPage + 1)}
                disabled={currentPage === totalPages}
              >
                Next &gt;
              </button>
            </div>
          </div>
        </div>

        <div className="space-y-4">
          {paginatedData.length === 0 ? (
            <div className="text-center bg-white py-12 rounded-lg border border-gray-200 shadow-sm text-gray-500">
              <LuFilter className="mx-auto text-4xl mb-3 opacity-50" />
              <span className="text-lg font-medium">
                No requisitions found matching your criteria.
              </span>
            </div>
          ) : (
            paginatedData.map((item) => (
              <div
                className="bg-white border border-gray-200 rounded-lg shadow-sm hover:shadow-md transition-all duration-200 cursor-pointer p-6"
                key={item.requisitionNumber}
                data-testid="newEmployeeRequisition"
                onClick={() => {
                  setSelectedRequisition(item);
                  setViewModalOpen(true);
                }}
              >
                <div className="flex flex-col md:flex-row justify-between">
                  <div className="flex items-start space-x-6">
                    <div className="bg-blue-50 p-3 rounded-lg border border-blue-100 hidden sm:block">
                      <img
                        src={item.imageUrl || "/assets/briefcase.svg"}
                        alt={item.position || "job"}
                        className="h-8 w-8 object-contain"
                      />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-[#0f172a] mb-1">
                        {item.position}
                      </h3>
                      <div className="flex flex-wrap items-center text-sm text-gray-600 gap-4 mb-4">
                        <span className="flex items-center">
                          <strong className="mr-1">Req No:</strong> ERF
                          {item.requisitionNumber}
                        </span>
                        <span className="flex items-center">
                          <strong className="mr-1">Dept:</strong> {item.department}
                        </span>
                        <span className="flex items-center">
                          <strong className="mr-1">Type:</strong>{" "}
                          {item.requisitionType}
                        </span>
                        <span className="flex items-center">
                          <strong className="mr-1">Positions:</strong>{" "}
                          {item.noOfPositions}
                        </span>
                      </div>
                      <div className="text-xs text-gray-400">
                        Applied On:{" "}
                        <span className="text-gray-600">{item.appliedOn}</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center justify-end gap-6 mt-4 border-t border-gray-100 pt-4">
                    <div className="flex flex-col items-end">
                      <span className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-1">
                        Approval Status
                      </span>
                      <span
                        style={{
                          backgroundColor: overallStatusList[item.wfSeqId]
                            ? getTypeBackgroundColor(overallStatusList[item.wfSeqId])
                            : getTypeBackgroundColor("default"),
                        }}
                        className="px-3 py-1 rounded-full text-sm font-medium border border-black/5"
                      >
                        {overallStatusList[item.wfSeqId] || "No Status"}
                      </span>
                    </div>

                    <div className="flex flex-col items-end">
                      <span className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-1">
                        Overall Status
                      </span>
                      <span
                        style={{
                          backgroundColor:
                            item.requisitionStatus && item.requisitionStatus.trim() !== ""
                              ? getTypeBackgroundColor(item.requisitionStatus)
                              : getTypeBackgroundColor("Default"),
                        }}
                        className="px-3 py-1 rounded-full text-sm font-medium border border-black/5"
                      >
                        {item.requisitionStatus || "No Status"}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {viewModalOpen && selectedRequisition && (
        <ViewRequisitionModal
          open={viewModalOpen}
          onClose={() => setViewModalOpen(false)}
          requisition={selectedRequisition}
          approvalStatus={overallStatusList[selectedRequisition.wfSeqId]}
        />
      )}

      <Modal open={modalOpen} onClose={handleModalClose}>
        <Box sx={style}>
          <div className="bg-white rounded-lg flex flex-col h-full">
            <div className="bg-[#800000] text-white px-6 py-4 flex justify-between items-center rounded-t-lg sticky top-0 z-10">
              <h3 className="text-xl font-bold tracking-wide">
                Create New Employee Requisition
              </h3>
              <button
                onClick={handleModalClose}
                className="text-gray-300 hover:text-red-400 transition-colors"
              >
                <FaRegCircleXmark className="text-2xl" />
              </button>
            </div>

            <div className="p-6 overflow-y-auto">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                <div onClick={() => notifyFieldServiceDown("HIRING_TYPE")}>
                  <label className="block text-sm font-semibold text-[#0f172a] mb-1">
                    Requisition Type <span className="text-red-500">*</span>
                  </label>
                  <Dropdown
                    onChange={handleSelectRequisitionType}
                    options={requisitionOptions}
                    className="w-full border border-gray-300 rounded-md focus-within:ring-1 focus-within:ring-[#0f172a] focus-within:border-[#0f172a]"
                  />
                  {validationErrors.requisitionType && (
                    <p className="text-red-500 text-xs mt-1">
                      {validationErrors.requisitionType}
                    </p>
                  )}
                </div>
                <div>
                  <label className="block text-sm font-semibold text-[#0f172a] mb-1">
                    Date <span className="text-red-500">*</span>
                  </label>
                  <input
                    onChange={handleSelectAppliedOn}
                    type="date"
                    className="w-full border border-gray-300 p-2 rounded-md outline-none focus:ring-1 focus:ring-[#0f172a] focus:border-[#0f172a]"
                  />
                  {validationErrors.appliedOn && (
                    <p className="text-red-500 text-xs mt-1">
                      {validationErrors.appliedOn}
                    </p>
                  )}
                </div>
                <div onClick={() => notifyFieldServiceDown("JOB_TYPE")}>
                  <label className="block text-sm font-semibold text-[#0f172a] mb-1">
                    Employment Type <span className="text-red-500">*</span>
                  </label>
                  <Dropdown
                    onChange={handleSelectEmploymentType}
                    options={employmentOptions}
                    className="w-full border border-gray-300 rounded-md focus-within:ring-1 focus-within:ring-[#0f172a] focus-within:border-[#0f172a]"
                  />
                  {validationErrors.employmentType && (
                    <p className="text-red-500 text-xs mt-1">
                      {validationErrors.employmentType}
                    </p>
                  )}
                </div>
                <div>
                  <label className="block text-sm font-semibold text-[#0f172a] mb-1">
                    Billing Type <span className="text-red-500">*</span>
                  </label>
                  <Dropdown
                    onChange={handleSelectBillingType}
                    options={billingOptions}
                    className="w-full border border-gray-300 rounded-md focus-within:ring-1 focus-within:ring-[#0f172a] focus-within:border-[#0f172a]"
                  />
                  {validationErrors.billingType && (
                    <p className="text-red-500 text-xs mt-1">
                      {validationErrors.billingType}
                    </p>
                  )}
                </div>
                <div onClick={() => notifyFieldServiceDown("JOB_PRIORITY")}>
                  <label className="block text-sm font-semibold text-[#0f172a] mb-1">
                    Job Priority
                  </label>
                  <Dropdown
                    onChange={handleSelectJobPriority}
                    options={jobPriorityNames}
                    placeholder="Select Job Priority"
                    className="w-full border border-gray-300 rounded-md"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">
                    Lead Time (in days) <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    onChange={handleSelectLeadTime}
                    className="w-full border border-gray-300 p-2 rounded-md outline-none focus:ring-1 focus:ring-[#0f172a]"
                  />
                  {validationErrors.leadTime && (
                    <p className="text-red-500 text-xs mt-1">
                      {validationErrors.leadTime}
                    </p>
                  )}
                </div>
                <div onClick={() => notifyFieldServiceDown("PUBLISH_TYPE")}>
                  <label className="block text-sm font-semibold text-[#0f172a] mb-1">
                    Publish Type
                  </label>
                  <Dropdown
                    onChange={handleSelectPublishType}
                    options={publishTypeNames}
                    placeholder="Select Publish Type"
                    className="w-full border border-gray-300 rounded-md"
                  />
                </div>
              </div>

              {employeeRequisition.requisitionType === "Replacement" && (
                <div className="bg-gray-50 border border-gray-200 rounded-md p-5 mb-8">
                  <h3 className="text-lg font-bold text-[#0f172a] border-b border-gray-300 pb-2 mb-4">
                    Replacement Details
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-gray-700 mb-1">
                        Name of Replacement
                      </label>
                      <input
                        type="text"
                        onChange={handleSelectReplacementType}
                        className="w-full border border-gray-300 p-2 rounded-md outline-none focus:ring-1 focus:ring-[#0f172a]"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-gray-700 mb-1">
                        Employee Code
                      </label>
                      <input
                        type="text"
                        onChange={handleSelectEmployeeCode}
                        className="w-full border border-gray-300 p-2 rounded-md outline-none focus:ring-1 focus:ring-[#0f172a]"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-gray-700 mb-1">
                        Project
                      </label>
                      <input
                        type="text"
                        onChange={handleSelectReplacementProject}
                        className="w-full border border-gray-300 p-2 rounded-md outline-none focus:ring-1 focus:ring-[#0f172a]"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-gray-700 mb-1">
                        Department
                      </label>
                      <input
                        type="text"
                        onChange={handleSelectReplacementDepartment}
                        className="w-full border border-gray-300 p-2 rounded-md outline-none focus:ring-1 focus:ring-[#0f172a]"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-gray-700 mb-1">
                        Job Location
                      </label>
                      <input
                        type="text"
                        onChange={handleSelectReplacementLocation}
                        className="w-full border border-gray-300 p-2 rounded-md outline-none focus:ring-1 focus:ring-[#0f172a]"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-gray-700 mb-1">
                        CTC(LPA) <span className="text-red-500">*</span>
                      </label>
                      <input
                        value={employeeRequisition.ctc ?? ""}
                        onChange={handleSelectCtc}
                        onBlur={() => formatFloatField("ctc")}
                        className="w-full border border-gray-300 p-2 rounded-md outline-none focus:ring-1 focus:ring-[#0f172a]"
                      />
                      {validationErrors.ctc && (
                        <p className="text-red-500 text-xs mt-1">{validationErrors.ctc}</p>
                      )}
                    </div>
                  </div>
                </div>
              )}

              

              {employeeRequisition.requisitionType === "New" && (
                <div className="bg-gray-50 border border-gray-200 rounded-md p-5 mb-8">
                  <h3 className="text-lg font-bold text-[#0f172a] border-b border-gray-300 pb-2 mb-4">
                    New Recruitment Details
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-gray-700 mb-1">
                        Project Name <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="text"
                        onChange={handleSelectProjectName}
                        className="w-full border border-gray-300 p-2 rounded-md outline-none focus:ring-1 focus:ring-[#0f172a]"
                      />
                      {validationErrors.projectName && (
                        <p className="text-red-500 text-xs mt-1">
                          {validationErrors.projectName}
                        </p>
                      )}
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-gray-700 mb-1">
                        Project Manager <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="text"
                        onChange={handleSelectProjectManager}
                        className="w-full border border-gray-300 p-2 rounded-md outline-none focus:ring-1 focus:ring-[#0f172a]"
                      />
                      {validationErrors.projectManager && (
                        <p className="text-red-500 text-xs mt-1">
                          {validationErrors.projectManager}
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              )}

              <div className="bg-gray-50 border border-gray-200 rounded-md p-5 mb-8">
                <h3 className="text-lg font-bold text-[#0f172a] border-b border-gray-300 pb-2 mb-4">
                  Position Details
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div onClick={() => notifyFieldServiceDown("HIRING_DEPT&item_map_caption=true")}>
                    <label className="block text-xs font-semibold text-gray-700 mb-1">
                      Department
                    </label>
                    <Dropdown
                      onChange={handleSelectDepartment}
                      options={departmentNames}
                      placeholder="Select Department"
                      className="w-full border border-gray-300 rounded-md focus-within:ring-1 focus-within:ring-[#0f172a] focus-within:border-[#0f172a]"
                    />
                    {validationErrors.department && (
                      <p className="text-red-500 text-xs mt-1">
                        {validationErrors.department}
                      </p>
                    )}
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-gray-700 mb-1">
                      Position
                    </label>
                    <input
                      type="text"
                      onChange={handleSelectPosition}
                      className="w-full border border-gray-300 p-2 rounded-md outline-none focus:ring-1 focus:ring-[#0f172a]"
                    />
                    {validationErrors.position && (
                      <p className="text-red-500 text-xs mt-1">
                        {validationErrors.position}
                      </p>
                    )}
                  </div>
                  <div className="flex gap-2">
                    <div className="w-1/2">
                      <label className="block text-xs font-semibold text-gray-700 mb-1">
                        Min Exp (years)
                      </label>
                      <input
                        type="text"
                        inputMode="numeric"
                        value={employeeRequisition.minimumExperienceRange ?? ""}
                        onChange={handleSelectMinimumExperienceRange}
                        className="w-full border border-gray-300 p-2 rounded-md outline-none focus:ring-1 focus:ring-[#0f172a]"
                      />
                      {validationErrors.minimumExperienceRange && (
                        <p className="text-red-500 text-xs mt-1">
                          {validationErrors.minimumExperienceRange}
                        </p>
                      )}
                    </div>
                    <div className="w-1/2">
                      <label className="block text-xs font-semibold text-gray-700 mb-1">
                        Max Exp (years)
                      </label>
                      <input
                        type="text"
                        inputMode="numeric"
                        value={employeeRequisition.maximumExperienceRange ?? ""}
                        onChange={handleSelectMaximumExperienceRange}
                        className="w-full border border-gray-300 p-2 rounded-md outline-none focus:ring-1 focus:ring-[#0f172a]"
                      />
                      {validationErrors.maximumExperienceRange && (
                        <p className="text-red-500 text-xs mt-1">
                          {validationErrors.maximumExperienceRange}
                        </p>
                      )}
                    </div>
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-gray-700 mb-1">
                      Education
                    </label>
                    <input
                      type="text"
                      onChange={handleSelectEducation}
                      className="w-full border border-gray-300 p-2 rounded-md outline-none focus:ring-1 focus:ring-[#0f172a]"
                    />
                    {validationErrors.education && (
                      <p className="text-red-500 text-xs mt-1">
                        {validationErrors.education}
                      </p>
                    )}
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-gray-700 mb-1">
                      Certifications
                    </label>
                    <input
                      type="text"
                      onChange={handleSelectCertifications}
                      className="w-full border border-gray-300 p-2 rounded-md outline-none focus:ring-1 focus:ring-[#0f172a]"
                    />
                    {validationErrors.certifications && (
                      <p className="text-red-500 text-xs mt-1">
                        {validationErrors.certifications}
                      </p>
                    )}
                  </div>
                   <div>
                    <label className="block text-xs font-semibold text-gray-700 mb-1">
                      Job Location <span className="text-red-500">*</span>
                    </label>
                    <Select
                      isMulti
                      options={jobLocationSelectOptions}
                      value={getSelectedJobLocations()}
                      onChange={handleJobLocationChange}
                      onMenuOpen={() => notifyFieldServiceDown("JOB_LOCATIONS")}
                      placeholder="Select locations..."
                      className="basic-multi-select"
                      classNamePrefix="select"
                    />
                    {validationErrors.jobLocation && (
                      <p className="text-red-500 text-xs mt-1">
                        {validationErrors.jobLocation}
                      </p>
                    )}
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-gray-700 mb-1">
                      Other Job Location
                    </label>
                    <input
                      type="text"
                      onChange={handleSelectOtherJobLocation}
                      className="w-full border border-gray-300 p-2 rounded-md outline-none focus:ring-1 focus:ring-[#0f172a]"
                    />
                    {validationErrors.otherJobLocation && (
                      <p className="text-red-500 text-xs mt-1">
                        {validationErrors.otherJobLocation}
                      </p>
                    )}
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-gray-700 mb-1">
                      Reporting To
                    </label>
                    <input
                      type="text"
                      onChange={handleSelectReportingTo}
                      className="w-full border border-gray-300 p-2 rounded-md outline-none focus:ring-1 focus:ring-[#0f172a]"
                    />
                    {validationErrors.reportingTo && (
                      <p className="text-red-500 text-xs mt-1">
                        {validationErrors.reportingTo}
                      </p>
                    )}
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-gray-700 mb-1">
                      Salary Budget(LPA) <span className="text-red-500">*</span>
                    </label>
                    <input
                      value={employeeRequisition.budget ?? ""}
                      onChange={handleSelectBudget}
                      onBlur={() => formatFloatField("budget")}
                      className="w-full border border-gray-300 p-2 rounded-md outline-none focus:ring-1 focus:ring-[#0f172a]"
                    />
                    {validationErrors.budget && (
                      <p className="text-red-500 text-xs mt-1">
                        {validationErrors.budget}
                      </p>
                    )}
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-gray-700 mb-1">
                      Salary Min(LPA) <span className="text-red-500">*</span>
                    </label>
                    <input
                      value={employeeRequisition.salaryMin ?? ""}
                      onChange={handleSelectSalaryMin}
                      onBlur={() => formatFloatField("salaryMin")}
                      className="w-full border border-gray-300 p-2 rounded-md outline-none focus:ring-1 focus:ring-[#0f172a]"
                    />
                    {validationErrors.salaryMin && (
                      <p className="text-red-500 text-xs mt-1">
                        {validationErrors.salaryMin}
                      </p>
                    )}
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-gray-700 mb-1">
                      Salary Max(LPA) <span className="text-red-500">*</span>
                    </label>
                    <input
                      value={employeeRequisition.salaryMax ?? ""}
                      onChange={handleSelectSalaryMax}
                      onBlur={() => formatFloatField("salaryMax")}
                      className="w-full border border-gray-300 p-2 rounded-md outline-none focus:ring-1 focus:ring-[#0f172a]"
                    />
                    {validationErrors.salaryMax && (
                      <p className="text-red-500 text-xs mt-1">
                        {validationErrors.salaryMax}
                      </p>
                    )}
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-gray-700 mb-1">
                      No of Positions <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      inputMode="numeric"
                      value={employeeRequisition.noOfPositions ?? ""}
                      onChange={handleSelectNoOfPositions}
                      className="w-full border border-gray-300 p-2 rounded-md outline-none focus:ring-1 focus:ring-[#0f172a]"
                    />
                    {validationErrors.noOfPositions && (
                      <p className="text-red-500 text-xs mt-1">
                        {validationErrors.noOfPositions}
                      </p>
                    )}
                  </div>
                </div>
              </div>

             <div className="mb-8 space-y-4">
    <div onClick={() => notifyFieldServiceDown("JOB_ROLE")}>
      <label className="block text-sm font-semibold text-[#0f172a] mb-1">
        Select Job Role <span className="text-red-500">*</span>
      </label>
      <Dropdown
        onChange={handleSelectJob}
        options={jobRoleNames}
        className="w-full md:w-1/3 border border-gray-300 rounded-md"
      />
      {validationErrors.selectedJob && (
        <p className="text-red-500 text-xs mt-1">
          {validationErrors.selectedJob}
        </p>
      )}
    </div>

    <div>
      <label className="block text-sm font-semibold text-[#0f172a] mb-1">
        Job Description <span className="text-red-500">*</span>
      </label>
      <textarea
        rows="4"
        value={employeeRequisition.jobDescription || ""} // <-- ADDED THIS
        onChange={handleSelectJobDescription}
        className="w-full border border-gray-300 p-3 rounded-md outline-none focus:ring-1 focus:ring-[#0f172a]"
      ></textarea>
      {validationErrors.jobDescription && (
        <p className="text-red-500 text-xs mt-1">
          {validationErrors.jobDescription}
        </p>
      )}
    </div>

    <div>
      <label className="block text-sm font-semibold text-[#0f172a] mb-1">
        Mandatory Skills <span className="text-red-500">*</span>
      </label>
      <textarea
        rows="2"
        value={employeeRequisition.requiredSkills || ""} // <-- ADDED THIS
        onChange={handleSelectRequiredSkills}
        className="w-full border border-gray-300 p-3 rounded-md outline-none focus:ring-1 focus:ring-[#0f172a]"
      ></textarea>
      {validationErrors.requiredSkills && (
        <p className="text-red-500 text-xs mt-1">
          {validationErrors.requiredSkills}
        </p>
      )}
    </div>

    <div>
      <label className="block text-sm font-semibold text-[#0f172a] mb-1">
        Key Role <span className="text-red-500">*</span>
      </label>
      <input
        type="text"
        value={employeeRequisition.keyRoles || ""}
        onChange={(e) => setEmployeeRequisition({ ...employeeRequisition, keyRoles: e.target.value })}
        className="w-full border border-gray-300 p-3 rounded-md outline-none focus:ring-1 focus:ring-[#0f172a]"
        placeholder="Auto-filled based on Job Role"
      />
      {validationErrors.keyRoles && (
        <p className="text-red-500 text-xs mt-1">
          {validationErrors.keyRoles}
        </p>
      )}
    </div>

    <div>
      <label className="block text-sm font-semibold text-[#0f172a] mb-1">
        Additional Skills <span className="text-red-500">*</span>
      </label>
      <textarea
        rows="2"
        value={employeeRequisition.additionalSkills || ""}
        onChange={handleSelectAdditionalSkills}
        className="w-full border border-gray-300 p-3 rounded-md outline-none focus:ring-1 focus:ring-[#0f172a]"
      ></textarea>
      {validationErrors.additionalSkills && (
        <p className="text-red-500 text-xs mt-1">
          {validationErrors.additionalSkills}
        </p>
      )}
    </div>
  </div>

              <div className="bg-gray-50 border border-gray-200 rounded-md p-5 mb-8">
                <h3 className="text-lg font-bold text-[#0f172a] border-b border-gray-300 pb-2 mb-4">
                  IT Asset Requirements & Approval Details
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-gray-700 mb-1">
                      IT Asset
                    </label>
                    <Dropdown
                      onChange={handleSelectItAsset}
                      options={itAssetNames}
                      placeholder="Select IT Asset"
                      className="w-full border border-gray-300 rounded-md"
                    />
                    {validationErrors.itAsset && (
                      <p className="text-red-500 text-xs mt-1">
                        {validationErrors.itAsset}
                      </p>
                    )}
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-gray-700 mb-1">
                      Configurations
                    </label>
                    <Dropdown
                      onChange={handleSelectConfigurations}
                      options={configNames}
                      placeholder="Select Configuration"
                      className="w-full border border-gray-300 rounded-md"
                    />
                    {validationErrors.configurations && (
                      <p className="text-red-500 text-xs mt-1">
                        {validationErrors.configurations}
                      </p>
                    )}
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-gray-700 mb-1">
                      Additional Information 
                    </label>
                    <input
                      type="text"
                      onChange={handleSelectAdditionalInformations}
                      className="w-full border border-gray-300 p-2 rounded-md outline-none focus:ring-1 focus:ring-[#0f172a]"
                    />
                    {validationErrors.additionalInformations && (
                      <p className="text-red-500 text-xs mt-1">
                        {validationErrors.additionalInformations}
                      </p>
                    )}
                  </div>
                </div>
              </div>

              <div className="bg-gray-50 border border-gray-200 rounded-md p-5 mb-8">
                <h3 className="text-lg font-bold text-[#0f172a] border-b border-gray-300 pb-2 mb-4">
                  Initiator Details
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-gray-700 mb-1">
                      Name
                    </label>
                    <input
                      type="text"
                      value={employeeRequisition.initiatorName || ""}
                      disabled
                      className="w-full border border-gray-300 p-2 rounded-md outline-none bg-gray-100 cursor-not-allowed"
                    />
                    {validationErrors.initiatorName && (
                      <p className="text-red-500 text-xs mt-1">
                        {validationErrors.initiatorName}
                      </p>
                    )}
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-gray-700 mb-1">
                      Employee Code
                    </label>
                    <input
                      type="text"
                      value={employeeRequisition.initiatorEmployeeCode || ""}
                      disabled
                      className="w-full border border-gray-300 p-2 rounded-md outline-none bg-gray-100 cursor-not-allowed"
                    />
                    {validationErrors.initiatorEmployeeCode && (
                      <p className="text-red-500 text-xs mt-1">
                        {validationErrors.initiatorEmployeeCode}
                      </p>
                    )}
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-gray-700 mb-1">
                      BU Head
                    </label>
                    <input
                      type="text"
                      value={employeeRequisition.buHead || ""}
                      disabled
                      className="w-full border border-gray-300 p-2 rounded-md outline-none bg-gray-100 cursor-not-allowed"
                    />
                    {validationErrors.buHead && (
                      <p className="text-red-500 text-xs mt-1">
                        {validationErrors.buHead}
                      </p>
                    )}
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-gray-700 mb-1">
                      Location
                    </label>
                    <input
                      type="text"
                      value={employeeRequisition.initiatorLocation || ""}
                      disabled
                      className="w-full border border-gray-300 p-2 rounded-md outline-none bg-gray-100 cursor-not-allowed"
                    />
                    {validationErrors.initiatorLocation && (
                      <p className="text-red-500 text-xs mt-1">
                        {validationErrors.initiatorLocation}
                      </p>
                    )}
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-gray-100 border-t border-gray-200 px-6 py-4 rounded-b-lg flex flex-col sm:flex-row justify-between items-center gap-4">
              <p className="text-xs text-gray-500 italic">
                *Disclaimer: All details are subject to approval by the BU Head and HR Head.
              </p>
              <div className="flex space-x-4">
                <button
                  onClick={handleModalClose}
                  className="px-6 py-2 bg-white border border-gray-300 text-gray-700 font-semibold rounded-md hover:bg-gray-50 transition-colors shadow-sm"
                >
                  Cancel
                </button>
                <button
                  onClick={handleSubmit}
                  data-testid="submit"
                  className="px-8 py-2 bg-[#e11d48] text-white font-semibold rounded-md hover:bg-red-700 transition-colors shadow-md"
                >
                  Submit
                </button>
              </div>
            </div>
          </div>
        </Box>
      </Modal>

      <Modal open={filterOpen} onClose={() => setFilterOpen(false)}>
        <Box sx={filterStyle}>
          <div className="bg-white rounded-lg flex flex-col">
            <div className="bg-[#0f172a] text-white px-6 py-4 flex justify-between items-center rounded-t-lg">
              <h3 className="text-lg font-bold">Filter Requisitions</h3>
              <button
                onClick={() => setFilterOpen(false)}
                className="text-gray-300 hover:text-red-400"
              >
                <FaRegCircleXmark className="text-2xl" />
              </button>
            </div>
            <div className="p-6 space-y-5">
              <div>
                <label className="block text-sm font-semibold text-[#0f172a] mb-1">
                  Positions
                </label>
                <Dropdown
                  options={[...role1.positions]}
                  placeholder="Select position"
                  onChange={handleFilterChangePosition}
                  className="w-full border border-gray-300 rounded-md"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-[#0f172a] mb-1">
                  Requisition Type
                </label>
                <Dropdown
                  options={[...role1.requisitionTypes]}
                  placeholder="Select requisition type"
                  onChange={handleFilterChangeRequisition}
                  className="w-full border border-gray-300 rounded-md"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-semibold text-[#0f172a] mb-1">
                    From Date
                  </label>
                  <input
                    type="date"
                    value={fromDate}
                    onChange={handleFromDateChange}
                    className="w-full border border-gray-300 p-2 rounded-md outline-none focus:ring-1 focus:ring-[#0f172a]"
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-[#0f172a] mb-1">
                    To Date
                  </label>
                  <input
                    type="date"
                    value={toDate}
                    onChange={handleToDateChange}
                    className="w-full border border-gray-300 p-2 rounded-md outline-none focus:ring-1 focus:ring-[#0f172a]"
                  />
                </div>
              </div>
            </div>
            <div className="bg-gray-100 border-t border-gray-200 px-6 py-4 rounded-b-lg flex justify-end">
              <button
                onClick={() => setFilterOpen(false)}
                className="px-6 py-2 bg-[#e11d48] text-white font-semibold rounded-md hover:bg-red-700 transition-colors shadow-md w-full sm:w-auto"
              >
                Apply Filters
              </button>
            </div>
          </div>
        </Box>
      </Modal>
    </div>
  );
}

export default EmployeeRequisition;