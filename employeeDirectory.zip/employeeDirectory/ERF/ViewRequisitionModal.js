import React, { useState, useEffect } from "react";
import { X } from "lucide-react";
import axios from "axios";
import Swal from "sweetalert2";
import { IoEnterOutline } from "react-icons/io5";
import { BASE_URL } from "../config";

const Field = ({ label, value }) => (
  <div className="flex text-sm">
    <div className="min-w-[200px] flex text-slate-500 font-semibold">{label}</div>
    <div className="font-semibold text-black">{value || "-"}</div>
  </div>
);

// JOB_DOC attachment rules: only .pdf / .docx allowed, size must be < 1 MB
const JD_ALLOWED_MIME_TYPES = [
  "application/pdf",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document", // .docx
];
const JD_ALLOWED_EXTENSIONS = [".pdf", ".docx"];
const JD_MAX_FILE_SIZE = 1 * 1024 * 1024; // 1 MB

const validateJdAttachment = (file) => {
  if (!file) return { valid: true };

  const lowerName = (file.name || "").toLowerCase();
  const hasValidExtension = JD_ALLOWED_EXTENSIONS.some((ext) => lowerName.endsWith(ext));
  const hasValidMimeType = JD_ALLOWED_MIME_TYPES.includes(file.type);

  if (!hasValidExtension || !hasValidMimeType) {
    return {
      valid: false,
      message: "Only .pdf and .docx files are allowed for the JD Attachment.",
    };
  }

  if (file.size > JD_MAX_FILE_SIZE) {
    return {
      valid: false,
      message: `File size must be less than 1 MB. Selected file is ${(file.size / (1024 * 1024)).toFixed(2)} MB.`,
    };
  }

  return { valid: true };
};

// Pulls a human-readable message out of an axios error, whatever shape the
// backend's error body happens to be in (JSON with "message", JSON with
// "error"/"detail", a plain-text body, or nothing at all).
const extractErrorMessage = (error, fallback) => {
  const data = error?.response?.data;

  if (typeof data === "string" && data.trim()) {
    return data;
  }
  if (data && typeof data === "object") {
    const candidate =
      data.message || data.error || data.errorMessage || data.detail || data.msg;
    if (candidate) return candidate;
  }
  return error?.message || fallback;
};

const ViewRequisitionModal = ({
  requisition,
  onClose,
  wfSeqId,
  onApprove,
  showApproveButtons = false,
  erfNumber,
  autoFetch = false,
  approvalStatus,
}) => {
  const [data, setData] = useState(requisition);
  const [loading, setLoading] = useState(false);
  const [comment, setComment] = useState("");
  const [filteredRequisition, setFilteredRequisition] = useState([]);
  const [isPopupVisible, setIsPopupVisible] = useState(false);
  const [isChecked, setIsChecked] = useState(false);
  const [requisitionToWithdraw, setRequisitionToWithdraw] = useState(null);
  //const empCode = '9085119';
  const empCode = localStorage.getItem('empId');
  const [commentFetched, setCommentFetched] = useState([]);

  const [jobPostId, setJobPostId] = useState("");
  const [showPublishPopup, setShowPublishPopup] = useState(false);
  const [isPublishing, setIsPublishing] = useState(false);
  const [jdAttachmentFile, setJdAttachmentFile] = useState(null);
  const [jdTemplatePath, setJdTemplatePath] = useState("");


  // Determine if the logged-in user has the "HR Payroll" role
  const isHRPayroll = (() => {
    try {
      const storedRoles = JSON.parse(sessionStorage.getItem("role") || "[]");
      return Array.isArray(storedRoles) && storedRoles.includes("Talent Aquisition");
    } catch (e) {
      return false;
    }
  })();

  const [publishForm, setPublishForm] = useState({
    applicationDeadline: "",
    loginEmailId: "",
    custName: "",
    projCode: "",
    projName: "",
    projWave: "",
    resReqWave: "",
  });

  useEffect(() => {
    const email = localStorage.getItem("email") || "";
    setPublishForm(prev => ({ ...prev, loginEmailId: email }));
  }, []);

  useEffect(() => {
    fetchMgrComment();
  }, []);

  const fetchMgrComment = async () => {
    try {
      const response = await axios.get(
        `${BASE_URL}:9028/api/workflow/getAllComments/${data?.wfSeqId || requisition?.wfSeqId}`
      );
      setCommentFetched(response.data);
    } catch (error) {
      console.error("Error fetching comments:", error);
    }
  };

  const submitMgrComment = () => {
    if (comment.trim() === "") {
      alert("Comment cannot be empty");
      return;
    }
    const url = `${BASE_URL}:9028/api/workflow/sendComments/${data?.wfSeqId || requisition?.wfSeqId}/${empCode}`;
    axios
      .post(url, comment, { headers: { "Content-Type": "text/plain" } })
      .then(() => {
        Swal.fire({
          toast: true,
          position: "top-end",
          showConfirmButton: false,
          timer: 3000,
          timerProgressBar: true,
          icon: "success",
          title: "Message sent successfully!",
        });
        setComment("");
        fetchMgrComment();
      })
      .catch((error) => {
        console.error("Error posting comment:", error);
        alert("Failed to post comment. Please try again.");
      });
  };

  // useEffect(() => {
  //   if (autoFetch && erfNumber && wfSeqId) {
  //     const fetchData = async () => {
  //       try {
  //         setLoading(true);
  //         const response = await axios.get(
  //           `${BASE_URL}:9024/api/employeeRequisition/getRequisitionDetails/${erfNumber}/${wfSeqId}`
  //         );
  //         setData(response.data);
  //         if (response.data.jobPostId) setJobPostId(response.data.jobPostId);
  //         setLoading(false);
  //       } catch (error) {
  //         console.error("Error fetching requisition details:", error);
  //         setLoading(false);
  //       }
  //     };
  //     fetchData();
  //   } else {
  //     setData(requisition);
  //     if (requisition?.jobPostId) setJobPostId(requisition.jobPostId);
  //   }
  // }, [erfNumber, wfSeqId, autoFetch, requisition]);

  useEffect(() => {
    if (autoFetch && erfNumber && wfSeqId) {
      const fetchData = async () => {
        try {
          setLoading(true);
          const response = await axios.get(
            `${BASE_URL}:9024/api/employeeRequisition/getRequisitionDetails/${erfNumber}/${wfSeqId}`
          );
          setData(response.data);

          if (response.data.jobPostId) setJobPostId(response.data.jobPostId);
          // Set the auto-fetched JD Template
          if (response.data.jdTemplate) setJdTemplatePath(response.data.jdTemplate);

          setLoading(false);
        } catch (error) {
          console.error("Error fetching requisition details:", error);
          setLoading(false);
        }
      };
      fetchData();
    } else {
      setData(requisition);
      if (requisition?.jobPostId) setJobPostId(requisition.jobPostId);
      if (requisition?.jdTemplate) setJdTemplatePath(requisition.jdTemplate);
    }
  }, [erfNumber, wfSeqId, autoFetch, requisition]);

  // UPDATE the file selection useEffect so it doesn't overwrite the database template 
  // unless a NEW file is explicitly uploaded.
  useEffect(() => {
    if (jdAttachmentFile) {
      setJdTemplatePath(jdAttachmentFile.name);
    } else {
      setJdTemplatePath(data?.jdTemplate || "");   // ✅ shows saved value
    }
  }, [jdAttachmentFile, data]);
  const handleOpenPublishPopup = () => setShowPublishPopup(true);

  const handlePublishFormChange = (e) => {
    const { name, value } = e.target;
    setPublishForm(prev => ({ ...prev, [name]: value }));
  };

  const getErfValue = (field) => data?.[field] || "";


  const handlePublishSubmit = async () => {
    const {
      applicationDeadline,
      loginEmailId,
      custName,
      projCode,
      projName,
      projWave,
      resReqWave
    } = publishForm;

    const errors = [];

    if (!applicationDeadline)
      errors.push("Application Deadline is required.");

    if (!loginEmailId)
      errors.push("Login Email Id is required.");

    // Only require a new file upload if no file already exists from the backend
    if (!jdAttachmentFile && !jdTemplatePath)
      errors.push("JD Attachment is required.");

    if (errors.length > 0) {
      Swal.fire({
        icon: "error",
        title: "Validation Error",
        html: errors.join("<br/>")
      });
      return;
    }

    // Existing JD validation
    const jdValidation = validateJdAttachment(jdAttachmentFile);
    if (!jdValidation.valid) {
      Swal.fire({
        icon: "error",
        title: "Invalid File",
        text: jdValidation.message,
      });
      return;
    }

    setIsPublishing(true);
    try {
      const formData = new FormData();

      // 📤 Append all fields – these must match the backend DTO
      formData.append("requisitionNumber", data?.requisitionNumber || 0);
      formData.append("wfSeqId", data?.wfSeqId || 0);
      formData.append("initiatorEmailId", data?.initiatorEmailId || "");
      formData.append("intRefData", data?.requisitionNumber?.toString() || "");
      formData.append("jobPostTitle", data?.position || "");
      formData.append("jobRole", data?.position || "");
      formData.append("department", data?.department || "");
      formData.append("noOfPositions", Number(data?.noOfPositions ?? 0));
      formData.append("expMin", Number(data?.minimumExperienceRange ?? 0));
      formData.append("expMax", Number(data?.maximumExperienceRange ?? 0));
      formData.append("education", data?.education || "");
      formData.append("certifications", data?.certifications || "");
      formData.append("location", data?.jobLocation || "");
      formData.append("hiringType", data?.employmentType || "");
      formData.append("billingType", data?.billingType || "");
      formData.append("requisitionType", data?.requisitionType || "");
      formData.append("salaryBudget", Number(data?.budget ?? 0));
      formData.append("jobDescription", data?.jobDescription || "");
      formData.append("keySkills", data?.requiredSkills || "");
      formData.append("additionalSkills", data?.additionalSkills || "");
      formData.append("hiringManager", data?.initiatorName || "");

      formData.append("buHead", data?.buHead || "");
      formData.append("ctc", Number(data?.ctc ?? 0));
      formData.append("applicationDeadline", applicationDeadline);
      formData.append("custName", custName || "");
      formData.append("projCode", projCode || "");
      formData.append("projName", projName || "");
      formData.append("projWave", projWave || "");
      formData.append("resReqWave", resReqWave || "");
      formData.append("jobType", "Full-time");
      formData.append("jobStatus", "Open");
      formData.append("publishType", data?.publishType || "");
      formData.append("keyRoles", data?.additionalSkills || "");
      formData.append("otherLocations", data?.otherJobLocation || "");
      formData.append("hiringDept", data?.erecDeptCode || "");
      formData.append("salaryMin", Number(data?.salaryMin ?? 0));
      formData.append("salaryMax", Number(data?.salaryMax ?? 0));
      formData.append("leadTime", data?.leadTime || "");
      formData.append("jobPriority", data?.jobPriority || "");
      formData.append("loginEmailId", loginEmailId || "");
      formData.append("jobDoc", "");  // kept for compatibility

      // 📎 File attachment
      if (jdAttachmentFile) {
        formData.append("jdAttachment", jdAttachmentFile);
        console.log("📎 Attaching file:", jdAttachmentFile.name, jdAttachmentFile.size, "bytes");
      } else {
        console.warn("⚠️ No file selected");
      }

      // 📄 Template path (auto-filled)
      formData.append("jdTemplate", jdTemplatePath || "");
      console.log("📄 Sending jdTemplate:", jdTemplatePath);

      // Debug: log all form data entries
      console.log("📋 Full form data:");
      for (let [key, value] of formData.entries()) {
        if (value instanceof File) {
          console.log(`  ${key}: File(${value.name}, ${value.size} bytes)`);
        } else {
          console.log(`  ${key}: ${value}`);
        }
      }

      const response = await axios.post(`${BASE_URL}:9024/api/jobpost/publish`, formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      });

      console.log("✅ Server response:", response.data);

      const newJobPostId = response.data.jobPostId;
      setJobPostId(newJobPostId);
      setShowPublishPopup(false);
      Swal.fire({
        icon: "success",
        title: "Published!",
        text: `JobPost ID: ${newJobPostId}`,
      });
    } catch (error) {
      console.error("❌ Error publishing to JobPost:", error);
      if (error.response) {
        console.error("Response data:", error.response.data);
        console.error("Response status:", error.response.status);
        console.error("Response headers:", error.response.headers);
      } else if (error.request) {
        console.error("No response received:", error.request);
      } else {
        console.error("Request error:", error.message);
      }
      Swal.fire({
        icon: "error",
        title: "Publish Failed",
        text: extractErrorMessage(error, "An error occurred while publishing. Please try again."),
      });
    } finally {
      setIsPublishing(false);
      // Uncomment if you want to reload after completion
      // window.location.reload();
    }
  };

  const handleWithdrawClick = (req) => {
    setRequisitionToWithdraw(req);
    setIsPopupVisible(true);
  };

  const handleConfirmWithdraw = () => {
    if (isChecked && requisitionToWithdraw) {
      const updatedClaims = filteredRequisition.filter(
        (requisition) => requisition.wfSeqId !== requisitionToWithdraw.wfSeqId
      );
      setFilteredRequisition(updatedClaims);
      setIsPopupVisible(false);
      setRequisitionToWithdraw(null);
      setIsChecked(false);
      handleWithdrawal(requisitionToWithdraw);
    } else {
      Swal.fire({
        icon: "warning",
        title: "Warning",
        text: "Please agree to the terms before withdrawing.",
      });
    }
  };

  const handleWithdrawal = async (requisition) => {
    const url = `${BASE_URL}:9028/api/workflow/setOverallStatusOfMainAndItemTableForWithdrawButton/${requisition.wfSeqId}`;
    try {
      const response = await axios.get(url);
      if (response.status === 200) {
        Swal.fire({
          toast: true,
          position: "top-end",
          showConfirmButton: false,
          timer: 3000,
          timerProgressBar: true,
          icon: "success",
          title: "Successfully withdrawn!",
        });
        window.location.reload();
      } else {
        alert("Failed to withdraw. Please try again.");
      }
    } catch (error) {
      console.error("Error withdrawing:", error);
      alert("Error occurred while withdrawing: " + error.message);
    }
  };

  const handleClosePopup = () => {
    setIsPopupVisible(false);
    setRequisitionToWithdraw(null);
    setIsChecked(false);
  };

  if (loading) {
    return (
      <div className="fixed inset-0 z-50 bg-black bg-opacity-40 flex justify-center items-center">
        <div className="bg-white rounded-lg p-8">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto"></div>
          <p className="text-center text-gray-600 mt-4">Loading requisition details...</p>
        </div>
      </div>
    );
  }

  if (!data) return null;

  const currentRequisition = data;
  const displayedApprovalStatus = approvalStatus || currentRequisition?.approvalStatus;

  const handleApprove = () => {
    if (onApprove) {
      onApprove(currentRequisition.requisitionNumber, wfSeqId);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black bg-opacity-40 flex justify-center items-start pt-10">
      <div className="bg-white w-[90%] max-w-6xl rounded-xl p-6 relative shadow-xl border border-gray-300 max-h-[90vh] overflow-y-auto">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-red-500 border border-red-500 rounded-full p-1 hover:bg-red-100"
          title="Close"
        >
          <X size={20} />
        </button>

        <div className="mb-1">
          <h2 className="text-xl font-semibold text-gray-800">
            Request No:{" "}
            <span className="text-green-600">
              {currentRequisition.requisitionNumber}
            </span>
            {wfSeqId && <span className="text-gray-600"> (Seq: {wfSeqId})</span>}
          </h2>
        </div>

        <div className="flex justify-between items-center mb-4">
          <div className="w-1/3" />
          <div className="w-1/3 text-center text-base font-medium text-gray-700">
            Approval Status:{" "}
            <span className="text-red-500">{displayedApprovalStatus}</span>
          </div>
          <div className="w-1/3 text-right text-base font-medium text-gray-700 mr-[5rem]">
            Overall Status:{" "}
            <span className="text-blue-600">{currentRequisition.requisitionStatus}</span>
          </div>
        </div>

        <div className="border border-gray-300 rounded px-6 py-4 mb-6">
          <div className="flex justify-between items-center mb-4">
            <div className="text-slate-500 font-semibold flex">
              <div className="min-w-[200px]">Requisition Type</div>
              <div className="font-semibold text-black">
                {currentRequisition.requisitionType || "-"}
              </div>
            </div>
            <select
              className="border text-sm border-gray-300 rounded px-2 py-1 text-blue-500 bg-white"
              onChange={(e) => {
                if (e.target.value === 'delete') {
                  handleWithdrawClick(currentRequisition);
                }
                e.target.selectedIndex = 0;
              }}
            >
              <option value="close">Close</option>
              <option value="onhold">On Hold</option>
              <option value="Resume">ReOpen</option>
              <option value="delete">Delete</option>
            </select>
          </div>

          <div className="flex justify-between items-center mb-4">
            <div className="flex items-center space-x-4">
              <span className="text-slate-500 font-semibold">JobPost ID:</span>
              <input
                type="text"
                value={jobPostId}
                readOnly
                className="border border-gray-300 rounded px-2 py-1 w-40 bg-gray-100 text-black"
                placeholder="Not published"
              />
            </div>
            {isHRPayroll && (
              <button
                onClick={handleOpenPublishPopup}
                disabled={
                  displayedApprovalStatus !== "Approved" ||
                  !!jobPostId ||
                  isPublishing
                }
                className={`px-4 py-2 rounded font-semibold transition-colors ${displayedApprovalStatus === "Approved" && !jobPostId && !isPublishing
                  ? "bg-blue-600 text-white hover:bg-blue-700"
                  : "bg-gray-300 text-gray-500 cursor-not-allowed"
                  }`}
              >
                {isPublishing ? "Publishing..." : "Publish to JobPost"}
              </button>
            )}
          </div>

          <div className="w-[50%] h-px bg-gray-200 mt-1 mb-4" />
          <Field label="Date" value={currentRequisition.appliedOn} />
          <div className="w-[50%] h-px bg-gray-200 mt-2 mb-4" />
          <Field label="Employment Type" value={currentRequisition.employmentType} />
          <div className="w-[50%] h-px bg-gray-200 mt-2 mb-4" />
          <Field label="Billing Type" value={currentRequisition.billingType} />

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-6 pb-6 text-semibold">
            <div>
              <h3 className="text-md font-semibold text-gray-700 mb-4">Replacement</h3>
              <div className="space-y-4">
                <Field label="Name of Replacement" value={currentRequisition.replacementType} />
                <Field label="Employee Code" value={currentRequisition.employeeCode} />
                <Field label="Project" value={currentRequisition.replacementProject} />
                <Field label="Department" value={currentRequisition.replacementDepartment} />
                <Field label="Location" value={currentRequisition.replacementLocation} />
                <Field label="CTC" value={currentRequisition.ctc} />
              </div>
            </div>

            <div>
              <h3 className="text-md font-semibold text-gray-700 mb-4">Position Details</h3>
              <div className="space-y-4">
                <Field label="Department" value={currentRequisition.department} />
                <Field label="Position" value={currentRequisition.position} />
                <Field label="No of Positions" value={currentRequisition.noOfPositions} />
                <Field label="Experience Range (years)" value={`${currentRequisition.minimumExperienceRange} - ${currentRequisition.maximumExperienceRange}`} />
                <Field label="Education" value={currentRequisition.education} />
                <Field label="Certification(s)" value={currentRequisition.certifications} />
                <Field label="Location" value={currentRequisition.jobLocation} />
                <Field label="Reporting To" value={currentRequisition.reportingTo} />
                <Field label="Budget (LPA)" value={currentRequisition.budget} />
              </div>
            </div>

            <div className="border-l-[1px] border-gray-300 pl-6 mt-6">
              <h3 className="text-md font-semibold text-gray-700 mb-4 -mt-6">Timeline</h3>
              <div className="border-l-[2px] border-gray-300">
                <div className="justify-between items-center p-4">
                  <h2 className="text-sm font-medium text-red-500">Pending</h2>
                  <div className="flex">
                    <div className="text-gray-400 font-medium mr-2">With</div>
                    <div className="text-gray-700 font-medium">Manager</div>
                  </div>
                  <button
                    onClick={() => handleWithdrawClick(currentRequisition)}
                    className="bg-[#f26c6c] text-white text-xs px-4 py-[6px] rounded"
                  >
                    withdraw
                  </button>
                </div>

                <div className="flex p-4">
                  <input
                    className="border border-gray-300 w-full text-xs p-2"
                    placeholder="Enter your text..."
                    value={comment}
                    onChange={(e) => setComment(e.target.value)}
                  />
                  <IoEnterOutline
                    className="ml-[-2rem] mt-1 text-sm cursor-pointer"
                    onClick={submitMgrComment}
                  />
                </div>
                <div className="mt-3 p-4 text-base">
                  {commentFetched.length > 0 ? (
                    <ul>
                      {commentFetched.map((comment, index) => (
                        <li key={index}>
                          <p className="text-gray-600 font-normal">
                            <strong>{comment.employeeName}</strong> added a <strong>Comment</strong>
                          </p>
                          <p className="text-gray-500">{comment.comments}</p>
                          <p className="text-gray-400 font-medium mb-4">
                            {comment.commentDateTime}
                          </p>
                        </li>
                      ))}
                    </ul>
                  ) : (
                    <p>No comments available.</p>
                  )}
                </div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-6 pb-6 text-semibold">
            <div>
              <h3 className="text-md font-semibold text-gray-700 mb-4">IT Asset Requirements</h3>
              <div className="space-y-4">
                <Field label="IT Asset" value={currentRequisition.itAsset} />
                <Field label="Configurations" value={currentRequisition.configuartions} />
                <Field label="Additional Informations" value={currentRequisition.additionalInformations} />
                <Field label="Initiated by (Hiring manager)" value={currentRequisition.initiatorName} />
              </div>
            </div>

            <div>
              <h3 className="text-md font-semibold text-gray-700 mb-4">Initiator Details</h3>
              <div className="space-y-4">
                <Field label="Name" value={currentRequisition.initiatorName} />
                <Field label="Employee Code" value={currentRequisition.initiatorEmployeeCode} />
                <Field label="Email" value={currentRequisition.initiatorEmailId} />
                <Field label="BU Head" value={currentRequisition.buHead} />
                <Field label="Location" value={currentRequisition.initiatorLocation} />
              </div>
            </div>

            <div className="flex items-center justify-center">
              <select
                className="w-48 border border-gray-400 rounded-md px-4 py-2 text-left text-[#0ddd1a] text-sm focus:outline-none"
              >
                <option>{currentRequisition.requisitionStatus}</option>
              </select>
            </div>
          </div>

          <div className="mb-6">
            <h3 className="text-md font-semibold mb-2">Selected JD</h3>
            <div className="flex text-slate-700 font-semibold pl-2">{currentRequisition.selectedJob}</div>
          </div>

          <div className="mb-6">
            <h3 className="text-md font-semibold mb-2">Job Description</h3>
            <div className="text-slate-500 font-semibold text-black whitespace-pre-line pl-2">
              {currentRequisition.jobDescription
                ? currentRequisition.jobDescription
                  .split('\n')
                  .map((line, index) => (
                    <div key={index}>
                      {line.trim() !== '' ? `• ${line}` : ''}
                    </div>
                  ))
                : "-"}
            </div>
          </div>

          <div className="mb-6">
            <h3 className="text-md font-semibold mb-2">Required Skills</h3>
            <div className="text-slate-500 font-semibold text-black pl-2">
              {currentRequisition.requiredSkills
                ? currentRequisition.requiredSkills.split('\n').map((line, index) => (
                  <div key={index}>{line.trim() ? `• ${line}` : ''}</div>
                ))
                : "-"}
            </div>
          </div>

          <div className="mb-6">
            <h3 className="text-md font-semibold mb-2">Additional Skills</h3>
            <div className="text-slate-500 font-semibold text-black pl-2">
              {currentRequisition.additionalSkills
                ? currentRequisition.additionalSkills.split('\n').map((line, index) => (
                  <div key={index}>{line.trim() ? `• ${line}` : ''}</div>
                ))
                : "-"}
            </div>
          </div>
        </div>

        {showApproveButtons && (
          <div className="flex gap-4 justify-end mt-6 border-t pt-6">
            <button
              onClick={onClose}
              className="px-6 py-2 border border-gray-400 text-gray-700 hover:bg-gray-100 rounded-lg font-semibold transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={handleApprove}
              className="px-6 py-2 bg-green-600 text-white hover:bg-green-700 rounded-lg font-semibold transition-colors"
            >
              Approve
            </button>
          </div>
        )}

        {isPopupVisible && (
          <div className="popup fixed inset-0 flex items-center justify-center bg-gray-800 bg-opacity-50 py-36 px-56">
            <div className="popup-content bg-white md:p-24 p-3 h-full md:w-full w-[412px] flex flex-col">
              <div>Are you sure you want to delete the submitted claim request?</div>
              <div className="flex items-center mt-4">
                <input
                  type="checkbox"
                  id="agree"
                  checked={isChecked}
                  onChange={(e) => setIsChecked(e.target.checked)}
                  className="mr-2"
                />
                <label htmlFor="agree">I agree</label>
              </div>
              <div className="mt-4">
                <button
                  onClick={handleConfirmWithdraw}
                  className="bg-red-500 text-white p-2 rounded mr-2"
                  disabled={!isChecked}
                >
                  Delete
                </button>
                <button
                  onClick={handleClosePopup}
                  className="bg-gray-500 text-white p-2 rounded"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ====== PUBLISH POPUP – Job Title is Job Role (read-only) ====== */}
        {showPublishPopup && (
          <div className="fixed inset-0 z-50 bg-black bg-opacity-60 flex justify-center items-center p-4">
            <div className="bg-white rounded-xl shadow-2xl max-w-4xl w-full max-h-[95vh] overflow-y-auto">
              <div className="bg-gradient-to-r from-red-900 to-red-600 text-white px-6 py-4 rounded-t-xl flex justify-between items-center sticky top-0 z-10">
                <h2 className="text-2xl font-bold flex items-center gap-2">
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                  </svg>
                  Publish to JobPost – Review &amp; Fill Project Details
                </h2>
                <button
                  onClick={() => setShowPublishPopup(false)}
                  className="text-white hover:text-red-200 transition-colors"
                >
                  <X size={28} />
                </button>
              </div>

              <div className="p-6">
                {/* Editable fields: Deadline and Email */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Application Deadline <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="date"
                      name="applicationDeadline"
                      value={publishForm.applicationDeadline}
                      onChange={handlePublishFormChange}
                      className="w-full border border-gray-300 rounded px-3 py-2 focus:ring-2 focus:ring-blue-400"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Login EmailId</label>
                    <input
                      type="loginEmailId"
                      name="loginEmailId"
                      value={publishForm.loginEmailId}
                      onChange={handlePublishFormChange}
                      className="w-full border border-gray-300 rounded px-3 py-2 focus:ring-2 focus:ring-blue-400"
                    />
                  </div>
                </div>

                <hr className="my-4 border-gray-300" />

                {/* Job Posting – read‑only */}
                <h3 className="text-lg font-semibold text-gray-700 mb-3">Job Posting</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-600">Job Title (Job Role)</label>
                    <input type="text" value={getErfValue("position")} readOnly className="w-full bg-gray-100 border border-gray-200 rounded px-3 py-2 text-gray-700" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-600">Job Type</label>
                    <input type="text" value="Full-time" readOnly className="w-full bg-gray-100 border border-gray-200 rounded px-3 py-2 text-gray-700" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-600">Job Status</label>
                    <input type="text" value="Open" readOnly className="w-full bg-gray-100 border border-gray-200 rounded px-3 py-2 text-gray-700" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-600">Publish Type</label>
                    <input type="text" value={getErfValue("publishType")} readOnly className="w-full bg-gray-100 border border-gray-200 rounded px-3 py-2 text-gray-700" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-600">Job Priority</label>
                    <input type="text" value={getErfValue("jobPriority")} readOnly className="w-full bg-gray-100 border border-gray-200 rounded px-3 py-2 text-gray-700" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-600">Lead Time (in days)</label>
                    <input type="text" value={getErfValue("leadTime")} readOnly className="w-full bg-gray-100 border border-gray-200 rounded px-3 py-2 text-gray-700" />
                  </div>
                </div>

                <hr className="my-4 border-gray-300" />

                {/* Job Details – read‑only */}
                <h3 className="text-lg font-semibold text-gray-700 mb-3">Job Details</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-600">Job Role</label>
                    <input type="text" value={getErfValue("position")} readOnly className="w-full bg-gray-100 border border-gray-200 rounded px-3 py-2 text-gray-700" />
                  </div>
                  <div className="md:col-span-2">
                    <label className="block text-sm font-medium text-gray-600">Job Description</label>
                    <textarea rows="2" value={getErfValue("jobDescription")} readOnly className="w-full bg-gray-100 border border-gray-200 rounded px-3 py-2 text-gray-700" />
                  </div>
                  {/* JD Attachment – file upload */}
                  <div>
                    <label className="block text-sm font-medium text-gray-600">JD Attachment File  <span className="text-red-500">*</span></label>
                    <input
                      type="file"
                      accept=".pdf,.docx,application/pdf,application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                      onChange={(e) => {
                        const file = e.target.files[0];
                        if (!file) {
                          setJdAttachmentFile(null);
                          return;
                        }

                        const { valid, message } = validateJdAttachment(file);
                        if (!valid) {
                          Swal.fire({
                            icon: "error",
                            title: "Invalid File",
                            text: message,
                          });
                          e.target.value = ""; // reset the input
                          setJdAttachmentFile(null);
                          return;
                        }

                        setJdAttachmentFile(file);
                        console.log("📎 File selected:", file?.name);
                      }}
                      className="w-full border border-gray-300 rounded px-3 py-2 focus:ring-2 focus:ring-blue-400"
                    />
                    <p className="text-xs text-gray-500 mt-1">
                      Allowed formats: PDF, DOCX. Max size: 1 MB.
                    </p>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-600">JD Template (auto‑filled)</label>
                    <input
                      type="text"
                      value={jdTemplatePath}
                      readOnly
                      className="w-full border border-gray-300 rounded px-3 py-2 bg-gray-100 text-gray-700"
                    />
                    {/* Only the file already saved on the requisition can be viewed
                        from the server. A newly chosen (not-yet-uploaded) file lives only in
                        the browser, so we hide this link while jdAttachmentFile is set. */}
                    {jdTemplatePath && !jdAttachmentFile && (
                      <div className="flex gap-3 mt-1 text-sm">
                        <a
                          href={`${BASE_URL}:9024/api/jobpost/downloadJd?filePath=${encodeURIComponent(jdTemplatePath)}&mode=view`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-blue-600 hover:underline"
                        >
                          View
                        </a>
                      </div>
                    )}
                  </div>
                  <div className="md:col-span-2">
                    <label className="block text-sm font-medium text-gray-600">Key Skills</label>
                    <textarea rows="2" value={getErfValue("requiredSkills")} readOnly className="w-full bg-gray-100 border border-gray-200 rounded px-3 py-2 text-gray-700" />
                  </div>
                  <div className="md:col-span-2">
                    <label className="block text-sm font-medium text-gray-600">Key Roles</label>
                    <textarea rows="2" value={getErfValue("additionalSkills")} readOnly className="w-full bg-gray-100 border border-gray-200 rounded px-3 py-2 text-gray-700" />
                  </div>
                </div>

                <hr className="my-4 border-gray-300" />

                {/* Location and Dept – read‑only */}
                <h3 className="text-lg font-semibold text-gray-700 mb-3">Location and Dept</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-600">Job Locations</label>
                    <input
                      type="text"
                      value={getErfValue("jobLocation")}
                      readOnly
                      className="w-full bg-gray-100 border border-gray-200 rounded px-3 py-2 text-gray-700"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-600">Other Location(s)</label>
                    <input type="text" value={getErfValue("otherJobLocation")} readOnly className="w-full bg-gray-100 border border-gray-200 rounded px-3 py-2 text-gray-700" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-600">Hiring Type</label>
                    <input type="text" value={getErfValue("employmentType")} readOnly className="w-full bg-gray-100 border border-gray-200 rounded px-3 py-2 text-gray-700" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-600">Hiring Department</label>
                    <input type="text" value={getErfValue("department")} readOnly className="w-full bg-gray-100 border border-gray-200 rounded px-3 py-2 text-gray-700" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-600">Hiring Manager</label>
                    <input type="text" value={data?.initiatorName || ""} readOnly className="w-full bg-gray-100 border border-gray-200 rounded px-3 py-2 text-gray-700" />
                  </div>
                </div>

                <hr className="my-4 border-gray-300" />

                {/* Experience and Salary – read‑only */}
                <h3 className="text-lg font-semibold text-gray-700 mb-3">Experience and Salary</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-600">Min Experience (years)</label>
                    <input type="number" value={getErfValue("minimumExperienceRange")} readOnly className="w-full bg-gray-100 border border-gray-200 rounded px-3 py-2 text-gray-700" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-600">Max Experience (years)</label>
                    <input type="number" value={getErfValue("maximumExperienceRange")} readOnly className="w-full bg-gray-100 border border-gray-200 rounded px-3 py-2 text-gray-700" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-600">Min Salary (LPA)</label>
                    <input type="number" value={getErfValue("salaryMin")} readOnly className="w-full bg-gray-100 border border-gray-200 rounded px-3 py-2 text-gray-700" placeholder="Not set" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-600">Max Salary (LPA)</label>
                    <input type="number" value={getErfValue("salaryMax")} readOnly className="w-full bg-gray-100 border border-gray-200 rounded px-3 py-2 text-gray-700" placeholder="Not set" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-600">Salary Budget (LPA)</label>
                    <input type="number" step="0.01" value={getErfValue("budget")} readOnly className="w-full bg-gray-100 border border-gray-200 rounded px-3 py-2 text-gray-700" />
                  </div>
                </div>

                <hr className="my-4 border-gray-300" />

                {/* Project Details – EDITABLE */}
                <h3 className="text-lg font-semibold text-gray-700 mb-3">Project Details</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Customer Name</label>
                    <input
                      type="text"
                      name="custName"
                      value={publishForm.custName}
                      onChange={handlePublishFormChange}
                      className="w-full border border-gray-300 rounded px-3 py-2 focus:ring-2 focus:ring-blue-400"
                      placeholder="Enter customer name"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Project Code</label>
                    <input
                      type="text"
                      name="projCode"
                      value={publishForm.projCode}
                      onChange={handlePublishFormChange}
                      className="w-full border border-gray-300 rounded px-3 py-2 focus:ring-2 focus:ring-blue-400"
                      placeholder="Enter project code"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Project Name</label>
                    <input
                      type="text"
                      name="projName"
                      value={publishForm.projName}
                      onChange={handlePublishFormChange}
                      className="w-full border border-gray-300 rounded px-3 py-2 focus:ring-2 focus:ring-blue-400"
                      placeholder="Enter project name"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Project Wave</label>
                    <input
                      type="text"
                      name="projWave"
                      value={publishForm.projWave}
                      onChange={handlePublishFormChange}
                      className="w-full border border-gray-300 rounded px-3 py-2 focus:ring-2 focus:ring-blue-400"
                      placeholder="Enter project wave"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Resource Wave</label>
                    <input
                      type="text"
                      name="resReqWave"
                      value={publishForm.resReqWave}
                      onChange={handlePublishFormChange}
                      className="w-full border border-gray-300 rounded px-3 py-2 focus:ring-2 focus:ring-blue-400"
                      placeholder="Enter resource wave"
                    />
                  </div>
                </div>

                <hr className="my-4 border-gray-300" />

                {/* Job Count/RefNum – read‑only */}
                <h3 className="text-lg font-semibold text-gray-700 mb-3">Job Count / RefNum</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-600">No of Positions</label>
                    <input type="number" step="1" value={getErfValue("noOfPositions")} readOnly className="w-full bg-gray-100 border border-gray-200 rounded px-3 py-2 text-gray-700" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-600">Internal Reference Data</label>
                    <input
                      type="text"
                      value={data?.requisitionNumber || ""}
                      readOnly
                      className="w-full bg-gray-100 border border-gray-200 rounded px-3 py-2 text-gray-700"
                    />
                  </div>
                </div>
              </div>

              <div className="bg-gray-50 px-6 py-4 rounded-b-xl border-t border-gray-200 flex justify-end gap-4">
                <button
                  onClick={() => setShowPublishPopup(false)}
                  className="px-6 py-2 border border-gray-300 text-gray-700 font-semibold rounded-lg hover:bg-gray-100 transition-colors"
                >
                  Cancel
                </button>
                <button
                  onClick={handlePublishSubmit}
                  disabled={isPublishing}
                  className={`px-8 py-2 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700 transition-colors shadow-md ${isPublishing ? "opacity-70 cursor-not-allowed" : ""
                    }`}
                >
                  {isPublishing ? "Publishing..." : "Publish Job Post"}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ViewRequisitionModal;