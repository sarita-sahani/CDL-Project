
 //export  const empolyeeRequisitionUrl= "http://localhost:9024/employeeRequisition";
  //  EMPLOYEE_REQUISITION_BASE_URL: "http://localhost:9024/api/employeeRequisition",
  //  WORKFLOW_BASE_URL: "http://localhost:9028/api/workflow",
  //  ONBOARDING_BASE_URL: "http://localhost:9034/api/onboarding",
   // export const BASE_URL = "http://43.205.24.208";
// export const BASE_URL = "https://mycdl.cms.co.in";
//export const HELPDESK_URL = "http://localhost";
//export const BASE_URL = "http://43.205.24.208";
export const BASE_URL = "http://localhost";


