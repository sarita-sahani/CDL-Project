// CandidateDetails.js
import React, { useEffect, useState } from "react";
import { FiCheckCircle } from "react-icons/fi";
import { MdClose } from 'react-icons/md';
import { BASE_URL } from "../config";
import { getStatusBadgeStyle } from "./JobApplicants";
const CandidateDetails = ({ candidateId, applicationStatus }) => {
  const [candidateInfo, setCandidateInfo] = useState(null);
  const [allSchedules, setAllSchedules] = useState([]);
  const [allFeedback, setAllFeedback] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [activeTab, setActiveTab] = useState('schedule'); // Track active tab

  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    try {
      const date = new Date(dateString.replace(/GMT.*$/, '').trim());
      return date.toLocaleDateString('en-GB', { day: '2-digit', month: '2-digit', year: 'numeric' });
    } catch (e) {
      return dateString;
    }
  };

  useEffect(() => {
    // Reset state immediately when candidateId changes
    setCandidateInfo(null);
    setAllSchedules([]);
    setAllFeedback([]);
    setError(null);

    if (!candidateId) return;

    const fetchData = async () => {
      setLoading(true);
      
      try {
        // Fetch interview schedules and feedback
        const [scheduleRes, feedbackRes] = await Promise.all([
          fetch(`${BASE_URL}:9034/api/display/fetch/interviewSchedule/data/${candidateId}`),
          fetch(`${BASE_URL}:9034/api/display/interview/feedback/data/${candidateId}`)
        ]);

        const scheduleData = await scheduleRes.json();
        const feedbackData = await feedbackRes.json();

        // Handle API returning arrays
        setAllSchedules(Array.isArray(scheduleData) ? scheduleData : [scheduleData]);
        setAllFeedback(Array.isArray(feedbackData) ? feedbackData : [feedbackData]);

        // Extract candidate info from the first schedule
        if (Array.isArray(scheduleData) && scheduleData.length > 0) {
          setCandidateInfo({
            name: scheduleData[0].CandidateName || "N/A",
            candidateId: scheduleData[0].CandidateID || "N/A",
            jobPosition: scheduleData[0].JobPosition || "N/A"
          });
        } else if (scheduleData) {
          setCandidateInfo({
            name: scheduleData.CandidateName || "N/A",
            candidateId: scheduleData.CandidateID || "N/A",
            jobPosition: scheduleData.JobPosition || "N/A"
          });
        }

      } catch (e) {
        console.error("API fetch error:", e);
        setError("Failed to load interview history for this candidate.");
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [candidateId]);

  if (!candidateId) return <div className="p-8 text-center text-gray-400 font-medium">Select an applicant to view interview details.</div>;
  if (loading) return <div className="p-8 text-center text-indigo-600 animate-pulse font-bold">Loading Interview Details...</div>;

  // Get the latest (most recent) interview as current
  const currentInterview = allSchedules && allSchedules.length > 0 ? allSchedules[allSchedules.length - 1] : null;
  const currentFeedback = currentInterview && allFeedback && allFeedback.length > 0 
    ? allFeedback.find(f => f.IntNum === currentInterview.IntNum) 
    : null;
  
  // Get previous interviews as history
  const previousInterviews = allSchedules ? allSchedules.slice(0, -1) : [];
  const previousFeedback = allFeedback ? allFeedback.slice(0, -1) : [];

  // Build the status-tracking steps from real data (IntType + IntStatus + applicationStatus).
  // Slots stay fixed as Screening -> Interview 1 -> Interview 2 -> Offer, but each slot's
  // state (completed / current / skipped / in-process / pending) is derived, not hardcoded.
  const sortedSchedulesForTracker = allSchedules && allSchedules.length > 0
    ? [...allSchedules].sort((a, b) => (a.IntNum || 0) - (b.IntNum || 0))
    : [];

  const interview1Schedule = sortedSchedulesForTracker[0] || null;
  const interview2Schedule = sortedSchedulesForTracker[1] || null;

  const statusForTracker = (applicationStatus || '').toLowerCase();
  const isOfferCompleted = ['joined', 'hired', 'join-planned'].some(s => statusForTracker.includes(s));
  const isOfferInProcess = statusForTracker.includes('to be created');
  const isOfferCurrent = statusForTracker.includes('offer') && !isOfferCompleted && !isOfferInProcess;

  // Screening can only be "done" once at least one interview has actually been scheduled -
  // an interview can't exist without screening having happened first.
  const screeningState = interview1Schedule
    ? 'completed'
    : (statusForTracker.includes('applied') ? 'current' : 'pending');

  // Interview 1 can only be marked completed if screening is also complete.
  const interview1State = !interview1Schedule
    ? 'pending'
    : (interview1Schedule.IntStatus === 'Completed' && screeningState === 'completed')
      ? 'completed'
      : 'current';

  // Interview 2 depends on Interview 1 being completed first. If Interview 1 is done but
  // Interview 2 was never scheduled, mark it "skipped" (X) rather than hiding the slot,
  // and the pipeline still moves on to the Offer stage.
  const interview2State = interview1State !== 'completed'
    ? 'pending'
    : !interview2Schedule
      ? 'skipped'
      : (interview2Schedule.IntStatus === 'Completed' ? 'completed' : 'current');

  const offerState = isOfferCompleted ? 'completed' : isOfferInProcess ? 'inprocess' : isOfferCurrent ? 'current' : 'pending';

  const trackerSteps = [
    { label: 'Screening', state: screeningState },
    { label: interview1Schedule?.IntType || 'Interview 1', state: interview1State },
    { label: interview2Schedule?.IntType || 'Interview 2', state: interview2State },
    { label: 'Offer', state: offerState },
  ];

  // Same keyword logic JobApplicants uses (via getStatusBadgeStyle) to decide when a status
  // reads as rejected/declined/revoked or on-hold. Whichever step is currently "active" gets
  // recolored to red/orange in that case, instead of staying blue/amber, so the tracker matches
  // the same status coloring shown on the Job Applicants list/badge.
  const isRejectedStatus = ['reject', 'declin', 'revok', 'cancel', 'abort', 'blocked', 'closed'].some(s => statusForTracker.includes(s));
  const isOnHoldStatus = !isRejectedStatus && statusForTracker.includes('hold');

  const applyOutcomeOverride = (state) => {
    if (state !== 'current' && state !== 'inprocess') return state;
    if (isRejectedStatus) return 'rejected';
    if (isOnHoldStatus) return 'onhold';
    return state;
  };

  const trackerStepsWithOutcome = trackerSteps.map(step => ({ ...step, state: applyOutcomeOverride(step.state) }));

  const stepIcon = (state) => {
    if (state === 'completed') return '✓';
    if (state === 'rejected') return '✕';
    if (state === 'skipped') return '−'; // neutral dash: step wasn't required, not a rejection
    if (state === 'current' || state === 'inprocess' || state === 'onhold') return '●';
    return '○';
  };

  const stepBubbleClass = (state) => {
    if (state === 'completed') return 'bg-green-500 text-white';
    if (state === 'rejected') return 'bg-red-500 text-white';
    if (state === 'onhold') return 'bg-orange-500 text-white';
    if (state === 'skipped') return 'bg-gray-400 text-white'; // neutral gray, not red, so it doesn't read as rejected
    if (state === 'current') return 'bg-blue-500 text-white';
    if (state === 'inprocess') return 'bg-amber-500 text-white';
    return 'bg-gray-300 text-gray-600';
  };

  const connectorClass = (state) => {
    if (state === 'completed') return 'bg-green-500';
    if (state === 'rejected') return 'bg-red-400';
    if (state === 'onhold') return 'bg-orange-400';
    if (state === 'inprocess') return 'bg-amber-400';
    if (state === 'current') return 'bg-blue-400';
    return 'bg-gray-300';
  };

  const showTracker = Boolean(applicationStatus) || sortedSchedulesForTracker.length > 0;

  // Same badge coloring used for the JOB_APP_STATUS pill on the Job Applicants list, applied
  // here to the Current Status field so both pages read the status color identically.
  const currentStatusStyle = getStatusBadgeStyle(applicationStatus);

  return (
    <div className="bg-white rounded-lg shadow-lg h-full flex flex-col border border-slate-200">
      {/* Header */}
      <div className="p-4 border-b border-slate-100 bg-slate-50">
        <h2 className="text-lg font-bold text-slate-800">Candidate Details</h2>
      </div>

      <div className="p-6 space-y-6 flex-1 overflow-y-auto max-h-[calc(100vh-120px)]">
        
        {/* STEPPER SECTION - fixed Screening/Interview1/Interview2/Offer slots, state derived from real data */}
        {showTracker && (
          <div className="border border-gray-200 p-4 rounded-lg">
            <div className="flex justify-between items-center relative">
              {trackerStepsWithOutcome.map((step, idx) => (
                <React.Fragment key={step.label + idx}>
                  <div className="flex flex-col items-center flex-1">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold ${stepBubbleClass(step.state)}`}>
                      {stepIcon(step.state)}
                    </div>
                    <p className="text-xs text-gray-600 mt-1 text-center">{step.label}</p>
                  </div>
                  {idx < trackerStepsWithOutcome.length - 1 && (
                    <div className={`flex-1 h-0.5 mx-1 ${connectorClass(step.state)}`}></div>
                  )}
                </React.Fragment>
              ))}
            </div>
          </div>
        )}

        {/* CURRENT STATUS - from applicationStatus (JOB_APP_STATUS) fetched in JobApplicants.
             Uses the same getStatusBadgeStyle keyword mapping as the Job Applicants list, so
             the badge color here matches the badge shown there for the same status. */}
        {applicationStatus && (
          <div>
            <p className="text-xs text-gray-500 font-medium mb-1">Current Status:</p>
            <span className={`inline-block px-3 py-1 rounded-full text-sm font-semibold border whitespace-nowrap ${currentStatusStyle.bg} ${currentStatusStyle.text} ${currentStatusStyle.border}`}>
              {applicationStatus}
            </span>
          </div>
        )}

        {/* INTERVIEW TABS CARD */}
        {currentInterview && (
          <div className="border border-gray-200 rounded-lg overflow-hidden">
            {/* Card Title */}
            <div className="bg-gray-50 border-b border-gray-200 px-4 py-2">
              <p className="text-sm font-bold text-gray-900">Interview Details</p>
            </div>

            {/* Tabs Header */}
            <div className="flex gap-0 bg-gray-100 border-b border-gray-200">
              <button
                onClick={() => setActiveTab('schedule')}
                className={`flex-1 px-4 py-3 text-sm font-semibold transition-colors ${
                  activeTab === 'schedule'
                    ? 'bg-indigo-600 text-white'
                    : 'text-gray-700 hover:bg-gray-200'
                }`}
              >
                Interview Schedule
              </button>
              <button
                onClick={() => setActiveTab('feedback')}
                className={`flex-1 px-4 py-3 text-sm font-semibold transition-colors border-l border-gray-200 ${
                  activeTab === 'feedback'
                    ? 'bg-indigo-600 text-white'
                    : 'text-gray-700 hover:bg-gray-200'
                }`}
              >
                Interview Feedback
              </button>
            </div>

            {/* Tab Content */}
            <div className="p-4">
              {/* INTERVIEW SCHEDULE TAB */}
              {activeTab === 'schedule' && (
                <div className="space-y-6">
                  {/* RECENT INTERVIEW SCHEDULE */}
                  <div>
                    <h4 className="font-bold text-gray-800 mb-3">Interview Details</h4>
                    <div className="border border-indigo-200 bg-indigo-50 rounded-lg p-4 space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <p className="text-xs text-gray-500 font-semibold uppercase mb-1">Interview Number</p>
                          <p className="text-sm font-semibold text-gray-900">{currentInterview.IntNum || 'N/A'}</p>
                        </div>
                        <div>
                          <p className="text-xs text-gray-500 font-semibold uppercase mb-1">Interview Type</p>
                          <p className="text-sm font-semibold text-gray-900">{currentInterview.IntType || 'N/A'}</p>
                        </div>
                        <div>
                          <p className="text-xs text-gray-500 font-semibold uppercase mb-1">Interview Date</p>
                          <p className="text-sm font-semibold text-gray-900">{new Date(currentInterview.IntDate).toLocaleDateString()}</p>
                        </div>
                        <div>
                          <p className="text-xs text-gray-500 font-semibold uppercase mb-1">Time</p>
                          <p className="text-sm font-semibold text-gray-900">{currentInterview.StartTime} - {currentInterview.EndTime}</p>
                        </div>
                        <div>
                          <p className="text-xs text-gray-500 font-semibold uppercase mb-1">Interview Status</p>
                          <p className={`text-sm font-semibold ${currentInterview.IntStatus === 'Completed' ? 'text-green-600' : 'text-orange-500'}`}>
                            {currentInterview.IntStatus || 'N/A'}
                          </p>
                        </div>
                        <div>
                          <p className="text-xs text-gray-500 font-semibold uppercase mb-1">Panel</p>
                          <p className="text-sm font-semibold text-gray-900">{currentInterview.PanelUserID || 'N/A'}</p>
                        </div>
                        <div className="col-span-2">
                          <p className="text-xs text-gray-500 font-semibold uppercase mb-1">Interview Mode</p>
                          <p className="text-sm font-semibold text-gray-900">{currentInterview.IntMode || 'N/A'}</p>
                        </div>
                      </div>

                      {/* {currentInterview.MeetingLink && (
                        <div className="mt-4 pt-4 border-t border-indigo-200">
                          <p className="text-xs text-gray-500 font-semibold uppercase mb-2">Meeting Link</p>
                          <a
                            href={currentInterview.MeetingLink}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium text-sm"
                          >
                            Join Meeting
                          </a>
                        </div>
                      )} */}

                      {currentInterview.Remarks && (
                        <div className="mt-4 pt-4 border-t border-indigo-200">
                          <p className="text-xs text-gray-500 font-semibold uppercase mb-2">Remarks</p>
                          <p className="text-sm text-gray-700 bg-white p-3 rounded">{currentInterview.Remarks}</p>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* INTERVIEW SCHEDULE HISTORY */}
                  {previousInterviews.length > 0 && (
                    <div>
                      <h4 className="font-bold text-gray-800 mb-3">Interview Schedule History</h4>
                      
                      {previousInterviews.map((interview, index) => (
                        <div key={index} className="border border-gray-200 rounded-lg overflow-hidden mb-3">
                          {/* Header with Interview Type and Status */}
                          <div className="bg-gray-50 border-b border-gray-200 px-4 py-3">
                            <div className="flex justify-between items-start">
                              <div>
                                <h5 className="font-semibold text-gray-900">{interview.IntType}</h5>
                                <p className="text-xs text-gray-500 mt-1">Interview #{interview.IntNum} • {new Date(interview.IntDate).toLocaleDateString()}</p>
                              </div>
                              <span className={`px-2 py-1 text-xs font-semibold rounded-full ${
                                interview.IntStatus === 'Completed' ? 'bg-green-100 text-green-700' : 'bg-orange-100 text-orange-700'
                              }`}>
                                {interview.IntStatus}
                              </span>
                            </div>
                          </div>

                          {/* Schedule Content */}
                          <div className="p-4 space-y-3">
                            <div className="grid grid-cols-2 gap-3 text-xs">
                              <div>
                                <p className="text-gray-500 font-semibold uppercase mb-1">Time</p>
                                <p className="text-gray-900 font-medium">{interview.StartTime} - {interview.EndTime}</p>
                              </div>
                              <div>
                                <p className="text-gray-500 font-semibold uppercase mb-1">Panel</p>
                                <p className="text-gray-900 font-medium">{interview.PanelUserID || 'N/A'}</p>
                              </div>
                              <div className="col-span-2">
                                <p className="text-gray-500 font-semibold uppercase mb-1">Interview Mode</p>
                                <p className="text-gray-900 font-medium">{interview.IntMode || 'N/A'}</p>
                              </div>
                            </div>

                            {interview.MeetingLink && (
                              <div className="bg-indigo-50 border border-indigo-200 p-3 rounded-lg">
                                <p className="text-xs font-semibold text-gray-700 mb-2">Meeting Link</p>
                                <a
                                  href={interview.MeetingLink}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="text-xs text-indigo-600 hover:text-indigo-700 font-medium break-all"
                                >
                                  {interview.MeetingLink}
                                </a>
                              </div>
                            )}

                            {interview.Remarks && (
                              <div className="bg-gray-50 p-3 rounded-lg border border-gray-200">
                                <p className="text-xs font-semibold text-gray-700 mb-1">Remarks</p>
                                <p className="text-xs text-gray-700">{interview.Remarks}</p>
                              </div>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* INTERVIEW FEEDBACK TAB */}
              {activeTab === 'feedback' && (
                <div className="space-y-6">
                  {/* RECENT INTERVIEW FEEDBACK */}
                  {currentFeedback ? (
                    <div>
                      <h4 className="font-bold text-gray-800 mb-3">Interview Feedback Details</h4>
                      <div className="border border-green-200 bg-green-50 rounded-lg p-4 space-y-4">
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <p className="text-xs text-gray-500 font-semibold uppercase mb-1">Selection Status</p>
                            <p className="text-sm font-semibold text-green-600">{currentFeedback.SelStatus || 'N/A'}</p>
                          </div>
                          <div>
                            <p className="text-xs text-gray-500 font-semibold uppercase mb-1">Overall Rating</p>
                            <span className="inline-block px-3 py-1 bg-red-600 text-white text-xs font-bold rounded-full">{currentFeedback.OverallRating || 'N/A'}</span>
                          </div>
                          <div>
                            <p className="text-xs text-gray-500 font-semibold uppercase mb-1">Feedback By</p>
                            <p className="text-sm font-semibold text-gray-900">{currentFeedback.FeedbackByUser || 'N/A'}</p>
                          </div>
                          <div>
                            <p className="text-xs text-gray-500 font-semibold uppercase mb-1">Feedback Date</p>
                            <p className="text-sm font-semibold text-gray-900">{new Date(currentFeedback.FeedbackDate).toLocaleDateString()}</p>
                          </div>
                        </div>

                        {/* Ratings Grid */}
                        <div className="mt-4 pt-4 border-t border-green-200">
                          <p className="text-xs text-gray-500 font-semibold uppercase mb-3">Ratings & Remarks</p>
                          <div className="grid grid-cols-2 gap-3">
                            {currentFeedback.JobRating && (
                              <div className="bg-white p-3 rounded-lg border border-blue-200">
                                <div className="flex justify-between items-center">
                                  <p className="text-xs font-semibold text-gray-700">Job Rating</p>
                                  <span className="text-xs font-bold text-blue-600">{currentFeedback.JobRating}</span>
                                </div>
                                {currentFeedback.JobRemarks && (
                                  <p className="text-xs text-gray-600 mt-1">{currentFeedback.JobRemarks}</p>
                                )}
                              </div>
                            )}
                            {currentFeedback.TechRating && (
                              <div className="bg-white p-3 rounded-lg border border-green-200">
                                <div className="flex justify-between items-center">
                                  <p className="text-xs font-semibold text-gray-700">Technical Rating</p>
                                  <span className="text-xs font-bold text-green-600">{currentFeedback.TechRating}</span>
                                </div>
                                {currentFeedback.TechRemarks && (
                                  <p className="text-xs text-gray-600 mt-1">{currentFeedback.TechRemarks}</p>
                                )}
                              </div>
                            )}
                            {currentFeedback.SoftCommRating && (
                              <div className="bg-white p-3 rounded-lg border border-indigo-200">
                                <div className="flex justify-between items-center">
                                  <p className="text-xs font-semibold text-gray-700">Communication</p>
                                  <span className="text-xs font-bold text-indigo-600">{currentFeedback.SoftCommRating}</span>
                                </div>
                                {currentFeedback.SoftCommRemarks && (
                                  <p className="text-xs text-gray-600 mt-1">{currentFeedback.SoftCommRemarks}</p>
                                )}
                              </div>
                            )}
                            {currentFeedback.ManagementRating && (
                              <div className="bg-white p-3 rounded-lg border border-yellow-200">
                                <div className="flex justify-between items-center">
                                  <p className="text-xs font-semibold text-gray-700">Management</p>
                                  <span className="text-xs font-bold text-yellow-600">{currentFeedback.ManagementRating}</span>
                                </div>
                                {currentFeedback.ManagementRemarks && (
                                  <p className="text-xs text-gray-600 mt-1">{currentFeedback.ManagementRemarks}</p>
                                )}
                              </div>
                            )}
                          </div>
                        </div>

                        {currentFeedback.OverallRemarks && (
                          <div className="mt-4 pt-4 border-t border-green-200">
                            <p className="text-xs text-gray-500 font-semibold uppercase mb-2">Overall Remarks</p>
                            <p className="text-sm text-gray-700 bg-white p-3 rounded">{currentFeedback.OverallRemarks}</p>
                          </div>
                        )}
                      </div>
                    </div>
                  ) : (
                    <div className="text-center py-6 text-gray-500">
                      <p className="text-sm">No feedback available yet</p>
                    </div>
                  )}

                  {/* INTERVIEW FEEDBACK HISTORY */}
                  {previousInterviews.length > 0 && (
                    <div>
                      <h4 className="font-bold text-gray-800 mb-3">Interview Feedback History</h4>
                      
                      {previousInterviews.map((interview, index) => {
                        const feedback = previousFeedback.find(f => f.IntNum === interview.IntNum);
                        return (
                          <div key={index} className="border border-gray-200 rounded-lg overflow-hidden mb-3">
                            {/* Header with Interview Type and Status */}
                            <div className="bg-gray-50 border-b border-gray-200 px-4 py-3">
                              <div className="flex justify-between items-start">
                                <div>
                                  <h5 className="font-semibold text-gray-900">{interview.IntType}</h5>
                                  <p className="text-xs text-gray-500 mt-1">Interview #{interview.IntNum} • {new Date(interview.IntDate).toLocaleDateString()}</p>
                                </div>
                                <span className={`px-2 py-1 text-xs font-semibold rounded-full ${
                                  interview.IntStatus === 'Completed' ? 'bg-green-100 text-green-700' : 'bg-orange-100 text-orange-700'
                                }`}>
                                  {interview.IntStatus}
                                </span>
                              </div>
                            </div>

                            {/* Feedback Content */}
                            <div className="p-4 space-y-3">
                              {feedback ? (
                                <>
                                  <div className="grid grid-cols-2 gap-3 text-xs">
                                    <div>
                                      <p className="text-gray-500 font-semibold uppercase mb-1">Selection Status</p>
                                      <p className="text-gray-900 font-medium text-green-600">{feedback.SelStatus || 'N/A'}</p>
                                    </div>
                                    <div>
                                      <p className="text-gray-500 font-semibold uppercase mb-1">Overall Rating</p>
                                      <span className="inline-block px-2 py-1 bg-red-600 text-white text-xs font-bold rounded-full">{feedback.OverallRating || 'N/A'}</span>
                                    </div>
                                    <div>
                                      <p className="text-gray-500 font-semibold uppercase mb-1">Feedback By</p>
                                      <p className="text-gray-900 font-medium">{feedback.FeedbackByUser || 'N/A'}</p>
                                    </div>
                                    <div>
                                      <p className="text-gray-500 font-semibold uppercase mb-1">Feedback Date</p>
                                      <p className="text-gray-900 font-medium">{new Date(feedback.FeedbackDate).toLocaleDateString()}</p>
                                    </div>
                                  </div>

                                  {feedback.OverallRemarks && (
                                    <div className="bg-indigo-50 border border-indigo-200 p-3 rounded-lg">
                                      <p className="text-xs font-semibold text-gray-700 mb-1">Overall Remarks</p>
                                      <p className="text-xs text-gray-700">{feedback.OverallRemarks}</p>
                                    </div>
                                  )}

                                  {/* Ratings Summary */}
                                  {(feedback.JobRating || feedback.TechRating || feedback.SoftCommRating || feedback.ManagementRating) && (
                                    <div>
                                      <p className="text-xs font-semibold text-gray-700 mb-2 uppercase">Ratings</p>
                                      <div className="grid grid-cols-2 gap-2">
                                        {feedback.JobRating && (
                                          <div className="bg-blue-50 p-2 rounded-lg border border-blue-200">
                                            <p className="text-xs font-semibold text-gray-700">Job</p>
                                            <p className="text-xs font-bold text-blue-600">{feedback.JobRating}</p>
                                            {feedback.JobRemarks && (
                                              <p className="text-xs text-gray-600 mt-1">{feedback.JobRemarks}</p>
                                            )}
                                          </div>
                                        )}
                                        {feedback.TechRating && (
                                          <div className="bg-green-50 p-2 rounded-lg border border-green-200">
                                            <p className="text-xs font-semibold text-gray-700">Technical</p>
                                            <p className="text-xs font-bold text-green-600">{feedback.TechRating}</p>
                                            {feedback.TechRemarks && (
                                              <p className="text-xs text-gray-600 mt-1">{feedback.TechRemarks}</p>
                                            )}
                                          </div>
                                        )}
                                        {feedback.SoftCommRating && (
                                          <div className="bg-indigo-50 p-2 rounded-lg border border-indigo-200">
                                            <p className="text-xs font-semibold text-gray-700">Communication</p>
                                            <p className="text-xs font-bold text-indigo-600">{feedback.SoftCommRating}</p>
                                            {feedback.SoftCommRemarks && (
                                              <p className="text-xs text-gray-600 mt-1">{feedback.SoftCommRemarks}</p>
                                            )}
                                          </div>
                                        )}
                                        {feedback.ManagementRating && (
                                          <div className="bg-yellow-50 p-2 rounded-lg border border-yellow-200">
                                            <p className="text-xs font-semibold text-gray-700">Management</p>
                                            <p className="text-xs font-bold text-yellow-600">{feedback.ManagementRating}</p>
                                            {feedback.ManagementRemarks && (
                                              <p className="text-xs text-gray-600 mt-1">{feedback.ManagementRemarks}</p>
                                            )}
                                          </div>
                                        )}
                                      </div>
                                    </div>
                                  )}
                                </>
                              ) : (
                                <p className="text-xs text-gray-500 italic">No feedback available for this interview</p>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        )}

        {/* No Data State */}
        {!currentInterview && (
          <div className="text-center py-8 border border-dashed border-gray-200 rounded-lg">
            <p className="text-sm text-gray-400">No interview details available for this candidate.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default CandidateDetails;

// CandidateDetails.js
// import React, { useEffect, useState } from "react";
// import { FiCheckCircle } from "react-icons/fi";
// import { MdClose } from 'react-icons/md';
// import { BASE_URL } from "../config";
// import { getStatusBadgeStyle } from "./JobApplicants";
// const CandidateDetails = ({ candidateId, applicationStatus }) => {
//   const [candidateInfo, setCandidateInfo] = useState(null);
//   const [allSchedules, setAllSchedules] = useState([]);
//   const [allFeedback, setAllFeedback] = useState([]);
//   const [loading, setLoading] = useState(false);
//   const [error, setError] = useState(null);
//   const [activeTab, setActiveTab] = useState('schedule'); // Track active tab

//   const formatDate = (dateString) => {
//     if (!dateString) return 'N/A';
//     try {
//       const date = new Date(dateString.replace(/GMT.*$/, '').trim());
//       return date.toLocaleDateString('en-GB', { day: '2-digit', month: '2-digit', year: 'numeric' });
//     } catch (e) {
//       return dateString;
//     }
//   };

//   useEffect(() => {
//     // Reset state immediately when candidateId changes
//     setCandidateInfo(null);
//     setAllSchedules([]);
//     setAllFeedback([]);
//     setError(null);

//     if (!candidateId) return;

//     const fetchData = async () => {
//       setLoading(true);
      
//       try {
//         // Fetch interview schedules and feedback
//         const [scheduleRes, feedbackRes] = await Promise.all([
//           fetch(`${BASE_URL}:9034/api/display/fetch/interviewSchedule/data/${candidateId}`),
//           fetch(`${BASE_URL}:9034/api/display/interview/feedback/data/${candidateId}`)
//         ]);

//         const scheduleData = await scheduleRes.json();
//         const feedbackData = await feedbackRes.json();

//         // Handle API returning arrays
//         setAllSchedules(Array.isArray(scheduleData) ? scheduleData : [scheduleData]);
//         setAllFeedback(Array.isArray(feedbackData) ? feedbackData : [feedbackData]);

//         // Extract candidate info from the first schedule
//         if (Array.isArray(scheduleData) && scheduleData.length > 0) {
//           setCandidateInfo({
//             name: scheduleData[0].CandidateName || "N/A",
//             candidateId: scheduleData[0].CandidateID || "N/A",
//             jobPosition: scheduleData[0].JobPosition || "N/A"
//           });
//         } else if (scheduleData) {
//           setCandidateInfo({
//             name: scheduleData.CandidateName || "N/A",
//             candidateId: scheduleData.CandidateID || "N/A",
//             jobPosition: scheduleData.JobPosition || "N/A"
//           });
//         }

//       } catch (e) {
//         console.error("API fetch error:", e);
//         setError("Failed to load interview history for this candidate.");
//       } finally {
//         setLoading(false);
//       }
//     };

//     fetchData();
//   }, [candidateId]);

//   if (!candidateId) return <div className="p-8 text-center text-gray-400 font-medium">Select an applicant to view interview details.</div>;
//   if (loading) return <div className="p-8 text-center text-blue-600 animate-pulse font-bold">Loading Interview Details...</div>;

//   // Get the latest (most recent) interview as current
//   const currentInterview = allSchedules && allSchedules.length > 0 ? allSchedules[allSchedules.length - 1] : null;
//   const currentFeedback = currentInterview && allFeedback && allFeedback.length > 0 
//     ? allFeedback.find(f => f.IntNum === currentInterview.IntNum) 
//     : null;
  
//   // Get previous interviews as history
//   const previousInterviews = allSchedules ? allSchedules.slice(0, -1) : [];
//   const previousFeedback = allFeedback ? allFeedback.slice(0, -1) : [];

//   // Build the status-tracking steps from real data (IntType + IntStatus + applicationStatus).
//   // Slots stay fixed as Screening -> Interview 1 -> Interview 2 -> Offer, but each slot's
//   // state (completed / current / skipped / in-process / pending) is derived, not hardcoded.
//   const sortedSchedulesForTracker = allSchedules && allSchedules.length > 0
//     ? [...allSchedules].sort((a, b) => (a.IntNum || 0) - (b.IntNum || 0))
//     : [];

//   const interview1Schedule = sortedSchedulesForTracker[0] || null;
//   const interview2Schedule = sortedSchedulesForTracker[1] || null;

//   const statusForTracker = (applicationStatus || '').toLowerCase();
//   const isOfferCompleted = ['joined', 'hired', 'join-planned'].some(s => statusForTracker.includes(s));
//   const isOfferInProcess = statusForTracker.includes('to be created');
//   const isOfferCurrent = statusForTracker.includes('offer') && !isOfferCompleted && !isOfferInProcess;

//   // Screening can only be "done" once at least one interview has actually been scheduled -
//   // an interview can't exist without screening having happened first.
//   const screeningState = interview1Schedule
//     ? 'completed'
//     : (statusForTracker.includes('applied') ? 'current' : 'pending');

//   // Interview 1 can only be marked completed if screening is also complete.
//   const interview1State = !interview1Schedule
//     ? 'pending'
//     : (interview1Schedule.IntStatus === 'Completed' && screeningState === 'completed')
//       ? 'completed'
//       : 'current';

//   // Interview 2 depends on Interview 1 being completed first. If Interview 1 is done but
//   // Interview 2 was never scheduled, mark it "skipped" (X) rather than hiding the slot,
//   // and the pipeline still moves on to the Offer stage.
//   const interview2State = interview1State !== 'completed'
//     ? 'pending'
//     : !interview2Schedule
//       ? 'skipped'
//       : (interview2Schedule.IntStatus === 'Completed' ? 'completed' : 'current');

//   const offerState = isOfferCompleted ? 'completed' : isOfferInProcess ? 'inprocess' : isOfferCurrent ? 'current' : 'pending';

//   const trackerSteps = [
//     { label: 'Screening', state: screeningState },
//     { label: interview1Schedule?.IntType || 'Interview 1', state: interview1State },
//     { label: interview2Schedule?.IntType || 'Interview 2', state: interview2State },
//     { label: 'Offer', state: offerState },
//   ];

//   // Same keyword logic JobApplicants uses (via getStatusBadgeStyle) to decide when a status
//   // reads as rejected/declined/revoked or on-hold. Whichever step is currently "active" gets
//   // recolored to red/orange in that case, instead of staying blue/amber, so the tracker matches
//   // the same status coloring shown on the Job Applicants list/badge.
//   const isRejectedStatus = ['reject', 'declin', 'revok', 'cancel', 'abort', 'blocked', 'closed'].some(s => statusForTracker.includes(s));
//   const isOnHoldStatus = !isRejectedStatus && statusForTracker.includes('hold');

//   const applyOutcomeOverride = (state) => {
//     if (state !== 'current' && state !== 'inprocess') return state;
//     if (isRejectedStatus) return 'rejected';
//     if (isOnHoldStatus) return 'onhold';
//     return state;
//   };

//   const trackerStepsWithOutcome = trackerSteps.map(step => ({ ...step, state: applyOutcomeOverride(step.state) }));

//   const stepIcon = (state) => {
//     if (state === 'completed') return '✓';
//     if (state === 'rejected') return '✕';
//     if (state === 'skipped') return '−'; // neutral dash: step wasn't required, not a rejection
//     if (state === 'current' || state === 'inprocess' || state === 'onhold') return '●';
//     return '○';
//   };

//   const stepBubbleClass = (state) => {
//     if (state === 'completed') return 'bg-green-500 text-white';
//     if (state === 'rejected') return 'bg-red-500 text-white';
//     if (state === 'onhold') return 'bg-orange-500 text-white';
//     if (state === 'skipped') return 'bg-gray-400 text-white'; // neutral gray, not red, so it doesn't read as rejected
//     if (state === 'current') return 'bg-blue-500 text-white';
//     if (state === 'inprocess') return 'bg-amber-500 text-white';
//     return 'bg-gray-300 text-gray-600';
//   };

//   const connectorClass = (state) => {
//     if (state === 'completed') return 'bg-green-500';
//     if (state === 'rejected') return 'bg-red-400';
//     if (state === 'onhold') return 'bg-orange-400';
//     if (state === 'inprocess') return 'bg-amber-400';
//     if (state === 'current') return 'bg-blue-400';
//     return 'bg-gray-300';
//   };

//   const showTracker = Boolean(applicationStatus) || sortedSchedulesForTracker.length > 0;

//   // Same badge coloring used for the JOB_APP_STATUS pill on the Job Applicants list, applied
//   // here to the Current Status field so both pages read the status color identically.
//   const currentStatusStyle = getStatusBadgeStyle(applicationStatus);

//   return (
//     <div className="bg-white rounded-lg shadow-lg h-full flex flex-col border border-slate-200">
//       {/* Header */}
//       <div className="p-4 border-b border-slate-100 bg-slate-50">
//         <h2 className="text-lg font-bold text-slate-800">Candidate Details</h2>
//       </div>

//       <div className="p-6 space-y-6 flex-1 overflow-y-auto max-h-[calc(100vh-120px)]">
        
//         {/* STEPPER SECTION - fixed Screening/Interview1/Interview2/Offer slots, state derived from real data */}
//         {showTracker && (
//           <div className="border border-gray-200 p-4 rounded-lg">
//             <div className="flex justify-between items-center relative">
//               {trackerStepsWithOutcome.map((step, idx) => (
//                 <React.Fragment key={step.label + idx}>
//                   <div className="flex flex-col items-center flex-1">
//                     <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold ${stepBubbleClass(step.state)}`}>
//                       {stepIcon(step.state)}
//                     </div>
//                     <p className="text-xs text-gray-600 mt-1 text-center">{step.label}</p>
//                   </div>
//                   {idx < trackerStepsWithOutcome.length - 1 && (
//                     <div className={`flex-1 h-0.5 mx-1 ${connectorClass(step.state)}`}></div>
//                   )}
//                 </React.Fragment>
//               ))}
//             </div>
//           </div>
//         )}

//         {/* CURRENT STATUS - from applicationStatus (JOB_APP_STATUS) fetched in JobApplicants.
//              Uses the same getStatusBadgeStyle keyword mapping as the Job Applicants list, so
//              the badge color here matches the badge shown there for the same status. */}
//         {applicationStatus && (
//           <div>
//             <p className="text-xs text-gray-500 font-medium mb-1">Current Status:</p>
//             <span className={`inline-block px-3 py-1 rounded-full text-sm font-semibold border whitespace-nowrap ${currentStatusStyle.bg} ${currentStatusStyle.text} ${currentStatusStyle.border}`}>
//               {applicationStatus}
//             </span>
//           </div>
//         )}

//         {/* INTERVIEW TABS CARD */}
//         {currentInterview && (
//           <div className="border border-gray-200 rounded-lg overflow-hidden">
//             {/* Card Title */}
//             <div className="bg-gray-50 border-b border-gray-200 px-4 py-2">
//               <p className="text-sm font-bold text-gray-900">Interview Details</p>
//             </div>

//             {/* Tabs Header */}
//             <div className="flex gap-0 bg-gray-100 border-b border-gray-200">
//               <button
//                 onClick={() => setActiveTab('schedule')}
//                 className={`flex-1 px-4 py-3 text-sm font-semibold transition-colors ${
//                   activeTab === 'schedule'
//                     ? 'bg-blue-600 text-white'
//                     : 'text-gray-700 hover:bg-gray-200'
//                 }`}
//               >
//                 Interview Schedule
//               </button>
//               <button
//                 onClick={() => setActiveTab('feedback')}
//                 className={`flex-1 px-4 py-3 text-sm font-semibold transition-colors border-l border-gray-200 ${
//                   activeTab === 'feedback'
//                     ? 'bg-blue-600 text-white'
//                     : 'text-gray-700 hover:bg-gray-200'
//                 }`}
//               >
//                 Interview Feedback
//               </button>
//             </div>

//             {/* Tab Content */}
//             <div className="p-4">
//               {/* INTERVIEW SCHEDULE TAB */}
//               {activeTab === 'schedule' && (
//                 <div className="space-y-6">
//                   {/* RECENT INTERVIEW SCHEDULE */}
//                   <div>
//                     <h4 className="font-bold text-gray-800 mb-3">Interview Details</h4>
//                     <div className="border border-blue-200 bg-blue-50 rounded-lg p-4 space-y-4">
//                       <div className="grid grid-cols-2 gap-4">
//                         <div>
//                           <p className="text-xs text-gray-500 font-semibold uppercase mb-1">Interview Number</p>
//                           <p className="text-sm font-semibold text-gray-900">{currentInterview.IntNum || 'N/A'}</p>
//                         </div>
//                         <div>
//                           <p className="text-xs text-gray-500 font-semibold uppercase mb-1">Interview Type</p>
//                           <p className="text-sm font-semibold text-gray-900">{currentInterview.IntType || 'N/A'}</p>
//                         </div>
//                         <div>
//                           <p className="text-xs text-gray-500 font-semibold uppercase mb-1">Interview Date</p>
//                           <p className="text-sm font-semibold text-gray-900">{new Date(currentInterview.IntDate).toLocaleDateString()}</p>
//                         </div>
//                         <div>
//                           <p className="text-xs text-gray-500 font-semibold uppercase mb-1">Time</p>
//                           <p className="text-sm font-semibold text-gray-900">{currentInterview.StartTime} - {currentInterview.EndTime}</p>
//                         </div>
//                         <div>
//                           <p className="text-xs text-gray-500 font-semibold uppercase mb-1">Interview Status</p>
//                           <p className={`text-sm font-semibold ${currentInterview.IntStatus === 'Completed' ? 'text-green-600' : 'text-orange-500'}`}>
//                             {currentInterview.IntStatus || 'N/A'}
//                           </p>
//                         </div>
//                         <div>
//                           <p className="text-xs text-gray-500 font-semibold uppercase mb-1">Panel</p>
//                           <p className="text-sm font-semibold text-gray-900">{currentInterview.PanelUserID || 'N/A'}</p>
//                         </div>
//                         <div className="col-span-2">
//                           <p className="text-xs text-gray-500 font-semibold uppercase mb-1">Interview Mode</p>
//                           <p className="text-sm font-semibold text-gray-900">{currentInterview.IntMode || 'N/A'}</p>
//                         </div>
//                       </div>

//                       {/* {currentInterview.MeetingLink && (
//                         <div className="mt-4 pt-4 border-t border-blue-200">
//                           <p className="text-xs text-gray-500 font-semibold uppercase mb-2">Meeting Link</p>
//                           <a
//                             href={currentInterview.MeetingLink}
//                             target="_blank"
//                             rel="noopener noreferrer"
//                             className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium text-sm"
//                           >
//                             Join Meeting
//                           </a>
//                         </div>
//                       )} */}

//                       {currentInterview.Remarks && (
//                         <div className="mt-4 pt-4 border-t border-blue-200">
//                           <p className="text-xs text-gray-500 font-semibold uppercase mb-2">Remarks</p>
//                           <p className="text-sm text-gray-700 bg-white p-3 rounded">{currentInterview.Remarks}</p>
//                         </div>
//                       )}
//                     </div>
//                   </div>

//                   {/* INTERVIEW SCHEDULE HISTORY */}
//                   {previousInterviews.length > 0 && (
//                     <div>
//                       <h4 className="font-bold text-gray-800 mb-3">Interview Schedule History</h4>
                      
//                       {previousInterviews.map((interview, index) => (
//                         <div key={index} className="border border-gray-200 rounded-lg overflow-hidden mb-3">
//                           {/* Header with Interview Type and Status */}
//                           <div className="bg-gray-50 border-b border-gray-200 px-4 py-3">
//                             <div className="flex justify-between items-start">
//                               <div>
//                                 <h5 className="font-semibold text-gray-900">{interview.IntType}</h5>
//                                 <p className="text-xs text-gray-500 mt-1">Interview #{interview.IntNum} • {new Date(interview.IntDate).toLocaleDateString()}</p>
//                               </div>
//                               <span className={`px-2 py-1 text-xs font-semibold rounded-full ${
//                                 interview.IntStatus === 'Completed' ? 'bg-green-100 text-green-700' : 'bg-orange-100 text-orange-700'
//                               }`}>
//                                 {interview.IntStatus}
//                               </span>
//                             </div>
//                           </div>

//                           {/* Schedule Content */}
//                           <div className="p-4 space-y-3">
//                             <div className="grid grid-cols-2 gap-3 text-xs">
//                               <div>
//                                 <p className="text-gray-500 font-semibold uppercase mb-1">Time</p>
//                                 <p className="text-gray-900 font-medium">{interview.StartTime} - {interview.EndTime}</p>
//                               </div>
//                               <div>
//                                 <p className="text-gray-500 font-semibold uppercase mb-1">Panel</p>
//                                 <p className="text-gray-900 font-medium">{interview.PanelUserID || 'N/A'}</p>
//                               </div>
//                               <div className="col-span-2">
//                                 <p className="text-gray-500 font-semibold uppercase mb-1">Interview Mode</p>
//                                 <p className="text-gray-900 font-medium">{interview.IntMode || 'N/A'}</p>
//                               </div>
//                             </div>

//                             {interview.MeetingLink && (
//                               <div className="bg-blue-50 border border-blue-200 p-3 rounded-lg">
//                                 <p className="text-xs font-semibold text-gray-700 mb-2">Meeting Link</p>
//                                 <a
//                                   href={interview.MeetingLink}
//                                   target="_blank"
//                                   rel="noopener noreferrer"
//                                   className="text-xs text-blue-600 hover:text-blue-700 font-medium break-all"
//                                 >
//                                   {interview.MeetingLink}
//                                 </a>
//                               </div>
//                             )}

//                             {interview.Remarks && (
//                               <div className="bg-gray-50 p-3 rounded-lg border border-gray-200">
//                                 <p className="text-xs font-semibold text-gray-700 mb-1">Remarks</p>
//                                 <p className="text-xs text-gray-700">{interview.Remarks}</p>
//                               </div>
//                             )}
//                           </div>
//                         </div>
//                       ))}
//                     </div>
//                   )}
//                 </div>
//               )}

//               {/* INTERVIEW FEEDBACK TAB */}
//               {activeTab === 'feedback' && (
//                 <div className="space-y-6">
//                   {/* RECENT INTERVIEW FEEDBACK */}
//                   {currentFeedback ? (
//                     <div>
//                       <h4 className="font-bold text-gray-800 mb-3">Interview Feedback Details</h4>
//                       <div className="border border-green-200 bg-green-50 rounded-lg p-4 space-y-4">
//                         <div className="grid grid-cols-2 gap-4">
//                           <div>
//                             <p className="text-xs text-gray-500 font-semibold uppercase mb-1">Selection Status</p>
//                             <p className="text-sm font-semibold text-green-600">{currentFeedback.SelStatus || 'N/A'}</p>
//                           </div>
//                           <div>
//                             <p className="text-xs text-gray-500 font-semibold uppercase mb-1">Overall Rating</p>
//                             <span className="inline-block px-3 py-1 bg-red-600 text-white text-xs font-bold rounded-full">{currentFeedback.OverallRating || 'N/A'}</span>
//                           </div>
//                           <div>
//                             <p className="text-xs text-gray-500 font-semibold uppercase mb-1">Feedback By</p>
//                             <p className="text-sm font-semibold text-gray-900">{currentFeedback.FeedbackByUser || 'N/A'}</p>
//                           </div>
//                           <div>
//                             <p className="text-xs text-gray-500 font-semibold uppercase mb-1">Feedback Date</p>
//                             <p className="text-sm font-semibold text-gray-900">{new Date(currentFeedback.FeedbackDate).toLocaleDateString()}</p>
//                           </div>
//                         </div>

//                         {/* Ratings Grid */}
//                         <div className="mt-4 pt-4 border-t border-green-200">
//                           <p className="text-xs text-gray-500 font-semibold uppercase mb-3">Ratings & Remarks</p>
//                           <div className="grid grid-cols-2 gap-3">
//                             {currentFeedback.JobRating && (
//                               <div className="bg-white p-3 rounded-lg border border-blue-200">
//                                 <div className="flex justify-between items-center">
//                                   <p className="text-xs font-semibold text-gray-700">Job Rating</p>
//                                   <span className="text-xs font-bold text-blue-600">{currentFeedback.JobRating}</span>
//                                 </div>
//                                 {currentFeedback.JobRemarks && (
//                                   <p className="text-xs text-gray-600 mt-1">{currentFeedback.JobRemarks}</p>
//                                 )}
//                               </div>
//                             )}
//                             {currentFeedback.TechRating && (
//                               <div className="bg-white p-3 rounded-lg border border-green-200">
//                                 <div className="flex justify-between items-center">
//                                   <p className="text-xs font-semibold text-gray-700">Technical Rating</p>
//                                   <span className="text-xs font-bold text-green-600">{currentFeedback.TechRating}</span>
//                                 </div>
//                                 {currentFeedback.TechRemarks && (
//                                   <p className="text-xs text-gray-600 mt-1">{currentFeedback.TechRemarks}</p>
//                                 )}
//                               </div>
//                             )}
//                             {currentFeedback.SoftCommRating && (
//                               <div className="bg-white p-3 rounded-lg border border-indigo-200">
//                                 <div className="flex justify-between items-center">
//                                   <p className="text-xs font-semibold text-gray-700">Communication</p>
//                                   <span className="text-xs font-bold text-indigo-600">{currentFeedback.SoftCommRating}</span>
//                                 </div>
//                                 {currentFeedback.SoftCommRemarks && (
//                                   <p className="text-xs text-gray-600 mt-1">{currentFeedback.SoftCommRemarks}</p>
//                                 )}
//                               </div>
//                             )}
//                             {currentFeedback.ManagementRating && (
//                               <div className="bg-white p-3 rounded-lg border border-yellow-200">
//                                 <div className="flex justify-between items-center">
//                                   <p className="text-xs font-semibold text-gray-700">Management</p>
//                                   <span className="text-xs font-bold text-yellow-600">{currentFeedback.ManagementRating}</span>
//                                 </div>
//                                 {currentFeedback.ManagementRemarks && (
//                                   <p className="text-xs text-gray-600 mt-1">{currentFeedback.ManagementRemarks}</p>
//                                 )}
//                               </div>
//                             )}
//                           </div>
//                         </div>

//                         {currentFeedback.OverallRemarks && (
//                           <div className="mt-4 pt-4 border-t border-green-200">
//                             <p className="text-xs text-gray-500 font-semibold uppercase mb-2">Overall Remarks</p>
//                             <p className="text-sm text-gray-700 bg-white p-3 rounded">{currentFeedback.OverallRemarks}</p>
//                           </div>
//                         )}
//                       </div>
//                     </div>
//                   ) : (
//                     <div className="text-center py-6 text-gray-500">
//                       <p className="text-sm">No feedback available yet</p>
//                     </div>
//                   )}

//                   {/* INTERVIEW FEEDBACK HISTORY */}
//                   {previousInterviews.length > 0 && (
//                     <div>
//                       <h4 className="font-bold text-gray-800 mb-3">Interview Feedback History</h4>
                      
//                       {previousInterviews.map((interview, index) => {
//                         const feedback = previousFeedback.find(f => f.IntNum === interview.IntNum);
//                         return (
//                           <div key={index} className="border border-gray-200 rounded-lg overflow-hidden mb-3">
//                             {/* Header with Interview Type and Status */}
//                             <div className="bg-gray-50 border-b border-gray-200 px-4 py-3">
//                               <div className="flex justify-between items-start">
//                                 <div>
//                                   <h5 className="font-semibold text-gray-900">{interview.IntType}</h5>
//                                   <p className="text-xs text-gray-500 mt-1">Interview #{interview.IntNum} • {new Date(interview.IntDate).toLocaleDateString()}</p>
//                                 </div>
//                                 <span className={`px-2 py-1 text-xs font-semibold rounded-full ${
//                                   interview.IntStatus === 'Completed' ? 'bg-green-100 text-green-700' : 'bg-orange-100 text-orange-700'
//                                 }`}>
//                                   {interview.IntStatus}
//                                 </span>
//                               </div>
//                             </div>

//                             {/* Feedback Content */}
//                             <div className="p-4 space-y-3">
//                               {feedback ? (
//                                 <>
//                                   <div className="grid grid-cols-2 gap-3 text-xs">
//                                     <div>
//                                       <p className="text-gray-500 font-semibold uppercase mb-1">Selection Status</p>
//                                       <p className="text-gray-900 font-medium text-green-600">{feedback.SelStatus || 'N/A'}</p>
//                                     </div>
//                                     <div>
//                                       <p className="text-gray-500 font-semibold uppercase mb-1">Overall Rating</p>
//                                       <span className="inline-block px-2 py-1 bg-red-600 text-white text-xs font-bold rounded-full">{feedback.OverallRating || 'N/A'}</span>
//                                     </div>
//                                     <div>
//                                       <p className="text-gray-500 font-semibold uppercase mb-1">Feedback By</p>
//                                       <p className="text-gray-900 font-medium">{feedback.FeedbackByUser || 'N/A'}</p>
//                                     </div>
//                                     <div>
//                                       <p className="text-gray-500 font-semibold uppercase mb-1">Feedback Date</p>
//                                       <p className="text-gray-900 font-medium">{new Date(feedback.FeedbackDate).toLocaleDateString()}</p>
//                                     </div>
//                                   </div>

//                                   {feedback.OverallRemarks && (
//                                     <div className="bg-blue-50 border border-blue-200 p-3 rounded-lg">
//                                       <p className="text-xs font-semibold text-gray-700 mb-1">Overall Remarks</p>
//                                       <p className="text-xs text-gray-700">{feedback.OverallRemarks}</p>
//                                     </div>
//                                   )}

//                                   {/* Ratings Summary */}
//                                   {(feedback.JobRating || feedback.TechRating || feedback.SoftCommRating || feedback.ManagementRating) && (
//                                     <div>
//                                       <p className="text-xs font-semibold text-gray-700 mb-2 uppercase">Ratings</p>
//                                       <div className="grid grid-cols-2 gap-2">
//                                         {feedback.JobRating && (
//                                           <div className="bg-blue-50 p-2 rounded-lg border border-blue-200">
//                                             <p className="text-xs font-semibold text-gray-700">Job</p>
//                                             <p className="text-xs font-bold text-blue-600">{feedback.JobRating}</p>
//                                             {feedback.JobRemarks && (
//                                               <p className="text-xs text-gray-600 mt-1">{feedback.JobRemarks}</p>
//                                             )}
//                                           </div>
//                                         )}
//                                         {feedback.TechRating && (
//                                           <div className="bg-green-50 p-2 rounded-lg border border-green-200">
//                                             <p className="text-xs font-semibold text-gray-700">Technical</p>
//                                             <p className="text-xs font-bold text-green-600">{feedback.TechRating}</p>
//                                             {feedback.TechRemarks && (
//                                               <p className="text-xs text-gray-600 mt-1">{feedback.TechRemarks}</p>
//                                             )}
//                                           </div>
//                                         )}
//                                         {feedback.SoftCommRating && (
//                                           <div className="bg-indigo-50 p-2 rounded-lg border border-indigo-200">
//                                             <p className="text-xs font-semibold text-gray-700">Communication</p>
//                                             <p className="text-xs font-bold text-indigo-600">{feedback.SoftCommRating}</p>
//                                             {feedback.SoftCommRemarks && (
//                                               <p className="text-xs text-gray-600 mt-1">{feedback.SoftCommRemarks}</p>
//                                             )}
//                                           </div>
//                                         )}
//                                         {feedback.ManagementRating && (
//                                           <div className="bg-yellow-50 p-2 rounded-lg border border-yellow-200">
//                                             <p className="text-xs font-semibold text-gray-700">Management</p>
//                                             <p className="text-xs font-bold text-yellow-600">{feedback.ManagementRating}</p>
//                                             {feedback.ManagementRemarks && (
//                                               <p className="text-xs text-gray-600 mt-1">{feedback.ManagementRemarks}</p>
//                                             )}
//                                           </div>
//                                         )}
//                                       </div>
//                                     </div>
//                                   )}
//                                 </>
//                               ) : (
//                                 <p className="text-xs text-gray-500 italic">No feedback available for this interview</p>
//                               )}
//                             </div>
//                           </div>
//                         );
//                       })}
//                     </div>
//                   )}
//                 </div>
//               )}
//             </div>
//           </div>
//         )}

//         {/* No Data State */}
//         {!currentInterview && (
//           <div className="text-center py-8 border border-dashed border-gray-200 rounded-lg">
//             <p className="text-sm text-gray-400">No interview details available for this candidate.</p>
//           </div>
//         )}
//       </div>
//     </div>
//   );
// };

// export default CandidateDetails;