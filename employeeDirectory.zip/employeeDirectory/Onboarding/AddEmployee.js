import React, { useState, useEffect } from "react";
import { useLocation, useNavigate } from 'react-router-dom';
import axios from "axios";
import {BASE_URL} from "../config";
import Header from '../../components/Header';
// --- START: Transformation Helper Functions ---

const formatDate = (dateString) => {
  if (!dateString) return null;
  try {
    if (dateString.match(/^\d{4}-\d{2}-\d{2}$/)) {
      return dateString;
    }
    const date = new Date(dateString);
    if (isNaN(date)) {
      console.warn("Invalid date string encountered:", dateString);
      return null;
    }
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  } catch (e) {
    console.error("Date parsing failed for:", dateString, e);
    return null;
  }
};

const safeSplit = (str) => {
  if (!str || typeof str !== 'string') return [];
  return str.split(',').map(s => s.trim()).filter(s => s.length > 0);
};

const transformDataForBackend = (flatData, existingIds, originalData = {}) => {
  const primarySkills = safeSplit(flatData.primarySkillName);
  const primaryLevels = safeSplit(flatData.primarySkillLevel);
  const secondarySkills = safeSplit(flatData.secondarySkillName);
  const secondaryLevels = safeSplit(flatData.secondarySkillLevel);

  const personalOrig = originalData.personal || {};
  const pfOrig = originalData.pf || {};
  const documentProofOrig = originalData.documentProof || {};
  const profExpOrig = originalData.profExp || {};
  const skillOrig = originalData.skill || {};
  const onboardingOrig = originalData.employeeOnboardingInfo || {};
  const bankOrig = originalData.bank || {};

  const payload = {
    candId: flatData.candID,

    personal: {
      id: existingIds.personalId || null,
      candID: flatData.candID,
      firstName: flatData.firstName,
      middleName: flatData.middleName || null,
      lastName: flatData.lastName,
      emailAddr: flatData.personalEmail,
      dob: formatDate(flatData?.dateOfBirth || "2000-01-01"), // default to avoid invalid date
      maritalStatus: flatData.maritalStatus,
      bloodGroup: flatData.bloodGroup,
      emrContactNum: flatData.emergencyContact,
      curContactNum: flatData.secondaryContactNo,
      permContactNum: flatData.primaryContactNo,
      aadharNum: flatData.aadharNumber,
      panNum: flatData.panNumber,
      gender: flatData.gender,
      passportNumber: flatData.passportNumber,
      fullNameAsPerAadhar: flatData.fullNameAsPerAadhar,
      noOfDependents: personalOrig.noOfDependents ?? null,
curAddress: personalOrig.curAddress ?? null,
curCity: personalOrig.curCity ?? null,
curState: personalOrig.curState ?? null,
curPinCode: personalOrig.curPinCode ?? null,
permAddress: personalOrig.permAddress ?? null,
permCity: personalOrig.permCity ?? null,
permState: personalOrig.permState ?? null,
permPinCode: personalOrig.permPinCode ?? null,
memberEPS: pfOrig.memberEPS ?? null,
addrProofType1: documentProofOrig.addrProofType1 ?? null,
    },

    general: {
      id: existingIds.generalId || null,
      candID: flatData.candID,
      dateOfJoin: formatDate(flatData.dateOfJoining),
      locationId: flatData.selectedLocationId || null,
    },

    pf: {
      id: existingIds.pfId || null,
      candID: flatData.candID,
      uan: flatData.uanNumber,
      prevPFNum: flatData.currentPfNumber,
      prevESICNum: flatData.currentESICNumber,
      memberEPS: pfOrig.memberEPS ?? 'YES',
    },

    documentProof: {
      id: existingIds.documentProofId || null,
      candID: flatData.candID,
      aadharCard: flatData.aadharNumber,
      panCard: flatData.panNumber,
      addrProofType1: documentProofOrig.addrProofType1 ?? "Aadhar",
    },

    skill: {
      id: existingIds.skillId || null,
      candID: flatData.candID,
      primarySkill1Name: primarySkills[0] || skillOrig.primarySkill1Name || null,
      primarySkill1Level: primaryLevels[0] || skillOrig.primarySkill1Level || null,
      primarySkill2Name: primarySkills[1] || skillOrig.primarySkill2Name || null,
      primarySkill2Level: primaryLevels[1] || skillOrig.primarySkill2Level || null,
      primarySkill3Name: primarySkills[2] || skillOrig.primarySkill3Name || null,
      primarySkill3Level: primaryLevels[2] || skillOrig.primarySkill3Level || null,
      secondarySkill1Name: secondarySkills[0] || skillOrig.secondarySkill1Name || null,
      secondarySkill1Level: secondaryLevels[0] || skillOrig.secondarySkill1Level || null,
      secondarySkill2Name: secondarySkills[1] || skillOrig.secondarySkill2Name || null,
      secondarySkill2Level: secondaryLevels[1] || skillOrig.secondarySkill2Level || null,
      secondarySkill3Name: secondarySkills[2] || skillOrig.secondarySkill3Name || null,
      secondarySkill3Level: secondaryLevels[2] || skillOrig.secondarySkill3Level || null,
    },

    profExp: {
      id: existingIds.profExpId || null,
      candID: flatData.candID,
      company1: flatData.previousCompany,
      fromDate1: formatDate(flatData.previousCompanyFrom),
      toDate1: formatDate(flatData.previousCompanyTo),
      totalExp: flatData.totalExp || profExpOrig.totalExp || null,
      location1: profExpOrig.location1 ?? "",
      desGrad1: profExpOrig.desGrad1 ?? "",
      annualCTC1: profExpOrig.annualCTC1 ?? "",
      jobRole1: profExpOrig.jobRole1 ?? "",
      leaveReason1: profExpOrig.leaveReason1 ?? "",
    },

    // EmployeeOnboardingInfo now includes all fields from the entity,
    // including nominee/dependent fields (previously in separate family object).
    employeeOnboardingInfo: {
      id: existingIds.onboardingId || null,
      candID: flatData.candID,
      empOnboardingRefNum: flatData.empOnboardingRefNum || "",
      isProbationApplicable: flatData.isProbationApplicable,
      rptManagerName: flatData.rptManagerName || null,
      rptMgrEmployeeCode: flatData.rptMgrEmployeeCode || "",
      rptManagerEmailId: flatData.rptManagerEmailId || "",
      hiringHr: flatData.hiringHr || null,
      employmentStatus: flatData.employmentStatus || null,
      grade: flatData.grade || "",
      payrollAreaType: flatData.payrollAreaType || "",
      buHead: flatData.buHead || "",
      buHeadECode: flatData.buHeadECode || "",
      buHeadName: flatData.buHeadName || null,
      buHeadEmail: flatData.buHeadEmail || null,
      mainDepartment: flatData.mainDepartment || null,
      subDepartment: flatData.subDepartment || null,
      project: flatData.project || "",
      organisationCode: flatData.organisationCode || "",
      designation: flatData.designation || null,
      organisationHierarchy: flatData.organisationHierarchy || "",
      fullNameAsPerPAN: flatData.fullNameAsPerPAN || null,
      currentPfNumber: flatData.currentPfNumber,
      currentESICNumber: flatData.currentESICNumber,
      status: flatData.status,
      confirmationDate: formatDate(flatData.confirmationDate),
      probationStartDate: formatDate(flatData.probationStartDate), // renamed from probationPeriod
      probationPeriod: flatData.probationPeriodDuration || null,   // new text field
      maxProbationExtension: flatData.maxProbationExtension || "",
      companyCode: flatData.companyCode,
      officialEmailId: flatData.officialEmailId,
      orgUnit: flatData.orgUnit,
      orgUnitDesc: flatData.orgUnitDescription || null,
      deptDesc: flatData.departmentDescription || null,
      wbsElement: flatData.wbsElement,
      wbsElementText: flatData.wbsElementText || null,
      projectDesc: flatData.projectDescription || null,
      category: flatData.category || "",
      qualification: flatData.qualification || "",
      certification1: flatData.certification1 || null,
      certification2: flatData.certification2 || null,
      otherCertifications: flatData.tertiarySkills || null,
      gender: flatData.gender || null,
      segment: flatData.segment || null,
      eeSubGrpName: flatData.eeSubGrpName || null,
      eeSubgroup: flatData.eeSubgroup || null,
      classification: flatData.classification || null,
      resignationStatus: flatData.resignationStatus || null,
      dateOfResignation: formatDate(flatData.dateOfResignation) || null,
      dateOfLeaving: formatDate(flatData.dateOfLeaving) || null,
      exitStatus: flatData.exitStatus || null,
      subDeptDesc: flatData.subDepartmentDescription || null,
      joiningDate: formatDate(flatData.dateOfJoining), // added
      nomineeName1: flatData.nomineeName1,
      dependentName: flatData.dependentName,
      dependentRelation: flatData.dependentRelationship,
      dependentDob: formatDate(flatData.dependentDOB),
      empCode: flatData.empCode,   
    },

    bank: {
      id: existingIds.bankId || null,
      candID: flatData.candID,
      bankName: flatData.bankName,
      accountNum: flatData.salaryAccountNumber,
      ifscCode: flatData.ifscCode,
      nameAsPerBank: flatData.nameOnSalaryAccount
    },

    // Other mandatory entities (minimal required)
    education: { id: existingIds.educationId || null, candID: flatData.candID },
   candidateDeclaration: {
  id: existingIds.candDeclId || null,
  candID: flatData.candID,
  declDate: null,          // or leave out if backend accepts missing
  declPlace: null,
  candSignature: flatData.firstName || ""
},
    declQuestionnaire: { id: existingIds.quesId || null, candID: flatData.candID },
    hrDeclaration: { id: existingIds.hrDeclId || null, candID: flatData.candID },
    interest: { id: existingIds.interestId || null, candID: flatData.candID },
    language: { id: existingIds.languageId || null, candID: flatData.candID },
    overallStatus: { id: existingIds.statusId || null, candID: flatData.candID },
    profReference: { id: existingIds.refId || null, candID: flatData.candID },
  };

  return payload;
};

// --- END: Transformation Helper Functions ---

const AddEmployee = ({ initialCandidateData, onClose }) => {
  const [locations, setLocations] = useState([]);
  const location = useLocation();
  const candidateData = initialCandidateData || location.state?.candidate;
  const [roles, setRoles] = useState([]);
  const [selectedLocation, setSelectedLocation] = useState('');
  const [selectedRole, setSelectedRole] = useState('');
  const navigate = useNavigate();

  const isDataPresent = !!candidateData;
  const isEditMode = !!initialCandidateData;

  const [formData, setFormData] = useState({
    empOnboardingRefNum: '',
    isProbationApplicable: false,
    rptManagerName: '',
    rptMgrEmployeeCode: '',
    rptManagerEmailId: '',
    hiringHr: '',
    employmentStatus: '',
    grade: '',
    payrollAreaType: '',
    buHead: '',
    buHeadECode: '',
    buHeadName: '',           
    buHeadEmail: '',
    mainDepartment: '',
    subDepartment: '',
    project: '',
    organisationCode: '',
    designation: '',
    organisationHierarchy: '',
    fullNameAsPerPAN: '',
    currentPfNumber: '',
    currentESICNumber: '',
    status: '',
    confirmationDate: '',
    probationStartDate: '',   
    probationPeriodDuration: '', 
    maxProbationExtension: '',

    companyCode: '',
     empCode: '',  
    fullNameAsPerAadhar: '',
    emergencyContactName: '',
    relationWithEmergencyContact: '',
    passportNumber: '',

    nomineeName1: '',

    candID: '',
    firstName: '',
    middleName: '',
    lastName: '',
    fullName: '',
    dateOfJoining: '',
    gender: '',
    dateOfBirth: '',
    primaryContactNo: '',
    secondaryContactNo: '',
    emergencyContact: '',
    personalEmail: '',
    maritalStatus: '',
    bloodGroup: '',
    totalExp: '',
    previousCompany: '',
    previousCompanyFrom: '',
    previousCompanyTo: '',
    primarySkillName: '',
    primarySkillLevel: '',
    secondarySkillName: '',
    secondarySkillLevel: '',
    aadharNumber: '',
    panNumber: '',
    uanNumber: '',

    dependentName: '',
    dependentRelationship: '',
    dependentDOB: '',

    bankName: '',
    salaryAccountNumber: '',
    nameOnSalaryAccount: '',
    ifscCode: '',
    officialEmailId: '',

    orgUnit: '',
    orgUnitDescription: '',
    departmentDescription: '',
    subDepartmentDescription: '',
    wbsElement: '',
    wbsElementText: '',
    projectDescription: '',
    classification: '',
    category: '',
    eeSubGrpName: '',
    eeSubgroup: '',          
    segment: '',

    qualification: '',
    certification1: '',
    certification2: '',
    tertiarySkills: '',

    resignationStatus: '',
    dateOfResignation: '',
    dateOfLeaving: '',
    exitStatus: ''
  });

  useEffect(() => {
    if (isDataPresent) {
      const onboardingInfo = candidateData.employeeOnboardingInfo || {};
      const personal = candidateData.personal || {};
      const general = candidateData.general || {};
      const profExp = candidateData.profExp || {};
      const skill = candidateData.skill || {};
      const documentProof = candidateData.documentProof || {};
      const pf = candidateData.pf || {};
      const bank = candidateData.bank || {};
      // family object is no longer used; fields now come from onboardingInfo

      const getSkillsString = (s1, s2, s3) => [s1, s2, s3].filter(Boolean).join(', ');

      setFormData(prevFormData => ({
        ...prevFormData,
        candID: personal.candID || general.candID || onboardingInfo.candID || candidateData.candId || '',
        firstName: personal.firstName || '',
        middleName: personal.middleName || '',
        lastName: personal.lastName || '',
        fullName: [personal.firstName, personal.middleName, personal.lastName].filter(Boolean).join(' ') || '',
        dateOfJoining: onboardingInfo.joiningDate || general.dateOfJoin || '',
        gender: onboardingInfo.gender || '',
        dateOfBirth: personal.dob || '',
        primaryContactNo: personal.permContactNum || '',
        secondaryContactNo: personal.curContactNum || '',
        emergencyContact: personal.emrContactNum || '',
        personalEmail: personal.emailAddr || '',
        maritalStatus: personal.maritalStatus || '',
        bloodGroup: personal.bloodGroup || '',
        totalExp: profExp.totalExp || '',
        previousCompany: profExp.company1 || '',
        previousCompanyFrom: profExp.fromDate1 || '',
        previousCompanyTo: profExp.toDate1 || '',
        primarySkillName: getSkillsString(skill.primarySkill1Name, skill.primarySkill2Name, skill.primarySkill3Name),
        primarySkillLevel: getSkillsString(skill.primarySkill1Level, skill.primarySkill2Level, skill.primarySkill3Level),
        secondarySkillName: getSkillsString(skill.secondarySkill1Name, skill.secondarySkill2Name, skill.secondarySkill3Name),
        secondarySkillLevel: getSkillsString(skill.secondarySkill1Level, skill.secondarySkill2Level, skill.secondarySkill3Level),
        aadharNumber: documentProof.aadharCard || '',
        panNumber: documentProof.panCard || '',
        uanNumber: pf.uan || '',

        bankName: bank.bankName || '',
        salaryAccountNumber: bank.accountNum || '',
        ifscCode: bank.ifscCode || '',
        nameOnSalaryAccount: bank.nameAsPerBank || '',

        // Nominee/dependent fields now come from onboardingInfo
        nomineeName1: onboardingInfo.nomineeName1 || '',
        dependentName: onboardingInfo.dependentName || '',
        dependentRelationship: onboardingInfo.dependentRelation || '',
        dependentDOB: onboardingInfo.dependentDob || '',

        empOnboardingRefNum: onboardingInfo.empOnboardingRefNum || '',
        isProbationApplicable: onboardingInfo.isProbationApplicable || false,
        rptManagerName: onboardingInfo.rptManagerName || '',
        rptMgrEmployeeCode: onboardingInfo.rptMgrEmployeeCode || '',
        rptManagerEmailId: onboardingInfo.rptManagerEmailId || '',
        hiringHr: onboardingInfo.hiringHr || '',
        employmentStatus: onboardingInfo.employmentStatus || '',
        grade: onboardingInfo.grade || '',
        payrollAreaType: onboardingInfo.payrollAreaType || '',
        buHead: onboardingInfo.buHead || '',
        buHeadECode: onboardingInfo.buHeadECode || '',
        buHeadName: onboardingInfo.buHeadName || '',           
        buHeadEmail: onboardingInfo.buHeadEmail || '',
        mainDepartment: onboardingInfo.mainDepartment || '',
        subDepartment: onboardingInfo.subDepartment || '',
        project: onboardingInfo.project || '',
        organisationCode: onboardingInfo.organisationCode || '',
        designation: onboardingInfo.designation || '',
        organisationHierarchy: onboardingInfo.organisationHierarchy || '',
        fullNameAsPerPAN: onboardingInfo.fullNameAsPerPAN || '',
        currentPfNumber: onboardingInfo.currentPfNumber || '',
        currentESICNumber: onboardingInfo.currentESICNumber || '',
        status: onboardingInfo.status || '',
        confirmationDate: onboardingInfo.confirmationDate || '',
        probationStartDate: onboardingInfo.probationStartDate || '',   
        probationPeriodDuration: onboardingInfo.probationPeriod || '', 
        maxProbationExtension: onboardingInfo.maxProbationExtension || '',
        orgUnit: onboardingInfo.orgUnit || '',
        orgUnitDescription: onboardingInfo.orgUnitDesc || '',
        departmentDescription: onboardingInfo.deptDesc || '',
        subDepartmentDescription: onboardingInfo.subDeptDesc || '',
        wbsElement: onboardingInfo.wbsElement || '',
        wbsElementText: onboardingInfo.wbsElementText || '',
        projectDescription: onboardingInfo.projectDesc || '',
        buHeadECode: onboardingInfo.buHeadECode || '',
        buHeadEmail: onboardingInfo.buHeadEmail || '',
        category: onboardingInfo.category || '',
        eeSubGrpName: onboardingInfo.eeSubGrpName || '',
        eeSubgroup: onboardingInfo.eeSubgroup || '',           
        segment: onboardingInfo.segment || '',
        classification: onboardingInfo.classification || '',
        qualification: onboardingInfo.qualification || '',
        certification1: onboardingInfo.certification1 || '',
        certification2: onboardingInfo.certification2 || '',
        tertiarySkills: onboardingInfo.otherCertifications || '',
        resignationStatus: onboardingInfo.resignationStatus || '',
        dateOfResignation: onboardingInfo.dateOfResignation || '',
        dateOfLeaving: onboardingInfo.dateOfLeaving || '',
        exitStatus: onboardingInfo.exitStatus || '',
        companyCode: onboardingInfo.companyCode || '',
        empCode: onboardingInfo.empCode || '',
        officialEmailId: onboardingInfo.officialEmailId || '',  
      }));

      if (candidateData.general?.locationId) {
        setSelectedLocation(candidateData.general.locationId);
      }
      if (candidateData.userRoles && candidateData.userRoles.length > 0) {
        setSelectedRole(candidateData.userRoles[0].roleId);
      }
    }
  }, [isDataPresent, candidateData]);

  const handleProbationChange = (e) => {
    handleChange({
      target: {
        name: "isProbationApplicable",
        type: "checkbox",
        checked: e.target.checked
      }
    });
  };

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData((prev) => {
      let newFormData = {
        ...prev,
        [name]: type === "checkbox" ? checked : value,
      };

      if (name === 'firstName' || name === 'middleName' || name === 'lastName') {
        const personalData = candidateData?.personal || {};
        const fName = name === 'firstName' ? value : personalData.firstName || newFormData.firstName;
        const mName = name === 'middleName' ? value : personalData.middleName || newFormData.middleName;
        const lName = name === 'lastName' ? value : personalData.lastName || newFormData.lastName;
        newFormData.fullName = [fName, mName, lName].filter(Boolean).join(' ').trim();
      }

      return newFormData;
    });
  };

  const fetchOptions = async (url, setter) => {
    try {
      const res = await fetch(url);
      if (!res.ok) throw new Error("Network response was not ok");
      const data = await res.json();
      setter(data);
    } catch (error) {
      console.error("Failed to fetch:", error);
      setter([]);
    }
  };

  useEffect(() => {
    fetchOptions("http://43.205.24.208:9021/location/getAll", setLocations);
    fetchOptions("http://43.205.24.208:9021/role/getAllRoleNames", setRoles);
  }, []);

  const handleSaveAndContinue = async () => {
    console.log("Save button clicked — starting request...");
  };

  const onSubmit = async () => {
    const candidateId = formData.candID;

    if (isEditMode && !candidateId) {
      alert("Candidate ID is missing. Cannot update.");
      return;
    }

    const existingIds = {
      personalId: candidateData?.personal?.id || null,
      generalId: candidateData?.general?.id || null,
      pfId: candidateData?.pf?.id || null,
      skillId: candidateData?.skill?.id || null,
      profExpId: candidateData?.profExp?.id || null,
      onboardingId: candidateData?.employeeOnboardingInfo?.id || null,
      documentProofId: candidateData?.documentProof?.id || null,
      // familyId removed — fields now inside employeeOnboardingInfo
      bankId: candidateData?.bank?.id || null,
      educationId: candidateData?.education?.id || null,
      candDeclId: candidateData?.candidateDeclaration?.id || null,
      quesId: candidateData?.declQuestionnaire?.id || null,
      hrDeclId: candidateData?.hrDeclaration?.id || null,
      interestId: candidateData?.interest?.id || null,
      languageId: candidateData?.language?.id || null,
      statusId: candidateData?.overallStatus?.id || null,
      refId: candidateData?.profReference?.id || null,
    };

    const payload = transformDataForBackend(formData, existingIds, candidateData);

    const method = isEditMode ? 'put' : 'post';
    const url = isEditMode
      ? `${BASE_URL}:9034/api/onboarding/updateEmployeeDataInOnboardingTable/${candidateId}`
      : `${BASE_URL}:9034/api/onboarding/saveEmployeeDataInOnboardingTable`;

    console.log(`Sending payload via ${method.toUpperCase()} to ${url}:`, payload);

    try {
      const response = await axios[method](url, payload);

      // After successful save/update, attempt to update overall status to 'Onboarded'
      try {
        const candidateId = formData.candID || candidateData?.candId || candidateData?.personal?.candID || candidateData?.eonGeneralReqDTO?.CandID || '';
        const jobId = parseInt(candidateData?.eonGeneralReqDTO?.JOB_ID || candidateData?.general?.JOB_ID || candidateData?.general?.jobId) || 0;
        const applicationId = parseInt(candidateData?.eonGeneralReqDTO?.JOB_APP_ID || candidateData?.general?.JOB_APP_ID || candidateData?.general?.applicationId) || 0;
        const status = 'Onboarded';
        const statusUrl = `${BASE_URL}:9034/api/onboarding/update-overall-status?candId=${candidateId}&jobId=${jobId}&applicationId=${applicationId}&status=${status}`;

        const statusRes = await fetch(statusUrl, { method: 'PUT' });
        if (!statusRes.ok) {
          const txt = await statusRes.text().catch(() => '');
          console.warn('Failed to update overall status:', txt || statusRes.statusText);
        } else {
          console.log('Overall status updated to Onboarded');
        }
      } catch (err) {
        console.error('Error updating overall status:', err);
      }

      alert(`Data ${isEditMode ? 'updated' : 'saved'} successfully!`);
      console.log(response.data);
      if (isEditMode && onClose) {
        onClose();
      } else {
        navigate(-1);
      }
    } catch (error) {
      console.error(`Error ${isEditMode ? 'updating' : 'submitting'} form:`, error.response || error);
      const errorMsg = error.response?.data?.message || error.message || 'Unknown error occurred.';
      alert(`Failed to ${isEditMode ? 'update' : 'save'} data: ${errorMsg}`);
    }
  };

  return (
  <>
      <Header />

      <div className="bg-gray-100 min-h-screen pt-24">
      <div className="max-w-6xl mx-auto p-4 sm:p-6 lg:p-8 text-xs">
        <div className="space-y-6">

          <div className="bg-white rounded-xl border border-gray-200 shadow-sm px-6 py-5 flex items-center justify-between flex-wrap gap-3">
            <div>
              <h1 className="text-xl font-bold text-gray-800">{isEditMode ? "Edit Employee Onboarding Form" : "Employee Onboarding Form"}</h1>
              <p className="mt-1 text-gray-500">Please fill in the details below to {isEditMode ? "update employee details" : "add a new employee"}.</p>
            </div>
            <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-indigo-50 text-indigo-700 text-[11px] font-semibold border border-indigo-200">
              {isEditMode ? "Editing Record" : "New Onboarding"}
            </span>
          </div>

          {/* Card 1: Basic Information */}
          <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm hover:shadow-md transition-shadow duration-200">
            <h2 className="text-[15px] font-semibold text-indigo-800 border-b-2 border-indigo-100 pb-3 mb-5 flex items-center gap-2"><span className="flex items-center justify-center h-6 w-6 rounded-md bg-indigo-50 text-indigo-700 text-xs font-bold">1</span>Basic Information</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-6 gap-y-5">
              <FormRow label="Emp Onboarding Ref number" required>
                <input type="text" name="empOnboardingRefNum" className="input-field" value={formData.empOnboardingRefNum} onChange={handleChange} />
              </FormRow>
              <FormRow label="Date of Joining" required>
                <input type="date" name="dateOfJoining" className="input-field" value={formData.dateOfJoining} onChange={handleChange} />
              </FormRow>
              <FormRow label="Status" required>
                <select name="status" className="input-field" value={formData.status} onChange={handleChange}>
                  <option value="Probation">Probation</option>
                  <option value="Confirmed">Confirmed</option>
                  <option value="Contract">Contract</option>
                </select>
              </FormRow>
              <FormRow label="Employee Full Name" required>
                <input
                  type="text"
                  name="fullName"
                  className={candidateData?.personal?.firstName ? "input-field-disabled" : "input-field"}
                  value={candidateData?.personal?.firstName ? [candidateData.personal.firstName, candidateData.personal.middleName, candidateData.personal.lastName].filter(Boolean).join(' ') : formData.fullName}
                  disabled={!!candidateData?.personal?.firstName}
                  onChange={handleChange}
                />
              </FormRow>
              <FormRow label="Date of Birth" required>
                <input
                  type="date"
                  name="dateOfBirth"
                  className={candidateData?.personal?.dob ? "input-field-disabled" : "input-field"}
                  value={candidateData?.personal?.dob || formData.dateOfBirth}
                  disabled={!!candidateData?.personal?.dob}
                  onChange={handleChange}
                />
              </FormRow>
              <FormRow label="Gender" required>
                <select
                  name="gender"
                  value={candidateData?.personal?.gender || formData.gender}
                  onChange={handleChange}
                  className={candidateData?.personal?.gender ? "input-field-disabled" : "input-field"}
                  disabled={!!candidateData?.personal?.gender}
                >
                  <option value="">Select Gender</option>
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                  <option value="Other">Other</option>
                </select>
              </FormRow>
              <FormRow label="Reporting Manager Name" required>
                <input type="text" name="rptManagerName" className="input-field" value={formData.rptManagerName} onChange={handleChange} />
              </FormRow>
              <FormRow label="Reporting Manager Code" required>
                <input type="text" name="rptMgrEmployeeCode" className="input-field" value={formData.rptMgrEmployeeCode} onChange={handleChange} />
              </FormRow>
              <FormRow label="Reporting Manager Email" required>
                <input type="email" name="rptManagerEmailId" className="input-field" value={formData.rptManagerEmailId} onChange={handleChange} />
              </FormRow>

              <div className="md:col-span-2 lg:col-span-3 pt-2">
                <label className="flex items-center gap-3 bg-gray-50 border border-gray-200 rounded-lg px-4 py-3 w-fit cursor-pointer">
                  <input type="checkbox" name="isProbationApplicable" className="h-4 w-4 rounded border-gray-300 text-indigo-700 focus:ring-indigo-600" checked={formData.isProbationApplicable} onChange={handleProbationChange} />
                  <span className="text-gray-700">Is probation Applicable? <span className="font-semibold text-indigo-700">{formData.isProbationApplicable ? "Yes" : "No"}</span></span>
                </label>
              </div>

              {formData.isProbationApplicable && (
                <>
                  <FormRow label="Probation Start Date" required>
                    <input type="date" name="probationStartDate" className="input-field" value={formData.probationStartDate} onChange={handleChange} />
                  </FormRow>
                  <FormRow label="Probation Period (e.g., 3 months)" required>
                    <input type="text" name="probationPeriodDuration" className="input-field" value={formData.probationPeriodDuration} onChange={handleChange} placeholder="e.g., 3 months" />
                  </FormRow>
                  <FormRow label="Confirmation End Date" required>
                    <input type="date" name="confirmationDate" className="input-field" value={formData.confirmationDate} onChange={handleChange} />
                  </FormRow>
                  <FormRow label="Max Probation Extension" required>
                    <input type="number" name="maxProbationExtension" placeholder="e.g., 2 times" className="input-field" value={formData.maxProbationExtension} onChange={handleChange} />
                  </FormRow>
                </>
              )}
            </div>
          </div>

          {/* Card 3: Personal Details */}
          <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm hover:shadow-md transition-shadow duration-200">
            <h2 className="text-[15px] font-semibold text-indigo-800 border-b-2 border-indigo-100 pb-3 mb-5 flex items-center gap-2"><span className="flex items-center justify-center h-6 w-6 rounded-md bg-indigo-50 text-indigo-700 text-xs font-bold">2</span>Personal Details</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-6 gap-y-5">
              <FormRow label="Primary Contact">
                <input
                  type="text"
                  name="primaryContactNo"
                  className={candidateData?.personal?.permContactNum ? "input-field-disabled" : "input-field"}
                  value={candidateData?.personal?.permContactNum || formData.primaryContactNo}
                  disabled={!!candidateData?.personal?.permContactNum}
                  onChange={handleChange}
                />
              </FormRow>
              <FormRow label="Secondary Contact">
                <input
                  type="text"
                  name="secondaryContactNo"
                  className={candidateData?.personal?.curContactNum ? "input-field-disabled" : "input-field"}
                  value={candidateData?.personal?.curContactNum || formData.secondaryContactNo}
                  disabled={!!candidateData?.personal?.curContactNum}
                  onChange={handleChange}
                />
              </FormRow>
              <FormRow label="Emergency Contact">
                <input
                  type="text"
                  name="emergencyContact"
                  className={candidateData?.personal?.emrContactNum ? "input-field-disabled" : "input-field"}
                  value={candidateData?.personal?.emrContactNum || formData.emergencyContact}
                  disabled={!!candidateData?.personal?.emrContactNum}
                  onChange={handleChange}
                />
              </FormRow>
              <FormRow label="Personal Email">
                <input
                  type="email"
                  name="personalEmail"
                  className={candidateData?.personal?.emailAddr ? "input-field-disabled" : "input-field"}
                  value={candidateData?.personal?.emailAddr || formData.personalEmail}
                  disabled={!!candidateData?.personal?.emailAddr}
                  onChange={handleChange}
                />
              </FormRow>
              <FormRow label="Marital Status">
                <input
                  type="text"
                  name="maritalStatus"
                  className={candidateData?.personal?.maritalStatus ? "input-field-disabled" : "input-field"}
                  value={candidateData?.personal?.maritalStatus || formData.maritalStatus}
                  disabled={!!candidateData?.personal?.maritalStatus}
                  onChange={handleChange}
                />
              </FormRow>
              <FormRow label="Blood Group">
                <input
                  type="text"
                  name="bloodGroup"
                  className={candidateData?.personal?.bloodGroup ? "input-field-disabled" : "input-field"}
                  value={candidateData?.personal?.bloodGroup || formData.bloodGroup}
                  disabled={!!candidateData?.personal?.bloodGroup}
                  onChange={handleChange}
                />
              </FormRow>
            </div>
          </div>

          {/* Card 4: Statutory & Financial Details */}
          <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm hover:shadow-md transition-shadow duration-200">
            <h2 className="text-[15px] font-semibold text-indigo-800 border-b-2 border-indigo-100 pb-3 mb-5 flex items-center gap-2"><span className="flex items-center justify-center h-6 w-6 rounded-md bg-indigo-50 text-indigo-700 text-xs font-bold">3</span>Statutory & Financial Details</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-6 gap-y-5">
              <FormRow label="Aadhar No">
                <input
                  type="text"
                  name="aadharNumber"
                  className={candidateData?.documentProof?.aadharCard ? "input-field-disabled" : "input-field"}
                  value={candidateData?.documentProof?.aadharCard || formData.aadharNumber}
                  disabled={!!candidateData?.documentProof?.aadharCard}
                  onChange={handleChange}
                />
              </FormRow>
              <FormRow label="PAN No">
                <input
                  type="text"
                  name="panNumber"
                  className={candidateData?.documentProof?.panCard ? "input-field-disabled" : "input-field"}
                  value={candidateData?.documentProof?.panCard || formData.panNumber}
                  disabled={!!candidateData?.documentProof?.panCard}
                  onChange={handleChange}
                />
              </FormRow>
              <FormRow label="Full Name as per PAN" required>
                <input type="text" name="fullNameAsPerPAN" className="input-field" value={formData.fullNameAsPerPAN} onChange={handleChange} />
              </FormRow>
              <FormRow label="UAN Number">
                <input
                  type="text"
                  name="uanNumber"
                  className={candidateData?.pf?.uan ? "input-field-disabled" : "input-field"}
                  value={candidateData?.pf?.uan || formData.uanNumber}
                  disabled={!!candidateData?.pf?.uan}
                  onChange={handleChange}
                />
              </FormRow>
              <FormRow label="Current PF Number" required>
                <input type="text" name="currentPfNumber" className="input-field" value={formData.currentPfNumber} onChange={handleChange} />
              </FormRow>
              <FormRow label="Current ESIC Number" required>
                <input type="text" name="currentESICNumber" className="input-field" value={formData.currentESICNumber} onChange={handleChange} />
              </FormRow>
            </div>
          </div>

          {/* Card 5: Organization & Structure Details */}
          <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm hover:shadow-md transition-shadow duration-200">
            <h2 className="text-[15px] font-semibold text-indigo-800 border-b-2 border-indigo-100 pb-3 mb-5 flex items-center gap-2"><span className="flex items-center justify-center h-6 w-6 rounded-md bg-indigo-50 text-indigo-700 text-xs font-bold">4</span>Organization & Structure Details</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-6 gap-y-5">
              <FormRow label="Employment Status" required>
                <input type="text" name="employmentStatus" className="input-field" value={formData.employmentStatus} onChange={handleChange} />
              </FormRow>
              <FormRow label="Employee Code" required>
                <input type="text" name="empCode" className="input-field" value={formData.empCode} onChange={handleChange} />
              </FormRow>
              <FormRow label="Payroll Area Type" required>
                <input type="text" name="payrollAreaType" className="input-field" value={formData.payrollAreaType} onChange={handleChange} />
              </FormRow>
              <FormRow label="BU Head" required>
                <input type="text" name="buHead" className="input-field" value={formData.buHead} onChange={handleChange} />
              </FormRow>
              <FormRow label="BU Head ECode">
                <input type="text" name="buHeadECode" className="input-field" value={formData.buHeadECode} onChange={handleChange} />
              </FormRow>
              <FormRow label="BU Head Name">
                <input type="text" name="buHeadName" className="input-field" value={formData.buHeadName} onChange={handleChange} />
              </FormRow>
              <FormRow label="BU Head Email">
                <input type="email" name="buHeadEmail" className="input-field" value={formData.buHeadEmail} onChange={handleChange} />
              </FormRow>
              <FormRow label="Project" required>
                <input type="text" name="project" className="input-field" value={formData.project} onChange={handleChange} />
              </FormRow>
              <FormRow label="Organisation Code" required>
                <input type="text" name="organisationCode" className="input-field" value={formData.organisationCode} onChange={handleChange} />
              </FormRow>
              <FormRow label="Organisation Hierarchy" required>
                <input type="text" name="organisationHierarchy" className="input-field" value={formData.organisationHierarchy} onChange={handleChange} />
              </FormRow>
              <FormRow label="EE Subgroup">
                <input type="text" name="eeSubgroup" className="input-field" value={formData.eeSubgroup} onChange={handleChange} />
              </FormRow>
              <FormRow label="EE Subgroup Name">
                <input type="text" name="eeSubGrpName" className="input-field" value={formData.eeSubGrpName} onChange={handleChange} />
              </FormRow>
            </div>
          </div>

          {/* Card 6: Work Details */}
          <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm hover:shadow-md transition-shadow duration-200">
            <h2 className="text-[15px] font-semibold text-indigo-800 border-b-2 border-indigo-100 pb-3 mb-5 flex items-center gap-2"><span className="flex items-center justify-center h-6 w-6 rounded-md bg-indigo-50 text-indigo-700 text-xs font-bold">5</span>Work Details</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-6 gap-y-5">
              <FormRow label="Designation" required>
                <input type="text" name="designation" className="input-field" value={formData.designation} onChange={handleChange} />
              </FormRow>
              <FormRow label="Role" required>
                <Select options={["Select a role", ...roles]} value={selectedRole} onChange={(e) => setSelectedRole(e.target.value)} />
              </FormRow>
              <FormRow label="Location" required>
                <Select options={locations.map(loc => loc.locationName)} value={selectedLocation} onChange={(e) => setSelectedLocation(e.target.value)} />
              </FormRow>
              <FormRow label="Main Department" required>
                <input type="text" name="mainDepartment" className="input-field" value={formData.mainDepartment} onChange={handleChange} />
              </FormRow>
              <FormRow label="Sub Department" required>
                <input type="text" name="subDepartment" className="input-field" value={formData.subDepartment} onChange={handleChange} />
              </FormRow>
              <FormRow label="Grade" required>
                <input type="text" name="grade" className="input-field" value={formData.grade} onChange={handleChange} />
              </FormRow>
              <FormRow label="Hiring HR" required>
                <input type="text" name="hiringHr" className="input-field" value={formData.hiringHr} onChange={handleChange} />
              </FormRow>

              <FormRow label="Total Experience">
                <input
                  type="text"
                  name="totalExp"
                  className={candidateData?.profExp?.totalExp ? "input-field-disabled" : "input-field"}
                  value={candidateData?.profExp?.totalExp || formData.totalExp}
                  disabled={!!candidateData?.profExp?.totalExp}
                  onChange={handleChange}
                />
              </FormRow>
              <FormRow label="Previous Company">
                <input
                  type="text"
                  name="previousCompany"
                  className={candidateData?.profExp?.company1 ? "input-field-disabled" : "input-field"}
                  value={candidateData?.profExp?.company1 || formData.previousCompany}
                  disabled={!!candidateData?.profExp?.company1}
                  onChange={handleChange}
                />
              </FormRow>
              <FormRow label="From Date">
                <input
                  type="date"
                  name="previousCompanyFrom"
                  className={candidateData?.profExp?.fromDate1 ? "input-field-disabled" : "input-field"}
                  value={candidateData?.profExp?.fromDate1 || formData.previousCompanyFrom}
                  disabled={!!candidateData?.profExp?.fromDate1}
                  onChange={handleChange}
                />
              </FormRow>
              <FormRow label="To Date">
                <input
                  type="date"
                  name="previousCompanyTo"
                  className={candidateData?.profExp?.toDate1 ? "input-field-disabled" : "input-field"}
                  value={candidateData?.profExp?.toDate1 || formData.previousCompanyTo}
                  disabled={!!candidateData?.profExp?.toDate1}
                  onChange={handleChange}
                />
              </FormRow>

              <FormRow label="Primary Skill Name">
                <input
                  type="text"
                  name="primarySkillName"
                  className={candidateData?.skill?.primarySkill1Name ? "input-field-disabled" : "input-field"}
                  value={candidateData?.skill?.primarySkill1Name ? ([candidateData.skill.primarySkill1Name, candidateData.skill.primarySkill2Name, candidateData.skill.primarySkill3Name].filter(Boolean).join(', ')) : formData.primarySkillName}
                  disabled={!!candidateData?.skill?.primarySkill1Name}
                  onChange={handleChange}
                />
              </FormRow>
              <FormRow label="Primary Skills level">
                <input
                  type="text"
                  name="primarySkillLevel"
                  className={candidateData?.skill?.primarySkill1Level ? "input-field-disabled" : "input-field"}
                  value={candidateData?.skill?.primarySkill1Level ? ([candidateData.skill.primarySkill1Level, candidateData.skill.primarySkill2Level, candidateData.skill.primarySkill3Level].filter(Boolean).join(', ')) : formData.primarySkillLevel}
                  disabled={!!candidateData?.skill?.primarySkill1Level}
                  onChange={handleChange}
                />
              </FormRow>
              <FormRow label="Secondary Skill Name">
                <input
                  type="text"
                  name="secondarySkillName"
                  className={candidateData?.skill?.secondarySkill1Name ? "input-field-disabled" : "input-field"}
                  value={candidateData?.skill?.secondarySkill1Name ? ([candidateData.skill.secondarySkill1Name, candidateData.skill.secondarySkill2Name, candidateData.skill.secondarySkill3Name].filter(Boolean).join(', ')) : formData.secondarySkillName}
                  disabled={!!candidateData?.skill?.secondarySkill1Name}
                  onChange={handleChange}
                />
              </FormRow>
              <FormRow label="Secondary Skill Level">
                <input
                  type="text"
                  name="secondarySkillLevel"
                  className={candidateData?.skill?.secondarySkill1Level ? "input-field-disabled" : "input-field"}
                  value={candidateData?.skill?.secondarySkill1Level ? ([candidateData.skill.secondarySkill1Level, candidateData.skill.secondarySkill2Level, candidateData.skill.secondarySkill3Level].filter(Boolean).join(', ')) : formData.secondarySkillLevel}
                  disabled={!!candidateData?.skill?.secondarySkill1Level}
                  onChange={handleChange}
                />
              </FormRow>
            </div>
          </div>

          {/* Card 7: Bank & Official Details */}
          <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm hover:shadow-md transition-shadow duration-200">
            <h2 className="text-[15px] font-semibold text-indigo-800 border-b-2 border-indigo-100 pb-3 mb-5 flex items-center gap-2"><span className="flex items-center justify-center h-6 w-6 rounded-md bg-indigo-50 text-indigo-700 text-xs font-bold">6</span>Bank & Official Details</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-6 gap-y-5">
              <FormRow label="Official Email ID">
                <input type="email" name="officialEmailId" className="input-field" value={formData.officialEmailId} onChange={handleChange} />
              </FormRow>
              <FormRow label="Bank Name">
                <input type="text" name="bankName" className="input-field" value={formData.bankName} onChange={handleChange} />
              </FormRow>
              <FormRow label="Salary Account Number">
                <input type="text" name="salaryAccountNumber" className="input-field" value={formData.salaryAccountNumber} onChange={handleChange} />
              </FormRow>
              <FormRow label="IFSC Code">
                <input type="text" name="ifscCode" className="input-field" value={formData.ifscCode} onChange={handleChange} />
              </FormRow>
              <FormRow label="Name as per Bank">
                <input type="text" name="nameOnSalaryAccount" className="input-field" value={formData.nameOnSalaryAccount} onChange={handleChange} />
              </FormRow>
            </div>
          </div>

          {/* Card 8: Family & Nominee */}
          <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm hover:shadow-md transition-shadow duration-200">
            <h2 className="text-[15px] font-semibold text-indigo-800 border-b-2 border-indigo-100 pb-3 mb-5 flex items-center gap-2"><span className="flex items-center justify-center h-6 w-6 rounded-md bg-indigo-50 text-indigo-700 text-xs font-bold">7</span>Family & Nominee</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-6 gap-y-5">
              <FormRow label="Nominee Name 1 (Mandatory)" required>
                <input type="text" name="nomineeName1" className="input-field" value={formData.nomineeName1} onChange={handleChange} />
              </FormRow>
              <FormRow label="Dependent Name">
                <input type="text" name="dependentName" className="input-field" value={formData.dependentName} onChange={handleChange} />
              </FormRow>
              <FormRow label="Dependent Relation">
                <input type="text" name="dependentRelationship" className="input-field" value={formData.dependentRelationship} onChange={handleChange} />
              </FormRow>
              <FormRow label="Dependent DOB">
                <input type="date" name="dependentDOB" className="input-field" value={formData.dependentDOB} onChange={handleChange} />
              </FormRow>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-wrap items-center justify-end gap-3 bg-white rounded-xl border border-gray-200 shadow-sm px-6 py-4">
            <button
              type="button"
              className="px-5 py-2.5 rounded-lg bg-white border border-gray-300 text-gray-700 font-medium hover:bg-gray-50 transition"
              onClick={isEditMode ? onClose : () => navigate(-1)}
            >
              ← {isEditMode ? "Cancel" : "Back"}
            </button>
            <button
              type="button"
              className="px-5 py-2.5 rounded-lg bg-indigo-700 text-white font-medium hover:bg-indigo-800 shadow-sm transition"
              onClick={onSubmit}
            >
              {isEditMode ? "Update Employee" : "Save Employee"}
            </button>
          </div>
        </div>
      </div>

      {/* Professional input styling overrides */}
      <style>{`
        .input-field {
          width: 100%;
          border: 1px solid #93c5fd;
          border-radius: 0.5rem;
          padding: 0.55rem 0.75rem;
          font-size: 0.8rem;
          color: #1e3a8a;
          background-color: #eff6ff;
          transition: border-color 0.15s ease, box-shadow 0.15s ease, background-color 0.15s ease;
        }
        .input-field::placeholder {
          color: #93a5c4;
        }
        .input-field:hover {
          border-color: #60a5fa;
        }
        .input-field:focus {
          outline: none;
          border-color: #1d4ed8;
          background-color: #ffffff;
          box-shadow: 0 0 0 3px rgba(29, 78, 216, 0.15);
        }
        .input-field-disabled {
          width: 100%;
          border: 1px solid #93c5fd;
          border-radius: 0.5rem;
          padding: 0.55rem 0.75rem;
          font-size: 0.8rem;
          color: #1e40af;
          background-color: #eff6ff;
          cursor: not-allowed;
        }
      `}</style>
      </div>
    </>
  );
};

// Helper components
const FormRow = ({ label, required, children, className }) => (
  <div className={`flex flex-col gap-1 ${className}`}>
    <label className="font-medium text-gray-800">
      {label}
      {required && <span className="text-red-600 ml-1">*</span>}
    </label>
    <div className="w-full">{children}</div>
  </div>
);

const Select = ({ options = [], value, onChange }) => (
  <select className="input-field" value={value} onChange={onChange}>
    {options.map((opt, i) =>
      typeof opt === "string" ? (
        <option key={i} value={opt}>{opt}</option>
      ) : (
        <option key={opt.id} value={opt.id}>{opt.name}</option>
      )
    )}
  </select>
);

export default AddEmployee;