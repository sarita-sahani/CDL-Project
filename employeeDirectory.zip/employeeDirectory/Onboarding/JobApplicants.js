// JobApplicants.js (Updated for robust default selection)
import React, { useEffect, useState, useMemo } from "react";
import { FaSearch, FaFilter, FaEye, FaDownload, FaFilePdf } from 'react-icons/fa';
import { MdOutlineEmail, MdPhone, MdClose } from 'react-icons/md';
import {BASE_URL} from "../config";
// Helper function for date sorting
const getDateForSorting = (dateString) => {
    if (!dateString) return new Date(0);
    const date = new Date(dateString);
    return isNaN(date.getTime()) ? new Date(0) : date; 
};

// Buckets an applicant's raw JOB_APP_STAGE/JOB_APP_STATUS into one of the 6 filter
// buckets: Initial, Screening, Interview, Final, Offer, Joining.
// Instead of matching against exact hardcoded stage constants, this looks for
// keywords in the combined stage + status text - so it keeps working regardless
// of the exact literal format the backend sends (e.g. '@JobAppl_STG_Offer' vs
// 'Offer' vs 'Offer-InProgress'). All of the many Offer-* sub-statuses
// (Offer-Approval, Offer-To be Created, Offer-InProgress, Offer-Accepted,
// Offer-Declined, etc.) collapse into a single "Offer" bucket - we only care
// that the applicant has reached the Offer stage.
export const getApplicantBucket = (applicant) => {
    const text = `${applicant.JOB_APP_STAGE || ''} ${applicant.JOB_APP_STATUS || ''}`.toLowerCase();

    // Joining stage - joined / hired / completed onboarding
    if (text.includes('joining') || text.includes('joined') || text.includes('hired') || text.includes('completed')) {
        return 'Joining';
    }

    // Offer stage - assume offer only, regardless of which Offer-* sub-status
    if (text.includes('offer')) {
        return 'Offer';
    }

    // Final round - checked before the generic "interview" keyword so a
    // "Final Interview" style status still lands in the Final bucket.
    if (text.includes('final')) {
        return 'Final';
    }

    // Any interview round (L1-L4, HR, Mgmt)
    if (text.includes('interview') || /\bl[1-4]\b/.test(text)) {
        return 'Interview';
    }

    // Screening
    if (text.includes('screening') || text.includes('screen')) {
        return 'Screening';
    }

    // Initial / Applied
    if (text.includes('initial') || text.includes('applied')) {
        return 'Initial';
    }

    return 'Initial';
};

// Maps the raw JOB_APP_STATUS value to a color scheme for the status badge shown
// on each candidate card, and anywhere else a status pill is rendered (imported
// into CandidateDetails.js too, so both pages color the exact same status the
// exact same way).
//
// Color meaning:
//   gray   -> not started / queued
//   blue   -> actively in progress (scheduled, applied, discussion, pending action)
//   amber  -> needs attention / awaiting a decision (feedback pending, approval pending)
//   orange -> on hold
//   green  -> positive / completed outcome
//   red    -> rejected, declined, revoked, cancelled, aborted, blocked, closed
export const STATUS_COLOR_STYLES = {
    gray:   { bg: 'bg-gray-100',   text: 'text-gray-700',   border: 'border-gray-200' },
    blue:   { bg: 'bg-blue-100',   text: 'text-blue-700',   border: 'border-blue-200' },
    amber:  { bg: 'bg-amber-100',  text: 'text-amber-700',  border: 'border-amber-200' },
    orange: { bg: 'bg-orange-100', text: 'text-orange-700', border: 'border-orange-200' },
    green:  { bg: 'bg-green-100',  text: 'text-green-700',  border: 'border-green-200' },
    red:    { bg: 'bg-red-100',    text: 'text-red-700',    border: 'border-red-200' },
    slate:  { bg: 'bg-slate-100',  text: 'text-slate-700',  border: 'border-slate-200' },
};

// Every interview round (L1, L2, L3, L4, HR, Mgmt) shares the same 8 sub-statuses,
// just with a different suffix - build those entries once instead of repeating them
// six times.
const buildInterviewRoundStatuses = (suffix) => ({
    [`to be scheduled-${suffix}`]: 'gray',
    [`scheduled-${suffix}`]: 'blue',
    [`completed-${suffix}`]: 'blue',
    [`feedback pending-${suffix}`]: 'amber',
    [`selected-${suffix}`]: 'green',
    [`rejected-${suffix}`]: 'red',
    [`cancelled-${suffix}`]: 'red',
    [`abort-${suffix}`]: 'red',
});

// Exact-match table for every sub-status defined in the ItemList.JobAppl_STG_* config.
// Keys are lowercased/trimmed status text; values are keys into STATUS_COLOR_STYLES.
export const EXACT_STATUS_COLOR_MAP = {
    // JobAppl_STG_Initial
    'applied': 'blue',
    'open': 'gray',
    'hold': 'orange',

    // JobAppl_STG_Screening
    'to screen': 'gray',
    'screen done': 'blue',
    'shortlisted': 'green',
    'rejected-screen': 'red',
    'needinfo-screen': 'amber',

    // JobAppl_STG_L1_Interview / L2 / L3 / L4 / HR / Mgmt
    ...buildInterviewRoundStatuses('l1'),
    ...buildInterviewRoundStatuses('l2'),
    ...buildInterviewRoundStatuses('l3'),
    ...buildInterviewRoundStatuses('l4'),
    ...buildInterviewRoundStatuses('hr'),
    ...buildInterviewRoundStatuses('mgmt'),

    // JobAppl_STG_Final
    'selected': 'green',
    'rejected': 'red',
    'closed': 'red',
    'cancelled': 'red',
    'abort': 'red',
    'blocked': 'red',

    // JobAppl_STG_Offer
    'group-approval': 'amber',
    'group-approval-done': 'green',
    'group-approval-reject': 'red',
    'group-approval-hold': 'orange',
    'offer-approval': 'amber',
    'offer-approval-done': 'green',
    'offer-approval-reject': 'red',
    'offer-approval-hold': 'orange',
    'offer-to be created': 'gray',
    'offer-inprogress': 'blue',
    'offer-completed': 'green',
    'offer-draft': 'gray',
    'offer-finalized': 'green',
    'offered': 'green',
    'offer-accepted': 'green',
    'offer-discussion': 'blue',
    'offer-declined': 'red',
    'offer-revoked': 'red',
    'offer-onhold': 'orange',

    // JobAppl_STG_Joining
    'onb-to be initiated': 'gray',
    'onb-pending-candidate': 'blue',
    'onb-pending-hr': 'blue',
    'onb-completed-hr': 'green',
    'onb-cancelled': 'red',
    'join-planned': 'green',
    'joined': 'green',
    'join-abort': 'red',
};

// Keyword fallback for anything not in the exact map above (older data, free-text
// remarks, or values outside the configured stage list). Checked in order - most
// decisive/terminal keywords first - so e.g. "Rejected-XYZ" always reads red even
// if XYZ is a status this list has never seen.
const KEYWORD_STATUS_COLOR_RULES = [
    { color: 'red', keywords: ['reject', 'declin', 'revok', 'cancel', 'abort', 'blocked', 'closed'] },
    { color: 'orange', keywords: ['hold'] },
    { color: 'amber', keywords: ['needinfo', 'feedback pending', 'approval'] },
    { color: 'green', keywords: ['selected', 'shortlist', 'accepted', 'finalized', 'completed', 'done', 'joined', 'offered'] },
    { color: 'gray', keywords: ['to be scheduled', 'to be created', 'to be initiated', 'draft', 'to screen', 'open'] },
    { color: 'blue', keywords: ['scheduled', 'inprogress', 'in progress', 'discussion', 'applied', 'pending'] },
];

const getStatusColorKey = (status) => {
    const text = (status || '').trim().toLowerCase();
    if (!text) return 'gray';

    if (EXACT_STATUS_COLOR_MAP[text]) return EXACT_STATUS_COLOR_MAP[text];

    for (const rule of KEYWORD_STATUS_COLOR_RULES) {
        if (rule.keywords.some(k => text.includes(k))) return rule.color;
    }

    return 'slate';
};

export const getStatusBadgeStyle = (status) => STATUS_COLOR_STYLES[getStatusColorKey(status)];

const JobApplicants = ({ selectedJobId, onCandidateSelect }) => {
    const [allApplicants, setAllApplicants] = useState([]);
    const [loading, setLoading] = useState(false);
    const [searchTerm, setSearchTerm] = useState("");
    const [selectedCandidateJobAppID, setSelectedCandidateJobAppID] = useState(null);
    const [hasAutoSelected, setHasAutoSelected] = useState(false); // Track if we've auto-selected for this job
    const [activeFilter, setActiveFilter] = useState("All"); // Track active filter
    const [selectedApplicant, setSelectedApplicant] = useState(null); // Track modal state
    
    useEffect(() => {
        const fetchApplicants = async () => {
            // Only fetch if we actually have a jobId
            if (!selectedJobId) {
                setAllApplicants([]);
                setSelectedCandidateJobAppID(null);
                setHasAutoSelected(false);
                return;
            }

            setLoading(true);
            try {
                // Fetching specifically for the selected JOB_ID
                const response = await fetch(`${BASE_URL}:9034/api/display/fetch/jobApplication/data/${selectedJobId}`);
                const data = await response.json();
                
                const fetchedApplicants = Array.isArray(data) ? data : [];
                setAllApplicants(fetchedApplicants);

                // Auto-select the first applicant only once per job selection
                if (fetchedApplicants.length > 0 && onCandidateSelect && !hasAutoSelected) {
                    const firstApplicantId = fetchedApplicants[0].JOB_APP_ID;
                    onCandidateSelect(firstApplicantId, fetchedApplicants[0].JOB_APP_STATUS);
                    setSelectedCandidateJobAppID(firstApplicantId);
                    setHasAutoSelected(true);
                }
            } catch (error) {
                console.error("Failed to load job applicants", error);
                setAllApplicants([]);
            } finally {
                setLoading(false);
            }
        };

        fetchApplicants();
    }, [selectedJobId]);
    // 2. Filter, Sort, and Calculate Default Candidate ID
    const { applicantsToDisplay, defaultJobAppID } = useMemo(() => {
        let list = [];
        let defaultId = null;
        const term = searchTerm.toLowerCase();

        // Step A: Filter by selected Job ID
        if (selectedJobId) {
            list = allApplicants.filter(applicant => 
                applicant.JOB_ID === selectedJobId
            );
        } else {
            // If no job is selected (should only happen briefly on initial load), use all
            list = allApplicants;
        }
        
        // Step B: Filter by Search Term - by NAME ONLY (for this step)
        if (term) {
             list = list.filter(applicant => {
                const fullName = (applicant.CAND_FIRST_NAME + ' ' + applicant.CAND_LAST_NAME).toLowerCase();
                return fullName.includes(term);
             });
        }

        // Step C: Filter by Status Filter Button
        if (activeFilter !== "All") {
            list = list.filter(applicant => getApplicantBucket(applicant) === activeFilter);
        }

        // Step D: Sort by date descending (latest first)
        if (list.length > 0) {
            list.sort((a, b) => 
                getDateForSorting(b.JOB_APPL_DATE) - getDateForSorting(a.JOB_APPL_DATE)
            );
            
            // Set the default selected candidate (latest one)
            defaultId = list[0].JOB_APP_ID; 
        }

        return { applicantsToDisplay: list, defaultJobAppID: defaultId };
    }, [selectedJobId, allApplicants, searchTerm, activeFilter]); 

    // Handler for clicking a candidate card (manual selection)
    const handleCandidateClick = (applicant) => {
        const jobAppID = applicant.JOB_APP_ID;
        if (onCandidateSelect) {
            onCandidateSelect(jobAppID, applicant.JOB_APP_STATUS);
            setSelectedCandidateJobAppID(jobAppID);
        }
    };

    // Handler for viewing candidate details
    const handleViewApplicant = (e, applicant) => {
        e.stopPropagation();
        setSelectedApplicant(applicant);
    };

    // Handler for closing modal
    const closeModal = () => {
        setSelectedApplicant(null);
    };

    // Calculate counts for filter buttons based on JOB_APP_STATUS
    const getCandidateListByNameSearch = useMemo(() => {
        let list = [];
        const term = searchTerm.toLowerCase();

        // Filter by selected Job ID
        if (selectedJobId) {
            list = allApplicants.filter(applicant => 
                applicant.JOB_ID === selectedJobId
            );
        } else {
            list = allApplicants;
        }
        
        // Filter by Search Term - by NAME ONLY
        if (term) {
             list = list.filter(applicant => {
                const fullName = (applicant.CAND_FIRST_NAME + ' ' + applicant.CAND_LAST_NAME).toLowerCase();
                return fullName.includes(term);
             });
        }

        return list;
    }, [selectedJobId, allApplicants, searchTerm]);

    const allCount = getCandidateListByNameSearch.length;
    const initialCount = getCandidateListByNameSearch.filter(applicant => getApplicantBucket(applicant) === 'Initial').length;
    const screeningCount = getCandidateListByNameSearch.filter(applicant => getApplicantBucket(applicant) === 'Screening').length;
    const interviewCount = getCandidateListByNameSearch.filter(applicant => getApplicantBucket(applicant) === 'Interview').length;
    const finalCount = getCandidateListByNameSearch.filter(applicant => getApplicantBucket(applicant) === 'Final').length;
    const offerCount = getCandidateListByNameSearch.filter(applicant => getApplicantBucket(applicant) === 'Offer').length;
    const joiningCount = getCandidateListByNameSearch.filter(applicant => getApplicantBucket(applicant) === 'Joining').length;

    const filters = [
        { label: 'All', count: allCount, active: true },
        { label: 'Initial', count: initialCount, active: false },
        { label: 'Screening', count: screeningCount, active: false },
        { label: 'Interview', count: interviewCount, active: false },
        { label: 'Final', count: finalCount, active: false },
        { label: 'Offer', count: offerCount, active: false },
        { label: 'Joining', count: joiningCount, active: false },
    ];

    return (
        <div className="bg-white rounded-lg shadow h-full flex flex-col max-h-[800px] overflow-y-auto max-h-[calc(100vh-120px)]">
            {/* Header with Title and Total */}
            <div className="p-4 ">
                <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-2">
                    <h2 className="text-lg font-medium text-indigo-800">Job Applicants</h2>
                    <span className="text-2xl font-bold text-indigo-600">{applicantsToDisplay.length}</span>
                </div>
            </div>

            {/* Full-Width Search Bar */}
            <div className="p-4  ">
                <div className="relative">
                    <FaSearch className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                    <input
                        type="text"
                        placeholder="Start typing to search candidates"
                        className="w-full pl-10 pr-10 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        value={searchTerm} 
                        onChange={(e) => setSearchTerm(e.target.value)} 
                    />
                    <FaFilter className="absolute right-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400 cursor-pointer hover:text-indigo-600 transition-colors" />
                </div>
            </div>

            {/* Filter Buttons Row */}
            <div className="px-4 py-3  flex flex-nowrap overflow-x-auto space-x-px gap-0.5 scrollbar-thin scrollbar-thumb-gray-300 scrollbar-track-gray-100">
                {filters.map((filter, index) => (
                    <button
                        key={index}
                        onClick={() => setActiveFilter(filter.label)}
                        className={`px-3 py-1.5 rounded-md text-xs font-medium whitespace-nowrap flex items-center space-x-1 flex-shrink-0 ${activeFilter === filter.label 
                            ? 'bg-indigo-600 text-white shadow-sm'
                            : 'bg-white border border-gray-300 text-gray-700 hover:bg-gray-50'
                            }`}
                    >
                        <span>{filter.label}</span>
                        <span className={`font-bold ${activeFilter === filter.label ? 'text-white' : 'text-indigo-600'}`}>
                            {filter.count}
                        </span>
                    </button>
                ))}
            </div>

            {/* Applicants List */}
            <div className="flex-1 overflow-y-auto p-2 sm:p-4 space-y-3">
                {applicantsToDisplay.length > 0 ? applicantsToDisplay.map((applicant, index) => { 
                    const jobAppID = applicant.JOB_APP_ID;
                    const isActive = jobAppID === selectedCandidateJobAppID;
                    return (
                        <div 
                            key={index} 
                            onClick={() => handleCandidateClick(applicant)}
                            className={`
                                flex flex-col md:flex-row md:items-start gap-3 md:gap-0 p-3 border rounded-lg 
                                transition-all duration-200 cursor-pointer 
                                
                                ${isActive 
                                    ? 'border-indigo-600 bg-indigo-50 ring-1 ring-indigo-300 shadow-md' 
                                    : 'border-gray-200 bg-white hover:border-indigo-400 hover:bg-gray-50 hover:shadow-md'
                                }
                            `}
                        >
                            {/* Left Column: Profile and Contact Details */}
                            <div className="flex-1 w-full">
                                <div className="flex items-start space-x-3">
                                    <img
                                        src={`https://i.pravatar.cc/40?img=${jobAppID}`}
                                        alt={applicant.CAND_FIRST_NAME}
                                        className="w-10 h-10 rounded-full flex-shrink-0"
                                    />
                                    <div className="space-y-1 flex-1 min-w-0">
                                        <h3 className="font-semibold text-gray-900 text-sm truncate">{applicant.CAND_FIRST_NAME + ' ' + applicant.CAND_LAST_NAME}</h3>
                                        <div className="flex items-center text-xs text-gray-600">
                                            <MdOutlineEmail className="w-3 h-3 mr-1 flex-shrink-0" />
                                            <span className="truncate flex-1">{applicant.CAND_EMAIL_ID}</span>
                                        </div>
                                        <div className="flex items-center text-xs text-gray-600">
                                            <MdPhone className="w-3 h-3 mr-1 flex-shrink-0" />
                                            <span className="truncate">{applicant.CAND_MOBILE_NO}</span>
                                        </div>
                                        <p className="text-xs text-indigo-800">Ref: {applicant.REF_TYPE}</p>
                                    </div>
                                </div>
                            </div>

                            {/* Right Column: Status, Applied Date and View Icon */}
                            <div className="w-full md:w-auto mt-3 md:mt-0 flex flex-row md:flex-col items-start md:items-end justify-between md:justify-start gap-2 md:pl-3 py-1">
                                <div className="flex items-center gap-2">
                                    <button
                                        onClick={(e) => handleViewApplicant(e, applicant)}
                                        className="p-2 hover:bg-indigo-100 rounded-lg transition-colors"
                                        title="Applicants Details"
                                    >
                                        <FaEye className="text-indigo-600 w-4 h-4" />
                                    </button>
                                    <div className="md:p-2 p-1 flex items-center gap-1.5">
                                        <span className="text-xs font-medium text-indigo-800">Status:</span>
                                        {(() => {
                                            const statusStyle = getStatusBadgeStyle(applicant.JOB_APP_STATUS);
                                            return (
                                                <span className={`inline-block px-2 py-0.5 rounded-full text-xs font-medium border whitespace-nowrap ${statusStyle.bg} ${statusStyle.text} ${statusStyle.border}`}>
                                                    {applicant.JOB_APP_STATUS || 'N/A'}
                                                </span>
                                            );
                                        })()}
                                    </div>
                                </div>
                                <p className="text-xs text-gray-500 md:mt-2">Applied: {applicant.JOB_APPL_DATE}</p>
                            </div>
                        </div>
                    );
                }) : (
                    <div className="text-center text-gray-500 p-8 border border-dashed border-gray-300 rounded-lg">
                        <p>No applicants found matching your criteria.</p>
                        <p className="text-sm mt-1">Please select a job opening or adjust your search.</p>
                    </div>
                )}
            </div>

            {/* Applicant Details Modal */}
            {selectedApplicant && (
                <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
                    <div className="bg-white rounded-lg shadow-2xl max-w-3xl w-full max-h-[90vh] overflow-y-auto">
                        {/* Modal Header */}
                        <div className="sticky top-0 bg-indigo-600 text-white p-4 flex justify-between items-center">
                            <h2 className="text-xl font-bold">{selectedApplicant.CAND_FIRST_NAME} {selectedApplicant.CAND_LAST_NAME} - Details</h2>
                            <button
                                onClick={closeModal}
                                className="hover:bg-indigo-700 p-2 rounded-lg transition-colors"
                            >
                                <MdClose className="w-6 h-6" />
                            </button>
                        </div>

                        {/* Modal Body */}
                        <div className="p-6 space-y-6">
                            {/* Candidate Personal Info */}
                            <div>
                                <h3 className="text-lg font-semibold text-gray-900 mb-3 pb-2 border-b border-gray-200">Personal Information</h3>
                                <div className="grid grid-cols-2 gap-4">
                                    <div>
                                        <p className="text-xs text-gray-500 font-semibold uppercase">First Name</p>
                                        <p className="text-sm text-gray-900 font-medium">{selectedApplicant.CAND_FIRST_NAME}</p>
                                    </div>
                                    <div>
                                        <p className="text-xs text-gray-500 font-semibold uppercase">Last Name</p>
                                        <p className="text-sm text-gray-900 font-medium">{selectedApplicant.CAND_LAST_NAME}</p>
                                    </div>
                                    <div>
                                        <p className="text-xs text-gray-500 font-semibold uppercase">Date of Birth</p>
                                        <p className="text-sm text-gray-900 font-medium">{new Date(selectedApplicant.CAND_DOB).toLocaleDateString()}</p>
                                    </div>
                                    <div>
                                        <p className="text-xs text-gray-500 font-semibold uppercase">Address</p>
                                        <p className="text-sm text-gray-900 font-medium">{selectedApplicant.CAND_ADDRESS || 'N/A'}</p>
                                    </div>
                                </div>
                            </div>

                            {/* Contact Information */}
                            <div>
                                <h3 className="text-lg font-semibold text-gray-900 mb-3 pb-2 border-b border-gray-200">Contact Information</h3>
                                <div className="grid grid-cols-2 gap-4">
                                    <div>
                                        <p className="text-xs text-gray-500 font-semibold uppercase">Email</p>
                                        <p className="text-sm text-gray-900 font-medium break-all">{selectedApplicant.CAND_EMAIL_ID}</p>
                                    </div>
                                    <div>
                                        <p className="text-xs text-gray-500 font-semibold uppercase">Mobile Number</p>
                                        <p className="text-sm text-gray-900 font-medium">{selectedApplicant.CAND_MOBILE_NO}</p>
                                    </div>
                                    <div>
                                        <p className="text-xs text-gray-500 font-semibold uppercase">Referee Email</p>
                                        <p className="text-sm text-gray-900 font-medium break-all">{selectedApplicant.REF_EMAIL_ID || 'N/A'}</p>
                                    </div>
                                </div>
                            </div>

                            {/* Education & Qualification */}
                            <div>
                                <h3 className="text-lg font-semibold text-gray-900 mb-3 pb-2 border-b border-gray-200">Education</h3>
                                <div className="grid grid-cols-2 gap-4">
                                    <div>
                                        <p className="text-xs text-gray-500 font-semibold uppercase">Qualification</p>
                                        <p className="text-sm text-gray-900 font-medium">{selectedApplicant.CAND_QUALIFICATION || 'N/A'}</p>
                                    </div>
                                    <div>
                                        <p className="text-xs text-gray-500 font-semibold uppercase">Institute</p>
                                        <p className="text-sm text-gray-900 font-medium">{selectedApplicant.CAND_STUDY_INSTITUTE || 'N/A'}</p>
                                    </div>
                                </div>
                            </div>

                            {/* Experience & Skills */}
                            <div>
                                <h3 className="text-lg font-semibold text-gray-900 mb-3 pb-2 border-b border-gray-200">Experience & Skills</h3>
                                <div className="grid grid-cols-2 gap-4">
                                    <div>
                                        <p className="text-xs text-gray-500 font-semibold uppercase">Current Role</p>
                                        <p className="text-sm text-gray-900 font-medium">{selectedApplicant.CAND_CUR_ROLE || 'N/A'}</p>
                                    </div>
                                    <div>
                                        <p className="text-xs text-gray-500 font-semibold uppercase">Years of Experience</p>
                                        <p className="text-sm text-gray-900 font-medium">{selectedApplicant.CAND_EXP_YEAR || 0} years</p>
                                    </div>
                                    <div>
                                        <p className="text-xs text-gray-500 font-semibold uppercase">Applied Role</p>
                                        <p className="text-sm text-gray-900 font-medium">{selectedApplicant.CAND_ROLE_APPL || 'N/A'}</p>
                                    </div>
                                </div>
                                {selectedApplicant.CAND_EXP_DESC && (
                                    <div className="mt-4">
                                        <p className="text-xs text-gray-500 font-semibold uppercase mb-2">Experience Description</p>
                                        <p className="text-sm text-gray-700 whitespace-pre-wrap bg-gray-50 p-3 rounded">{selectedApplicant.CAND_EXP_DESC}</p>
                                    </div>
                                )}
                            </div>

                            {/* Salary Information */}
                            <div>
                                <h3 className="text-lg font-semibold text-gray-900 mb-3 pb-2 border-b border-gray-200">Salary Information</h3>
                                <div className="grid grid-cols-2 gap-4">
                                    <div className="bg-blue-50 p-3 rounded-lg">
                                        <p className="text-xs text-gray-500 font-semibold uppercase">Current Salary</p>
                                        <p className="text-lg font-bold text-blue-600">₹{selectedApplicant.SALARY_CUR}L</p>
                                    </div>
                                    <div className="bg-green-50 p-3 rounded-lg">
                                        <p className="text-xs text-gray-500 font-semibold uppercase">Expected Salary</p>
                                        <p className="text-lg font-bold text-green-600">₹{selectedApplicant.SALARY_EXP}L</p>
                                    </div>
                                </div>
                            </div>

                            {/* Location Preferences */}
                            <div>
                                <h3 className="text-lg font-semibold text-gray-900 mb-3 pb-2 border-b border-gray-200">Location Preferences</h3>
                                <div className="grid grid-cols-2 gap-4">
                                    <div>
                                        <p className="text-xs text-gray-500 font-semibold uppercase">Applied Location</p>
                                        <p className="text-sm text-gray-900 font-medium">{selectedApplicant.APP_JOB_LOCATIONS || 'N/A'}</p>
                                    </div>
                                    <div>
                                        <p className="text-xs text-gray-500 font-semibold uppercase">Preferred Location</p>
                                        <p className="text-sm text-gray-900 font-medium">{selectedApplicant.PREF_JOB_LOCATIONS || 'N/A'}</p>
                                    </div>
                                    <div>
                                        <p className="text-xs text-gray-500 font-semibold uppercase">Notice Period</p>
                                        <p className="text-sm text-gray-900 font-medium">{selectedApplicant.CAND_NOTICE_PERIOD || 0} days</p>
                                    </div>
                                    <div>
                                        <p className="text-xs text-gray-500 font-semibold uppercase">Last Working Date</p>
                                        <p className="text-sm text-gray-900 font-medium">{new Date(selectedApplicant.LAST_WORKING_DATE).toLocaleDateString()}</p>
                                    </div>
                                </div>
                            </div>

                            {/* Application Status & Screening */}
                            <div>
                                <h3 className="text-lg font-semibold text-gray-900 mb-3 pb-2 border-b border-gray-200">Application Status</h3>
                                <div className="grid grid-cols-2 gap-4">
                                    <div>
                                        <p className="text-xs text-gray-500 font-semibold uppercase">Application Stage</p>
                                        <p className="text-sm text-gray-900 font-medium">{selectedApplicant.JOB_APP_STAGE || 'N/A'}</p>
                                    </div>
                                    <div>
                                        <p className="text-xs text-gray-500 font-semibold uppercase mb-1">Application Status</p>
                                        {(() => {
                                            const statusStyle = getStatusBadgeStyle(selectedApplicant.JOB_APP_STATUS);
                                            return (
                                                <span className={`inline-block px-2 py-0.5 rounded-full text-xs font-medium border whitespace-nowrap ${statusStyle.bg} ${statusStyle.text} ${statusStyle.border}`}>
                                                    {selectedApplicant.JOB_APP_STATUS || 'N/A'}
                                                </span>
                                            );
                                        })()}
                                    </div>
                                    <div>
                                        <p className="text-xs text-gray-500 font-semibold uppercase">Screening ID</p>
                                        <p className="text-sm text-gray-900 font-medium">{selectedApplicant.ScreenID || 'N/A'}</p>
                                    </div>
                                    <div>
                                        <p className="text-xs text-gray-500 font-semibold uppercase">Screened By</p>
                                        <p className="text-sm text-gray-900 font-medium">{selectedApplicant.ScreenUserID || 'N/A'}</p>
                                    </div>
                                </div>
                            </div>

                            {/* Interview & HR Status */}
                            <div>
                                <h3 className="text-lg font-semibold text-gray-900 mb-3 pb-2 border-b border-gray-200">Interview & HR Status</h3>
                                <div className="grid grid-cols-2 gap-4">
                                    {[
                                        { label: 'L1 Status', value: selectedApplicant.L1_STATUS },
                                        { label: 'L2 Status', value: selectedApplicant.L2_STATUS },
                                        { label: 'L3 Status', value: selectedApplicant.L3_STATUS },
                                        { label: 'L4 Status', value: selectedApplicant.L4_STATUS },
                                        { label: 'HR Status', value: selectedApplicant.HR_STATUS },
                                        { label: 'Offer Status', value: selectedApplicant.OFFER_APP_STATUS },
                                    ].map(({ label, value }) => {
                                        const style = getStatusBadgeStyle(value);
                                        return (
                                            <div key={label}>
                                                <p className="text-xs text-gray-500 font-semibold uppercase mb-1">{label}</p>
                                                <span className={`inline-block px-2 py-0.5 rounded-full text-xs font-medium border whitespace-nowrap ${style.bg} ${style.text} ${style.border}`}>
                                                    {value || 'N/A'}
                                                </span>
                                            </div>
                                        );
                                    })}
                                </div>
                                {selectedApplicant.CommentsHR && (
                                    <div className="mt-4">
                                        <p className="text-xs text-gray-500 font-semibold uppercase mb-2">HR Comments</p>
                                        <p className="text-sm text-gray-700 bg-gray-50 p-3 rounded">{selectedApplicant.CommentsHR}</p>
                                    </div>
                                )}
                            </div>

                            {/* Timeline Information */}
                            <div>
                                <h3 className="text-lg font-semibold text-gray-900 mb-3 pb-2 border-b border-gray-200">Timeline</h3>
                                <div className="grid grid-cols-2 gap-4">
                                    <div>
                                        <p className="text-xs text-gray-500 font-semibold uppercase">Application Date</p>
                                        <p className="text-sm text-gray-900 font-medium">{new Date(selectedApplicant.JOB_APPL_DATE).toLocaleDateString()}</p>
                                    </div>
                                    <div>
                                        <p className="text-xs text-gray-500 font-semibold uppercase">Selected Date</p>
                                        <p className="text-sm text-gray-900 font-medium">{selectedApplicant.SELECTED_DATE ? new Date(selectedApplicant.SELECTED_DATE).toLocaleDateString() : 'N/A'}</p>
                                    </div>
                                    <div>
                                        <p className="text-xs text-gray-500 font-semibold uppercase">Offered Date</p>
                                        <p className="text-sm text-gray-900 font-medium">{selectedApplicant.OFFERED_DATE ? new Date(selectedApplicant.OFFERED_DATE).toLocaleDateString() : 'N/A'}</p>
                                    </div>
                                    <div>
                                        <p className="text-xs text-gray-500 font-semibold uppercase">Joined Date</p>
                                        <p className="text-sm text-gray-900 font-medium">{selectedApplicant.JOINED_DATE ? new Date(selectedApplicant.JOINED_DATE).toLocaleDateString() : 'N/A'}</p>
                                    </div>
                                    <div>
                                        <p className="text-xs text-gray-500 font-semibold uppercase">Selection SLA</p>
                                        <p className="text-sm text-gray-900 font-medium">{selectedApplicant.SELECTION_SLA || 0} days ({selectedApplicant.SELECTION_SLA_DESC || 'N/A'})</p>
                                    </div>
                                </div>
                            </div>

                            {/* Additional Information */}
                            <div>
                                <h3 className="text-lg font-semibold text-gray-900 mb-3 pb-2 border-b border-gray-200">Additional Information</h3>
                                <div className="grid grid-cols-2 gap-4">
                                    <div>
                                        <p className="text-xs text-gray-500 font-semibold uppercase">Offer Info</p>
                                        <p className="text-sm text-gray-900 font-medium">{selectedApplicant.OFFER_INFO || 'N/A'}</p>
                                    </div>
                                    <div>
                                        <p className="text-xs text-gray-500 font-semibold uppercase">Joined Employee ID</p>
                                        <p className="text-sm text-gray-900 font-medium">{selectedApplicant.JOINED_EMPID || 'N/A'}</p>
                                    </div>
                                    <div>
                                        <p className="text-xs text-gray-500 font-semibold uppercase">Onboarding User ID</p>
                                        <p className="text-sm text-gray-900 font-medium">{selectedApplicant.ONB_USERID || 'N/A'}</p>
                                    </div>
                                    <div>
                                        <p className="text-xs text-gray-500 font-semibold uppercase">Ref Type</p>
                                        <p className="text-sm text-gray-900 font-medium">{selectedApplicant.REF_TYPE || 'N/A'}</p>
                                    </div>
                                    <div>
                                        <p className="text-xs text-gray-500 font-semibold uppercase">Owner</p>
                                        <p className="text-sm text-gray-900 font-medium">{selectedApplicant.OWNER_USERID || 'N/A'}</p>
                                    </div>
                                    <div>
                                        <p className="text-xs text-gray-500 font-semibold uppercase">Owner Organization</p>
                                        <p className="text-sm text-gray-900 font-medium">{selectedApplicant.OWNER_USERORG || 'N/A'}</p>
                                    </div>
                                </div>
                            </div>

                            {/* Resume Section */}
                            {selectedApplicant.CAND_RESUME && selectedApplicant.CAND_RESUME.length > 0 && (
                                <div>
                                    <h3 className="text-lg font-semibold text-gray-900 mb-3 pb-2 border-b border-gray-200">Resume</h3>
                                    <div>
                                        <a
                                            href={selectedApplicant.CAND_RESUME[0]}
                                            download
                                            className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium"
                                        >
                                            <FaDownload className="w-4 h-4" />
                                            {selectedApplicant.CAND_RESUME[1] || 'Download Resume'}
                                        </a>
                                    </div>
                                </div>
                            )}
                        </div>

                        {/* Modal Footer */}
                        <div className="sticky bottom-0 bg-gray-50 p-4 border-t border-gray-200 flex justify-end">
                            <button
                                onClick={closeModal}
                                className="px-6 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors font-medium"
                            >
                                Close
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default JobApplicants;

// JobApplicants.js (Updated for robust default selection)
// import React, { useEffect, useState, useMemo } from "react";
// import { FaSearch, FaFilter, FaEye, FaDownload, FaFilePdf } from 'react-icons/fa';
// import { MdOutlineEmail, MdPhone, MdClose } from 'react-icons/md';
// import {BASE_URL} from "../config";
// // Helper function for date sorting
// const getDateForSorting = (dateString) => {
//     if (!dateString) return new Date(0);
//     const date = new Date(dateString);
//     return isNaN(date.getTime()) ? new Date(0) : date; 
// };

// // Buckets an applicant's raw JOB_APP_STAGE/JOB_APP_STATUS into one of the 6 filter
// // buckets: Initial, Screening, Interview, Final, Offer, Joining.
// // Instead of matching against exact hardcoded stage constants, this looks for
// // keywords in the combined stage + status text - so it keeps working regardless
// // of the exact literal format the backend sends (e.g. '@JobAppl_STG_Offer' vs
// // 'Offer' vs 'Offer-InProgress'). All of the many Offer-* sub-statuses
// // (Offer-Approval, Offer-To be Created, Offer-InProgress, Offer-Accepted,
// // Offer-Declined, etc.) collapse into a single "Offer" bucket - we only care
// // that the applicant has reached the Offer stage.
// export const getApplicantBucket = (applicant) => {
//     const text = `${applicant.JOB_APP_STAGE || ''} ${applicant.JOB_APP_STATUS || ''}`.toLowerCase();

//     // Joining stage - joined / hired / completed onboarding
//     if (text.includes('joining') || text.includes('joined') || text.includes('hired') || text.includes('completed')) {
//         return 'Joining';
//     }

//     // Offer stage - assume offer only, regardless of which Offer-* sub-status
//     if (text.includes('offer')) {
//         return 'Offer';
//     }

//     // Final round - checked before the generic "interview" keyword so a
//     // "Final Interview" style status still lands in the Final bucket.
//     if (text.includes('final')) {
//         return 'Final';
//     }

//     // Any interview round (L1-L4, HR, Mgmt)
//     if (text.includes('interview') || /\bl[1-4]\b/.test(text)) {
//         return 'Interview';
//     }

//     // Screening
//     if (text.includes('screening') || text.includes('screen')) {
//         return 'Screening';
//     }

//     // Initial / Applied
//     if (text.includes('initial') || text.includes('applied')) {
//         return 'Initial';
//     }

//     return 'Initial';
// };

// // Maps the raw JOB_APP_STATUS value to a color scheme for the status badge shown
// // on each candidate card, and anywhere else a status pill is rendered (imported
// // into CandidateDetails.js too, so both pages color the exact same status the
// // exact same way).
// //
// // Color meaning:
// //   gray   -> not started / queued
// //   blue   -> actively in progress (scheduled, applied, discussion, pending action)
// //   amber  -> needs attention / awaiting a decision (feedback pending, approval pending)
// //   orange -> on hold
// //   green  -> positive / completed outcome
// //   red    -> rejected, declined, revoked, cancelled, aborted, blocked, closed
// export const STATUS_COLOR_STYLES = {
//     gray:   { bg: 'bg-gray-100',   text: 'text-gray-700',   border: 'border-gray-200' },
//     blue:   { bg: 'bg-blue-100',   text: 'text-blue-700',   border: 'border-blue-200' },
//     amber:  { bg: 'bg-amber-100',  text: 'text-amber-700',  border: 'border-amber-200' },
//     orange: { bg: 'bg-orange-100', text: 'text-orange-700', border: 'border-orange-200' },
//     green:  { bg: 'bg-green-100',  text: 'text-green-700',  border: 'border-green-200' },
//     red:    { bg: 'bg-red-100',    text: 'text-red-700',    border: 'border-red-200' },
//     slate:  { bg: 'bg-slate-100',  text: 'text-slate-700',  border: 'border-slate-200' },
// };

// // Every interview round (L1, L2, L3, L4, HR, Mgmt) shares the same 8 sub-statuses,
// // just with a different suffix - build those entries once instead of repeating them
// // six times.
// const buildInterviewRoundStatuses = (suffix) => ({
//     [`to be scheduled-${suffix}`]: 'gray',
//     [`scheduled-${suffix}`]: 'blue',
//     [`completed-${suffix}`]: 'blue',
//     [`feedback pending-${suffix}`]: 'amber',
//     [`selected-${suffix}`]: 'green',
//     [`rejected-${suffix}`]: 'red',
//     [`cancelled-${suffix}`]: 'red',
//     [`abort-${suffix}`]: 'red',
// });

// // Exact-match table for every sub-status defined in the ItemList.JobAppl_STG_* config.
// // Keys are lowercased/trimmed status text; values are keys into STATUS_COLOR_STYLES.
// export const EXACT_STATUS_COLOR_MAP = {
//     // JobAppl_STG_Initial
//     'applied': 'blue',
//     'open': 'gray',
//     'hold': 'orange',

//     // JobAppl_STG_Screening
//     'to screen': 'gray',
//     'screen done': 'blue',
//     'shortlisted': 'green',
//     'rejected-screen': 'red',
//     'needinfo-screen': 'amber',

//     // JobAppl_STG_L1_Interview / L2 / L3 / L4 / HR / Mgmt
//     ...buildInterviewRoundStatuses('l1'),
//     ...buildInterviewRoundStatuses('l2'),
//     ...buildInterviewRoundStatuses('l3'),
//     ...buildInterviewRoundStatuses('l4'),
//     ...buildInterviewRoundStatuses('hr'),
//     ...buildInterviewRoundStatuses('mgmt'),

//     // JobAppl_STG_Final
//     'selected': 'green',
//     'rejected': 'red',
//     'closed': 'red',
//     'cancelled': 'red',
//     'abort': 'red',
//     'blocked': 'red',

//     // JobAppl_STG_Offer
//     'group-approval': 'amber',
//     'group-approval-done': 'green',
//     'group-approval-reject': 'red',
//     'group-approval-hold': 'orange',
//     'offer-approval': 'amber',
//     'offer-approval-done': 'green',
//     'offer-approval-reject': 'red',
//     'offer-approval-hold': 'orange',
//     'offer-to be created': 'gray',
//     'offer-inprogress': 'blue',
//     'offer-completed': 'green',
//     'offer-draft': 'gray',
//     'offer-finalized': 'green',
//     'offered': 'green',
//     'offer-accepted': 'green',
//     'offer-discussion': 'blue',
//     'offer-declined': 'red',
//     'offer-revoked': 'red',
//     'offer-onhold': 'orange',

//     // JobAppl_STG_Joining
//     'onb-to be initiated': 'gray',
//     'onb-pending-candidate': 'blue',
//     'onb-pending-hr': 'blue',
//     'onb-completed-hr': 'green',
//     'onb-cancelled': 'red',
//     'join-planned': 'green',
//     'joined': 'green',
//     'join-abort': 'red',
// };

// // Keyword fallback for anything not in the exact map above (older data, free-text
// // remarks, or values outside the configured stage list). Checked in order - most
// // decisive/terminal keywords first - so e.g. "Rejected-XYZ" always reads red even
// // if XYZ is a status this list has never seen.
// const KEYWORD_STATUS_COLOR_RULES = [
//     { color: 'red', keywords: ['reject', 'declin', 'revok', 'cancel', 'abort', 'blocked', 'closed'] },
//     { color: 'orange', keywords: ['hold'] },
//     { color: 'amber', keywords: ['needinfo', 'feedback pending', 'approval'] },
//     { color: 'green', keywords: ['selected', 'shortlist', 'accepted', 'finalized', 'completed', 'done', 'joined', 'offered'] },
//     { color: 'gray', keywords: ['to be scheduled', 'to be created', 'to be initiated', 'draft', 'to screen', 'open'] },
//     { color: 'blue', keywords: ['scheduled', 'inprogress', 'in progress', 'discussion', 'applied', 'pending'] },
// ];

// const getStatusColorKey = (status) => {
//     const text = (status || '').trim().toLowerCase();
//     if (!text) return 'gray';

//     if (EXACT_STATUS_COLOR_MAP[text]) return EXACT_STATUS_COLOR_MAP[text];

//     for (const rule of KEYWORD_STATUS_COLOR_RULES) {
//         if (rule.keywords.some(k => text.includes(k))) return rule.color;
//     }

//     return 'slate';
// };

// export const getStatusBadgeStyle = (status) => STATUS_COLOR_STYLES[getStatusColorKey(status)];

// const JobApplicants = ({ selectedJobId, onCandidateSelect }) => {
//     const [allApplicants, setAllApplicants] = useState([]);
//     const [loading, setLoading] = useState(false);
//     const [searchTerm, setSearchTerm] = useState("");
//     const [selectedCandidateJobAppID, setSelectedCandidateJobAppID] = useState(null);
//     const [hasAutoSelected, setHasAutoSelected] = useState(false); // Track if we've auto-selected for this job
//     const [activeFilter, setActiveFilter] = useState("All"); // Track active filter
//     const [selectedApplicant, setSelectedApplicant] = useState(null); // Track modal state
    
//     useEffect(() => {
//         const fetchApplicants = async () => {
//             // Only fetch if we actually have a jobId
//             if (!selectedJobId) {
//                 setAllApplicants([]);
//                 setSelectedCandidateJobAppID(null);
//                 setHasAutoSelected(false);
//                 return;
//             }

//             setLoading(true);
//             try {
//                 // Fetching specifically for the selected JOB_ID
//                 const response = await fetch(`${BASE_URL}:9034/api/display/fetch/jobApplication/data/${selectedJobId}`);
//                 const data = await response.json();
                
//                 const fetchedApplicants = Array.isArray(data) ? data : [];
//                 setAllApplicants(fetchedApplicants);

//                 // Auto-select the first applicant only once per job selection
//                 if (fetchedApplicants.length > 0 && onCandidateSelect && !hasAutoSelected) {
//                     const firstApplicantId = fetchedApplicants[0].JOB_APP_ID;
//                     onCandidateSelect(firstApplicantId, fetchedApplicants[0].JOB_APP_STATUS);
//                     setSelectedCandidateJobAppID(firstApplicantId);
//                     setHasAutoSelected(true);
//                 }
//             } catch (error) {
//                 console.error("Failed to load job applicants", error);
//                 setAllApplicants([]);
//             } finally {
//                 setLoading(false);
//             }
//         };

//         fetchApplicants();
//     }, [selectedJobId]);
//     // 2. Filter, Sort, and Calculate Default Candidate ID
//     const { applicantsToDisplay, defaultJobAppID } = useMemo(() => {
//         let list = [];
//         let defaultId = null;
//         const term = searchTerm.toLowerCase();

//         // Step A: Filter by selected Job ID
//         if (selectedJobId) {
//             list = allApplicants.filter(applicant => 
//                 applicant.JOB_ID === selectedJobId
//             );
//         } else {
//             // If no job is selected (should only happen briefly on initial load), use all
//             list = allApplicants;
//         }
        
//         // Step B: Filter by Search Term - by NAME ONLY (for this step)
//         if (term) {
//              list = list.filter(applicant => {
//                 const fullName = (applicant.CAND_FIRST_NAME + ' ' + applicant.CAND_LAST_NAME).toLowerCase();
//                 return fullName.includes(term);
//              });
//         }

//         // Step C: Filter by Status Filter Button
//         if (activeFilter !== "All") {
//             list = list.filter(applicant => getApplicantBucket(applicant) === activeFilter);
//         }

//         // Step D: Sort by date descending (latest first)
//         if (list.length > 0) {
//             list.sort((a, b) => 
//                 getDateForSorting(b.JOB_APPL_DATE) - getDateForSorting(a.JOB_APPL_DATE)
//             );
            
//             // Set the default selected candidate (latest one)
//             defaultId = list[0].JOB_APP_ID; 
//         }

//         return { applicantsToDisplay: list, defaultJobAppID: defaultId };
//     }, [selectedJobId, allApplicants, searchTerm, activeFilter]); 

//     // Handler for clicking a candidate card (manual selection)
//     const handleCandidateClick = (applicant) => {
//         const jobAppID = applicant.JOB_APP_ID;
//         if (onCandidateSelect) {
//             onCandidateSelect(jobAppID, applicant.JOB_APP_STATUS);
//             setSelectedCandidateJobAppID(jobAppID);
//         }
//     };

//     // Handler for viewing candidate details
//     const handleViewApplicant = (e, applicant) => {
//         e.stopPropagation();
//         setSelectedApplicant(applicant);
//     };

//     // Handler for closing modal
//     const closeModal = () => {
//         setSelectedApplicant(null);
//     };

//     // Calculate counts for filter buttons based on JOB_APP_STATUS
//     const getCandidateListByNameSearch = useMemo(() => {
//         let list = [];
//         const term = searchTerm.toLowerCase();

//         // Filter by selected Job ID
//         if (selectedJobId) {
//             list = allApplicants.filter(applicant => 
//                 applicant.JOB_ID === selectedJobId
//             );
//         } else {
//             list = allApplicants;
//         }
        
//         // Filter by Search Term - by NAME ONLY
//         if (term) {
//              list = list.filter(applicant => {
//                 const fullName = (applicant.CAND_FIRST_NAME + ' ' + applicant.CAND_LAST_NAME).toLowerCase();
//                 return fullName.includes(term);
//              });
//         }

//         return list;
//     }, [selectedJobId, allApplicants, searchTerm]);

//     const allCount = getCandidateListByNameSearch.length;
//     const initialCount = getCandidateListByNameSearch.filter(applicant => getApplicantBucket(applicant) === 'Initial').length;
//     const screeningCount = getCandidateListByNameSearch.filter(applicant => getApplicantBucket(applicant) === 'Screening').length;
//     const interviewCount = getCandidateListByNameSearch.filter(applicant => getApplicantBucket(applicant) === 'Interview').length;
//     const finalCount = getCandidateListByNameSearch.filter(applicant => getApplicantBucket(applicant) === 'Final').length;
//     const offerCount = getCandidateListByNameSearch.filter(applicant => getApplicantBucket(applicant) === 'Offer').length;
//     const joiningCount = getCandidateListByNameSearch.filter(applicant => getApplicantBucket(applicant) === 'Joining').length;

//     const filters = [
//         { label: 'All', count: allCount, active: true },
//         { label: 'Initial', count: initialCount, active: false },
//         { label: 'Screening', count: screeningCount, active: false },
//         { label: 'Interview', count: interviewCount, active: false },
//         { label: 'Final', count: finalCount, active: false },
//         { label: 'Offer', count: offerCount, active: false },
//         { label: 'Joining', count: joiningCount, active: false },
//     ];

//     return (
//         <div className="bg-white rounded-lg shadow h-full flex flex-col max-h-[800px] overflow-y-auto max-h-[calc(100vh-120px)]">
//             {/* Header with Title and Total */}
//             <div className="p-4 ">
//                 <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-2">
//                     <h2 className="text-lg font-medium text-red-800">Job Applicants</h2>
//                     <span className="text-2xl font-bold text-red-600">{applicantsToDisplay.length}</span>
//                 </div>
//             </div>

//             {/* Full-Width Search Bar */}
//             <div className="p-4  ">
//                 <div className="relative">
//                     <FaSearch className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
//                     <input
//                         type="text"
//                         placeholder="Start typing to search candidates"
//                         className="w-full pl-10 pr-10 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-red-500"
//                         value={searchTerm} 
//                         onChange={(e) => setSearchTerm(e.target.value)} 
//                     />
//                     <FaFilter className="absolute right-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400 cursor-pointer hover:text-red-600 transition-colors" />
//                 </div>
//             </div>

//             {/* Filter Buttons Row */}
//             <div className="px-4 py-3  flex flex-nowrap overflow-x-auto space-x-px gap-0.5 scrollbar-thin scrollbar-thumb-gray-300 scrollbar-track-gray-100">
//                 {filters.map((filter, index) => (
//                     <button
//                         key={index}
//                         onClick={() => setActiveFilter(filter.label)}
//                         className={`px-3 py-1.5 rounded-md text-xs font-medium whitespace-nowrap flex items-center space-x-1 flex-shrink-0 ${activeFilter === filter.label 
//                             ? 'bg-red-600 text-white shadow-sm'
//                             : 'bg-white border border-gray-300 text-gray-700 hover:bg-gray-50'
//                             }`}
//                     >
//                         <span>{filter.label}</span>
//                         <span className={`font-bold ${activeFilter === filter.label ? 'text-white' : 'text-red-600'}`}>
//                             {filter.count}
//                         </span>
//                     </button>
//                 ))}
//             </div>

//             {/* Applicants List */}
//             <div className="flex-1 overflow-y-auto p-2 sm:p-4 space-y-3">
//                 {applicantsToDisplay.length > 0 ? applicantsToDisplay.map((applicant, index) => { 
//                     const jobAppID = applicant.JOB_APP_ID;
//                     const isActive = jobAppID === selectedCandidateJobAppID;
//                     return (
//                         <div 
//                             key={index} 
//                             onClick={() => handleCandidateClick(applicant)}
//                             className={`
//                                 flex flex-col md:flex-row md:items-start gap-3 md:gap-0 p-3 border rounded-lg 
//                                 transition-all duration-200 cursor-pointer 
                                
//                                 ${isActive 
//                                     ? 'border-red-600 bg-red-50 ring-1 ring-red-300 shadow-md' 
//                                     : 'border-gray-200 bg-white hover:border-red-400 hover:bg-gray-50 hover:shadow-md'
//                                 }
//                             `}
//                         >
//                             {/* Left Column: Profile and Contact Details */}
//                             <div className="flex-1 w-full">
//                                 <div className="flex items-start space-x-3">
//                                     <img
//                                         src={`https://i.pravatar.cc/40?img=${jobAppID}`}
//                                         alt={applicant.CAND_FIRST_NAME}
//                                         className="w-10 h-10 rounded-full flex-shrink-0"
//                                     />
//                                     <div className="space-y-1 flex-1 min-w-0">
//                                         <h3 className="font-semibold text-gray-900 text-sm truncate">{applicant.CAND_FIRST_NAME + ' ' + applicant.CAND_LAST_NAME}</h3>
//                                         <div className="flex items-center text-xs text-gray-600">
//                                             <MdOutlineEmail className="w-3 h-3 mr-1 flex-shrink-0" />
//                                             <span className="truncate flex-1">{applicant.CAND_EMAIL_ID}</span>
//                                         </div>
//                                         <div className="flex items-center text-xs text-gray-600">
//                                             <MdPhone className="w-3 h-3 mr-1 flex-shrink-0" />
//                                             <span className="truncate">{applicant.CAND_MOBILE_NO}</span>
//                                         </div>
//                                         <p className="text-xs text-red-800">Ref: {applicant.REF_TYPE}</p>
//                                     </div>
//                                 </div>
//                             </div>

//                             {/* Right Column: Status, Applied Date and View Icon */}
//                             <div className="w-full md:w-auto mt-3 md:mt-0 flex flex-row md:flex-col items-start md:items-end justify-between md:justify-start gap-2 md:pl-3 py-1">
//                                 <div className="flex items-center gap-2">
//                                     <button
//                                         onClick={(e) => handleViewApplicant(e, applicant)}
//                                         className="p-2 hover:bg-red-100 rounded-lg transition-colors"
//                                         title="Applicants Details"
//                                     >
//                                         <FaEye className="text-red-600 w-4 h-4" />
//                                     </button>
//                                     <div className="md:p-2 p-1 flex items-center gap-1.5">
//                                         <span className="text-xs font-medium text-red-800">Status:</span>
//                                         {(() => {
//                                             const statusStyle = getStatusBadgeStyle(applicant.JOB_APP_STATUS);
//                                             return (
//                                                 <span className={`inline-block px-2 py-0.5 rounded-full text-xs font-medium border whitespace-nowrap ${statusStyle.bg} ${statusStyle.text} ${statusStyle.border}`}>
//                                                     {applicant.JOB_APP_STATUS || 'N/A'}
//                                                 </span>
//                                             );
//                                         })()}
//                                     </div>
//                                 </div>
//                                 <p className="text-xs text-gray-500 md:mt-2">Applied: {applicant.JOB_APPL_DATE}</p>
//                             </div>
//                         </div>
//                     );
//                 }) : (
//                     <div className="text-center text-gray-500 p-8 border border-dashed border-gray-300 rounded-lg">
//                         <p>No applicants found matching your criteria.</p>
//                         <p className="text-sm mt-1">Please select a job opening or adjust your search.</p>
//                     </div>
//                 )}
//             </div>

//             {/* Applicant Details Modal */}
//             {selectedApplicant && (
//                 <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
//                     <div className="bg-white rounded-lg shadow-2xl max-w-3xl w-full max-h-[90vh] overflow-y-auto">
//                         {/* Modal Header */}
//                         <div className="sticky top-0 bg-red-600 text-white p-4 flex justify-between items-center">
//                             <h2 className="text-xl font-bold">{selectedApplicant.CAND_FIRST_NAME} {selectedApplicant.CAND_LAST_NAME} - Details</h2>
//                             <button
//                                 onClick={closeModal}
//                                 className="hover:bg-red-700 p-2 rounded-lg transition-colors"
//                             >
//                                 <MdClose className="w-6 h-6" />
//                             </button>
//                         </div>

//                         {/* Modal Body */}
//                         <div className="p-6 space-y-6">
//                             {/* Candidate Personal Info */}
//                             <div>
//                                 <h3 className="text-lg font-semibold text-gray-900 mb-3 pb-2 border-b border-gray-200">Personal Information</h3>
//                                 <div className="grid grid-cols-2 gap-4">
//                                     <div>
//                                         <p className="text-xs text-gray-500 font-semibold uppercase">First Name</p>
//                                         <p className="text-sm text-gray-900 font-medium">{selectedApplicant.CAND_FIRST_NAME}</p>
//                                     </div>
//                                     <div>
//                                         <p className="text-xs text-gray-500 font-semibold uppercase">Last Name</p>
//                                         <p className="text-sm text-gray-900 font-medium">{selectedApplicant.CAND_LAST_NAME}</p>
//                                     </div>
//                                     <div>
//                                         <p className="text-xs text-gray-500 font-semibold uppercase">Date of Birth</p>
//                                         <p className="text-sm text-gray-900 font-medium">{new Date(selectedApplicant.CAND_DOB).toLocaleDateString()}</p>
//                                     </div>
//                                     <div>
//                                         <p className="text-xs text-gray-500 font-semibold uppercase">Address</p>
//                                         <p className="text-sm text-gray-900 font-medium">{selectedApplicant.CAND_ADDRESS || 'N/A'}</p>
//                                     </div>
//                                 </div>
//                             </div>

//                             {/* Contact Information */}
//                             <div>
//                                 <h3 className="text-lg font-semibold text-gray-900 mb-3 pb-2 border-b border-gray-200">Contact Information</h3>
//                                 <div className="grid grid-cols-2 gap-4">
//                                     <div>
//                                         <p className="text-xs text-gray-500 font-semibold uppercase">Email</p>
//                                         <p className="text-sm text-gray-900 font-medium break-all">{selectedApplicant.CAND_EMAIL_ID}</p>
//                                     </div>
//                                     <div>
//                                         <p className="text-xs text-gray-500 font-semibold uppercase">Mobile Number</p>
//                                         <p className="text-sm text-gray-900 font-medium">{selectedApplicant.CAND_MOBILE_NO}</p>
//                                     </div>
//                                     <div>
//                                         <p className="text-xs text-gray-500 font-semibold uppercase">Referee Email</p>
//                                         <p className="text-sm text-gray-900 font-medium break-all">{selectedApplicant.REF_EMAIL_ID || 'N/A'}</p>
//                                     </div>
//                                 </div>
//                             </div>

//                             {/* Education & Qualification */}
//                             <div>
//                                 <h3 className="text-lg font-semibold text-gray-900 mb-3 pb-2 border-b border-gray-200">Education</h3>
//                                 <div className="grid grid-cols-2 gap-4">
//                                     <div>
//                                         <p className="text-xs text-gray-500 font-semibold uppercase">Qualification</p>
//                                         <p className="text-sm text-gray-900 font-medium">{selectedApplicant.CAND_QUALIFICATION || 'N/A'}</p>
//                                     </div>
//                                     <div>
//                                         <p className="text-xs text-gray-500 font-semibold uppercase">Institute</p>
//                                         <p className="text-sm text-gray-900 font-medium">{selectedApplicant.CAND_STUDY_INSTITUTE || 'N/A'}</p>
//                                     </div>
//                                 </div>
//                             </div>

//                             {/* Experience & Skills */}
//                             <div>
//                                 <h3 className="text-lg font-semibold text-gray-900 mb-3 pb-2 border-b border-gray-200">Experience & Skills</h3>
//                                 <div className="grid grid-cols-2 gap-4">
//                                     <div>
//                                         <p className="text-xs text-gray-500 font-semibold uppercase">Current Role</p>
//                                         <p className="text-sm text-gray-900 font-medium">{selectedApplicant.CAND_CUR_ROLE || 'N/A'}</p>
//                                     </div>
//                                     <div>
//                                         <p className="text-xs text-gray-500 font-semibold uppercase">Years of Experience</p>
//                                         <p className="text-sm text-gray-900 font-medium">{selectedApplicant.CAND_EXP_YEAR || 0} years</p>
//                                     </div>
//                                     <div>
//                                         <p className="text-xs text-gray-500 font-semibold uppercase">Applied Role</p>
//                                         <p className="text-sm text-gray-900 font-medium">{selectedApplicant.CAND_ROLE_APPL || 'N/A'}</p>
//                                     </div>
//                                 </div>
//                                 {selectedApplicant.CAND_EXP_DESC && (
//                                     <div className="mt-4">
//                                         <p className="text-xs text-gray-500 font-semibold uppercase mb-2">Experience Description</p>
//                                         <p className="text-sm text-gray-700 whitespace-pre-wrap bg-gray-50 p-3 rounded">{selectedApplicant.CAND_EXP_DESC}</p>
//                                     </div>
//                                 )}
//                             </div>

//                             {/* Salary Information */}
//                             <div>
//                                 <h3 className="text-lg font-semibold text-gray-900 mb-3 pb-2 border-b border-gray-200">Salary Information</h3>
//                                 <div className="grid grid-cols-2 gap-4">
//                                     <div className="bg-blue-50 p-3 rounded-lg">
//                                         <p className="text-xs text-gray-500 font-semibold uppercase">Current Salary</p>
//                                         <p className="text-lg font-bold text-blue-600">₹{selectedApplicant.SALARY_CUR}L</p>
//                                     </div>
//                                     <div className="bg-green-50 p-3 rounded-lg">
//                                         <p className="text-xs text-gray-500 font-semibold uppercase">Expected Salary</p>
//                                         <p className="text-lg font-bold text-green-600">₹{selectedApplicant.SALARY_EXP}L</p>
//                                     </div>
//                                 </div>
//                             </div>

//                             {/* Location Preferences */}
//                             <div>
//                                 <h3 className="text-lg font-semibold text-gray-900 mb-3 pb-2 border-b border-gray-200">Location Preferences</h3>
//                                 <div className="grid grid-cols-2 gap-4">
//                                     <div>
//                                         <p className="text-xs text-gray-500 font-semibold uppercase">Applied Location</p>
//                                         <p className="text-sm text-gray-900 font-medium">{selectedApplicant.APP_JOB_LOCATIONS || 'N/A'}</p>
//                                     </div>
//                                     <div>
//                                         <p className="text-xs text-gray-500 font-semibold uppercase">Preferred Location</p>
//                                         <p className="text-sm text-gray-900 font-medium">{selectedApplicant.PREF_JOB_LOCATIONS || 'N/A'}</p>
//                                     </div>
//                                     <div>
//                                         <p className="text-xs text-gray-500 font-semibold uppercase">Notice Period</p>
//                                         <p className="text-sm text-gray-900 font-medium">{selectedApplicant.CAND_NOTICE_PERIOD || 0} days</p>
//                                     </div>
//                                     <div>
//                                         <p className="text-xs text-gray-500 font-semibold uppercase">Last Working Date</p>
//                                         <p className="text-sm text-gray-900 font-medium">{new Date(selectedApplicant.LAST_WORKING_DATE).toLocaleDateString()}</p>
//                                     </div>
//                                 </div>
//                             </div>

//                             {/* Application Status & Screening */}
//                             <div>
//                                 <h3 className="text-lg font-semibold text-gray-900 mb-3 pb-2 border-b border-gray-200">Application Status</h3>
//                                 <div className="grid grid-cols-2 gap-4">
//                                     <div>
//                                         <p className="text-xs text-gray-500 font-semibold uppercase">Application Stage</p>
//                                         <p className="text-sm text-gray-900 font-medium">{selectedApplicant.JOB_APP_STAGE || 'N/A'}</p>
//                                     </div>
//                                     <div>
//                                         <p className="text-xs text-gray-500 font-semibold uppercase mb-1">Application Status</p>
//                                         {(() => {
//                                             const statusStyle = getStatusBadgeStyle(selectedApplicant.JOB_APP_STATUS);
//                                             return (
//                                                 <span className={`inline-block px-2 py-0.5 rounded-full text-xs font-medium border whitespace-nowrap ${statusStyle.bg} ${statusStyle.text} ${statusStyle.border}`}>
//                                                     {selectedApplicant.JOB_APP_STATUS || 'N/A'}
//                                                 </span>
//                                             );
//                                         })()}
//                                     </div>
//                                     <div>
//                                         <p className="text-xs text-gray-500 font-semibold uppercase">Screening ID</p>
//                                         <p className="text-sm text-gray-900 font-medium">{selectedApplicant.ScreenID || 'N/A'}</p>
//                                     </div>
//                                     <div>
//                                         <p className="text-xs text-gray-500 font-semibold uppercase">Screened By</p>
//                                         <p className="text-sm text-gray-900 font-medium">{selectedApplicant.ScreenUserID || 'N/A'}</p>
//                                     </div>
//                                 </div>
//                             </div>

//                             {/* Interview & HR Status */}
//                             <div>
//                                 <h3 className="text-lg font-semibold text-gray-900 mb-3 pb-2 border-b border-gray-200">Interview & HR Status</h3>
//                                 <div className="grid grid-cols-2 gap-4">
//                                     {[
//                                         { label: 'L1 Status', value: selectedApplicant.L1_STATUS },
//                                         { label: 'L2 Status', value: selectedApplicant.L2_STATUS },
//                                         { label: 'L3 Status', value: selectedApplicant.L3_STATUS },
//                                         { label: 'L4 Status', value: selectedApplicant.L4_STATUS },
//                                         { label: 'HR Status', value: selectedApplicant.HR_STATUS },
//                                         { label: 'Offer Status', value: selectedApplicant.OFFER_APP_STATUS },
//                                     ].map(({ label, value }) => {
//                                         const style = getStatusBadgeStyle(value);
//                                         return (
//                                             <div key={label}>
//                                                 <p className="text-xs text-gray-500 font-semibold uppercase mb-1">{label}</p>
//                                                 <span className={`inline-block px-2 py-0.5 rounded-full text-xs font-medium border whitespace-nowrap ${style.bg} ${style.text} ${style.border}`}>
//                                                     {value || 'N/A'}
//                                                 </span>
//                                             </div>
//                                         );
//                                     })}
//                                 </div>
//                                 {selectedApplicant.CommentsHR && (
//                                     <div className="mt-4">
//                                         <p className="text-xs text-gray-500 font-semibold uppercase mb-2">HR Comments</p>
//                                         <p className="text-sm text-gray-700 bg-gray-50 p-3 rounded">{selectedApplicant.CommentsHR}</p>
//                                     </div>
//                                 )}
//                             </div>

//                             {/* Timeline Information */}
//                             <div>
//                                 <h3 className="text-lg font-semibold text-gray-900 mb-3 pb-2 border-b border-gray-200">Timeline</h3>
//                                 <div className="grid grid-cols-2 gap-4">
//                                     <div>
//                                         <p className="text-xs text-gray-500 font-semibold uppercase">Application Date</p>
//                                         <p className="text-sm text-gray-900 font-medium">{new Date(selectedApplicant.JOB_APPL_DATE).toLocaleDateString()}</p>
//                                     </div>
//                                     <div>
//                                         <p className="text-xs text-gray-500 font-semibold uppercase">Selected Date</p>
//                                         <p className="text-sm text-gray-900 font-medium">{selectedApplicant.SELECTED_DATE ? new Date(selectedApplicant.SELECTED_DATE).toLocaleDateString() : 'N/A'}</p>
//                                     </div>
//                                     <div>
//                                         <p className="text-xs text-gray-500 font-semibold uppercase">Offered Date</p>
//                                         <p className="text-sm text-gray-900 font-medium">{selectedApplicant.OFFERED_DATE ? new Date(selectedApplicant.OFFERED_DATE).toLocaleDateString() : 'N/A'}</p>
//                                     </div>
//                                     <div>
//                                         <p className="text-xs text-gray-500 font-semibold uppercase">Joined Date</p>
//                                         <p className="text-sm text-gray-900 font-medium">{selectedApplicant.JOINED_DATE ? new Date(selectedApplicant.JOINED_DATE).toLocaleDateString() : 'N/A'}</p>
//                                     </div>
//                                     <div>
//                                         <p className="text-xs text-gray-500 font-semibold uppercase">Selection SLA</p>
//                                         <p className="text-sm text-gray-900 font-medium">{selectedApplicant.SELECTION_SLA || 0} days ({selectedApplicant.SELECTION_SLA_DESC || 'N/A'})</p>
//                                     </div>
//                                 </div>
//                             </div>

//                             {/* Additional Information */}
//                             <div>
//                                 <h3 className="text-lg font-semibold text-gray-900 mb-3 pb-2 border-b border-gray-200">Additional Information</h3>
//                                 <div className="grid grid-cols-2 gap-4">
//                                     <div>
//                                         <p className="text-xs text-gray-500 font-semibold uppercase">Offer Info</p>
//                                         <p className="text-sm text-gray-900 font-medium">{selectedApplicant.OFFER_INFO || 'N/A'}</p>
//                                     </div>
//                                     <div>
//                                         <p className="text-xs text-gray-500 font-semibold uppercase">Joined Employee ID</p>
//                                         <p className="text-sm text-gray-900 font-medium">{selectedApplicant.JOINED_EMPID || 'N/A'}</p>
//                                     </div>
//                                     <div>
//                                         <p className="text-xs text-gray-500 font-semibold uppercase">Onboarding User ID</p>
//                                         <p className="text-sm text-gray-900 font-medium">{selectedApplicant.ONB_USERID || 'N/A'}</p>
//                                     </div>
//                                     <div>
//                                         <p className="text-xs text-gray-500 font-semibold uppercase">Ref Type</p>
//                                         <p className="text-sm text-gray-900 font-medium">{selectedApplicant.REF_TYPE || 'N/A'}</p>
//                                     </div>
//                                     <div>
//                                         <p className="text-xs text-gray-500 font-semibold uppercase">Owner</p>
//                                         <p className="text-sm text-gray-900 font-medium">{selectedApplicant.OWNER_USERID || 'N/A'}</p>
//                                     </div>
//                                     <div>
//                                         <p className="text-xs text-gray-500 font-semibold uppercase">Owner Organization</p>
//                                         <p className="text-sm text-gray-900 font-medium">{selectedApplicant.OWNER_USERORG || 'N/A'}</p>
//                                     </div>
//                                 </div>
//                             </div>

//                             {/* Resume Section */}
//                             {selectedApplicant.CAND_RESUME && selectedApplicant.CAND_RESUME.length > 0 && (
//                                 <div>
//                                     <h3 className="text-lg font-semibold text-gray-900 mb-3 pb-2 border-b border-gray-200">Resume</h3>
//                                     <div>
//                                         <a
//                                             href={selectedApplicant.CAND_RESUME[0]}
//                                             download
//                                             className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium"
//                                         >
//                                             <FaDownload className="w-4 h-4" />
//                                             {selectedApplicant.CAND_RESUME[1] || 'Download Resume'}
//                                         </a>
//                                     </div>
//                                 </div>
//                             )}
//                         </div>

//                         {/* Modal Footer */}
//                         <div className="sticky bottom-0 bg-gray-50 p-4 border-t border-gray-200 flex justify-end">
//                             <button
//                                 onClick={closeModal}
//                                 className="px-6 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors font-medium"
//                             >
//                                 Close
//                             </button>
//                         </div>
//                     </div>
//                 </div>
//             )}
//         </div>
//     );
// };

// export default JobApplicants;