import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import Swal from 'sweetalert2';
import AdvanceSearchModal from './AdvanceSearchModal';
import {BASE_URL} from "../config";

// Pulls a human-readable message out of an axios error, whatever shape the
// backend's error body happens to be in (JSON with "message", JSON with
// "error"/"detail", a plain-text body, or nothing at all). Mirrors
// ViewRequisitionModal.js so server-down / error responses look the same
// across the app.
const extractErrorMessage = (error, fallback) => {
  const data = error?.response?.data;

  if (typeof data === "string" && data.trim()) {
    return data;
  }
  if (data && typeof data === "object") {
    const candidate =
      data.message || data.error || data.errorMessage || data.detail || data.msg;
    if (candidate) return candidate;
  }
  return error?.message || fallback;
};

const OnboardedCandidates = () => {

  const [mergedData, setMergedData] = useState([]);
  const navigate = useNavigate();
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [selectedCandidate, setSelectedCandidate] = useState(null);
  const [openMenuIdx, setOpenMenuIdx] = useState(null);
  const [initiatedIds, setInitiatedIds] = useState([]);
  const [abottedIds, setAbottedIds] = useState([]);
  const [showPopup, setShowPopup] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [advSearchCriteria, setAdvSearchCriteria] = useState({});
  const [activeTab, setActiveTab] = useState('New');

  // Fetch backend status for each candidate in mergedData
  useEffect(() => {
    const fetchInitiatedStatuses = async () => {
      try {
        const statuses = await Promise.all(
          mergedData.map(async (candidate) => {
            const candId = candidate.candId || candidate.eonGeneralReqDTO?.CandID;
            if (!candId) return { candId, initiated: false, aborted: false };

            try {
              const response = await fetch(`${BASE_URL}:9034/api/onboarding/get/eonOverallStatus/data/${candId}`);
              if (!response.ok) return { candId, initiated: false, aborted: false };

              const text = await response.text();
              if (!text) return { candId, initiated: false, aborted: false };

              let data;
              try {
                data = JSON.parse(text);
              } catch (err) {
                console.warn(`Invalid JSON for ${candId}:`, text);
                return { candId, initiated: false, aborted: false };
              }

              const overallStatus = typeof data?.overallStatus === 'string' ? data.overallStatus.toLowerCase() : '';
              
              return {
                candId,
                initiated: overallStatus === 'initiated',
                aborted: overallStatus === 'hr-abort'
              };
            } catch (err) {
              console.error(`Error fetching status for ${candId}:`, err);
              return { candId, initiated: false, aborted: false };
            }
          })
        );

        const initiated = statuses
          .filter((status) => status.initiated)
          .map((status) => status.candId);

        const aborted = statuses
          .filter((status) => status.aborted)
          .map((status) => status.candId);

        setInitiatedIds(initiated);
        setAbottedIds(aborted);
      } catch (error) {
        console.error('Error fetching onboarding statuses:', error);
      }
    };

    if (mergedData.length > 0) fetchInitiatedStatuses();
  }, [mergedData]);

  // Calculate counts based on overallStatus from mergedData
  const getCounts = () => {
    let newCount = 0;
    let initiatedCount = 0;
    let abortedCount = 0;

    mergedData.forEach(candidate => {
      const overallStatus = candidate.eonOverallStatusReqDTO?.OverallStatus?.toLowerCase() || '';
      
      if (overallStatus === 'hr-abort') {
        abortedCount++;
      } else if (overallStatus === 'initiated') {
        initiatedCount++;
      } else {
        // Any other status (including 'hr-completed', etc.) goes to New tab
        newCount++;
      }
    });

    return { newCount, initiatedCount, abortedCount };
  };

  const { newCount, initiatedCount, abortedCount } = getCounts();

 const initiateOnboardingSubmit = async (candidate, idx) => {
  const candId = candidate.candId || candidate.eonGeneralReqDTO?.CandID;
  console.log('Initiating onboarding for candidate:', candId);
  
  try {
    // First, fetch the candidate details
    const resDetail = await fetch(`${BASE_URL}:9034/api/onboarding/fetchHRCompletedCandidateDetailsById/${candId}`);
    
    if (!resDetail.ok) throw new Error(`Server returned ${resDetail.status}: Failed to fetch details`);
    const fullCandidate = await resDetail.json();

    // Save the onboarding details
    const resSave = await fetch(`${BASE_URL}:9034/api/onboarding/saveOnBoardingCandidatesDetails`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(fullCandidate),
      //body: JSON.stringify(payload)
    });

    if (resSave.ok) {
      // NEW CODE: Update the status in database to 'Initiated'
      const jobId = parseInt(candidate.eonGeneralReqDTO?.JOB_ID) || 0;
      const applicationId = parseInt(candidate.eonGeneralReqDTO?.JOB_APP_ID) || 0;
      const status = 'Initiated';
      const statusUpdateUrl = `${BASE_URL}:9034/api/onboarding/update-overall-status?candId=${candId}&jobId=${jobId}&applicationId=${applicationId}&status=${status}`;
      
      const statusUpdateRes = await fetch(statusUpdateUrl, { method: 'PUT' });
      
      if (!statusUpdateRes.ok) {
        const errorText = await statusUpdateRes.text();
        console.error('Status update failed:', errorText);
        alert('Onboarding details saved but failed to update status: ' + errorText);
        return;
      }

      // Update the candidate's status in mergedData
      const updatedMergedData = mergedData.map(c => {
        if ((c.candId || c.eonGeneralReqDTO?.CandID) === candId) {
          return {
            ...c,
            eonOverallStatusReqDTO: {
              ...c.eonOverallStatusReqDTO,
              OverallStatus: 'Initiated'
            }
          };
        }
        return c;
      });
      
      setMergedData(updatedMergedData);
      
      // Also update initiatedIds for backward compatibility
      setInitiatedIds(prev => [...prev, candId]);

      alert(`✅ Onboarding initiated for ${candId}`);
      // Switch to Initiated tab
      setActiveTab('Initiated');
    } else {
      alert('❌ Failed to save onboarding details');
    }
  } catch (err) {
    console.error('Error during onboarding:', err);
    alert(`❌ Error: ${err.message}`);
  }
};

  const handleAbortEmployee = async (candidate) => {
    const candidateId = candidate.candId || candidate.eonGeneralReqDTO?.CandID || '';
    const jobId = parseInt(candidate.eonGeneralReqDTO?.JOB_ID) || 0;
    const applicationId = parseInt(candidate.eonGeneralReqDTO?.JOB_APP_ID) || 0;
    const status = 'HR-Abort';
    const url = `${BASE_URL}:9034/api/onboarding/update-overall-status?candId=${candidateId}&jobId=${jobId}&applicationId=${applicationId}&status=${status}`;

    try {
      const res = await fetch(url, { method: 'PUT' });

      if (!res.ok) {
        const errorText = await res.text();
        console.error('Abort failed:', errorText);
        alert('Failed to abort employee: ' + errorText);
        return;
      }

      const data = await res.text();
      console.log('Abort success:', data);

      // Update the candidate's status in mergedData
      const updatedMergedData = mergedData.map(c => {
        if ((c.candId || c.eonGeneralReqDTO?.CandID) === candidateId) {
          return {
            ...c,
            eonOverallStatusReqDTO: {
              ...c.eonOverallStatusReqDTO,
              OverallStatus: 'HR-Abort'
            }
          };
        }
        return c;
      });
      
      setMergedData(updatedMergedData);
      
      // Also update abottedIds for backward compatibility
      setAbottedIds((prev) => [...prev, candidateId]);
      
      alert(data || 'Employee aborted and status updated.');
      
      // Switch to Aborted tab
      setActiveTab('Aborted');
    } catch (err) {
      console.error('Network error:', err);
      alert('Error aborting employee: ' + err.message);
    }
  };

  const handleMoveToEmployee = async (candidate) => {
    const cid = candidate.candId || candidate.eonGeneralReqDTO?.CandID;
    if (!cid) {
      alert('Candidate ID not found');
      return;
    }
    try {
      const endpoints = {
        personal: `eonPersonal`,
        family: `eonFamily`,
        bank: `eonBank`,
        candidateDeclaration: `eonCandidateDeclaration`,
        declQuestionnaire: `eonDeclQuestionnaire`,
        documentProof: `eonDocumentProof`,
        education: `eonEducation`,
        general: `eonGeneral`,
        hrDeclaration: `eonHRDeclaration`,
        interest: `eonInterest`,
        language: `eonLanguage`,
        overallStatus: `eonOverallStatus`,
        pf: `eonPF`,
        profReference: `eonProfessionalReference`,
        profExp: `eonProfressionalExperience`,
        skill: `eonSkill`
      };
      
      const results = await Promise.all(
        Object.entries(endpoints).map(async ([key, endpoint]) => {
          const res = await fetch(`${BASE_URL}:9034/api/onboarding/get/${endpoint}/data/${cid}`);
          if (!res.ok) {
            return { [key]: {} };
          }
          try {
            const data = await res.json();
            return { [key]: data };
          } catch {
            return { [key]: {} };
          }
        })
      );
      const merged = results.reduce((acc, item) => ({ ...acc, ...item }), {});
      navigate('/addEmployee', { state: { candidate: merged } });
    } catch (err) {
      alert('Failed to fetch all candidate data');
    }
  };

  const fetchAllGenealCandidates = async (params = {}) => {
    try {
      const response = await axios.get(`${BASE_URL}:9034/api/onboarding/fetchAllHRCompletedGeneralCandidatesDetails`, { params });

      const data = response.data;
      setMergedData(Array.isArray(data) ? data : []);
      console.log("Merged Data:", data);
    } catch (error) {
      console.error("Failed to load candidates", error);
     Swal.fire({
             icon: "error",
             title: "Service Unavailable",
             text: "E-recruitment service is down. Please try again later.",
           });
    }
  };

  useEffect(() => {
    fetchAllGenealCandidates();
  }, []);

  const handleProbationEvaluation = (candidate) => {
    navigate('/probation-status-card', { state: { candidate } });
  };

  const handleAdvancedSearch = (criteria) => {
    setAdvSearchCriteria(criteria);
  };

  // Filter candidates based on active tab using overallStatus
  const filteredCandidates = mergedData.filter((candidate) => {
    const overallStatus = candidate.eonOverallStatusReqDTO?.OverallStatus?.toLowerCase() || '';
    
    // TAB FILTERING LOGIC BASED ON OVERALLSTATUS
    if (activeTab === 'Aborted') {
      // Only show candidates with HR-Abort status
      if (overallStatus !== 'hr-abort') return false;
    } else if (activeTab === 'Initiated') {
      // Only show candidates with Initiated status
      if (overallStatus !== 'initiated') return false;
    } else if (activeTab === 'New') {
      // Show candidates that are NOT Initiated and NOT HR-Abort
      if (overallStatus === 'initiated' || overallStatus === 'hr-abort') return false;
    }

    // Search filter logic
    const name = candidate.eonGeneralReqDTO?.CandName?.toLowerCase() || '';
    const email = candidate.eonGeneralReqDTO?.email_id?.toLowerCase() || '';
    const position = candidate.eonGeneralReqDTO?.PosApplied?.toLowerCase() || '';
    const id = candidate.candId?.toLowerCase() || '';

    const query = searchQuery.toLowerCase();

    const simpleSearchMatch =
      name.includes(query) ||
      email.includes(query) ||
      position.includes(query) ||
      id.includes(query);

    const advSearchMatch =
      (!advSearchCriteria.candidateName || name.includes(advSearchCriteria.candidateName.toLowerCase())) &&
      (!advSearchCriteria.status || overallStatus.includes(advSearchCriteria.status.toLowerCase()));

    return simpleSearchMatch && advSearchMatch;
  });
  
  return (
      <div className="bg-slate-50 font-sans text-slate-900 w-full min-h-[calc(100vh-64px)]">
      <h2 className="text-xl font-semibold mb-4">To be Onboarded Candidates</h2>

      {/* Search & Filter */}
      <div className="flex flex-wrap gap-4 mb-6 ">
        <input
          type="text"
          placeholder="Search Employees"
          className="border px-4 py-2 rounded-md w-64"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />

        <button
          onClick={() => setShowPopup(true)}
          className="border px-4 py-2 rounded-md text-gray-600 hover:bg-gray-100"
        >
          🛠 AdvanceFilter
        </button>
        <AdvanceSearchModal
          isOpen={showPopup}
          onClose={() => setShowPopup(false)}
          onSearch={handleAdvancedSearch}
        />
      </div>
      
      {/* Tabs with correct counts based on overallStatus */}
      <div className="flex gap-4 mb-6 ">
        <button
          onClick={() => setActiveTab('New')}
          className={
            activeTab === 'New'
              ? 'bg-indigo-600 text-white px-6 py-2 rounded-full font-semibold'
              : 'border px-6 py-2 rounded-full font-semibold text-gray-600 hover:bg-gray-100'
          }
        >
          New ({newCount})
        </button>
        
        <button
          onClick={() => setActiveTab('Initiated')}
          className={
            activeTab === 'Initiated'
              ? 'bg-indigo-600 text-white px-6 py-2 rounded-full font-semibold'
              : 'border px-6 py-2 rounded-full font-semibold text-gray-600 hover:bg-gray-100'
          }
        >
          Initiated ({initiatedCount})
        </button>
        
        <button
          onClick={() => setActiveTab('Aborted')}
          className={
            activeTab === 'Aborted'
              ? 'bg-indigo-600 text-white px-6 py-2 rounded-full font-semibold'
              : 'border px-6 py-2 rounded-full font-semibold text-gray-600 hover:bg-gray-100'
          }
        >
          Aborted ({abortedCount})
        </button>
      </div>

      {/* Cards */}
      {filteredCandidates.length === 0 ? (
        <div className="text-center py-8 text-gray-500 ">
          No candidates found in {activeTab} tab
        </div>
      ) : (
        filteredCandidates.map((candidate, idx) => {
          const candidateId = candidate.candId || candidate.eonGeneralReqDTO?.CandID;
          const overallStatus = candidate.eonOverallStatusReqDTO?.OverallStatus || '';
          const overallStatusLower = overallStatus.toLowerCase();
          
          const isAborted = overallStatusLower === 'hr-abort';
          const isInitiated = overallStatusLower === 'initiated';
          
          return (
            <div
              key={candidateId || idx}
              className="bg-[#f9f9fb] shadow-md rounded-2xl mb-8 px-6 py-4 "
            >
              {/* Top Section */}
              <div className="flex items-center justify-between ">
                <div className="flex gap-4">
                  <img
                    src={`https://i.pravatar.cc/60?img=${idx + 10}`}
                    alt="avatar"
                    className="w-14 h-14 rounded-full"
                  />
                  <div>
                    <p className="text-base font-semibold">
                      {candidate.eonGeneralReqDTO?.CandName || 'N/A'}</p>
                    <p className="text-sm text-gray-500">{candidate.eonGeneralReqDTO?.PosApplied || 'N/A'}</p>
                    <div className="flex items-center gap-2 text-sm text-indigo-600">
                      <a href={`mailto:${candidate.eonGeneralReqDTO?.email_id}`} className="underline">
                        {candidate.eonGeneralReqDTO?.email_id || 'N/A'}
                      </a> | {candidate.eonGeneralReqDTO?.CurContactNum || 'N/A'}
                    </div>
                  </div>
                </div>
                <div className="relative">
                  <p className="text-sm text-gray-500">HR Declaration</p><br />
                  <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                    isAborted 
                      ? 'bg-red-100 text-red-600' 
                      : isInitiated 
                        ? 'bg-blue-100 text-blue-600'
                        : 'bg-green-100 text-green-600'
                  }`}>
                    ✔ {overallStatus || 'Pending'}
                  </span>
                </div>
                {/* Three-dot Menu - Only show for non-aborted candidates */}
                {!isAborted && (
                  <div className="relative">
                    <button
                      onClick={() => setOpenMenuIdx(openMenuIdx === idx ? null : idx)}
                      className="p-2 rounded-full hover:bg-gray-100 text-xl"
                      title="Actions"
                    >
                      &#8942;
                    </button>

                    {openMenuIdx === idx && (
                      <div className="absolute right-0 mt-2 w-52 bg-white border border-gray-200 rounded-lg shadow-lg z-10">
                        <div className="px-4 py-2 text-xs text-gray-500 border-b font-semibold cursor-default">Actions</div>
                        
                        {/* Initiate Onboarding button - only for New candidates */}
                        {!isInitiated && !isAborted && (
                          <button
                            className="w-full px-4 py-2 text-left text-sm hover:bg-indigo-100 hover:text-indigo-600 transition-colors rounded bg-white text-black border cursor-pointer"
                            onClick={() => {
                              initiateOnboardingSubmit(candidate, idx);
                              setOpenMenuIdx(null);
                            }}
                          >
                            🚀 Initiate Employee
                          </button>
                        )}

                        {/* Move to Employee - only for Initiated candidates */}
                        {isInitiated && (
                          <button
                            className="w-full px-4 py-2 text-left text-sm hover:bg-indigo-100 hover:text-indigo-600 transition-colors rounded bg-white text-black border cursor-pointer"
                            onClick={() => {
                              handleMoveToEmployee(candidate);
                              setOpenMenuIdx(null);
                            }}
                          >
                            Move to OnboardEmployee
                          </button>
                        )}

                        {/* Abort Employee - only for New candidates */}
                        {!isInitiated && !isAborted && (
                          <button
                            className="w-full px-4 py-2 text-left text-sm hover:bg-red-100 hover:text-red-600 transition-colors"
                            onClick={() => {
                              handleAbortEmployee(candidate);
                              setOpenMenuIdx(null);
                            }}
                          >
                            Abort Employee
                          </button>
                        )}
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Divider */}
              <div className="border-b border-gray-200 my-4 " />

              {/* Bottom Grid */}
              <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-y-3 text-sm text-gray-700 ">
                <div><strong>Candidate ID</strong><br />{candidate.candId || 'N/A'}</div>
                <div><strong>Job ID</strong><br />{candidate.eonGeneralReqDTO?.JOB_ID || 'N/A'}</div>
                <div><strong>Offer Date</strong><br />{candidate.eonGeneralReqDTO?.DateOfJoin
                  ? new Date(candidate.eonGeneralReqDTO.DateOfJoin).toDateString() : 'N/A'}</div>
                <div><strong>Expected joining Date</strong><br />{candidate.eonGeneralReqDTO?.DateOfJoin
                  ? new Date(candidate.eonGeneralReqDTO.DateOfJoin).toDateString() : 'N/A'}</div>
                <div><strong>HR (TA)</strong><br />{candidate.eonGeneralReqDTO?.INIT_USERID || 'N/A'}</div>
                <div><strong>HR Manager</strong><br />{candidate.eonGeneralReqDTO?.INIT_USERID || 'N/A'}</div>
                <div><strong>Current Status</strong><br />
                  <span className={isAborted ? 'text-red-600 font-semibold' : ''}>
                    {overallStatus}
                  </span>
                </div>
              </div>

              {/* Divider after Current Status */}
              <div className="border-b border-gray-200 my-4 " />

              {/* Extra Info Row */}
              <div className="grid grid-cols-3 md:grid-cols-6 gap-y-3 text-sm text-gray-700">
                <div><strong>Total Year of Experience</strong><br />
                  <span className="text-indigo-600 font-bold">{candidate.eonGeneralReqDTO?.TotalExp || 0}</span>
                </div>
                <div><strong>HR Declaration Date</strong><br />{candidate.eonhrDeclReqDTO?.VerifiedDate
                  ? new Date(candidate.eonhrDeclReqDTO.VerifiedDate).toDateString() : 'N/A'}</div>
                <div><strong>Due in Days</strong><br />
                  <span className="text-red-500 font-bold">{candidate.eonOverallStatusReqDTO?.dueInDays || 'N/A'}</span>
                </div>
              </div>
            </div>
          )
        })
      )}
      
      {showConfirmModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-lg shadow-lg w-full max-w-md relative">
            <button
              className="absolute top-2 right-2 text-red-500 text-lg"
              onClick={() => setShowConfirmModal(false)}
            >
              ✕
            </button>
            <h3 className="text-lg font-semibold mb-4 text-center">Moving to Employee Directory</h3>
            <p className="text-sm text-center mb-6">
              Do you want to move the selected Candidate to Employee Directory?<br />
              <span className="text-gray-500">The Candidate will be saved as an Employee</span>
            </p>
            <div className="flex justify-center gap-4">
              <button
                onClick={() => setShowConfirmModal(false)}
                className="px-4 py-2 bg-gray-200 rounded-md hover:bg-gray-300"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  navigate('/addEmployee', { state: { candidate: selectedCandidate } });
                  setShowConfirmModal(false);
                }}
                className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700"
              >
                Move
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default OnboardedCandidates;