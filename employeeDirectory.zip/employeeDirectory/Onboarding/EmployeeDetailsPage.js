import React, { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate, useLocation, useParams } from "react-router-dom";
// Added icons for the status and fallback profile image
import { FaRegCheckCircle, FaUserCircle } from "react-icons/fa";
import { BASE_URL } from "../config";
// Helper component to render a data field pair with consistent styling for the lower cards
const DataField = ({ label, value, className = "" }) => (
  <div className={`flex justify-between items-start mb-2.5 gap-4 ${className}`}>
    <span className="text-gray-500 font-medium text-sm flex-grow">{label}</span>
    <span className="text-indigo-900 font-medium text-sm text-right break-words max-w-[60%]">
      {value !== null && value !== undefined && value !== "" ? value : "N/A"}
    </span>
  </div>
);

// Helper to format date strings
const formatDate = (dateString) => {
  if (!dateString) return "N/A";
  const date = new Date(dateString);
  if (isNaN(date)) return dateString.length > 0 ? dateString : "N/A";
  return date.toLocaleDateString("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });
};

// Helper to format skill arrays
const formatSkillString = (s1, s2, s3) => {
    const skills = [s1, s2, s3].filter(Boolean);
    return skills.length > 0 ? skills.join(', ') : "N/A";
};

const EmployeeDetailsPage = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { candidateId: candidateIdParam } = useParams(); 
  
  const [employee, setEmployee] = useState(location.state?.employee || null);
  const [loading, setLoading] = useState(!location.state?.employee && !!candidateIdParam);

  useEffect(() => {
    if (employee) return;

    if (candidateIdParam) {
        setLoading(true);
        axios
            .get(`${BASE_URL}:9034/api/onboarding/get/candidate/${candidateIdParam}`)
            .then((res) => {
                if (res.data) {
                    setEmployee(res.data);
                } else {
                    alert(`Fetch Failed: API returned an empty response for ID ${candidateIdParam}.`);
                }
            })
            .catch((err) => {
                console.error("CRITICAL API ERROR:", err);
                alert(`CRITICAL ERROR: Failed to fetch candidate data. Check console.`);
            })
            .finally(() => {
                setLoading(false);
            });
    }
  }, [candidateIdParam, employee]);


  if (loading) {
      return <div className="p-10 flex justify-center">Loading employee details...</div>;
  }

  if (!employee) {
    return (
      <div className="p-10 bg-gray-100 min-h-screen">
        <div className="bg-white p-8 rounded-xl shadow-sm max-w-xl mx-auto border border-gray-200 border-t-4 border-t-indigo-700">
          <h1 className="text-2xl font-bold text-indigo-700 mb-4">Data Not Found</h1>
          <button onClick={() => navigate(-1)} className="mt-6 px-4 py-2 bg-indigo-700 text-white rounded-lg hover:bg-indigo-800 transition">Go Back</button>
        </div>
      </div>
    );
  }

  // Destructure structured data
  const {
    personal,
    employeeOnboardingInfo,
    skill,
    profExp,
    pf,
    documentProof,
    general,
  } = employee;

  const candId = personal?.candID || candidateIdParam;
  const fullName = [personal?.firstName, personal?.middleName, personal?.lastName].filter(Boolean).join(' ');
  const designation = employeeOnboardingInfo?.designation || "N/A";
  const status = employeeOnboardingInfo?.status || "N/A";
  // Check if status is confirmed to conditionally show green color and icon
  const isConfirmed = status.toLowerCase().includes("confirmed");


  // --- NEW HEADER SECTION RENDERER (Matches Screenshot Layout) ---
  const renderHeaderSection = () => {
    // Inline component for the header fields to match screenshot styling
    const HeaderField = ({ label, value, icon = null, valueClass = "text-indigo-900" }) => (
        <div className="flex flex-col">
            <span className="text-gray-400 text-xs font-semibold uppercase tracking-wide mb-1">{label}</span>
            <div className={`text-sm font-semibold break-words flex items-center gap-1 ${valueClass}`}>
                {icon}
                <span>{value !== null && value !== undefined && value !== "" ? value : "N/A"}</span>
            </div>
        </div>
    );

    return (
      <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 border-t-4 border-t-indigo-700 mb-6 flex flex-col md:flex-row gap-8 items-center md:items-start">
        {/* Left Side: Profile Image, Name, Designation */}
        <div className="flex flex-col items-center md:w-1/5 text-center">
            {/* Placeholder for profile image since it's not in onboarding data */}
            <div className="w-28 h-28 mb-3 rounded-full bg-indigo-50 border-2 border-indigo-100 flex items-center justify-center text-indigo-300 shadow-sm">
                <FaUserCircle size={90} />
            </div>
            <h2 className="text-xl font-bold text-indigo-800">{fullName}</h2>
            <p className="text-gray-500 text-sm font-medium">{designation}</p>
        </div>

        {/* Right Side: 4x2 Grid of Basic Details */}
        <div className="flex-grow grid grid-cols-2 md:grid-cols-4 gap-y-6 gap-x-4 content-center w-full">
            {/* Row 1 */}
            <HeaderField label="Employee ID / Cand ID" value={candId} />
            <HeaderField label="Contact No" value={personal?.permContactNum} />
            <HeaderField label="Email" value={personal?.emailAddr} />
            {/* Note: Showing Location ID as Name is not available in onboarding data */}
            <HeaderField label="Location" value={general?.locationId ? `ID: ${general.locationId}` : "N/A"} />

            {/* Row 2 */}
            <HeaderField label="Department" value={employeeOnboardingInfo?.mainDepartment} />
            <HeaderField label="Reporting To" value={employeeOnboardingInfo?.rptManagerName} />
            <HeaderField 
                label="Employment Status" 
                value={status} 
                valueClass={isConfirmed ? "text-green-600" : "text-orange-500"}
                icon={isConfirmed ? <FaRegCheckCircle /> : null}
            />
            {/* Empty slot in the 4th column of 2nd row as per screenshot structure */}
            <div></div>
        </div>
      </div>
    );
  };

  // --- OTHER CARD RENDERERS ---

  // Card 1: Basic Information
  const renderBasicInfoCard = () => {
    const isProbation = employeeOnboardingInfo?.isProbationApplicable;
    return (
    <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 hover:shadow-md transition-shadow duration-200">
      <h4 className="text-[15px] font-semibold text-indigo-800 border-b-2 border-indigo-100 pb-3 mb-5 flex items-center gap-2">
        <span className="flex items-center justify-center h-6 w-6 rounded-md bg-indigo-50 text-indigo-700 text-xs font-bold">1</span>
        Basic Information
      </h4>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-1">
        <DataField label="Emp Onboarding Ref number" value={employeeOnboardingInfo?.empOnboardingRefNum} />
        <DataField label="Date of Joining" value={formatDate(general?.dateOfJoin)} />
        <DataField label="Status" value={employeeOnboardingInfo?.status} />
        <DataField label="Employee Full Name" value={fullName} />
        <DataField label="Date of Birth" value={formatDate(personal?.dob)} />
        <DataField label="Gender" value={personal?.gender} />
        <DataField label="Reporting Manager Name" value={employeeOnboardingInfo?.rptManagerName} />
        <DataField label="Reporting Manager Code" value={employeeOnboardingInfo?.rptMgrEmployeeCode} />
        <DataField label="Reporting Manager Email" value={employeeOnboardingInfo?.rptManagerEmailId} />
      </div>

       {/* Conditional Probation Section */}
      <div className="mt-4 pt-4 border-t border-gray-100">
          <DataField label="Is probation Applicable?" value={isProbation ? "Yes" : "No"} className="font-semibold" />
          {isProbation && (
             <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-1 mt-2 pl-4 border-l-2 border-indigo-100">
                <DataField label="Probation Start Date" value={formatDate(employeeOnboardingInfo?.probationPeriod)} />
                <DataField label="Confirmation End Date" value={formatDate(employeeOnboardingInfo?.confirmationDate)} />
                <DataField label="Max Probation Extension" value={employeeOnboardingInfo?.maxProbationExtension} />
             </div>
          )}
      </div>
    </div>
  )};

  // Card 2: Personal Details
  const renderPersonalDetailsCard = () => (
    <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 hover:shadow-md transition-shadow duration-200">
      <h4 className="text-[15px] font-semibold text-indigo-800 border-b-2 border-indigo-100 pb-3 mb-5 flex items-center gap-2">
        <span className="flex items-center justify-center h-6 w-6 rounded-md bg-indigo-50 text-indigo-700 text-xs font-bold">2</span>
        Personal Details
      </h4>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-1">
        {/* Redundant fields removed from here as they are in header: Contact, Email */}
        <DataField label="Date of Birth" value={formatDate(personal?.dob)} />
        <DataField label="Gender" value={personal?.gender} />
        <DataField label="Secondary Contact" value={personal?.curContactNum} />
        <DataField label="Emergency Contact" value={personal?.emrContactNum} />
        <DataField label="Marital Status" value={personal?.maritalStatus} />
        <DataField label="Blood Group" value={personal?.bloodGroup} />
      </div>
    </div>
  );

  // Card 3: Statutory & Financial Details
  const renderStatutoryFinancialCard = () => (
    <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 hover:shadow-md transition-shadow duration-200">
      <h4 className="text-[15px] font-semibold text-indigo-800 border-b-2 border-indigo-100 pb-3 mb-5 flex items-center gap-2">
        <span className="flex items-center justify-center h-6 w-6 rounded-md bg-indigo-50 text-indigo-700 text-xs font-bold">3</span>
        Statutory & Financial Details
      </h4>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-1">
        <DataField label="Aadhar No" value={documentProof?.aadharCard} />
        <DataField label="PAN No" value={documentProof?.panCard} />
        <DataField label="Full Name as per PAN" value={employeeOnboardingInfo?.fullNameAsPerPAN} />
        <DataField label="UAN Number" value={pf?.uan} />
        <DataField label="Current PF Number" value={employeeOnboardingInfo?.currentPfNumber} />
        <DataField label="Current ESIC Number" value={employeeOnboardingInfo?.currentESICNumber} />
      </div>
    </div>
  );

    // Card 4: Organization & Structure Details
    const renderOrganizationStructureCard = () => {
      const isProbation = employeeOnboardingInfo?.isProbationApplicable;
      return (
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 hover:shadow-md transition-shadow duration-200">
          <h4 className="text-[15px] font-semibold text-indigo-800 border-b-2 border-indigo-100 pb-3 mb-5 flex items-center gap-2">
            <span className="flex items-center justify-center h-6 w-6 rounded-md bg-indigo-50 text-indigo-700 text-xs font-bold">4</span>
            Organization & Structure Details
          </h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-1">
            <DataField label="Emp Onboarding Ref No" value={employeeOnboardingInfo?.empOnboardingRefNum} />
            <DataField label="Date of Joining" value={formatDate(general?.dateOfJoin)} />
            <DataField label="Payroll Area Type" value={employeeOnboardingInfo?.payrollAreaType} />
            <DataField label="BU Head" value={employeeOnboardingInfo?.buHead} />
            <DataField label="Project" value={employeeOnboardingInfo?.project} />
            <DataField label="Organisation Code" value={employeeOnboardingInfo?.organisationCode} />
            <DataField label="Organisation Hierarchy" value={employeeOnboardingInfo?.organisationHierarchy} />
            <DataField label="Reporting Manager Code" value={employeeOnboardingInfo?.rptMgrEmployeeCode} />
            <DataField label="Reporting Manager Email" value={employeeOnboardingInfo?.rptManagerEmailId} />
          </div>

           {/* Conditional Probation Section moved here */}
          <div className="mt-4 pt-4 border-t border-gray-100">
              <DataField label="Is probation Applicable?" value={isProbation ? "Yes" : "No"} className="font-semibold" />
              {isProbation && (
                 <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-1 mt-2 pl-4 border-l-2 border-indigo-100">
                    <DataField label="Probation Start Date" value={formatDate(employeeOnboardingInfo?.probationPeriod)} />
                    <DataField label="Confirmation End Date" value={formatDate(employeeOnboardingInfo?.confirmationDate)} />
                    <DataField label="Max Probation Extension" value={employeeOnboardingInfo?.maxProbationExtension} />
                 </div>
              )}
          </div>
        </div>
      );
    };


  // Card 5: Work Details
  const renderWorkDetailsCard = () => (
    <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 hover:shadow-md transition-shadow duration-200">
      <h4 className="text-[15px] font-semibold text-indigo-800 border-b-2 border-indigo-100 pb-3 mb-5 flex items-center gap-2">
        <span className="flex items-center justify-center h-6 w-6 rounded-md bg-indigo-50 text-indigo-700 text-xs font-bold">5</span>
        Work Details
      </h4>
      
      <div className="mb-6">
        <h5 className="font-semibold text-indigo-800 mb-3 text-sm uppercase tracking-wide">Current Role Information</h5>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-1">
            <DataField label="Sub Department" value={employeeOnboardingInfo?.subDepartment} />
            <DataField label="Grade" value={employeeOnboardingInfo?.grade} />
            <DataField label="Hiring HR" value={employeeOnboardingInfo?.hiringHr} />
        </div>
      </div>

      <div className="mb-6 pt-4 border-t border-gray-100">
         <h5 className="font-semibold text-indigo-800 mb-3 text-sm uppercase tracking-wide">Previous Experience</h5>
         <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-1">
            <DataField label="Total Experience" value={profExp?.totalExp} />
            <DataField label="Previous Company" value={profExp?.company1} />
            <DataField label="From Date" value={formatDate(profExp?.fromDate1)} />
            <DataField label="To Date" value={formatDate(profExp?.toDate1)} />
         </div>
      </div>

      <div className="pt-4 border-t border-gray-100">
        <h5 className="font-semibold text-indigo-800 mb-3 text-sm uppercase tracking-wide">Skills</h5>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-1">
            <DataField label="Primary Skill Names" value={formatSkillString(skill?.primarySkill1Name, skill?.primarySkill2Name, skill?.primarySkill3Name)} />
             <DataField label="Primary Skill Levels" value={formatSkillString(skill?.primarySkill1Level, skill?.primarySkill2Level, skill?.primarySkill3Level)} />
             <DataField label="Secondary Skill Names" value={formatSkillString(skill?.secondarySkill1Name, skill?.secondarySkill2Name, skill?.secondarySkill3Name)} />
             <DataField label="Secondary Skill Levels" value={formatSkillString(skill?.secondarySkill1Level, skill?.secondarySkill2Level, skill?.secondarySkill3Level)} />
        </div>
      </div>
    </div>
  );
  
  const handleBack = () => {
    navigate(-1);
  };

  // --- MAIN RENDER ---

  return (
    <div className="bg-gray-100 min-h-screen p-4 sm:p-6 lg:p-8">      
      <div className="max-w-7xl mx-auto space-y-6">
        
        {/* Back Button Row */}
        <div className="flex justify-end">
          <button 
            type="button" 
            className="bg-white border border-gray-300 text-gray-700 font-medium py-2 px-4 rounded-lg hover:bg-gray-50 shadow-sm transition duration-150" 
            onClick={handleBack}
          >
            ← Back
          </button>
        </div>

        {/* New Detailed Header Section */}
        {renderHeaderSection()}

        {/* Content Layout - Two Columns for remaining cards */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Left Column */}
            <div className="space-y-6">
              {renderBasicInfoCard()}
                {renderPersonalDetailsCard()}
                {renderStatutoryFinancialCard()}
            </div>

            {/* Right Column */}
            <div className="space-y-6">
                {renderOrganizationStructureCard()}
                {renderWorkDetailsCard()}
            </div>
        </div>

      </div>
    </div>
  );
};

export default EmployeeDetailsPage;