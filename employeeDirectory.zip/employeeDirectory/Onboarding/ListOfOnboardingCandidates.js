import React, { useEffect, useState, useRef, useCallback } from "react";
import axios from "axios";
import * as XLSX from "xlsx";
import { saveAs } from "file-saver";
import { useNavigate, useLocation } from "react-router-dom";
import { FaDownload, FaSearch, FaPlus, FaUserCircle } from "react-icons/fa";
import { IoEyeSharp } from "react-icons/io5";
import { FaEdit, FaTrashAlt } from "react-icons/fa";
import Swal from "sweetalert2";
import {BASE_URL} from "../config";
// Import AddEmployee to use it as a modal
import AddEmployee from "./AddEmployee";

// Helper component for the modal overlay and positioning
const EditModalWrapper = ({ children, onClose }) => {
  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-gray-900 bg-opacity-75 flex items-center justify-center">
      {/* Increased max-w-7xl for a large form, and adjusted max-h for scrolling */}
      <div className="relative bg-white rounded-lg shadow-xl w-full max-w-7xl mx-4 my-8 max-h-[95vh] overflow-y-auto">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-600 hover:text-gray-900 z-10 p-2 text-3xl font-bold"
        >
          &times;
        </button>
        {children}
      </div>
    </div>
  );
};


const ListOfOnboardingCandidates = () => {
  const [employees, setEmployees] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [locationFilter, setLocationFilter] = useState("All Locations");
  const [departmentFilter, setDepartmentFilter] = useState("All Departments");
  const [statusFilter, setStatusFilter] = useState("All Status"); // excel export status filter
  const [showColumnsDropdown, setShowColumnsDropdown] = useState(false);
  const [selectedCandidateIds, setSelectedCandidateIds] = useState([]); // State for selected candidate IDs
  const dropdownRef = useRef(null); // Ref for the Choose Columns dropdown
  const navigate = useNavigate();
  const [exported, setExported] = useState(false);
  
  // State for Active/Inactive Tabs (Default to Active)
  const [activeTab, setActiveTab] = useState('Active'); 

  // State for Edit Modal
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [candidateToEdit, setCandidateToEdit] = useState(null); // Holds data of the candidate being edited

  // Define all available columns and their default visibility
  const allColumns = [
    { key: "select", label: "Select", visible: true }, 
    { key: "name", label: "Candidate Name", visible: true },
    { key: "email", label: "Email ID", visible: true },
    { key: "contact", label: "Contact No", visible: true },
    { key: "department", label: "Department", visible: true },
    { key: "designation", label: "Designation", visible: true },
    { key: "manager", label: "Manager", visible: true },
    { key: "overallStatus", label: "Status", visible: true },
    { key: "employeeStatus", label: "Candidate Status", visible: true },
    { key: "exportStatus", label: "Excel Export Status", visible: true },
    { key: "actions", label: "Actions", visible: true },
  ];
  const [visibleColumns, setVisibleColumns] = useState(allColumns);

  // Function to fetch data - Refactored to be callable
  const fetchData = useCallback(async () => {
    setLoading(true);
    try {
      // Fetch data from API
      const res = await axios.get(`${BASE_URL}:9034/api/onboarding/get/allCandidates`);
      const candidatesWithStatus = res.data.map(candidate => ({
          ...candidate,
          // Ensure default/existing status fields are populated
          excelExportStatus: candidate.employeeOnboardingInfo?.excelExportStatus || "Pending",
          // The employeeOnboardingInfo.status is used for the table column display, 
          // but overallStatus.overallStatus will be used for the Active/Inactive tab filtering.
          employeeOnboardingInfo: {
            ...candidate.employeeOnboardingInfo,
            status: candidate.employeeOnboardingInfo?.status || "Active" 
          }
      }));
      setEmployees(candidatesWithStatus);
    } catch (err) {
      console.error("Error fetching employee data:", err);
    } finally {
      setLoading(false);
    }
  }, []);

  // Fetch all onboarding candidates from API on mount
  useEffect(() => {
    fetchData();
  }, [fetchData]);

  // Close the columns dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setShowColumnsDropdown(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  const handleColumnToggle = (key) => {
    setVisibleColumns(
      visibleColumns.map((col) =>
        col.key === key ? { ...col, visible: !col.visible } : col
      )
    );
  };

  const handleSelectAllColumns = (e) => {
    const isChecked = e.target.checked;
    setVisibleColumns(
      visibleColumns.map((col) => ({ ...col, visible: isChecked }))
    );
  };

  // Function to handle individual candidate selection
  const handleCandidateSelection = (candidateId, isChecked) => {
    setSelectedCandidateIds(prevIds =>
      isChecked
        ? [...prevIds, candidateId] 
        : prevIds.filter(id => id !== candidateId)
    );
  };
  
  const handleEdit = (candidateData) => {
    setCandidateToEdit(candidateData);
    setIsEditModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsEditModalOpen(false);
    setCandidateToEdit(null);
    fetchData(); 
  };


  // Step 1: Filter employees based on the selected tab (Active/Inactive)
  // MODIFIED LOGIC: Use emp.overallStatus?.overallStatus for tab filtering.
  const tabFilteredEmployees = employees.filter((emp) => {
      // Use overallStatus.overallStatus for determining Active/Inactive tab placement
      const overallStatus = emp.overallStatus?.overallStatus; 
      
      if (activeTab === 'Active') {
          // Active tab: Show all candidates whose overallStatus is NOT 'InActive'
          return overallStatus !== 'InActive';
      } else { // activeTab === 'Inactive'
          // Inactive tab: Show only candidates whose overallStatus IS 'InActive'
          return overallStatus === 'InActive';
      }
  });


  // Step 2: Apply Search, Location, Department, and Export Status filters on the tab-filtered list
  const filteredEmployees = tabFilteredEmployees.filter((emp) => {
    const fullName = `${emp.personal?.firstName} ${emp.personal?.lastName}`.toLowerCase();
    const matchesSearch = fullName.includes(searchTerm.toLowerCase());
    const matchesLocation =
      locationFilter === "All Locations" || emp.employeeOnboardingInfo?.location === locationFilter;
    const matchesDepartment =
      departmentFilter === "All Departments" || emp.employeeOnboardingInfo?.mainDepartment === departmentFilter;
    const matchesStatus =
      statusFilter === "All Status" || emp.excelExportStatus === statusFilter;

    return matchesSearch && matchesLocation && matchesDepartment && matchesStatus;
  });

  // Get IDs of candidates that are filtered AND NOT 'Exported'
  const allSelectableFilteredIds = filteredEmployees
    .filter(emp => emp.excelExportStatus !== 'Exported')
    .map(emp => emp.personal?.candID)
    .filter(Boolean);

  // Check if all *selectable* filtered candidates are currently selected
  const allFilteredSelected = allSelectableFilteredIds.length > 0 &&
    allSelectableFilteredIds.every(id => selectedCandidateIds.includes(id));


  // Function to handle select all visible *selectable* candidates
  const handleSelectAllCandidates = (e) => {
    const isChecked = e.target.checked;
    
    setSelectedCandidateIds(prevIds => {
      if (isChecked) {
        // Add all selectable filtered IDs that are not already in the selection
        const newIds = [...new Set([...prevIds, ...allSelectableFilteredIds])];
        return newIds;
      } else {
        // Remove only the selectable IDs visible in the current filter
        return prevIds.filter(id => !allSelectableFilteredIds.includes(id));
      }
    });
  };

  const uniqueLocations = [...new Set(employees.map(emp => emp.employeeOnboardingInfo?.location).filter(Boolean))];
  const uniqueDepartments = [...new Set(employees.map(emp => emp.employeeOnboardingInfo?.mainDepartment).filter(Boolean))];
  const uniqueExportStatuses = [...new Set(employees.map(emp => emp.excelExportStatus).filter(Boolean))];

  // Calculate the total number of candidates pending export (only from Active Candidates)
  // MODIFIED LOGIC: Use overallStatus?.overallStatus !== 'InActive' for Active check
  const pendingExportCount = employees.filter(
      (emp) => emp.excelExportStatus === "Pending" && emp.overallStatus?.overallStatus !== 'InActive'
  ).length;

  // ------------------------- API CALL FUNCTIONS -------------------------
  
  // Helper to update Excel Export Status
  const updateCandidateImportStatus = async (candidateId, newStatus) => {
    const url = `${BASE_URL}:9034/api/onboarding/updateCandidatesDetails/${candidateId}`; 
    try {
      await axios.put(url, { excelExportStatus: newStatus });
    } catch (err) {
      console.error(`Failed to update status for candidate ${candidateId}:`, err);
    }
  };

  // Handler for Deactivate (Trash Icon) - shows a Swal.fire confirmation before deactivating
  const handleDelete = async (candID) => {
    Swal.fire({
      title: "Are you sure?",
      text: "This will deactivate the candidate and move them to the Inactive list.",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#dc2626", // red-600, matches the Deactivate action styling
      cancelButtonColor: "#6b7280", // gray-500
      confirmButtonText: "Yes, deactivate it!",
      cancelButtonText: "Cancel",
    }).then(async (result) => {
      if (!result.isConfirmed) return;

      try {
        // This API call likely updates the overallStatus to 'InActive' on the backend.
        await axios.put(`${BASE_URL}:9034/api/onboarding/candidates/${candID}/deactivate`);
        Swal.fire({
          title: "Deactivated!",
          text: "Candidate marked as InActive successfully.",
          icon: "success",
          confirmButtonColor: "#4338ca", // indigo-700
        });
        fetchData(); // refresh list to move the candidate to the Inactive tab
      } catch (error) {
        console.error(error);
        Swal.fire({
          title: "Failed",
          text: "Failed to deactivate candidate.",
          icon: "error",
          confirmButtonColor: "#4338ca",
        });
      }
    });
  };

  // Handler for Activate (Inactive tab) - same Swal.fire confirmation pattern as handleDelete above
  const handleActivateClick = (candidateData) => {
    const candID = candidateData.personal?.candID;

    Swal.fire({
      title: "Are you sure?",
      text: 'Are you sure you want to "activate" this candidate to "Active".',
      icon: "question",
      showCancelButton: true,
      confirmButtonColor: "#4338ca", // indigo-700, matches the Activate button styling
      cancelButtonColor: "#6b7280", // gray-500
      confirmButtonText: "Yes, activate it!",
      cancelButtonText: "Cancel",
    }).then(async (result) => {
      if (!result.isConfirmed) return;

      try {
        // API call to set status to 'Active'.
        const url = `${BASE_URL}:9034/api/onboarding/candidates/${candID}/activate`;
        await axios.put(url);

        Swal.fire({
          title: "Activated!",
          text: `Candidate ${candID} marked as Active successfully.`,
          icon: "success",
          confirmButtonColor: "#4338ca",
        });
        fetchData(); // Re-fetch data to move the candidate to the Active tab and update the table
      } catch (error) {
        console.error("Error activating candidate:", error);
        Swal.fire({
          title: "Failed",
          text: "Failed to activate candidate. Please ensure the backend API (/candidates/{candID}/activate) is available.",
          icon: "error",
          confirmButtonColor: "#4338ca",
        });
      }
    });
  };
  // --------------------------------------------------------------------------



  // Export to Excel for **Selected** candidates
  const exportSelectedToExcel = async () => {
    // CRITICAL: Prevent export if the Inactive tab is selected
    if (activeTab === 'Inactive') {
        alert("Only candidates from the 'Active' list can be exported.");
        setSelectedCandidateIds([]); // Clear selection
        return;
    }
    
    if (selectedCandidateIds.length === 0) {
      alert("Please select at least one candidate to download.");
      return;
    }

    // Filter the full employee list to get only the selected ones
    const selectedEmployees = employees.filter(emp => selectedCandidateIds.includes(emp.personal?.candID));

    // Map the selected employee data to a flattened format suitable for a single Excel sheet
    const formattedData = selectedEmployees.map((emp) => ({
      // Fields below are exactly (and only) the columns present in
      // user_create_or_update_template_6_v2, in the same order, using the
      // exact same header text (case/spacing/typos preserved). Columns with
      // no corresponding source field in our onboarding data are left blank.
      "Emp Code": "",
      "Full Name (As Per Aadhar)": [emp.personal?.firstName, emp.personal?.middleName, emp.personal?.lastName].filter(Boolean).join(" "),
      "Organization/ COMMON PROJECTany Code ": emp.employeeOnboardingInfo?.organisationCode || "",
      "COMMON PROJECTany / Organization Name  ": "",
      "Date Of Birth (Must be Encrypted)": emp.personal?.dob || "",
      "Age": "",
      "Personal Email Id": emp.personal?.emailAddr || "",
      "Personal Address ": "",
      "PAN                        (Must be Encrypted)": emp.documentProof?.panCard || "",
      " AADHAR No.                   (Must be Encrypted)": emp.documentProof?.aadharCard || "",
      "Gender": emp.employeeOnboardingInfo?.gender || "",
      "Blood Group": emp.personal?.bloodGroup || "",
      "Marital Status": emp.personal?.maritalStatus || "",
      "Primary Contact No": emp.personal?.permContactNum || "",
      "Official E-mail ID": emp.employeeOnboardingInfo?.officialEmailId || "",
      "Date of joining ": emp.employeeOnboardingInfo?.joiningDate || "",
      "Tenure in the Organization": "",
      "Probation Period ": emp.employeeOnboardingInfo?.probationPeriod || "",
      "Date of Confirmation": emp.employeeOnboardingInfo?.confirmationDate || "",
      "Generation Type ": "",
      "Employement Status": emp.employeeOnboardingInfo?.employmentStatus || "",
      "Designation / Job tile ": emp.employeeOnboardingInfo?.designation || "",
      "Job Location ": emp.employeeOnboardingInfo?.jobLocation || "",
      "State ": "",
      "Zone": "",
      "Department ": emp.employeeOnboardingInfo?.mainDepartment || "",
      "Department Description": "",
      "Sub-Department ": emp.employeeOnboardingInfo?.subDepartment || "",
      "Sub-Department Description": "",
      "Org Unit ": emp.employeeOnboardingInfo?.orgUnit || "",
      "WBS": "",
      "Project ": emp.employeeOnboardingInfo?.project || "",
      "Project Description": "",
      "Classification ": "",
      "Category ": emp.employeeOnboardingInfo?.category || "",
      "Reporting Manager (R1) E.Code": emp.employeeOnboardingInfo?.rptMgrEmployeeCode || "",
      "Reporting Manager (R1) Name ": emp.employeeOnboardingInfo?.rptManagerName || "",
      "Reporting Manager (R1) E-mail ID": emp.employeeOnboardingInfo?.rptManagerEmailId || "",
      "Reporting Manager (R2) ": "",
      "BU Head E.Code  ": "",
      "BU Head Name  ": emp.employeeOnboardingInfo?.buHead || "",
      "BU Head                      E-mail ID": "",
      "Payroll Area Type ": emp.employeeOnboardingInfo?.payrollAreaType || "",
      "Grade / Level ": emp.employeeOnboardingInfo?.grade || "",
      "EE SubGrp name": "",
      "Qualification ": emp.education?.highestQualification || "",
      "Certification (Need to give an Open Text to add certifications) ": "",
      "Primary Skills (Need to give an Open Text to add certifications) ": [
        emp.skill?.primarySkill1Name,
        emp.skill?.primarySkill2Name,
        emp.skill?.primarySkill3Name
      ].filter(Boolean).join(", "),
      "Secondary Skills (Need to give an Open Text to add certifications) ": [
        emp.skill?.secondarySkill1Name,
        emp.skill?.secondarySkill2Name,
        emp.skill?.secondarySkill3Name
      ].filter(Boolean).join(", "),
      "Tertiary Skills (Need to give an Open Text to add certifications)": "",
      "PF No.": emp.employeeOnboardingInfo?.currentPfNumber || "",
      "UAN ": emp.pf?.uan || "",
      "ESIC No.": emp.employeeOnboardingInfo?.currentESICNumber || "",
      "PT Applicablility (YES) ": "",
      "MLWF Applicablility ": "",
      "Group MediClaim (GMC) Applicaiblity (Applicable / Not Applicable )": "",
      "Group Term Life (GTL) Applicaiblity (Applicable / Not Applicable )": "",
      "Group Personal Accident (GPA) Applicaiblity (Applicable / Not Applicable )": "",
      "Resignation (YES / NO)": "",
      "Date of Leaving ": "",
      "Notice Period ": "",
      "Exit Status ": "",
    }));

   
    const ws = XLSX.utils.json_to_sheet(formattedData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Selected Active Candidates");

    XLSX.writeFile(wb, "SelectedActiveOnboardingCandidates.xlsx");
    
     
    try {
      await Promise.all(
        selectedCandidateIds.map(id => updateCandidateImportStatus(id, 'Exported'))
      );
      setEmployees(prevEmployees => 
          prevEmployees.map(emp => 
              selectedCandidateIds.includes(emp.personal?.candID)
                ? { ...emp, excelExportStatus: 'Exported' } 
                : emp
          )
      );
      
      setSelectedCandidateIds([]); 
      setExported(true);
      setTimeout(() => setExported(false), 3000);
      alert(`Successfully exported ${selectedCandidateIds.length} candidates and updated their status to 'Exported'.`);

    } catch (error) {
      console.error("Error during status update after export:", error);
      alert("Export successful, but there was an error updating candidate statuses on the server.");
    }
  };

// ...existing code...

  const handleClearFilters = () => {
    setSearchTerm("");
    setLocationFilter("All Locations");
    setDepartmentFilter("All Departments");
    setStatusFilter("All Status");
    setVisibleColumns(allColumns);
    setSelectedCandidateIds([]); 
  };


  // Helper function to render a status badge for Excel Import Status
  const renderStatusBadge = (status) => {
    let bgColor, textColor;
    switch (status) {
        case "Exported":
            bgColor = "bg-green-100";
            textColor = "text-green-800";
            break;
        case "Pending":
            bgColor = "bg-yellow-100";
            textColor = "text-yellow-800";
            break;
        case "Failed":
            bgColor = "bg-red-100";
            textColor = "text-red-800";
            break;
        default:
            bgColor = "bg-gray-100";
            textColor = "text-gray-800";
    }

    return (
        <span className={`px-2 py-1 rounded-full text-xs font-semibold ${bgColor} ${textColor}`}>
            {status || "N/A"}
        </span>
    );
  };
  // ---------------------------------------------

  return (
    <div className="p-6 bg-gray-100 min-h-screen">
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 border-t-4 border-t-indigo-700 p-6">
        <div className="flex items-center gap-3 mb-1">
          <span className="flex items-center justify-center h-9 w-9 rounded-lg bg-indigo-50 text-indigo-700 font-bold">
            <FaUserCircle size={20} />
          </span>
          <h2 className="text-2xl font-bold text-gray-800">Onboarding Candidates List</h2>
        </div>
        <p className="text-sm text-gray-400 ml-12 mb-4">Manage, review, and export employee onboarding records.</p>
        
        {/* Simple Tab Navigation */}
        <div className="flex border-b border-gray-200 mb-6">
            {['Active', 'Inactive'].map((tab) => (
                <button
                    key={tab}
                    onClick={() => {
                        setActiveTab(tab);
                        setSelectedCandidateIds([]); // Clear selection when switching tabs
                        // Reset all filters for a clean tab switch
                        setSearchTerm("");
                        setLocationFilter("All Locations");
                        setDepartmentFilter("All Departments");
                        setStatusFilter("All Status");
                    }}
                    className={`
                        py-2 px-4 text-sm font-semibold transition-colors duration-200 
                        ${activeTab === tab 
                            ? 'text-indigo-700 border-b-2 border-indigo-700' 
                            : 'text-gray-400 hover:text-gray-600'
                        }
                    `}
                >
                    {tab}
                </button>
            ))}
        </div>
        
        {/* Top bar with total employee count, Pending count, and Export button */}
        <div className="flex justify-between items-center mb-6 border-b border-gray-200 pb-4">
          
          {/* LEFT SIDE: Total Candidate Count */}
          <p className="text-sm font-medium text-gray-500">
            {activeTab} Candidates: <b className="text-2xl text-indigo-700 ml-1">{tabFilteredEmployees.length}</b>
            {tabFilteredEmployees.length !== filteredEmployees.length && (
              <span className="text-sm text-gray-400 ml-4">
                ({filteredEmployees.length} currently filtered)
              </span>
            )}
          </p>
          
          {/* RIGHT SIDE: Pending Count (Attractive Badge) and Export Button (Conditional) */}
          <div className="flex items-center space-x-4">
            
            {/* Conditional Rendering: Only show export tools on the Active tab */}
            {activeTab === 'Active' && (
              <>
                {/* Attractive Pending Export Display (Badge/Card) */}
                <div className="flex items-center space-x-2 px-4 py-2.5 bg-indigo-50 border border-indigo-200 rounded-lg">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-indigo-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                        <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                    </svg>
                    <span className="text-xs font-semibold text-indigo-700 uppercase tracking-wide">
                      Pending Export:
                    </span>
                    <span className="text-lg font-bold text-indigo-700">
                      {pendingExportCount}
                    </span>
                </div>

                {/* Export Button */}
                <button
                  onClick={exportSelectedToExcel} 
                  className="px-5 py-2.5 flex items-center bg-indigo-700 text-white text-sm font-semibold rounded-lg shadow-sm hover:bg-indigo-800 transition duration-200 disabled:opacity-50 disabled:shadow-none"
                  disabled={selectedCandidateIds.length === 0}
                >
                  <FaDownload className="mr-2" /> 
                  Export Selected ({selectedCandidateIds.length})
                </button>
              </>
            )}
          </div>
        </div>
        
        {/* Filter and Search Bar */}
        <div className="flex justify-between items-center mb-6 p-4 bg-gray-50 border border-gray-200 rounded-lg">
          <div className="flex items-center space-x-4 flex-1">
            <div className="relative flex-1">
              <FaSearch className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                placeholder="Search Candidates..."
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-600 focus:border-indigo-600"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>

            <select
              className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-600 focus:border-indigo-600"
              value={locationFilter}
              onChange={(e) => setLocationFilter(e.target.value)}
            >
              <option>All Locations</option>
              {uniqueLocations.map((loc) => (
                <option key={loc} value={loc}>
                  {loc}
                </option>
              ))}
            </select>

            <select
              className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-600 focus:border-indigo-600"
              value={departmentFilter}
              onChange={(e) => setDepartmentFilter(e.target.value)}
            >
              <option>All Departments</option>
              {uniqueDepartments.map((dept) => (
                <option key={dept} value={dept}>
                  {dept}
                </option>
              ))}
            </select>

            {/* Status filter (Excel Export Status) */}
            <select
              className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-600 focus:border-indigo-600"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
            >
              <option>All Status</option>
              {uniqueExportStatuses.map((excelExportStatus) => (
                <option key={excelExportStatus} value={excelExportStatus}>
                  {excelExportStatus}
                </option>
              ))}
            </select>
          </div>

          <div className="flex items-center space-x-2 ml-4">
            {/* Choose Columns button */}
            <div className="relative" ref={dropdownRef}>
              <button
                onClick={() => setShowColumnsDropdown(!showColumnsDropdown)}
                className="px-4 py-2 bg-white border border-gray-300 text-gray-700 text-sm font-medium rounded-lg hover:bg-gray-50 transition"
              >
                Choose Columns
              </button>
              {showColumnsDropdown && (
                <div className="absolute right-0 mt-2 w-64 p-4 bg-white border border-gray-200 rounded-lg shadow-lg z-10">
                  <h4 className="font-semibold mb-2 text-indigo-800 border-b border-indigo-100 pb-2">Select Columns to display</h4>
                  <div className="border-b border-gray-100 pb-2 mb-2">
                    <label className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        className="form-checkbox text-indigo-700 rounded"
                        checked={visibleColumns.every((col) => col.visible)}
                        onChange={handleSelectAllColumns} 
                      />
                      <span>Select All</span>
                    </label>
                  </div>
                  {allColumns.map((col) => (
                    <div key={col.key} className="mb-1">
                      <label className="flex items-center space-x-2">
                        <input
                          type="checkbox"
                          className="form-checkbox text-indigo-700 rounded"
                          checked={visibleColumns.find(c => c.key === col.key)?.visible || false}
                          onChange={() => handleColumnToggle(col.key)}
                        />
                        <span>{col.label}</span>
                      </label>
                    </div>
                  ))}
                  <button
                    onClick={() => setShowColumnsDropdown(false)}
                    className="mt-4 w-full py-2 bg-indigo-700 text-white text-sm font-semibold rounded-lg hover:bg-indigo-800 transition"
                  >
                    Submit
                  </button>
                </div>
              )}
            </div>
            <button
              onClick={handleClearFilters}
              className="px-4 py-2 text-gray-700 border border-gray-300 text-sm font-medium rounded-lg hover:bg-gray-50 transition"
            >
              Clear Filters
            </button>
          </div>
        </div>

        {loading ? (
          <p>Loading candidates...</p>
        ) : (
          <div className="overflow-x-auto rounded-lg border border-gray-200">
            <table className="min-w-full bg-white">
              <thead className="bg-gray-50">
                <tr className="text-left text-xs text-gray-500 uppercase tracking-wider">
                  {visibleColumns.filter(col => col.visible).map((col) => (
                    <th key={col.key} className="px-4 py-3 border-b-2 border-indigo-100 font-semibold">
                      {/* Logic for the 'Select All' checkbox in the header */}
                      {col.key === 'select' ? (
                        <input
                          type="checkbox"
                          className="form-checkbox h-4 w-4 text-indigo-700 rounded"
                          checked={allFilteredSelected}
                          onChange={handleSelectAllCandidates}
                          disabled={allSelectableFilteredIds.length === 0 || activeTab === 'Inactive'}
                        />
                      ) : (
                        col.label
                      )}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filteredEmployees.map((emp, index) => {
                  const candidateId = emp.personal?.candID;
                  const isSelected = selectedCandidateIds.includes(candidateId);
                  const isExported = emp.excelExportStatus === 'Exported'; 
                  // Check if the candidate is in the Inactive tab based on the new logic
                  const isInactive = emp.overallStatus?.overallStatus === 'InActive'; 

                  return (
                    <tr key={candidateId} className="border-b border-gray-100 hover:bg-indigo-50/40 transition-colors duration-200">
                      {visibleColumns.filter(col => col.visible).map((col) => (
                        <td key={col.key} className="p-4 text-sm text-gray-600">
                          {/* Checkbox Column (Select) */}
                          {col.key === "select" && (
                            <input
                              type="checkbox"
                              className="form-checkbox h-4 w-4 text-indigo-700 rounded"
                              checked={isSelected}
                              onChange={(e) => handleCandidateSelection(candidateId, e.target.checked)}
                              // Disabled logic remains based on 'isExported' and if it's the 'Inactive' tab
                              disabled={isExported || activeTab === 'Inactive'} 
                              title={isExported ? "Already exported" : activeTab === 'Inactive' ? "Cannot select inactive candidates for export" : "Select for export"}
                            />
                          )}

                          {col.key === "name" && (
                            <div className="flex items-center">
                              <img
                                src="https://via.placeholder.com/40"
                                alt="Profile"
                                className="w-8 h-8 rounded-full mr-3 border border-indigo-100"
                              />
                              <span className="font-semibold text-gray-800">
                                {emp.personal?.firstName} {emp.personal?.lastName}
                              </span>
                            </div>
                          )}
                          
                          {col.key === "email" && (emp.personal?.emailAddr || "N/A")}
                          {col.key === "contact" && (emp.personal?.curContactNum || "N/A")}
                          {col.key === "department" && (emp.employeeOnboardingInfo?.mainDepartment || "N/A")}
                          {col.key === "designation" && (emp.employeeOnboardingInfo?.designation || "N/A")}
                          {col.key === "manager" && (emp.employeeOnboardingInfo?.rptManagerName || "N/A")}

                          {col.key === "overallStatus" && (
                            <span
                              className={`px-2 py-1 rounded-full text-xs font-semibold ${emp.overallStatus?.overallStatus === "Initiated"
                                  ? "bg-yellow-100 text-yellow-800"
                                  : emp.overallStatus?.overallStatus === "HR-completed"
                                    ? "bg-green-100 text-green-800"
                                    : emp.overallStatus?.overallStatus === "InActive"
                                      ? "bg-red-100 text-red-800" // Added InActive style
                                      : "bg-gray-100 text-gray-800"
                                }`}
                            >
                              {emp.overallStatus?.overallStatus || "N/A"}
                            </span>
                          )}

                          {col.key === "employeeStatus" && (
                            // This column currently uses employeeOnboardingInfo?.status 
                            // which might be different from overallStatus?.overallStatus
                            <span
                              className={`px-2 py-1 rounded-full text-xs font-semibold ${emp.employeeOnboardingInfo?.status === "Active"
                                  ? "bg-green-100 text-green-800"
                                  : "bg-red-100 text-red-800"
                                }`}
                            >
                              {emp.employeeOnboardingInfo?.status || "N/A"}
                            </span>
                          )}

                          {/* Excel Export Status */}
                          {col.key === "exportStatus" && ( 
                            renderStatusBadge(emp.excelExportStatus)
                          )}
                          
                         {col.key === "actions" && (
                            <div className="flex space-x-3 items-center">
                              {isInactive ? (
                                // Show Activate button only when the candidate is InActive
                                <button
                                    onClick={() => handleActivateClick(emp)}
                                    className="px-3 py-1.5 text-xs font-semibold text-white bg-indigo-700 rounded-lg shadow-sm hover:bg-indigo-800 transition duration-150"
                                    title="Activate Candidate"
                                >
                                    Activate
                                </button>
                              ) : (
                                // Show View, Edit, and Deactivate button when the candidate is NOT InActive
                                <>
                                    {/* View Icon */}
                                    <button
                                        onClick={() => {
                                            navigate(`/OnboardingEmployeeDetails/${candidateId}`, { state: { employee: emp } });
                                        }}
                                        className="text-indigo-600 hover:text-indigo-800 transition-colors"
                                        title="View Candidate Details"
                                    >
                                        <IoEyeSharp size={18} />
                                    </button>

                                    {/* Edit Icon */}
                                    <button
                                        onClick={() => handleEdit(emp)} 
                                        className="text-gray-500 hover:text-indigo-700 transition-colors"
                                        title="Edit Candidate Details"
                                    >
                                        <FaEdit size={17} />
                                    </button>

                                    {/* Delete/Deactivate Icon */}
                                    <button
                                        onClick={() => handleDelete(candidateId)}
                                        className="text-red-600 hover:text-red-800 transition-colors"
                                        title="Deactivate Candidate (Move to Inactive list)"
                                    >
                                        <FaTrashAlt size={16} />
                                    </button>
                                </>
                              )}
                            </div>
                          )}
						  
                        </td>
                      ))}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
      
      {/* RENDER THE MODAL COMPONENT CONDITIONALLY */}
      {isEditModalOpen && candidateToEdit && (
        <EditModalWrapper onClose={handleCloseModal}>
          <AddEmployee 
             initialCandidateData={candidateToEdit}
             onClose={handleCloseModal}
          />
        </EditModalWrapper>
      )}

    </div>
  );
};

export default ListOfOnboardingCandidates;