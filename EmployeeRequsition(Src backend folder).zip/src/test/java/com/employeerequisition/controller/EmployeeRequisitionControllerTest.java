//package com.employeerequisition.controller;
//
//import static org.mockito.Mockito.when;
//import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
//import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
//import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
//import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
//
//import java.util.List;
//import java.util.stream.Collectors;
//
//import org.junit.jupiter.api.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
//import org.springframework.boot.test.mock.mockito.MockBean;
//import org.springframework.http.MediaType;
//
//import org.springframework.test.web.servlet.MockMvc;
//import com.employeerequisition.model.BillingType;
//import com.employeerequisition.model.EmployeeRequisition;
//import com.employeerequisition.model.EmploymentType;
//import com.employeerequisition.model.JobDescription;
//import com.employeerequisition.model.RequisitionType;
//import com.employeerequisition.service.EmployeeRequisitionServiceImpl;
//import com.employeerequisition.testdata.BiilingTypeTestData;
//import com.employeerequisition.testdata.EmployeeRequisitionTestData;
//import com.employeerequisition.testdata.EmploymentTypeTestData;
//import com.employeerequisition.testdata.JobDescriptionTestData;
//import com.employeerequisition.testdata.RequisitionTypeTestData;
//import com.fasterxml.jackson.databind.ObjectMapper;
//
//import static org.junit.jupiter.api.Assertions.assertTrue;
//
//@WebMvcTest(EmployeeRequisitionController.class)
//
//public class EmployeeRequisitionControllerTest {
//
//	@MockBean
//	EmployeeRequisitionServiceImpl employeeRequisitionService;
//
//	@Autowired
//	MockMvc mockMvc;
//
//	@Test
//	public void test_createNewEmployeeRequisition() throws Exception {
//		EmployeeRequisition employeeRequisition = EmployeeRequisitionTestData.createSampleEmployeeRequisition();
//		when(employeeRequisitionService.createNewEmployeeRequisition(employeeRequisition))
//				.thenReturn(employeeRequisition);
//		mockMvc.perform(post("/employeeRequisition/newEmployeeReuisition").contentType(MediaType.APPLICATION_JSON)
//				.content(new ObjectMapper().writeValueAsString(employeeRequisition))).andExpect(status().isOk());
//	}
//
//	@Test
//	public void test_getAllEmployeeRequisition() throws Exception {
//		List<EmployeeRequisition> employeeRequisitionList = EmployeeRequisitionTestData
//				.createSampleEmployeeRequisitionsList();
//
//		when(employeeRequisitionService.getAllEmployeeRequisition()).thenReturn(employeeRequisitionList);
//		mockMvc.perform(get("/employeeRequisition/getAllEmployeeRequisition").contentType(MediaType.APPLICATION_JSON))
//				.andExpect(status().isOk()).andExpect(jsonPath("$[0].employmentType").value("Trainee"));
//
//	}
//
//	@Test
//	public void test_searchEmp() throws Exception {
//		String searchCriteria = "Internal Transfer";
//
//		List<EmployeeRequisition> employeeRequisitionList = EmployeeRequisitionTestData
//				.createSampleEmployeeRequisitionsList();
//
//		// Filter the list based on search criteria
//		List<EmployeeRequisition> filteredList = employeeRequisitionList.stream().filter(
//				req -> req.getRequisitionType().equals(searchCriteria) || req.getPosition().equals(searchCriteria))
//				.collect(Collectors.toList());
//
//		// Mock the behavior of the service method
//		when(employeeRequisitionService.searchEmp(searchCriteria)).thenReturn(filteredList);
//
//		// Call the service method with the search criteria
//		List<EmployeeRequisition> result = employeeRequisitionService.searchEmp(searchCriteria);
//
//		// Assert that the result contains the expected requisition
//		assertTrue(result.stream().allMatch(
//				req -> req.getRequisitionType().equals(searchCriteria) || req.getPosition().equals(searchCriteria)));
//
//		// Perform the HTTP GET request with the correct URI template
//		mockMvc.perform(
//				get("/employeeRequisition/getValue/{search}", searchCriteria).contentType(MediaType.APPLICATION_JSON))
//				.andExpect(status().isOk()).andExpect(jsonPath("$[0].requisitionType").value("Internal Transfer"));
//	}
//
//	@Test
//	public void test_getAllBillingType() throws Exception {
//		List<BillingType> billingTypeList = BiilingTypeTestData.createBiilingTypeList();
//
//		when(employeeRequisitionService.getAllBillingType()).thenReturn(billingTypeList);
//		mockMvc.perform(get("/employeeRequisition/getAllBillingType").contentType(MediaType.APPLICATION_JSON))
//				.andExpect(status().isOk()).andExpect(jsonPath("$[1].billingTypeName").value("Non Billable"));
//
//	}
//
//	@Test
//	public void test_getAllEmploymentType() throws Exception {
//		List<EmploymentType> employmentTypeList = EmploymentTypeTestData.createEmploymentTypeList();
//
//		when(employeeRequisitionService.getAllEmploymentType()).thenReturn(employmentTypeList);
//		mockMvc.perform(get("/employeeRequisition/getAllEmploymentType").contentType(MediaType.APPLICATION_JSON))
//				.andExpect(status().isOk()).andExpect(jsonPath("$[0].employmentTypeName").value("Trainee"));
//
//	}
//
//	@Test
//	public void test_getAllJobDescription() throws Exception {
//		List<JobDescription> jobDescriptionList = JobDescriptionTestData.createSampleJobDescriptionList();
//
//		when(employeeRequisitionService.getAllJobDescription()).thenReturn(jobDescriptionList);
//		mockMvc.perform(get("/employeeRequisition/getAllJobDescription").contentType(MediaType.APPLICATION_JSON))
//				.andExpect(status().isOk()).andExpect(jsonPath("$[1].jobDescriptionName").value("Android Developer"));
//
//	}
//
//	@Test
//	public void test_getAllRequisitionType() throws Exception {
//		List<RequisitionType> requisitionTypeList = RequisitionTypeTestData.createSampleRequisitionTypeList();
//
//		when(employeeRequisitionService.getAllRequisitionType()).thenReturn(requisitionTypeList);
//		mockMvc.perform(get("/employeeRequisition/getAllRequisitionType").contentType(MediaType.APPLICATION_JSON))
//				.andExpect(status().isOk()).andExpect(jsonPath("$[1].requisitionTypeName").value("Additional Hire"));
//
//	}
//
//}
