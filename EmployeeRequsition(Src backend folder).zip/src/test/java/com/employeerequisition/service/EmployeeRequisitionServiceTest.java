//package com.employeerequisition.service;
//
//import static org.junit.jupiter.api.Assertions.assertEquals;
//import static org.junit.jupiter.api.Assertions.assertTrue;
//import static org.mockito.ArgumentMatchers.any;
//import static org.mockito.Mockito.when;
//
//import java.util.List;
//import java.util.stream.Collectors;
//
//import org.junit.jupiter.api.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.boot.test.mock.mockito.MockBean;
//
//import com.employeerequisition.model.BillingType;
//import com.employeerequisition.model.EmployeeRequisition;
//import com.employeerequisition.model.EmploymentType;
//import com.employeerequisition.model.JobDescription;
//import com.employeerequisition.model.RequisitionType;
//import com.employeerequisition.repository.BillingTypeRepository;
//import com.employeerequisition.repository.EmployeeRequisitionRepository;
//import com.employeerequisition.repository.EmploymentTypeRepository;
//import com.employeerequisition.repository.JobDescriptionRepository;
//import com.employeerequisition.repository.RequisitionTypeRepository;
//import com.employeerequisition.testdata.BiilingTypeTestData;
//import com.employeerequisition.testdata.EmployeeRequisitionTestData;
//import com.employeerequisition.testdata.EmploymentTypeTestData;
//import com.employeerequisition.testdata.JobDescriptionTestData;
//import com.employeerequisition.testdata.RequisitionTypeTestData;
//
//@SpringBootTest
//public class EmployeeRequisitionServiceTest {
//
//	@MockBean
//	EmployeeRequisitionRepository employeeRequisitionRepository;
//
//	@MockBean
//	BillingTypeRepository billingTypeRepository;
//
//	@MockBean
//	EmploymentTypeRepository employmentTypeRepository;
//
//	@MockBean
//	JobDescriptionRepository jobDescriptionRepository;
//
//	@MockBean
//	RequisitionTypeRepository requisitionTypeRepository;
//
//	@Autowired
//	EmployeeRequisitionServiceImpl employeeRequisitionService;
//
//	@Test
//	public void test_createNewEmployeeRequisition() {
//		EmployeeRequisition employeeRequisition = EmployeeRequisitionTestData.createSampleEmployeeRequisition();
//		when(employeeRequisitionRepository.save(employeeRequisition)).thenReturn(employeeRequisition);
//		assertEquals(employeeRequisition, employeeRequisitionService.createNewEmployeeRequisition(employeeRequisition));
//	}
//
//	@Test
//	public void test_getAllEmployeeRequisition() {
//		List<EmployeeRequisition> employeeRequisitionList = EmployeeRequisitionTestData
//				.createSampleEmployeeRequisitionsList();
//		when(employeeRequisitionRepository.findAll()).thenReturn(employeeRequisitionList);
//		assertEquals(2, employeeRequisitionService.getAllEmployeeRequisition().size());
//	}
//
//	@Test
//	public void test_searchEmp() {
//		String searchCriteria = "Developer";
//
//		List<EmployeeRequisition> employeeRequisitionList = EmployeeRequisitionTestData
//				.createSampleEmployeeRequisitionsList();
//
//		// Mock the behavior of the repository method
//		when(employeeRequisitionRepository.findBySearch(any())).thenReturn(employeeRequisitionList.stream().filter(
//				req -> req.getRequisitionType().equals(searchCriteria) || req.getPosition().equals(searchCriteria))
//				.collect(Collectors.toList()));
//
//		// Call the service method with the search criteria
//		List<EmployeeRequisition> result = employeeRequisitionService.searchEmp(searchCriteria);
//
//		// Assert that the result contains the expected requisition
//		assertEquals(1, result.size());
//		assertTrue(result.stream().allMatch(
//				req -> req.getRequisitionType().equals(searchCriteria) || req.getPosition().equals(searchCriteria)));
//	}
//
//	@Test
//	public void test_getAllBillingType() {
//		List<BillingType> billingTypeList = BiilingTypeTestData.createBiilingTypeList();
//		when(billingTypeRepository.findAll()).thenReturn(billingTypeList);
//		assertEquals(2, employeeRequisitionService.getAllBillingType().size());
//
//	}
//
//	@Test
//	public void test_getAllEmploymentType() {
//		List<EmploymentType> employmentTypeList = EmploymentTypeTestData.createEmploymentTypeList();
//		when(employmentTypeRepository.findAll()).thenReturn(employmentTypeList);
//		assertEquals(2, employeeRequisitionService.getAllEmploymentType().size());
//
//	}
//
//	@Test
//	public void test_getAllJobDescription() {
//		List<JobDescription> jobDescriptionList = JobDescriptionTestData.createSampleJobDescriptionList();
//		when(jobDescriptionRepository.findAll()).thenReturn(jobDescriptionList);
//		assertEquals(2, employeeRequisitionService.getAllJobDescription().size());
//
//	}
//
//	@Test
//	public void test_getAllRequisitionType() {
//		List<RequisitionType> requisitionTypeList = RequisitionTypeTestData.createSampleRequisitionTypeList();
//		when(requisitionTypeRepository.findAll()).thenReturn(requisitionTypeList);
//		assertEquals(2, employeeRequisitionService.getAllRequisitionType().size());
//
//	}
//
//
//
//}
