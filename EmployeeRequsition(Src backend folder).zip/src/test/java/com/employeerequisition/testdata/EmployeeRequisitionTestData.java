//package com.employeerequisition.testdata;
//
//
//
//import java.util.Arrays;
//import java.util.List;
//
//import com.employeerequisition.model.EmployeeRequisition;
//
//public class EmployeeRequisitionTestData {
//
//	public static EmployeeRequisition createSampleEmployeeRequisition() {
//		return new EmployeeRequisition(10L, "Internal Transfer", "2024-03-10", "Trainee", "Billable", "Replacement",
//				"9085678", "IREL", "GSD", "Mumbai", "700000", "SSD", "Developer", 6L, 5L, 6L, "B.Tech", "NA", "Pune",
//				"Saalim", "7909898", 3L, "NA", "NA", "NA", "NA", "NA", "NA", "NA", "NA", "NA", "NA", "NA", "NA", "NA",
//				"NA", "NA", "NA");
//	}
//
//	public static List<EmployeeRequisition> createSampleEmployeeRequisitionsList() {
//		return Arrays.asList(
//				new EmployeeRequisition(10L, "Internal Transfer", "2024-03-10", "Trainee", "Billable", "Replacement",
//						"9085678", "IREL", "GSD", "Mumbai", "700000", "SSD", "Developers", 6L, 5L, 6L, "B.Tech", "NA",
//						"Pune", "Saalim", "7909898", 3L, "NA", "NA", "NA", "NA", "NA", "NA", "NA", "NA", "NA", "NA",
//						"NA", "NA", "NA", "NA", "NA", "NA"),
//				new EmployeeRequisition(20L, "Additional Hire", "2024-03-10", "Trainee", "Billable", "Replacement",
//						"9085678", "IREL", "GSD", "Mumbai", "700000", "SSD", "Developer", 6L, 5L, 6L, "B.Tech", "NA",
//						"Pune", "Saalim", "7909898", 3L, "NA", "NA", "NA", "NA", "NA", "NA", "NA", "NA", "NA", "NA",
//						"NA", "NA", "NA", "NA", "NA", "NA"));
//	}
//}
//
