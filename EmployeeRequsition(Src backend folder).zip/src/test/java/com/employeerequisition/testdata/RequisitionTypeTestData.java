package com.employeerequisition.testdata;

import java.util.Arrays;
import java.util.List;

public class RequisitionTypeTestData {
	
	public static List<RequisitionType> createSampleRequisitionTypeList() {
		return Arrays.asList(
				new RequisitionType(10L,"Internal Transfer"),
				new RequisitionType(20L,"Additional Hire"));
	}

}
