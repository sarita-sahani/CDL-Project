package com.employeerequisition.testdata;

import java.util.Arrays;
import java.util.List;

import com.employeerequisition.model.BillingType;

public class BiilingTypeTestData {

	public static List<BillingType> createBiilingTypeList() {
		return Arrays.asList(new BillingType(10L, "Billable"), new BillingType(20L, "Non Billable"));
	}

}
