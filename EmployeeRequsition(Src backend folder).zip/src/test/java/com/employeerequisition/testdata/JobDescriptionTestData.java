package com.employeerequisition.testdata;

import java.util.Arrays;
import java.util.List;

public class JobDescriptionTestData {

	public static List<JobDescription> createSampleJobDescriptionList() {
		return Arrays.asList(new JobDescription(10L, "Alliance Manager"), new JobDescription(20L, "Android Developer"));
	}

}
