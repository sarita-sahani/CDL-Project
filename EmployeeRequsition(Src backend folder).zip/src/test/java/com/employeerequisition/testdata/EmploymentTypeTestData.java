package com.employeerequisition.testdata;

import java.util.Arrays;
import java.util.List;

public class EmploymentTypeTestData {

	public static List<EmploymentType> createEmploymentTypeList() {
		return Arrays.asList(new EmploymentType(10L, "Trainee"), new EmploymentType(20L, "Apprentice"));
	}

}
