package com.employeerequisition;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeRequisitionApplicationTests {

	@Test
	void contextLoads() {
	}

}
