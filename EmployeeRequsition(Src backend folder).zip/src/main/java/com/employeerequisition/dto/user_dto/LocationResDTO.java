package com.employeerequisition.dto.user_dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class LocationResDTO {
    private long locationId;
    private String country;
    private String region;
    private String state;
    private String zone;
    private String district;
    private String city;
    private String locationName;
    private Integer pinCode;
    private double latitude;
    private double longitude;
}
