package com.employeerequisition.dto.user_dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class EducationResDTO {
    private long educationId;
    private String name;
    private String fieldOfStudy;
    private String instituteName;
    private String instituteAddress;
    private Date academicStartYear;
    private Date academicEndYear;
    private String status;
    private String certificate;
    private String docName;
    private long educationDocId;
    private String qualification;
}
