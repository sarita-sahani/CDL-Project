package com.employeerequisition.dto.e_recruitment;

import lombok.Data;

@Data
public class JobRoleDetailsDTO {

    private String jobDescription;

    private String mandatorySkills;

    private String keyRoles;

    private String jdTemplate;
}