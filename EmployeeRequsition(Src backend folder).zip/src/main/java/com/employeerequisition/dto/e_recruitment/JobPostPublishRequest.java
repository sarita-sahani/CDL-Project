package com.employeerequisition.dto.e_recruitment;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import org.springframework.web.multipart.MultipartFile;

@Data
public class JobPostPublishRequest {

    // Workflow
    private Long wfSeqId;
    private String initiatorEmailId;
    private String intRefData;

    // Job Details
    private String jobRole;
    private String department;

    private Integer noOfPositions;

    // Experience

    @NotNull(message = "Minimum Experience is required")
    @Min(value = 0, message = "Minimum Experience should be a positive integer")
    private Integer expMin;

    @NotNull(message = "Maximum Experience is required")
    @Min(value = 0, message = "Maximum Experience should be a positive integer")
    private Integer expMax;

    private String education;
    private String certifications;
    private String location;
    private String hiringType;
    private String billingType;
    private String requisitionType;

    // Salary
    @NotNull(message = "Salary Budget is required")
    @DecimalMin(value = "0.0", message = "Salary Budget should be a valid decimal")
    private Float salaryBudget;

    @DecimalMin(value = "0.0", message = "Minimum Salary should be a valid decimal")
    private Float salaryMin;

    @DecimalMin(value = "0.0", message = "Maximum Salary should be a valid decimal")
    private Float salaryMax;

    @DecimalMin(value = "0.0", message = "CTC should be a valid decimal")
    private Float ctc;

    private String jobDescription;
    private String keySkills;
    private String additionalSkills;

    private String buHead;

    // External API
    private String jobType;
    private String jobStatus;
    private String publishType;
    private String keyRoles;
    private String otherLocations;
    private String hiringDept;
    private String custName;
    private String projCode;
    private String projName;
    private String projWave;
    private String resReqWave;
    private String leadTime;
    private String jobPriority;
    private String loginEmailId;

    // File
    private MultipartFile jdAttachment;
    private String jdTemplate;
}

//package com.employeerequisition.dto.e_recruitment;
//
//import lombok.Data;
//import org.springframework.web.multipart.MultipartFile;
//
//@Data
//public class JobPostPublishRequest {
//
//    // Workflow Details
//    private Long requisitionNumber;
//    private Long wfSeqId;
//    private String initiatorEmailId;
//    private String intRefData;
//
//    // Job Details
//    private String jobPostTitle;
//    private String jobPostDescription;
//    private String jobRole;
//    private String jobDescription;
//
//    private String department;
//    private String noOfPositions;
//
//    // Experience
//    private String expMin;
//    private String expMax;
//
//    // Qualification
//    private String education;
//    private String certifications;
//
//    // Skills
//    private String keySkills;
//    private String additionalSkills;
//    private String keyRoles;
//
//    // Location
//    private String location;
//    private String otherLocations;
//
//    // Hiring
//    private String hiringType;
//    private String hiringDept;
//    private String hiringManager;
//
//    // Requisition
//    private String billingType;
//    private String requisitionType;
//
//    // Salary
//    private String salaryMin;
//    private String salaryMax;
//    private String salaryBudget;
//    private String ctc;
//
//    // Publish Details
//    private String jobType;
//    private String jobStatus;
//    private String publishType;
//
//    // Project Details
//    private String custName;
//    private String projCode;
//    private String projName;
//    private String projWave;
//    private String resReqWave;
//
//    // Other Details
//    private String leadTime;
//    private String jobPriority;
//    private String applicationDeadline;
//    private String contactEmail;
//    private String buHead;
//
//    // JD Template Path (Optional)
//    //private String jdTemplate;
//
//    // Existing JOB_DOC path if any
//    private String jobDoc;
//
//    /**
//     * Uploaded JD Attachment
//     *
//     * React:
//     * formData.append("jdAttachment", file);
//     */
//    private MultipartFile jdAttachment;
//
//}

//==========================================//

//package com.employeerequisition.dto.e_recruitment;
//
//import lombok.Data;
//
//@Data
//public class JobPostPublishRequest {
//    //private Long requisitionNumber;
//    private Long wfSeqId;
//   // private String loginEmailId;
//    private String initiatorEmailId;
//
//    private String intRefData;
//    private String jobRole;
//    private String department;
//    private String noOfPositions;
////    private String experienceMin;
////    private String experienceMax;
//    private String education;
//    private String certifications;
//    private String location;
//    private String hiringType;
//    private String billingType;
//    private String requisitionType;
//    private String salaryBudget;
//    private String jobDescription;
//    private String keySkills;
//    private String additionalSkills;
//    private String hiringManager;
//    private String buHead;
//    private String ctc;
//
//    private String jobPostTitle;
//    private String jobPostDescription;
//    private String applicationDeadline;
//    private String contactEmail;
//
//    private String jobType;
//    private String jobStatus;
//    private String publishType;
//    private String jobDoc;
//    private String keyRoles;
//    private String otherLocations;
//    private String hiringDept;
//    private String expMin;
//    private String expMax;
//    private String salaryMin;
//    private String salaryMax;
//    private String custName;
//    private String projCode;
//    private String projName;
//    private String projWave;
//    private String resReqWave;
//    private String leadTime;
//    private String jobPriority;
//}