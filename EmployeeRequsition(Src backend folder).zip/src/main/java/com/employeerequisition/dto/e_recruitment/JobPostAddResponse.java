package com.employeerequisition.dto.e_recruitment;

import lombok.Data;

@Data
public class JobPostAddResponse {
    private int retcode;
    private String message;
    private String jobPostId;
}
