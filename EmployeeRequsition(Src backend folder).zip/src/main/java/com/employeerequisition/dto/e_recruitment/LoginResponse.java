package com.employeerequisition.dto.e_recruitment;

import lombok.Data;

@Data
public class LoginResponse {
    private String app_cfg_id;
    private String page_state;
    private String session_id;
    private String user_id;
    private String user_org;
    private String user_role;
}