package com.employeerequisition.dto.e_recruitment;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class UserDataResponse {
    private int retcode;
    private String message;
    private RetData retdata;

    @Data
    public static class RetData {

        private String userOrg;
        private String EmailID;
        private int Encrypt;
        private String JoinDate;
        private String JoinMonth;
        private String JoinQuarter;
        private int MemberDays;

        @JsonProperty("Password")
        private String Password;
        private String Remarks;
        private String UserHistory;
        @JsonProperty("UserID")
        private String userId;
        private String UserName;
        private String UserOrg;
        private String UserRole;
        private String UserStatus;
    }
}