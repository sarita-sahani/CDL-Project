package com.employeerequisition.dto.e_recruitment;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ItemValueDTO {
    private String value;
    private String label;
}
