package com.employeerequisition.dto.workflowDto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class WfItemStatusInfoDTO {

    private long wfItemSeqNum;
    private String wfItemName;
    private String wfItemType;
    private String status;
    private String subStatus;
    private Long wfSeqId;
    private int orderNum = 0;
    private String actorRemarks;
    private Date initialSubmitDate;
    private Date itemStartDate;
    private Date lastUpdatedDate;
    private String actorId;
    private int emailStatus=0;
    private String wfPrevListName;
}
