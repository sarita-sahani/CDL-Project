package com.employeerequisition.dto.workflowDto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.persistence.*;
import java.util.Date;

@NoArgsConstructor
@AllArgsConstructor

@Data
public class WFMainStatusInfo {
	@Id 
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long wfSeqId;
    private String wfSetName;
    private String overallStatus;
    private String empCode;
    private String userRole;
    private String userOrg;
    private Date initialSubmitDate;
    private Date lastUpdatedDate;
    private String Description;
    private String wbsId;
    private String wfInfo;

}
