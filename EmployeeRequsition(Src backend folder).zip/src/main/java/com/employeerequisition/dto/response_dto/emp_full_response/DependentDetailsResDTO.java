package com.employeerequisition.dto.response_dto.emp_full_response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class DependentDetailsResDTO {
    private long dependentDetailsId;
    private String dependentName;
    private String dependentRelationship;
    private LocalDate dependentDateOfBirth;
}
