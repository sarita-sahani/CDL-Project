package com.employeerequisition.dto.response_dto.emp_full_response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class EmpResDTO {
    private Long empId;
    private String empCode;
    private String firstName;
    private String middleName;
    private String lastName;
    private String emailId;
    private String fullNameAsAadhaar;
    private Long userId;
    private boolean status;
    private LocalDate dateOfJoining;
    private String dateOfBirth;
    private String bloodGroup;
    private String reportTo;
    private String reportingManager;
    private String buHeadName;
    private String reportingManagerEmailId;
    private String aboutEmp;
    private String gender;
    private long locationId;
    private int yearsCompleted;
    private String primaryContactNo;
    private String secondaryContactNo;
    private String emergencyContactNo;
    private String emergencyContactName;
    private String relationWithEmergencyContact;
    private String maritalStatus;
    private String description;
    private String expWithCurrentCompany;
    private String hiringHr;

    private MainDeptResDTO mainDeptResDTO;
    private SubDeptResDTO subDeptResDTO;
    private List<DependentDetailsResDTO> dependentDetailsResDTOS;
    private SalaryAccDetailsResDTO salaryAccDetailsResDTO;
    private DesignationResDTO designationResDTO;
    private OrganizationResDTO organizationResDTO;
    private ProjectResDTO projectResDTO;
    private OrgHierarchyResDTO orgHierarchyResDTO;
    private EmploymentStatusResDTO employmentStatusResDTO;
    private CategoryResDTO categoryResDTO;
 }
