package com.employeerequisition.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDate;

@Entity
@Table(name = "EmployeeRequisition_table")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class EmployeeRequisition {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long requisitionNumber;
	private String requisitionType;
	private String appliedOn;
	private String employmentType;

	private String projectName;
	private String projectManager;
	private String requirementName;
	private String reportingManager;
	private String publishType;
	private String jobPriority;
    private String leadTime;
	private String billingType;
	private String replacementType;
	private String employeeCode;
	private String replacementProject;
	private String replacementDepartment;
	private String replacementLocation;
	private String ctc;
	private Integer minimumExperienceRange;
	private Integer maximumExperienceRange;
	private Float salaryMin;
	private Float salaryMax;
	private Float budget;
	private String department;
	private String erecDeptCode;
	private String position;
	private Long experienceRange;
	private String education;
	private String certifications;
	private String jobLocation;
	private String otherJobLocation;
	private String reportingTo;

	private Long noOfPositions;
	private String selectedJob;
	private String jobDescription;
	private String requiredSkills;
	private String additionalSkills;
	private String itAsset;
	private String configuartions;
	private String additionalInformations;

//	private String firstLevelApprover;
//	private String secondLevelApprover;
	private String initiatorName;
	private String initiatorEmployeeCode;
	private String initiatorEmailId;
	private String initiatorDepartmentName;
	private String buHead;
	private String initiatorLocation;
	private String requisitionStatus;
	private String workflowName;
	private Long wfSeqId;
	@CreationTimestamp()
	private LocalDate createdDate;
	private Long wfItemSeqNum;

	private String jobPostId;
	@Column(name = "jd_attachment_path")
	private String jdAttachmentPath;

	private String keyRoles;

	private String jdTemplate;

}
