package com.employeerequisition.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "ITConfigurations")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ITConfigurationsTable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ItConfigurationId")
    private Long itConfigurationsId;
    @Column(name = "ITConfigurationsName")
    private String itConfigurationsName;
}
