package com.employeerequisition.model;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.persistence.*;

@Entity
@Table(name = "BillingType")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class BillingType {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "BillingTypeTypeId")
	private Long billingTypeId;
	@Column(name = "BillingTypeTypeName")
	private String billingTypeName;

}
