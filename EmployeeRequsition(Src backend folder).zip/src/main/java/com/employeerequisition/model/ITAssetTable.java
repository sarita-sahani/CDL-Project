package com.employeerequisition.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "ItAsset")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ITAssetTable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ItAssetId")
    private Long itAssetId;
    @Column(name = "ItAssetName")
    private String itAssetName;
}
