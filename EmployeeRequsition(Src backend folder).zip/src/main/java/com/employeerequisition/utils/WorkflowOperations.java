package com.employeerequisition.utils;

import com.employeerequisition.dto.workflowDto.WfItemStatusInfoDTO;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.List;

@Component("workflowOperations")
public class WorkflowOperations {
    private final WebClient webClient;

    public WorkflowOperations(@Value("${workflow.Base.API}") String baseUrl) {
        this.webClient = WebClient.builder()
                .baseUrl(baseUrl)
                .build();
    }

    // -------------------------------------------------
    // getAllPendingStatusItemList
    // -------------------------------------------------
    public List<WfItemStatusInfoDTO> getAllPendingStatusItemList(String empCode) {

        return webClient.get()
                .uri("/getAllPendingStatusItemList/{empCode}", empCode)
                .retrieve()
                .bodyToFlux(WfItemStatusInfoDTO.class)   // because List
                .collectList()
                .block();
    }


    // getOverallMainStatus
    // -------------------------------------------------
    public List<String> getOverallMainStatus(String empCode, String workflowName) {

        return webClient.get()
                .uri("/getOverallClaimMainStatus/{empCode}/{workflowName}",
                        empCode, workflowName)
                .retrieve()
                .bodyToFlux(String.class)   // because List<String>
                .collectList()
                .block();
    }
}
