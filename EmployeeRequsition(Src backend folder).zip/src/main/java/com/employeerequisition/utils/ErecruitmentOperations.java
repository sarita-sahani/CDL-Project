package com.employeerequisition.utils;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

import java.time.Duration;

@Slf4j
@Component
public class ErecruitmentOperations {

    @Value("${e-recruitment.base-url.api}")
    private String externalBaseUrl;

    @Value("${admin.user-id}")
    private String adminUserId;

    @Value("${admin.password}")
    private String adminPassword;

    private final WebClient webClient = WebClient.builder()
            .filter((request, next) -> {
                log.info("➡️ Outgoing request: {} {}", request.method(), request.url());
                return next.exchange(request);
            })
            .build();

    private final ObjectMapper objectMapper = new ObjectMapper()
            .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

    // cached session id, shared across every dropdown/item-values call
    private volatile String cachedSessionId;

    // ----- Server health check (ping) -----
    // Called before every fresh login attempt so we fail fast with a clear message
    // instead of letting the login call hang/timeout against a dead server.
    private boolean isServerUp() {
        String url = externalBaseUrl + "/ping?RetFormat=JSON&input_data=cdl";
        try {
            String response = webClient.get()
                    .uri(url)
                    .accept(MediaType.APPLICATION_JSON)
                    .retrieve()
                    .bodyToMono(String.class)
                    .timeout(Duration.ofSeconds(5))
                    .block();

            if (response == null || response.isBlank()) {
                log.error("❌ E-recruitment ping returned an empty response");
                return false;
            }

            JsonNode root = objectMapper.readTree(response);
            if (root.isArray() && root.size() > 0) root = root.get(0);
            int retcode = root.path("retcode").asInt(0);
            boolean up = retcode == 1;
            if (!up) {
                log.error("❌ E-recruitment ping responded but retcode={} (server considered down)", retcode);
            }
            return up;
        } catch (Exception e) {
            log.error("❌ E-recruitment ping failed: {}", e.getMessage());
            return false;
        }
    }

    /**
     * Public check other services can use to verify the e-recruitment server is reachable
     * before attempting any login-dependent call. Throws if the server is down.
     */
    public void ensureServerIsUp() {
        if (!isServerUp()) {
            throw new RuntimeException("E-recruitment service is down. Please try again later.");
        }
    }

    // ----- Authentication (unchanged) -----
    private String loginAdmin() {
        String url = externalBaseUrl + "/api/auth/login"
                + "?RetFormat=JSON&user_id=" + adminUserId + "&Password=" + adminPassword;
        String response = webClient.get()
                .uri(url)
                .accept(MediaType.APPLICATION_JSON)
                .retrieve()
                .bodyToMono(String.class)
                .block();
        return extractSessionId(response);
    }

    private String extractSessionId(String jsonResponse) {
        try {
            JsonNode root = objectMapper.readTree(jsonResponse);
            if (root.isArray() && root.size() > 0) root = root.get(0);
            JsonNode session = root.get("session_id");
            if (session != null && !session.isNull()) return session.asText();
            throw new RuntimeException("session_id not found");
        } catch (Exception e) {
            throw new RuntimeException("Failed to parse login response", e);
        }
    }


    private synchronized String getSessionId(boolean forceRefresh) {
        if (forceRefresh || cachedSessionId == null) {
            ensureServerIsUp();
            log.info("Logging in to e-recruitment system to obtain session id");
            cachedSessionId = loginAdmin();
        }
        return cachedSessionId;
    }

    /**
     * Public entry point for other services (e.g. JobPostPublishServiceImpl) to obtain
     * an admin session id, without duplicating the admin login logic themselves.
     * Reuses the cached session where possible.
     */
    public String getAdminSessionId() {
        return getSessionId(false);
    }

    /**
     * Forces a fresh admin login, bypassing the cache. Use when a cached session
     * has been found to be invalid/expired.
     */
    public String refreshAdminSessionId() {
        return getSessionId(true);
    }

    public String getItemValuesRaw(String itemListName) {
        String sessionId = getSessionId(false);
        String response = callItemValues(itemListName, sessionId);

        if (isSessionInvalid(response)) {
            log.info("Session appears invalid/expired, retrying with a fresh login");
            sessionId = getSessionId(true);
            response = callItemValues(itemListName, sessionId);
        }
        return response;
    }

    private String callItemValues(String itemListName, String sessionId) {
        String url = externalBaseUrl + "/api/system/itemvalues"
                + "?RetFormat=JSON&getter=true"
                + "&session_id=" + sessionId
                + "&user_id=" + adminUserId
                + "&item_list_name=" + itemListName
                + "&item_map_caption=true";

        return webClient.get()
                .uri(url)
                .accept(MediaType.APPLICATION_JSON)
                .retrieve()
                .bodyToMono(String.class)
                .block();
    }

    private boolean isSessionInvalid(String response) {
        if (response == null) {
            return true;
        }
        try {
            JsonNode root = objectMapper.readTree(response);
            int retcode = root.path("retcode").asInt(0);
            return retcode != 1;
        } catch (Exception e) {
            return false;
        }
    }

    public String getJobRoleDetails(String jobRole) {

        String sessionId = getSessionId(false);

        String response = callRoleSkillMap(jobRole, sessionId);

        if(isSessionInvalid(response)){
            sessionId = getSessionId(true);
            response = callRoleSkillMap(jobRole, sessionId);
        }

        return response;
    }

    private String callRoleSkillMap(String jobRole,String sessionId){

        String url = externalBaseUrl
                + "/api/system/itemvalues"
                + "?RetFormat=JSON"
                + "&getter=true"
                + "&session_id=" + sessionId
                + "&user_id=" + adminUserId
                + "&item_list_name=def.JobPost_ROLE_SKILL_MAP"
                + "&item_lookup_value=" + jobRole
                + "&item_lookup_map=true";

        return webClient.get()
                .uri(url)
                .retrieve()
                .bodyToMono(String.class)
                .block();

    }

    public byte[] downloadJdFile(String relativeFilePath) {
        String url = buildJdFileUrl(relativeFilePath);
        log.info("⬇️ Downloading JD file from: {}", url);

        byte[] fileBytes = webClient.get()
                .uri(url)
                .retrieve()
                .bodyToMono(byte[].class)
                .block();

        if (fileBytes == null || fileBytes.length == 0) {
            throw new RuntimeException("JD file not found or empty at: " + url);
        }
        return fileBytes;
    }

    private String buildJdFileUrl(String relativeFilePath) {
        if (relativeFilePath == null || relativeFilePath.isBlank()) {
            throw new IllegalArgumentException("File path must not be empty");
        }
        String jdFileBaseUrl = externalBaseUrl + "/download/files/jobdesc/";
        String base = jdFileBaseUrl.endsWith("/") ? jdFileBaseUrl : jdFileBaseUrl + "/";
        String path = relativeFilePath.startsWith("/") ? relativeFilePath.substring(1) : relativeFilePath;
        return base + path;
    }
}