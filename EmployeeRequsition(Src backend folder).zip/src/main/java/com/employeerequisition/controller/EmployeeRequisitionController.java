package com.employeerequisition.controller;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;

import com.employeerequisition.beans.emp_user_bean.EmpAndUserResponse;
import com.employeerequisition.dto.e_recruitment.ItemValueDTO;
import com.employeerequisition.model.*;
import com.employeerequisition.service.ItemValueService;
import com.employeerequisition.utils.WorkflowOperations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.employeerequisition.service.EmployeeRequisitionService;

@RestController
@CrossOrigin("*")
@RequestMapping("/api/employeeRequisition")
public class EmployeeRequisitionController {

	@Autowired
	EmployeeRequisitionService employeeRequisitionService;

	@Autowired
	ItemValueService itemValueService;



	//localhost:9024/employeeRequisition/getEmployeeInfo/
		@GetMapping("/getEmployeeInfo/{empCode}")
	public ResponseEntity<?> getByempCode(@PathVariable("empCode") String empCode) throws ExecutionException, InterruptedException {
		EmpAndUserResponse employeeDetails = employeeRequisitionService.getEmpInfoByEmpCode(empCode);
		if (employeeDetails != null) {
			return ResponseEntity.ok(employeeDetails);
		} else {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body("empId not exist");
		}
	}

	@PostMapping("/saveNewEmployeeRequisitionReq/{empCode}/{workflowName}")
	public ResponseEntity<String> createNewEmployeeRequisition(@RequestBody EmployeeRequisition employeeRequisition,  @PathVariable String empCode, @PathVariable String workflowName) {
		EmployeeRequisition newEmployeeRequisition = employeeRequisitionService
				.createNewEmployeeRequisition(employeeRequisition,empCode, workflowName);
		if (newEmployeeRequisition != null) {
			return ResponseEntity.ok("Data is added");
		} else {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Data is not added");
		}
	}

	@GetMapping("/getAllEmployeeRequisition")
	public ResponseEntity<?> getAllEmployeeRequisition() {
		List<EmployeeRequisition> newEmployeeRequisitionList = employeeRequisitionService.getAllEmployeeRequisition();
		if (newEmployeeRequisitionList != null) {
			return ResponseEntity.ok(newEmployeeRequisitionList);
		} else {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Data is not found");
		}
	}

	@GetMapping("/getValue/{search}")
	public ResponseEntity<?> searchEmp(@PathVariable("search") String search) {
		return new ResponseEntity<>(employeeRequisitionService.searchEmp(search), HttpStatus.OK);
	}

	@GetMapping("/getAllBillingType")
	public ResponseEntity<?> getAllBillingType() {
		List<BillingType> billingTypeList = employeeRequisitionService.getAllBillingType();
		if (billingTypeList != null) {
			return ResponseEntity.ok(billingTypeList);
		} else {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Data is not found");
		}
	}




	@GetMapping("/getAllITAsset")
	public ResponseEntity<?> getAllITAsset() {
		List<ITAssetTable> itAssetTableList = employeeRequisitionService.getAllITAsset();
		if (itAssetTableList != null) {
			return ResponseEntity.ok(itAssetTableList);
		} else {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Data is not found");
		}
	}

	@GetMapping("/getAllITConfigurations")
	public ResponseEntity<?> getAllITConfigurations() {
		List<ITConfigurationsTable> itConfigurationsList = employeeRequisitionService.getAllITConfigurations();
		if (itConfigurationsList != null) {
			return ResponseEntity.ok(itConfigurationsList);
		} else {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Data is not found");
		}
	}


	// Generic dropdown fetch from the external system.
	// Only the last path segment changes per dropdown, e.g.:
	//   GET /api/employeeRequisition/getItemValues/JOB_TYPE
	//   GET /api/employeeRequisition/getItemValues/JOB_PRIORITY
	//   GET /api/employeeRequisition/getItemValues/JOB_ROLE
	// which internally map to def.JobPost_JOB_TYPE, def.JobPost_JOB_PRIORITY, etc.
	@GetMapping("/getItemValues/{itemListName}")
	public ResponseEntity<?> getItemValues(@PathVariable String itemListName) {
		try {
			List<ItemValueDTO> values = itemValueService.getItemValues("def.JobPost_" + itemListName);
			return ResponseEntity.ok(values);
		} catch (Exception e) {
			return ResponseEntity
					.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body("Failed to fetch item values for " + itemListName + ": " + e.getMessage());
		}
	}

	@GetMapping("/getJobRoleDetails/{jobRole}")
	public ResponseEntity<?> getJobRoleDetails(
			@PathVariable String jobRole){

		try{

			return ResponseEntity.ok(
					itemValueService.getJobRoleDetails(jobRole));

		}catch(Exception e){

			return ResponseEntity
					.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body(e.getMessage());

		}

	}
//http:lpcalhost:9024/employeeRequisition/getSingleEmployeeRequistionData/
	@GetMapping("/getSingleEmployeeRequistionData/{id}")
	public ResponseEntity<EmployeeRequisition> getEmployeeRequisitionDataByErfId(@PathVariable("id") Long erfId) {
		EmployeeRequisition data = employeeRequisitionService.getEmployeeRequisitionDataByErfId(erfId);
		return ResponseEntity.ok(data);
	}

	//for approval of the requisition
	//http:localhost:9024/employeeRequisition/requisitionStatus/

	@PostMapping("/requisitionStatus/{id}")
	public ResponseEntity<?> processAction(
			@PathVariable Long id,
			@RequestBody Map<String, String> request) {
		try {
			String action = request.get("action"); // "APPROVE" or "REJECT"
			String comments = request.get("comments");

			EmployeeRequisition updated =
					employeeRequisitionService.updateApprovalStatus(id, action, comments);

			return ResponseEntity.ok(updated);

		} catch (IllegalArgumentException e) {
			return ResponseEntity.badRequest().body(e.getMessage());

		} catch (Exception e) {
			return ResponseEntity
					.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body("Error processing requisition");
		}
	}

	@GetMapping("/getEmpRequisitionFormDetails/{workFlowName}")
	public ResponseEntity<?> getEmpRequisitionFormDetails(@PathVariable String workFlowName) {
		System.out.println("Emp Requisition wf name................. " + workFlowName);

		EmployeeRequisition obj = employeeRequisitionService.getEmpRequisitionFormDetails(workFlowName);
		System.out.println("Entered into Requisition Form Mode................. " + obj);
		return new ResponseEntity<>(obj, HttpStatus.CREATED);
//		return new ResponseEntity<>(travelService.getClaimTypeDetails(claimType), HttpStatus.CREATED);
	}

	@PostMapping("/saveWfSeqIdInRequisitionTable/{empCode}/{wfSeqId}")
	public ResponseEntity<?> saveWfSeqIdinRequisitionTable(@PathVariable String empCode, @PathVariable Long wfSeqId) {
		//System.out.println("Entered into mediclaim claimType................. "+ claimType);
		EmployeeRequisition obj = employeeRequisitionService.SaveWfSeqIdinRequisitionTable(empCode, wfSeqId);
		System.out.println("Entered into Requisition data................. " + obj);
		return new ResponseEntity<>(obj, HttpStatus.CREATED);


	}

	@GetMapping("/getRequisitionFormDetailsByWfSeqId/{wfSeqId}")
	public ResponseEntity<?> getRequisitionFormDetailsByWfSeqId(@PathVariable Long wfSeqId) {
		EmployeeRequisition obj = employeeRequisitionService.getRequisitionFormDetailsByWfSeqId(wfSeqId);
		System.out.println("Entered into conveyance claimType................. " + obj);
		return new ResponseEntity<>(obj, HttpStatus.CREATED);
//		return new ResponseEntity<>(travelService.getClaimTypeDetails(claimType), HttpStatus.CREATED);
	}

	//http:localhost:9024/apiemployeeRequisition/getEmpRequisitionPendingList
	// Controller method for getting the list of Requisition request
	@GetMapping("getEmpRequisitionPendingList/{empCode}")
	public ResponseEntity<?> getEmpRequisitionPendingList(@PathVariable String empCode) {
		// Retrieve exit employee list from the service
		return new ResponseEntity<>(employeeRequisitionService.getEmpRequisitionPendingList(empCode), HttpStatus.OK);
	}
}
