package com.employeerequisition.controller;

import com.employeerequisition.dto.e_recruitment.JobPostAddResponse;
import com.employeerequisition.dto.e_recruitment.JobPostPublishRequest;
import com.employeerequisition.service.JobPostPublishService;
import com.employeerequisition.utils.ErecruitmentOperations;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
@CrossOrigin("*")
@RequestMapping("/api/jobpost")
@RequiredArgsConstructor
@Slf4j
public class JobPostController {

    private final JobPostPublishService publishService;
    private final ErecruitmentOperations erecruitmentOperations;

    @PostMapping(value = "/publish", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<JobPostAddResponse> publishJobPost(@Valid @ModelAttribute JobPostPublishRequest request) {
        log.info("Received publish request with initiatorEmailId: {}, file present: {}",
                request.getInitiatorEmailId(),
                request.getJdAttachment() != null && !request.getJdAttachment().isEmpty());
        JobPostAddResponse response = publishService.publishJobPost(request);
        return ResponseEntity.ok(response);
    }
//localhost:9024/api/jobpost/downloadJd
    @GetMapping("/downloadJd")
    public ResponseEntity<byte[]> downloadJd(
            @RequestParam("filePath") String filePath,
            @RequestParam(value = "mode", defaultValue = "download") String mode) {

        byte[] fileBytes = erecruitmentOperations.downloadJdFile(filePath);

        String fileName = filePath.contains("/")
                ? filePath.substring(filePath.lastIndexOf('/') + 1)
                : filePath;

        MediaType contentType = resolveContentType(fileName);
        String disposition = "view".equalsIgnoreCase(mode) ? "inline" : "attachment";

        return ResponseEntity.ok()
                .contentType(contentType)
                .header(HttpHeaders.CONTENT_DISPOSITION, disposition + "; filename=\"" + fileName + "\"")
                .body(fileBytes);
    }

    private MediaType resolveContentType(String fileName) {
        String lower = fileName.toLowerCase();
        if (lower.endsWith(".pdf")) {
            return MediaType.APPLICATION_PDF;
        }
        if (lower.endsWith(".docx")) {
            return MediaType.parseMediaType(
                    "application/vnd.openxmlformats-officedocument.wordprocessingml.document");
        }
        if (lower.endsWith(".doc")) {
            return MediaType.parseMediaType("application/msword");
        }
        return MediaType.APPLICATION_OCTET_STREAM;
    }
}