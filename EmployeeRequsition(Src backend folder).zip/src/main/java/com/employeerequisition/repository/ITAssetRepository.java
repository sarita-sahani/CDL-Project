package com.employeerequisition.repository;

import com.employeerequisition.model.ITAssetTable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ITAssetRepository extends JpaRepository<ITAssetTable, Long> {
}
