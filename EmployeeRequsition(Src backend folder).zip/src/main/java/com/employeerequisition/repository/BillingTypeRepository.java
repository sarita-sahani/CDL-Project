package com.employeerequisition.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.employeerequisition.model.BillingType;

public interface BillingTypeRepository extends JpaRepository<BillingType, Long> {

}
