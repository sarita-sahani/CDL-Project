package com.employeerequisition.repository;

import com.employeerequisition.model.ITConfigurationsTable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ITConfigurationsRepository extends JpaRepository<ITConfigurationsTable, Long> {
}
