package com.employeerequisition.repository;

import java.util.List;
import java.util.Optional;

import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.employeerequisition.model.EmployeeRequisition;

public interface EmployeeRequisitionRepository extends JpaRepository<EmployeeRequisition, Long> {

	@Query(value = "select * from public.employee_requisition_table where "
			+ "CONCAT(requisition_number, ' ' , requisition_type, ' ' , position) LIKE %:search%", nativeQuery = true)
	List<EmployeeRequisition> findBySearch(@Param("search") String search);

	Optional<EmployeeRequisition> getRequisitionByRequisitionNumber(Long id);

    List<EmployeeRequisition> findByWorkflowName(String workFlowName);

	@Query("SELECT sm FROM EmployeeRequisition sm WHERE sm.requisitionNumber = (" +
			"SELECT MAX(sm2.requisitionNumber) FROM EmployeeRequisition sm2 WHERE sm2.employeeCode = :employeeCode)")
	List<EmployeeRequisition> findDataByEmployeeCode(@Param("employeeCode") String empCode);
	EmployeeRequisition findByWfSeqId(Long wfSeqId);

	@Modifying
	@Transactional
	@Query("UPDATE EmployeeRequisition e SET e.jobPostId = :jobPostId WHERE e.requisitionNumber = :reqNo AND e.wfSeqId = :wfSeqId")
	void updateJobPostId(@Param("reqNo") Long requisitionNumber,
						 @Param("wfSeqId") Long wfSeqId,
						 @Param("jobPostId") String jobPostId);


}
