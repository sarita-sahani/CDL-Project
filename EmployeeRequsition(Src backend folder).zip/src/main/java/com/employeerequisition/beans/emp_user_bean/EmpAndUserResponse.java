package com.employeerequisition.beans.emp_user_bean;
import com.employeerequisition.beans.emp_bean.FileAndObjectTypeBean;
import com.employeerequisition.dto.user_dto.UserResDTO;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class EmpAndUserResponse {
    private FileAndObjectTypeBean fileAndObjectTypeBean;
    private UserResDTO userDTO;

    // Getters and setters
    @JsonProperty("fileAndObjectTypeBean")
    public FileAndObjectTypeBean getFileAndObjectTypeBean() {
        return fileAndObjectTypeBean;
    }

    public void setFileAndObjectTypeBean(FileAndObjectTypeBean fileAndObjectTypeBean) {
        this.fileAndObjectTypeBean = fileAndObjectTypeBean;
    }

    @JsonProperty("userDTO")
    public UserResDTO getUserDTO() {
        return userDTO;
    }

    public void setUserDTO(UserResDTO userDTO) {
        this.userDTO = userDTO;
    }
}
