package com.employeerequisition.beans.emp_bean;

import com.employeerequisition.beans.file_bean.FileAndContentTypeBean;
import com.employeerequisition.dto.response_dto.emp_full_response.EmpResDTO;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class FileAndObjectTypeBean {
    FileAndContentTypeBean fileAndContentTypeBean;
    EmpResDTO empResDTO;
}
