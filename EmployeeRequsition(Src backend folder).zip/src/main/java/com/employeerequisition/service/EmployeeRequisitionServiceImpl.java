package com.employeerequisition.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.ExecutionException;

import com.employeerequisition.beans.emp_user_bean.EmpAndUserResponse;
import com.employeerequisition.dto.workflowDto.WfItemStatusInfoDTO;
import com.employeerequisition.model.*;
import com.employeerequisition.repository.*;
import com.employeerequisition.utils.EmployeeOperations;
import com.employeerequisition.utils.WorkflowOperations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.employeerequisition.email.EmailUtils;

@Service
public class EmployeeRequisitionServiceImpl implements EmployeeRequisitionService {

	@Autowired
	EmployeeRequisitionRepository employeeRequisitionRepository;

	@Autowired
	EmailUtils emailUtils;

	@Autowired
	BillingTypeRepository billingTypeRepository;



	@Autowired
	ITAssetRepository itAssetRepository;

	@Autowired
	ITConfigurationsRepository itConfigurationsRepository;


	@Autowired
	private EmployeeOperations employeeOperations;

	@Autowired
	private WorkflowOperations workflowOperations;

	@Override
	public EmpAndUserResponse getEmpInfoByEmpCode(String empCode) throws ExecutionException, InterruptedException {
		return employeeOperations.getEmpByEmpCode(empCode);
	}


	/**
	 *
	 * @param employeeRequisition
	 * @return
	 */

	public EmployeeRequisition createNewEmployeeRequisition(EmployeeRequisition employeeRequisition, String empCode, String workflowName) {
		try {
			// Set values from path variables
			employeeRequisition.setEmployeeCode(empCode);
			employeeRequisition.setWorkflowName(workflowName);
			employeeRequisition.setRequisitionStatus("Open");

			EmployeeRequisition savedRequisition = employeeRequisitionRepository.save(employeeRequisition);
			System.out.println("Employee requsition===="+savedRequisition);
//			// Email Logic
//			if (savedRequisition.getRequisitionType() != null) {
//				emailUtils.sendEmail("cmstest31@gmail.com", "New Requisition", "Body content...");
//			}

			return savedRequisition;

		} catch (Exception e) {
			// This message will be caught by the @RestControllerAdvice
			throw new RuntimeException("Failed to save requisition: " + e.getMessage());
		}
	}

	/**
	 *
	 * @return
	 */

	public List<EmployeeRequisition> getAllEmployeeRequisition() {
		List<EmployeeRequisition> newEmployeeRequisitionList = employeeRequisitionRepository.findAll();
		return newEmployeeRequisitionList;
	}

	/**
	 *
	 * @param search
	 * @return
	 */

	public List<EmployeeRequisition> searchEmp(String search) {
		return employeeRequisitionRepository.findBySearch(search);
	}


	public List<BillingType> getAllBillingType() {

		List<BillingType> billingTypeList = billingTypeRepository.findAll();
		return billingTypeList;

	}

@Override
	public List<ITAssetTable> getAllITAsset() {

		List<ITAssetTable> itAssetTableList = itAssetRepository.findAll();
		return itAssetTableList;

	}
@Override
	public List<ITConfigurationsTable> getAllITConfigurations() {

		List<ITConfigurationsTable> configurationsTableListList = itConfigurationsRepository.findAll();
		return configurationsTableListList;

	}



	@Override
	public EmployeeRequisition getEmployeeRequisitionDataByErfId(Long erfId) {
		return employeeRequisitionRepository.getRequisitionByRequisitionNumber(erfId)
				.orElseThrow(() -> new RuntimeException("ERF Data not found for ID: " + erfId));
	}

	@Override
	public EmployeeRequisition updateApprovalStatus(Long id, String action, String comments) {
		Optional<EmployeeRequisition> existingReq = employeeRequisitionRepository.getRequisitionByRequisitionNumber(id);

		if (existingReq.isPresent()) {
			EmployeeRequisition req = existingReq.get();

			if ("REJECT".equalsIgnoreCase(action)) {
				// Business Logic: Reject requires comments
				if (comments == null || comments.trim().isEmpty()) {
					throw new IllegalArgumentException("Comments are required for rejection.");
				}
//				req.setApprovalStatus("Rejected");
//				req.setOverallStatus("Closed");
			} else if ("APPROVE".equalsIgnoreCase(action)) {

//				req.setApprovalStatus("Approved");
//				req.setOverallStatus("Completed");
			}

			// Note: You may want to add a 'comments' field to your Entity
			// to store these remarks permanently.
			return employeeRequisitionRepository.save(req);
		} else {
			throw new RuntimeException("Requisition not found with ID: " + id);
		}
	}

	@Override
	public EmployeeRequisition getEmpRequisitionFormDetails(String workFlowName) {
		EmployeeRequisition employeeRequisitionObj = null;
		System.out.println("FormMode:::::::::::::;: " + workFlowName);
		List<EmployeeRequisition> employeeRequisitionList = employeeRequisitionRepository.findByWorkflowName(workFlowName);
		if (employeeRequisitionList == null || employeeRequisitionList.isEmpty()) {
			System.out.println("No items found for formMode: " + workFlowName);
		} else {
			for (int i = 0; i < employeeRequisitionList.size(); i++) {
				employeeRequisitionObj = employeeRequisitionList.get(i);

			}
		}
		System.out.println("ESeperation Claim Final Oject: " + employeeRequisitionObj);
		return employeeRequisitionObj;
	}

	@Override
	public EmployeeRequisition SaveWfSeqIdinRequisitionTable(String empCode, Long wfSeqId) {
		EmployeeRequisition requisitionDetailsObj = null;
		System.out.println("WfSeqId from main Status:::::::::::::;: " + wfSeqId);
		//Optional<ResignationDetails> seqIdFOrResignationDetailsTable = resignationRepository.findByEmpId(empCode);
		List<EmployeeRequisition> ListOfseqIdFOrRequisitionDetailsTableData = employeeRequisitionRepository.findDataByEmployeeCode(empCode);

		EmployeeRequisition seqIdFOrRequisitionDetailsTableData= new EmployeeRequisition();
		System.out.println("ListOfseqIdFOrRequisitionDetailsTableData:::::" +ListOfseqIdFOrRequisitionDetailsTableData);
		for(int i=0;i<=ListOfseqIdFOrRequisitionDetailsTableData.size()-1;i++){
			seqIdFOrRequisitionDetailsTableData = ListOfseqIdFOrRequisitionDetailsTableData.get(i);
		}
		System.out.println("seqIdFOrRequisitionDetailsTableData:::::" +seqIdFOrRequisitionDetailsTableData);

		seqIdFOrRequisitionDetailsTableData.setWfSeqId(wfSeqId);
		requisitionDetailsObj = employeeRequisitionRepository.save(seqIdFOrRequisitionDetailsTableData);
//		System.out.println("TRAVEL CLAIM List:::::::::: "+travelFormobjList);
		System.out.println("Requisition ::  with seqId::::::; " + requisitionDetailsObj);
		return requisitionDetailsObj;
	}

	@Override
	public EmployeeRequisition getRequisitionFormDetailsByWfSeqId(Long wfSeqId) {
		EmployeeRequisition requisitionFormDetailsObj = employeeRequisitionRepository.findByWfSeqId(wfSeqId);
		System.out.println("Requisition Object::"+requisitionFormDetailsObj);
		return requisitionFormDetailsObj;
	}

	//for displaying conveyance claim  data//
	@Override
	public List<EmployeeRequisition> getEmpRequisitionPendingList(String empCode) {
		List<EmployeeRequisition> empRequisitionReqForParticularUsers = new ArrayList<>();

		// Fetch status item list using the web client
		List<WfItemStatusInfoDTO> statusItemList = workflowOperations.getAllPendingStatusItemList(empCode);
		System.out.println("getEmpRequisitionPendingList" + statusItemList);

		for (WfItemStatusInfoDTO statusInfo : statusItemList) {
			Long wfSeqId = statusInfo.getWfSeqId();
			Long wfItemSeqNum = statusInfo.getWfItemSeqNum(); // 👈 Get item seq number

			EmployeeRequisition empRequisitionReq = employeeRequisitionRepository.findByWfSeqId(wfSeqId);
			if (empRequisitionReq != null) {
				empRequisitionReq.setWfSeqId(wfSeqId); // 👈 Set it into the entity
				empRequisitionReq.setWfItemSeqNum(wfItemSeqNum);
				empRequisitionReqForParticularUsers.add(empRequisitionReq);
				System.out.println("conveyance data based on wfseqid====" + empRequisitionReq);
			}
		}

		System.out.println("conveyanceClaimsForUser=====" + empRequisitionReqForParticularUsers);
		return empRequisitionReqForParticularUsers;
	}




}
