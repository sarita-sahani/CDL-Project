package com.employeerequisition.service;
import java.util.ArrayList;
import java.util.List;

import com.employeerequisition.dto.e_recruitment.ItemValueDTO;
import com.employeerequisition.dto.e_recruitment.JobRoleDetailsDTO;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.employeerequisition.utils.ErecruitmentOperations;

@Service
public class ItemValueServiceImpl implements ItemValueService {

    @Autowired
    private ErecruitmentOperations erecruitmentOperations;

    private final ObjectMapper objectMapper = new ObjectMapper();

    @Override
    public List<ItemValueDTO> getItemValues(String itemListName) {
        String rawResponse = erecruitmentOperations.getItemValuesRaw(itemListName);
        return parseItemValues(rawResponse);
    }


    private List<ItemValueDTO> parseItemValues(String rawResponse) {
        List<ItemValueDTO> result = new ArrayList<>();
        if (rawResponse == null || rawResponse.isBlank()) {
            return result;
        }

        try {
            JsonNode root = objectMapper.readTree(rawResponse);
            int retcode = root.path("retcode").asInt(0);
            if (retcode != 1) {
                throw new RuntimeException("Item values call failed, retcode=" + retcode + " response=" + rawResponse);
            }

            String valueList = root.path("valuelist").asText("");
            if (valueList.isBlank()) {
                return result;
            }

            for (String raw : valueList.split(",", -1)) {
                String entry = raw.trim();
                if (entry.isEmpty()) {
                    continue;
                }

                String code;
                String caption;
                int colonIdx = entry.indexOf(':');
                if (colonIdx >= 0) {
                    code = entry.substring(0, colonIdx).trim();
                    caption = entry.substring(colonIdx + 1).trim();
                } else {
                    code = entry;
                    caption = entry;
                }

                boolean isPlaceholder = "<empty>".equalsIgnoreCase(caption) || "#NA".equalsIgnoreCase(code);
                if (isPlaceholder) {
                    result.add(new ItemValueDTO("", "-- Select --"));
                } else {
                    result.add(new ItemValueDTO(code, caption));
                }
            }
        } catch (RuntimeException e) {
            throw e;
        } catch (Exception e) {
            throw new RuntimeException("Failed to parse item values response: " + e.getMessage(), e);
        }

        return result;
    }

    @Override
    public JobRoleDetailsDTO getJobRoleDetails(String jobRole) {
        String response = erecruitmentOperations.getJobRoleDetails(jobRole);
        return parseJobRoleResponse(response);
    }

    private JobRoleDetailsDTO parseJobRoleResponse(String rawResponse) {
        JobRoleDetailsDTO dto = new JobRoleDetailsDTO();
        if (rawResponse == null || rawResponse.isBlank()) {
            return dto;
        }

        try {
            JsonNode root = objectMapper.readTree(rawResponse);
            int retcode = root.path("retcode").asInt(0);
            if (retcode != 1) {
                throw new RuntimeException("Job role details call failed, retcode=" + retcode);
            }

            // Map the exact JSON keys returned by the external API
            dto.setKeyRoles(root.path("valuelist1").asText(""));
            dto.setMandatorySkills(root.path("valuelist2").asText(""));
            dto.setJobDescription(root.path("valuelist3").asText(""));
            dto.setJdTemplate(root.path("valuelist4").asText(""));

        } catch (Exception e) {
            throw new RuntimeException("Failed to parse job role details response: " + e.getMessage(), e);
        }

        return dto;
    }
}