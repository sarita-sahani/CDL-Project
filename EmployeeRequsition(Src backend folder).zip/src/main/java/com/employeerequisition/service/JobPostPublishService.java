package com.employeerequisition.service;

import com.employeerequisition.dto.e_recruitment.JobPostAddResponse;
import com.employeerequisition.dto.e_recruitment.JobPostPublishRequest;
import org.springframework.web.multipart.MultipartFile;

public interface JobPostPublishService {
   // JobPostAddResponse publishJobPost(JobPostPublishRequest request);

    JobPostAddResponse publishJobPost(
            JobPostPublishRequest request);
}
