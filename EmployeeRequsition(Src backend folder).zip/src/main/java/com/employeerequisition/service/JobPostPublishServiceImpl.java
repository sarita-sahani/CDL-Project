package com.employeerequisition.service;

import com.employeerequisition.dto.e_recruitment.JobPostAddResponse;
import com.employeerequisition.dto.e_recruitment.JobPostPublishRequest;
import com.employeerequisition.dto.e_recruitment.UserDataResponse;
import com.employeerequisition.repository.EmployeeRequisitionRepository;
import com.employeerequisition.utils.ErecruitmentOperations;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.MediaType;
import org.springframework.http.client.MultipartBodyBuilder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class JobPostPublishServiceImpl implements JobPostPublishService {

    private final EmployeeRequisitionRepository requisitionRepository;
    private final ErecruitmentOperations erecruitmentOperations;
    private final WebClient webClient = WebClient.builder()
            .filter((request, next) -> {
                log.info("➡️ Outgoing request: {} {}", request.method(), request.url());
                return next.exchange(request);
            })
            .build();
    private final ObjectMapper objectMapper = new ObjectMapper()
            .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

    @Value("${e-recruitment.base-url.api}")
    private String externalBaseUrl;

    @Value("${admin.user-id}")
    private String adminUserId;

    // Hardcoded values (no .yml properties needed)
    private static final String FILE_FIELD_NAME = "file_obj_name";
    private static final String FILE_BASE_DIR = "files/jobdesc";
    private static final String KEY_COL_NAME = "JOB_ID";
    private static final String FILE_COL_NAME = "JOB_DOC";
    private static final String FILE_NAME_PREFIX = "jd_$JOB_ID_";
    private static final String APP_CFG_ID = "JOBWEB";

    // Allowed MIME types for JOB_DOC attachment (PDF or DOCX only)
    private static final List<String> ALLOWED_MIME_TYPES = Arrays.asList(
            "application/pdf",                                                          // .pdf
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document"    // .docx
    );
    // Allowed file extensions (fallback check in case contentType is missing/unreliable)
    private static final List<String> ALLOWED_EXTENSIONS = Arrays.asList(".pdf", ".docx");
    private static final long MAX_FILE_SIZE = 1 * 1024 * 1024; // 1 MB

    @Override
    public JobPostAddResponse publishJobPost(JobPostPublishRequest request) {
        log.info("📌 Publishing job post for requisition: {}", request.getIntRefData());

        // ----- Validate file type & size -----
        MultipartFile file = request.getJdAttachment();
        if (file != null && !file.isEmpty()) {
            validateFile(file);
        } else {
            log.warn("⚠️ No file attached or file is empty");
        }

        // STEP 1: Admin login (delegated to ErecruitmentOperations, which caches the session)
        String adminSession = erecruitmentOperations.getAdminSessionId();
        log.debug("Admin session: {}", adminSession);

        // STEP 1.5: Resolve Hiring Manager's userId from email using admin session
        String hiringMgrUserId = null;
        String hiringMgrEmailId = request.getInitiatorEmailId();
        if (hiringMgrEmailId != null && !hiringMgrEmailId.isBlank()) {
            UserDataResponse hiringMgrData = fetchUserData(adminSession, hiringMgrEmailId);
            if (hiringMgrData != null && hiringMgrData.getRetdata() != null) {
                hiringMgrUserId = hiringMgrData.getRetdata().getUserId();
                log.info("👔 Hiring Manager UserId = {}", hiringMgrUserId);
            } else {
                log.warn("⚠️ Could not resolve Hiring Manager userId for email={}", hiringMgrEmailId);
            }
        } else {
            log.warn("⚠️ No hiring manager email provided");
        }

        // STEP 2: Fetch HR user details
        String jobPostEmailId = request.getLoginEmailId();
        if (jobPostEmailId == null || jobPostEmailId.isEmpty()) {
            throw new RuntimeException("Initiator email ID is required");
        }
        UserDataResponse userData = fetchUserData(adminSession, jobPostEmailId);
        String hrUserId = userData.getRetdata().getUserId();
        String hrPassword = userData.getRetdata().getPassword();
        log.info("👤 HR UserId = {}", hrUserId);

        // STEP 3: HR login
        erecruitmentOperations.ensureServerIsUp();
        String hrSession = loginHrUser(hrUserId, hrPassword);
        log.debug("HR session: {}", hrSession);

        // STEP 4: Call external API
        JobPostAddResponse apiResponse = callExternalJobPostApi(hrSession, hrUserId, hiringMgrUserId, request);

        // STEP 5: Save jobPostId if successful
        if (apiResponse.getRetcode() == 1 && apiResponse.getJobPostId() != null) {
            String jobPostId = apiResponse.getJobPostId();
            requisitionRepository.updateJobPostId(
                    Long.valueOf(request.getIntRefData()),
                    request.getWfSeqId(),
                    jobPostId
            );
            log.info("✅ JobPost ID {} saved", jobPostId);
        } else {
            log.warn("❌ External API error: retcode={}, message={}",
                    apiResponse.getRetcode(), apiResponse.getMessage());
        }

        return apiResponse;
    }

    // ----- File validation for JOB_DOC attachment -----
    // Rules: only .pdf / .docx files are allowed, and size must be < 1 MB.
    private void validateFile(MultipartFile file) {
        String contentType = file.getContentType();
        long size = file.getSize();
        String originalFilename = file.getOriginalFilename();
        String lowerName = originalFilename != null ? originalFilename.toLowerCase() : "";

        log.info("📎 Validating file: name={}, type={}, size={} bytes",
                originalFilename, contentType, size);

        boolean validMimeType = contentType != null && ALLOWED_MIME_TYPES.contains(contentType);
        boolean validExtension = ALLOWED_EXTENSIONS.stream().anyMatch(lowerName::endsWith);

        if (!validMimeType || !validExtension) {
            throw new IllegalArgumentException(
                    "Invalid file format for JOB_DOC attachment: \"" + originalFilename +
                            "\". Only .pdf and .docx files are allowed.");
        }

        if (size > MAX_FILE_SIZE) {
            throw new IllegalArgumentException(
                    "JOB_DOC attachment \"" + originalFilename + "\" is too large (" +
                            (size / 1024) + " KB). Maximum allowed size is 1 MB.");
        }

        if (size <= 0) {
            throw new IllegalArgumentException(
                    "JOB_DOC attachment \"" + originalFilename + "\" appears to be empty.");
        }
    }

    // ----- External API call -----
    private JobPostAddResponse callExternalJobPostApi(String hrSession, String hrUserId,
                                                      String hiringMgrUserId,
                                                      JobPostPublishRequest request) {
        MultipartBodyBuilder builder = new MultipartBodyBuilder();

        // ----- System fields -----
        builder.part("RetFormat", "PAGE");
        builder.part("getter", "false");
        builder.part("session_id", hrSession);
        builder.part("user_id", hrUserId);
        builder.part("page_name", "add_jobpost");
        builder.part("app_cfg_id", APP_CFG_ID);
        builder.part("PAGE", "add_jobpost");

// ----- Mail / DB action -----
        builder.part("mail_trigger", "JobPost_Add");
        builder.part("action", "db_create");

        // ----- Job identification -----
        builder.part("JOB_ID", "#AUTONUM");
        builder.part("INT_REF_DATA", request.getIntRefData());
        builder.part("INT_JOB_STATUS", "Open");
        builder.part("JOB_POST_DATE", "[%#DATE_NOW%]");
        builder.part("JOB_POST_USERID", "#user_id");

        // ----- Job details -----
        builder.part("JOB_ROLE", request.getJobRole());
        builder.part("JOB_DESC", request.getJobDescription());
        builder.part("JOB_TYPE", request.getJobType());
        builder.part("JOB_STATUS", request.getJobStatus());
        builder.part("PUBLISH_TYPE", request.getPublishType());
        builder.part("JOB_PRIORITY", request.getJobPriority());

        // ----- Skills -----
        String keySkills = request.getKeySkills();
        if (request.getAdditionalSkills() != null && !request.getAdditionalSkills().isBlank()) {
            keySkills = keySkills + ";" + request.getAdditionalSkills();
        }
        builder.part("KEY_SKILLS", keySkills);
        builder.part("KEY_ROLES", request.getKeyRoles());

        // ----- Locations -----
        builder.part("JOB_LOCATIONS", request.getLocation());
        builder.part("OTH_JOB_LOCATIONS", request.getOtherLocations());

        // ----- Hiring info -----
        builder.part("HIRING_TYPE", request.getHiringType());
        builder.part("HIRING_DEPT", request.getHiringDept());

        builder.part("HIRING_MGR", hiringMgrUserId);

        // ----- Experience & Salary -----
        builder.part("EXP_MIN",
                request.getExpMin() != null ? request.getExpMin() : 0);

        builder.part("EXP_MAX",
                request.getExpMax() != null ? request.getExpMax() : 0);

        builder.part("SALARY_MIN",
                request.getSalaryMin() != null ? request.getSalaryMin() : 0F);

        builder.part("SALARY_MAX",
                request.getSalaryMax() != null ? request.getSalaryMax() : 0F);

        builder.part("SALARY_BUDGET",
                request.getSalaryBudget() != null ? request.getSalaryBudget() : 0F);

        // ----- Project details -----
        builder.part("CUST_NAME", request.getCustName());
        builder.part("PROJ_CODE", request.getProjCode());
        builder.part("PROJ_NAME", request.getProjName());
        builder.part("PROJ_WAVE", request.getProjWave());
        builder.part("RES_REQ_WAVE", request.getResReqWave());

        // ----- Additional required fields -----
        builder.part("LEAD_TIME", request.getLeadTime() != null ? request.getLeadTime() : "#NA");
        builder.part("TOTAL_COUNT", request.getNoOfPositions() != null ? request.getNoOfPositions() : "1");

        // ----- File handling meta-fields (NOW UNCOMMENTED) -----
        builder.part("file_base_dir", FILE_BASE_DIR);
        builder.part("key_col_name", KEY_COL_NAME);
        builder.part("file_col_name", FILE_COL_NAME);
        builder.part("file_name_prefix", FILE_NAME_PREFIX);

        // Template file path(s)
        String template = request.getJdTemplate();
        if (template != null && !template.isEmpty()) {
            builder.part("file_name_tmpl", template);
            builder.part("file_name_tmpl_sel", template);
        } else {
            builder.part("file_name_tmpl", "tmpl_jd/default.docx");
            builder.part("file_name_tmpl_sel", "tmpl_jd/default.docx");
        }

        // ----- The actual file (field name = file_obj_name) -----
        MultipartFile file = request.getJdAttachment();
        byte[] fileBytes = null;
        String fileName = null;
        String fileContentType = null;

        if (file != null && !file.isEmpty()) {
            // A new file was chosen in the browser — use it as-is.
            try {
                fileBytes = file.getBytes();
                fileName = file.getOriginalFilename();
                fileContentType = file.getContentType();
            } catch (IOException e) {
                log.error("Failed to read uploaded file bytes", e);
                throw new RuntimeException("File read error", e);
            }
        } else if (template != null && !template.isEmpty()) {
            // No new file was uploaded from the browser, but a JD template
            // path came from the backend (auto-filled). Fetch that file's
            // bytes so it still gets sent/saved as the JOB_DOC attachment.
            try {
                fileBytes = erecruitmentOperations.downloadJdFile(template);
                fileName = template.contains("/")
                        ? template.substring(template.lastIndexOf('/') + 1)
                        : template;
                fileContentType = resolveTemplateContentType(fileName);
                log.info("📎 No new file uploaded — using JD template file from backend: {}", template);
            } catch (Exception e) {
                log.error("⚠️ Failed to fetch JD template file '{}' for attachment", template, e);
            }
        }

        if (fileBytes != null && fileBytes.length > 0) {
            final byte[] resourceBytes = fileBytes;
            final String resourceFileName = fileName;
            ByteArrayResource fileResource = new ByteArrayResource(resourceBytes) {
                @Override
                public String getFilename() {
                    return resourceFileName;
                }
            };
            builder.part(FILE_FIELD_NAME, fileResource)
                    .filename(resourceFileName)
                    .contentType(fileContentType != null
                            ? MediaType.parseMediaType(fileContentType)
                            : MediaType.APPLICATION_OCTET_STREAM);
            log.info("📎 Added file part '{}' with name {}", FILE_FIELD_NAME, resourceFileName);
        } else {
            log.warn("⚠️ No file to attach (no browser upload and no usable JD template file)");
        }

        // Build and send
        String url = externalBaseUrl + "/api/jobpost/add";
        log.info("🌐 Sending multipart request to: {}", url);

        String responseBody = webClient.post()
                .uri(url)
                .contentType(MediaType.MULTIPART_FORM_DATA)
                .body(BodyInserters.fromMultipartData(builder.build()))
                .retrieve()
                .onStatus(status -> !status.is2xxSuccessful(), response ->
                        response.bodyToMono(String.class)
                                .flatMap(body -> {
                                    log.error("❌ External API error: status={}, body={}", response.statusCode(), body);
                                    return Mono.error(new RuntimeException("External API error: " + body));
                                })
                )
                .bodyToMono(String.class)
                .block();

        log.info("📥 External API response: {}", responseBody);
        return parseExternalResponse(responseBody);
    }

    // ----- Resolve content type for a JD template file fetched from backend storage -----
    private String resolveTemplateContentType(String fileName) {
        String lower = fileName != null ? fileName.toLowerCase() : "";
        if (lower.endsWith(".pdf")) {
            return "application/pdf";
        }
        if (lower.endsWith(".docx")) {
            return "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
        }
        return "application/octet-stream";
    }

    // ----- Helper methods (safe parsing, login, etc.) -----
//    private String safeParseInt(String value, int defaultValue) {
//        if (value == null || value.trim().isEmpty()) return String.valueOf(defaultValue);
//        try {
//            return String.valueOf(Integer.parseInt(value.trim()));
//        } catch (NumberFormatException e) {
//            return String.valueOf(defaultValue);
//        }
//    }

    private String safeParseDouble(String value, double defaultValue) {
        if (value == null || value.trim().isEmpty()) return String.valueOf(defaultValue);
        try {
            return String.valueOf(Double.parseDouble(value.trim()));
        } catch (NumberFormatException e) {
            return String.valueOf(defaultValue);
        }
    }

    // ----- Authentication -----
    private String loginHrUser(String hrUserId, String hrPassword) {
        String url = externalBaseUrl + "/api/auth/login"
                + "?RetFormat=JSON&user_id=" + hrUserId + "&Password=" + hrPassword;
        String response = webClient.get()
                .uri(url)
                .accept(MediaType.APPLICATION_JSON)
                .retrieve()
                .bodyToMono(String.class)
                .block();
        return extractSessionId(response);
    }

    private String extractSessionId(String jsonResponse) {
        try {
            JsonNode root = objectMapper.readTree(jsonResponse);
            if (root.isArray() && root.size() > 0) root = root.get(0);
            JsonNode session = root.get("session_id");
            if (session != null && !session.isNull()) return session.asText();
            throw new RuntimeException("session_id not found");
        } catch (Exception e) {
            throw new RuntimeException("Failed to parse login response", e);
        }
    }

    private UserDataResponse fetchUserData(String adminSession, String jobPostEmailId) {
        String url = externalBaseUrl + "/api/user/getdata_email"
                + "?RetFormat=JSON&getter=true&session_id=" + adminSession
                + "&user_id=" + adminUserId
                + "&page_name=mod_user_data&EmailID=" + jobPostEmailId;
        String responseBody = webClient.get()
                .uri(url)
                .accept(MediaType.APPLICATION_JSON)
                .retrieve()
                .bodyToMono(String.class)
                .block();
        try {
            JsonNode root = objectMapper.readTree(responseBody);
            if (root.isArray() && root.size() > 0) root = root.get(0);
            return objectMapper.readValue(root.toString(), UserDataResponse.class);
        } catch (Exception e) {
            throw new RuntimeException("Failed to parse user data", e);
        }
    }

    private JobPostAddResponse parseExternalResponse(String responseBody) {
        try {
            JsonNode root = objectMapper.readTree(responseBody);
            JsonNode data;
            if (root.isArray()) {
                data = (root.size() > 1 && root.get(1).isObject()) ? root.get(1) : root.get(0);
            } else {
                data = root;
            }
            JobPostAddResponse response = new JobPostAddResponse();
            response.setRetcode(data.path("retcode").asInt());
            response.setMessage(data.path("Result").asText());
            response.setJobPostId(data.path("JOB_ID").asText());
            return response;
        } catch (Exception e) {
            throw new RuntimeException("Failed to parse external API response", e);
        }
    }
}