package com.employeerequisition.service;

import java.util.List;
import java.util.concurrent.ExecutionException;

import com.employeerequisition.beans.emp_user_bean.EmpAndUserResponse;
import com.employeerequisition.model.*;
import org.springframework.web.bind.annotation.RequestBody;

public interface EmployeeRequisitionService {

	EmpAndUserResponse getEmpInfoByEmpCode(String empCode) throws ExecutionException, InterruptedException;

	EmployeeRequisition createNewEmployeeRequisition(EmployeeRequisition employeeRequisition, String empCode, String workflowName);

	List<EmployeeRequisition> getAllEmployeeRequisition();

	List<EmployeeRequisition> searchEmp(String search);

	List<BillingType> getAllBillingType();


	List<ITAssetTable> getAllITAsset();

	List<ITConfigurationsTable> getAllITConfigurations();


	public EmployeeRequisition getEmployeeRequisitionDataByErfId(Long erfId);

	EmployeeRequisition updateApprovalStatus(Long id, String action, String comments);

	EmployeeRequisition getEmpRequisitionFormDetails(String workFlowName);

	EmployeeRequisition SaveWfSeqIdinRequisitionTable(String empCode, Long wfSeqId);

	EmployeeRequisition getRequisitionFormDetailsByWfSeqId(Long wfSeqId);

	//for displaying conveyance claim  data//
	List<EmployeeRequisition> getEmpRequisitionPendingList(String empCode);
}
