package com.employeerequisition.service;


import com.employeerequisition.dto.e_recruitment.ItemValueDTO;
import com.employeerequisition.dto.e_recruitment.JobRoleDetailsDTO;

import java.util.List;

public interface ItemValueService {

    /**
     * @param itemListName full list name as expected by the external system,
     *                      e.g. "def.JobPost_JOB_TYPE"
     */
    List<ItemValueDTO> getItemValues(String itemListName);

    JobRoleDetailsDTO getJobRoleDetails(String jobRole);
}