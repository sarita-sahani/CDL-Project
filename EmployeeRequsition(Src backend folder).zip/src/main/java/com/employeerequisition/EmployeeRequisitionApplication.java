package com.employeerequisition;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeRequisitionApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeRequisitionApplication.class, args);
	}

}
