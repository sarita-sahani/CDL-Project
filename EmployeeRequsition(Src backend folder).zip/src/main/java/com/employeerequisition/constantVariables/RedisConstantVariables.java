package com.employeerequisition.constantVariables;

public class RedisConstantVariables {
    public static final String empCodeCache = "empCodeCache";
    public static final String empEmailCache = "empEmailCache";


}
