import axios from "axios";

const API_URL = "http://localhost:9031/api/stationary";

export const getAllRequests = async () => {
    const response = await axios.get(API_URL);
    return response.data;
};

export const createRequest = async (requestData) => {
    const response = await axios.post(API_URL, requestData);
    return response.data;
};

export const updateRequest = async (id, updatedData) => {
    const response = await axios.put(`${API_URL}/${id}`, updatedData);
    return response.data;
};

export const deleteRequest = async (id) => {
    await axios.delete(`${API_URL}/${id}`);
};
