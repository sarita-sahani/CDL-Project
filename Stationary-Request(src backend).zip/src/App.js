
import React from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import StationaryRequest from './Components/StationaryRequest';
import ViewRequestModal from "./Components/ViewRequestModal";
// import RequestDetail from "./components/RequestDetail";

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<StationaryRequest />} />
        <Route path="/viewrowdata" element={<ViewRequestModal/>}/>
        {/* <Route path="/request/:reqNo" element={<RequestDetail />} /> */}
      </Routes>
    </Router>
  );
}

export default App;








// import React from 'react';
// import { BrowserRouter as Router } from 'react-router-dom'; // Import BrowserRouter
// import StationaryRequest from './Components/StationaryRequest';

// function App() {
//   return (
//     <Router> {/* Wrap your component with Router */}
//       <div className="App">
//         <StationaryRequest />
//       </div>
//     </Router>
//   );
// }

// export default App;












// // import React from 'react';
// // import StationaryRequest from './Components/StationaryRequest';
// // function App() {
// //   return (
// //     <div className="App">
// //       <StationaryRequest />
// //     </div>
// //   );
// // }

// // export default App;
