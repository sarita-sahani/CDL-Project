import React, { useState, useEffect } from "react";
import { FaRegCircleXmark, FaSquarePlus } from "react-icons/fa6";
import { BsTrash } from "react-icons/bs";

const EditDraftRequestModal = ({ isOpen, onClose, record, onSubmit }) => {
  const [purpose, setPurpose] = useState("");
  const [priority, setPriority] = useState("");
  const [items, setItems] = useState([]);
  const [itemNames, setItemNames] = useState([]); // Fetched item names
  const [priorities, setPriorities] = useState([]); // Fetched priorities

  // Fetch item names and priorities when the modal opens
  useEffect(() => {
    const fetchData = async () => {
      try {
        const [itemNamesResponse, prioritiesResponse] = await Promise.all([
          fetch("http://localhost:9031/api/itemnames"),
          fetch("http://localhost:9031/api/priorities")
        ]);

        if (!itemNamesResponse.ok || !prioritiesResponse.ok) {
          throw new Error("Error fetching data");
        }

        const itemNamesData = await itemNamesResponse.json();
        const prioritiesData = await prioritiesResponse.json();

        setItemNames(itemNamesData);
        setPriorities(prioritiesData);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    if (isOpen) {
      fetchData();
    }
  }, [isOpen]);

  // Load the record data when it changes
  useEffect(() => {
    if (record) {
      console.log("Loaded Draft: ", record);
      setPurpose(record.purpose || "");
      setPriority(record.priority || "");

      if (Array.isArray(record.items) && record.items.length > 0) {
        setItems(
          record.items.map((item) => ({
            itemName: item.itemName || "",
            numberOfItems: item.numberOfItems || 0
          }))
        );
      } else {
        setItems([]);
      }
    }
  }, [record]);

  const handleAddItem = () => {
    setItems([...items, { itemName: "", numberOfItems: "" }]);
  };

  const handleRemoveItem = (index) => {
    setItems(items.filter((_, i) => i !== index));
  };

  const handleItemChange = (index, field, value) => {
    const updatedItems = [...items];
    updatedItems[index][field] = value;
    setItems(updatedItems);
  };

  const validateFields = () => {
    if (!purpose || !priority || items.some(item => !item.itemName || !item.numberOfItems)) {
      alert("Please fill all required fields.");
      return false;
    }
    return true;
  };

  // Update draft (save as draft)
  const handleUpdateDraft = () => {
    if (!validateFields()) return;
    const updatedDraft = { ...record, purpose, priority, items, status: "Draft" };
    onSubmit(updatedDraft);
    onClose();
  };

  // Update and submit the draft (change status to Submitted)
  const handleUpdateAndSubmit = () => {
    if (!validateFields()) return;
    const updatedDraft = { ...record, purpose, priority, items, status: "Submitted" };
    onSubmit(updatedDraft);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-gray-600 bg-opacity-50 flex justify-center items-center z-50">
      <div className="bg-white rounded-lg w-2/4 p-6 shadow-lg">
        {/* Modal Header */}
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-semibold">Edit Draft Request</h2>
          <button onClick={onClose} className="text-red-500 hover:text-red-700">
            <FaRegCircleXmark />
          </button>
        </div>

        {/* Purpose Field */}
        <div className="w-auto mt-6 mx-8 flex items-center justify-between">
          <h1 className="text-black-500 font-medium">Purpose</h1>
          <input
            type="text"
            value={purpose}
            onChange={(e) => setPurpose(e.target.value)}
            className="w-4/5 mr-2 border border-gray-300 h-9 outline-none rounded-md px-2"
          />
        </div>

        {/* Priority Field */}
        <div className="w-auto mt-6 mx-8 flex items-center justify-between">
          <h1 className="text-black-500 font-medium">Priority</h1>
          <select
            value={priority}
            onChange={(e) => setPriority(e.target.value)}
            className="w-4/5 mr-2 border border-gray-300 h-9 outline-none rounded-md px-2"
          >
            <option value="">Select</option>
            {priorities.map((priorityOption) => (
              <option key={priorityOption.id} value={priorityOption.name}>
                {priorityOption.name}
              </option>
            ))}
          </select>
        </div>

        {/* Items Table */}
        <div className="mt-6">
          <h3 className="font-semibold text-black-500 pb-2">Item Details</h3>
          <div className="relative border border-gray-300 rounded-md p-2 w-[40rem]">
            <table className="min-w-full">
              <thead>
                <tr>
                  <th className="text-left p-2 font-semibold border-b border-gray-200">S.NO</th>
                  <th className="text-left pl-6 pr-20 font-semibold whitespace-nowrap border-b border-gray-200">Item Name</th>
                  <th className="text-left pl-6 pr-20 font-semibold whitespace-nowrap border-b border-gray-200">Number of Items</th>
                  <th className="text-right pr-4 border-b border-gray-200">
                    <button onClick={handleAddItem} className="focus:outline-none">
                      <FaSquarePlus className="text-blue-500 text-2xl" />
                    </button>
                  </th>
                </tr>
              </thead>
              <tbody>
                {items.map((item, index) => (
                  <tr key={index} className="border border-gray-300">
                    <td className="text-left p-2">{index + 1}</td>
                    <td className="pl-4">
                      <select
                        className="w-full h-9 px-2 border border-gray-300 rounded-md focus:outline-none appearance-none"
                        value={item.itemName}
                        onChange={(e) => handleItemChange(index, "itemName", e.target.value)}
                      >
                        <option value="">Select Item</option>
                        {itemNames.map((itemName) => (
                          <option key={itemName.id} value={itemName.name}>
                            {itemName.name}
                          </option>
                        ))}
                      </select>
                    </td>
                    <td className="p-2">
                      <input
                        type="number"
                        className="w-full ml-2 border border-gray-300 h-9 px-2 rounded-md focus:outline-none"
                        value={item.numberOfItems || ""}
                        onChange={(e) => handleItemChange(index, "numberOfItems", e.target.value)}
                      />
                    </td>
                    <td className="p-2">
                      <button onClick={() => handleRemoveItem(index)} className="text-red-500 hover:text-red-700">
                        <BsTrash />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Updated Buttons Section */}
        <div className="mt-6 flex justify-end space-x-2">
          <button
            onClick={handleUpdateDraft}
            className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600"
          >
            Update
          </button>
          <button
            onClick={handleUpdateAndSubmit}
            className="px-4 py-2 bg-green-500 text-white rounded hover:bg-green-600"
          >
            Update and Submit
          </button>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-gray-300 rounded hover:bg-gray-400"
          >
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
};

export default EditDraftRequestModal;

