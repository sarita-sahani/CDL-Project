import React, { useState, useEffect } from "react";
import { FaRegCircleXmark, FaSquarePlus } from "react-icons/fa6";
import { BsTrash } from "react-icons/bs";

const CreateRequestModal = ({ isOpen, onClose }) => {
  const [form, setForm] = useState({
    purpose: "",
    priority: "",
    items: [{ itemName: "", numberOfItems: "" }],
  });

  // Fetch item names and priorities from the backend when the component is mounted
  const [itemNames, setItemNames] = useState([]); // State to store item names
  const [priority, setPriority] = useState([]); // State to store priorities

  // Fetch both item names and priorities when the component is mounted
  useEffect(() => {
    const fetchData = async () => {
      try {
        // Use Promise.all to fetch both APIs concurrently
        const [itemNamesResponse, prioritiesResponse] = await Promise.all([
          fetch("http://localhost:9031/api/itemnames"),
          fetch("http://localhost:9031/api/priorities"),
        ]);

        if (!itemNamesResponse.ok) {
          throw new Error(`Error fetching item names: ${itemNamesResponse.status}`);
        }
        if (!prioritiesResponse.ok) {
          throw new Error(`Error fetching priorities: ${prioritiesResponse.status}`);
        }

        const itemNamesData = await itemNamesResponse.json();
        const prioritiesData = await prioritiesResponse.json();

        // Update states with the fetched data
        setItemNames(itemNamesData); // Assuming response is [{ id, name }]
        setPriority(prioritiesData); // Assuming response is [{ id, name }]
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchData();
  }, []);  // Empty dependency array means this runs once when the component mounts

  // Add a new item to the items list
  const handleAddItem = () => {
    setForm({ ...form, items: [...form.items, { itemName: "", numberOfItems: "" }] });
  };

  // Remove an item from the items list
  const handleRemoveItem = (index) => {
    const newItems = form.items.filter((_, i) => i !== index);
    setForm({ ...form, items: newItems });
  };

  // Update individual item fields (convert numberOfItems to a number)
  const handleItemChange = (index, field, value) => {
    const newItems = [...form.items];
    if (field === "numberOfItems") {
      newItems[index][field] = value === "" ? "" : Number(value); // Allow empty string
    } else {
      newItems[index][field] = value;
    }
    setForm({ ...form, items: newItems });
  };

  // Update form-level fields (purpose, priority)
  const handleChange = (field, value) => {
    setForm({ ...form, [field]: value });
  };

  //save as deaft
  const handleSaveAsDraft = async () => {
    console.log("Saving draft:", form);

    const draftData = {
      ...form,
      items: form.items.map(item => ({
        ...item,
        numberOfItems: Number(item.numberOfItems),
      })),
      requestDate: new Date().toISOString().split("T")[0],
      status: "Draft",  // Marking as Draft
    };

    try {
      const response = await fetch("http://localhost:9031/api/save-draft", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(draftData),
      });

      if (response.ok) {
        alert("Draft saved successfully!");
        setForm({ purpose: "", priority: "", items: [{ itemName: "", numberOfItems: "" }] });
        onClose();
      } else {
        alert("Failed to save draft. Please try again.");
      }
    } catch (error) {
      console.error("Error saving draft:", error);
      alert("An error occurred while saving the draft.");
    }
  };

  // Submit form data to the backend
  const handleSubmit = async () => {
    console.log("Form data before submission:", form);

    // Validate fields before submission
    if (!form.purpose || !form.priority || form.items.some(item => !item.itemName || !item.numberOfItems)) {
      alert("Please fill in all required fields and ensure numbers are valid.");
      return;
    }

    // Prepare data for submission
    const requestData = {
      ...form,
      items: form.items.map(item => ({
        ...item,
        numberOfItems: Number(item.numberOfItems), // Ensure number conversion
      })),
      requestDate: new Date().toISOString().split("T")[0],
      status: "Pending",
      issueStatus: "Not Issued",
    };

    console.log("Payload being sent:", requestData); // Debugging payload

    try {
      const response = await fetch("http://localhost:9031/api/requests", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(requestData),
      });

      if (response.ok) {
        alert("Request submitted successfully!");
        setForm({ purpose: "", priority: "", items: [{ itemName: "", numberOfItems: "" }] });
        onClose();
      } else {
        alert("Failed to submit the request. Please try again.");
      }
    } catch (error) {
      console.error("Error submitting the request:", error);
      alert("An error occurred. Please try again.");
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-gray-600 bg-opacity-50 flex justify-center items-center z-50">
      <div className="bg-white rounded-lg w-2/4 p-6 shadow-lg">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-semibold">Create New Stationary Request</h2>
          <button onClick={onClose} className="text-red-500 hover:text-red-700">
            <FaRegCircleXmark />
          </button>
        </div>

        {/* Purpose Field */}
        <div className="w-auto mt-6 mx-8 flex items-center justify-between">
          <h1 className="text-black-500 font-medium">Purpose</h1>
          <input
            type="text"
            className="w-4/5 mr-2 border border-gray-300 h-9 outline-none rounded-md"
            value={form.purpose}
            onChange={(e) => handleChange("purpose", e.target.value)}
          />
        </div>

        {/* Priority Dropdown */}
        <div className="priorityDropdown">
          <div className="w-auto mt-6 mx-8 flex items-center justify-between">
            <h1 className="text-black-500 font-medium">Priority</h1>
            <div className="relative mr-2 w-4/5">
              <select
                className="appearance-none w-full border border-gray-300 h-9 px-2 outline-none rounded-md"
                value={form.priority}
                onChange={(e) => handleChange("priority", e.target.value)}
              >
                <option value="">Select </option>
                {priority.map((item) => (
                  <option key={item.id} value={item.name}>
                    {item.name}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Item Details */}
        <div className="mt-6">
          <h3 className="font-semibold text-black-500 pb-2">Item Details</h3>
          <div className="relative border border-gray-300 rounded-md p-2 w-full">
            <table className="min-w-full table-auto border-collapse">
              <thead>
                <tr>
                  <th className="text-left p-2 font-semibold border-b border-gray-200">S.NO</th>
                  <th className="text-left pl-6 pr-20 font-semibold whitespace-nowrap border-b border-gray-200">Item Name</th>
                  <th className="text-left pl-6 pr-20 font-semibold whitespace-nowrap border-b border-gray-200">Number of Items</th>
                  <th className="text-right pr-4 border-b border-gray-200">
                    <button onClick={handleAddItem} className="focus:outline-none">
                      <FaSquarePlus className="text-blue-500 text-2xl" />
                    </button>
                  </th>
                </tr>
              </thead>
              <tbody>
                {form.items.map((item, index) => (
                  <tr key={index} className="border border-gray-300">
                    <td className="text-left p-2">{index + 1}</td>
                    <td className="pl-4">
                      <select
                        className="w-full h-9 px-2 border border-gray-300 rounded-md focus:outline-none appearance-none"
                        value={item.itemName}
                        onChange={(e) => handleItemChange(index, "itemName", e.target.value)}
                      >
                        <option value="">Select Item</option>
                        {itemNames.map((item) => (
                          <option key={item.id} value={item.name}>
                            {item.name}
                          </option>
                        ))}
                      </select>
                    </td>
                    <td className="p-2">
                      <input
                        type="number"
                        className="w-full ml-2 border border-gray-300 h-9 px-2 rounded-md focus:outline-none"
                        value={item.numberOfItems}
                        onChange={(e) => handleItemChange(index, "numberOfItems", e.target.value)}
                      />
                    </td>
                    <td className="p-2">
                      <button
                        onClick={() => handleRemoveItem(index)}
                        className="text-red-500 hover:text-red-700"
                      >
                        <BsTrash />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Action Buttons */}

                

        <div className="mt-6 flex justify-end space-x-2">

                 <button
            onClick={handleSaveAsDraft}  // Save as draft button
            className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600"
          >
            Save as Draft
          </button>

          <button
            onClick={handleSubmit}
            className="px-4 py-2 bg-green-500 text-white rounded hover:bg-green-600"
          >
            Submit
          </button>
          <button onClick={onClose} className="px-4 py-2 bg-gray-300 rounded hover:bg-gray-400">
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
};

export default CreateRequestModal;












// import React, { useState } from "react";
// import { FaRegCircleXmark, FaSquarePlus } from "react-icons/fa6";
// import { BsTrash } from "react-icons/bs";

// const CreateRequestModal = ({ isOpen, onClose }) => {
//   const [form, setForm] = useState({
//     purpose: "",
//     priority: "",
//     items: [{ itemName: "", numberOfItems: "" }],
//   });

//   // Add a new item to the items list
//   const handleAddItem = () => {
//     setForm({ ...form, items: [...form.items, { itemName: "", numberOfItems: "" }] });
//   };

//   // Remove an item from the items list
//   const handleRemoveItem = (index) => {
//     const newItems = form.items.filter((_, i) => i !== index);
//     setForm({ ...form, items: newItems });
//   };

//   // Update individual item fields (convert numberOfItems to a number)
//   const handleItemChange = (index, field, value) => {
//     const newItems = [...form.items];
//     if (field === "numberOfItems") {
//       newItems[index][field] = value === "" ? "" : Number(value); // Allow empty string
//     } else {
//       newItems[index][field] = value;
//     }
//     setForm({ ...form, items: newItems });
//   };
  

//   // Update form-level fields (purpose, priority)
//   const handleChange = (field, value) => {
//     setForm({ ...form, [field]: value });
//   };

//   // Submit form data to the backend
//   const handleSubmit = async () => {
//      console.log("Form data before submission:", form);
//     // Validate fields before submission
//     if (!form.purpose || !form.priority || form.items.some(item => !item.itemName || !item.numberOfItems)) {
//       alert("Please fill in all required fields and ensure numbers are valid.");
      
//       return;
//     }

//     // Prepare data for submission
//     const requestData = {
//       ...form,
//       items: form.items.map(item => ({
//         ...item,
//         numberOfItems: Number(item.numberOfItems), // Ensure number conversion
//       })),
//       requestDate: new Date().toISOString().split("T")[0],
//       status: "Pending",
//      issueStatus: "Not Issued",
//     };

//     console.log("Payload being sent:", requestData); // Debugging payload

//     try {
//       const response = await fetch("http://localhost:9031/api/requests", {
//         method: "POST",
//         headers: {
//           "Content-Type": "application/json",
//         },
//         body: JSON.stringify(requestData),
//       });

//       if (response.ok) {
       
//         alert("Request submitted successfully!" + form.items[0].numberOfItems);
  
//         setForm({ purpose: "", priority: "", items: [{ itemName: "", numberOfItems: "" }] });
//       onClose();
//       } else {
//         alert("Failed to submit the request. Please try again.");
//       }
//     } catch (error) {
//       console.error("Error submitting the request:", error);
//       alert("An error occurred. Please try again.");
//     }
//   };

//   if (!isOpen) return null;

//   return (
//     <div className="fixed inset-0 bg-gray-600 bg-opacity-50 flex justify-center items-center z-50">
//       <div className="bg-white rounded-lg w-2/4 p-6 shadow-lg">
//         <div className="flex justify-between items-center mb-4">
//           <h2 className="text-xl font-semibold">Create New Stationary Request</h2>
//           <button onClick={onClose} className="text-red-500 hover:text-red-700">
//             <FaRegCircleXmark />
//           </button>
//         </div>

//         {/* Purpose Field */}
//         <div className="w-auto mt-6 mx-8 flex items-center justify-between">
//           <h1 className="text-black-500 font-medium">Purpose</h1>
//           <input
//             type="text"
//             className="w-4/5 mr-2 border border-gray-300 h-9 outline-none rounded-md"
//             value={form.purpose}
//             onChange={(e) => handleChange("purpose", e.target.value)}
//           />
//         </div>

//         {/* Priority Dropdown */}
//         <div className="priorityDropdown">
//           <div className="w-auto mt-6 mx-8 flex items-center justify-between">
//             <h1 className="text-black-500 font-medium">Priority</h1>
//             <div className="relative mr-2 w-4/5">
//               <select
//                 className="appearance-none w-full border border-gray-300 h-9 px-2 outline-none rounded-md"
//                 value={form.priority}
//                 onChange={(e) => handleChange("priority", e.target.value)}
//               >
//                 <option value="">Select</option>
//                 <option value="Low">Low</option>
//                 <option value="Medium">Medium</option>
//                 <option value="High">High</option>
//               </select>
//             </div>
//           </div>
//         </div>

//         {/* Item Details */}
//         <div className="mt-6">
//           <h3 className="font-semibold text-black-500 pb-2">Item Details</h3>
//           <div className="relative border border-gray-300 rounded-md p-2 w-full">
//             <table className="min-w-full table-auto border-collapse">
//               <thead>
//                 <tr>
//                     <th className="text-left p-2 font-semibold border-b border-gray-200">S.NO</th>
//                     <th className="text-left pl-6 pr-20 font-semibold whitespace-nowrap border-b border-gray-200">Item Name</th>
//                     <th className="text-left pl-6 pr-20 font-semibold whitespace-nowrap border-b border-gray-200">Number of Items</th>
//                     <th className="text-right pr-4 border-b border-gray-200">
//                     <button onClick={handleAddItem} className="focus:outline-none">
//                       <FaSquarePlus className="text-blue-500 text-2xl" />
//                     </button>
//                   </th>
//                 </tr>
//               </thead>
//               <tbody>
//                 {form.items.map((item, index) => (
//                   <tr key={index} className="border border-gray-300">
//                     <td className="text-left p-2">{index + 1}</td>
//                     <td className="pl-4">
//                       <select
//                         className="w-full h-9 px-2 border border-gray-300 rounded-md focus:outline-none appearance-none"
//                         value={item.itemName}
//                         onChange={(e) => handleItemChange(index, "itemName", e.target.value)}
//                       >
//                         <option value="">Select Item</option>
//                         <option value="Pen">Pen</option>
//                         <option value="Pencil">Pencil</option>
//                         <option value="Stapler">Stapler</option>
//                         <option value="Marker">Marker</option>
//                         <option value="Highlighter">Highlighter</option>
//                       </select>
//                     </td>
//                     <td className="p-2">
//                       <input
//                         type="number"
//                         className="w-full ml-2 border border-gray-300 h-9 px-2 rounded-md focus:outline-none"
//                         value={item.numberOfItems}
//                         onChange={(e) => handleItemChange(index, "numberOfItems", e.target.value)}
//                       />
//                     </td>
//                     <td className="p-2">
//                       <button
//                         onClick={() => handleRemoveItem(index)}
//                         className="text-red-500 hover:text-red-700"
//                       >
//                         <BsTrash />
//                       </button>
//                     </td>
//                   </tr>
//                 ))}
//               </tbody>
//             </table>
//           </div>
//         </div>

//         {/* Action Buttons */}
//         <div className="mt-6 flex justify-end space-x-2">
//           <button
//             onClick={handleSubmit}
//             className="px-4 py-2 bg-green-500 text-white rounded hover:bg-green-600"
//           >
//             Submit
//           </button>
//           <button onClick={onClose} className="px-4 py-2 bg-gray-300 rounded hover:bg-gray-400">
//             Cancel
//           </button>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default CreateRequestModal;





















//save as draft

// import React, { useState } from "react";
// import { FaRegCircleXmark, FaSquarePlus } from "react-icons/fa6";
// import { BsTrash } from "react-icons/bs";

// const CreateRequestModal = ({ isOpen, onClose }) => {
//   const [form, setForm] = useState({
//     purpose: "",
//     priority: "",
//     items: [{ itemName: "", numberOfItems: "" }],
//   });

//   // Add a new item to the items list
//   const handleAddItem = () => {
//     setForm({ ...form, items: [...form.items, { itemName: "", numberOfItems: "" }] });
//   };

//   // Remove an item from the items list
//   const handleRemoveItem = (index) => {
//     const newItems = form.items.filter((_, i) => i !== index);
//     setForm({ ...form, items: newItems });
//   };

//   // Update individual item fields (convert numberOfItems to a number)
//   const handleItemChange = (index, field, value) => {
//     const newItems = [...form.items];
//     if (field === "numberOfItems") {
//       newItems[index][field] = value === "" ? "" : Number(value); // Allow empty string
//     } else {
//       newItems[index][field] = value;
//     }
//     setForm({ ...form, items: newItems });
//   };

//   // Update form-level fields (purpose, priority)
//   const handleChange = (field, value) => {
//     setForm({ ...form, [field]: value });
//   };

//   // Submit form data to the backend
//   const handleSubmit = async (isDraft) => {
//     console.log("Form data before submission:", form);

//     // Validate fields before submission
//     if (!isDraft && (!form.purpose || !form.priority || form.items.some(item => !item.itemName || !item.numberOfItems))) {
//       alert("Please fill in all required fields and ensure numbers are valid.");
//       return;
//     }

//     // Prepare data for submission
//     const requestData = {
//       ...form,
//       items: form.items.map(item => ({
//         ...item,
//         numberOfItems: Number(item.numberOfItems), // Ensure number conversion
//       })),
//       requestDate: new Date().toLocaleDateString('en-CA'), // Format date as YYYY-MM-DD
//       status: isDraft ? "Draft" : "Pending",
//       issueStatus: "Not Issued",
//     };

//     console.log("Payload being sent:", requestData); // Debugging payload

//     try {
//       const response = await fetch("http://localhost:9031/api/requests", {
//         method: "POST",
//         headers: {
//           "Content-Type": "application/json",
//         },
//         body: JSON.stringify(requestData),
//       });

//       if (response.ok) {
//         alert(isDraft ? "Draft saved successfully!" : "Request submitted successfully!");
//         setForm({ purpose: "", priority: "", items: [{ itemName: "", numberOfItems: "" }] });
//         onClose();
//       } else {
//         alert("Failed to submit the request. Please try again.");
//       }
//     } catch (error) {
//       console.error("Error submitting the request:", error);
//       alert("An error occurred. Please try again.");
//     }
//   };

// if (!isOpen) return null;

//   return (
//     <div className="fixed inset-0 bg-gray-600 bg-opacity-50 flex justify-center items-center z-50">
//       <div className="bg-white rounded-lg w-2/4 p-6 shadow-lg">
//         <div className="flex justify-between items-center mb-4">
//           <h2 className="text-xl font-semibold">Create New Stationary Request</h2>
//           <button onClick={onClose} className="text-red-500 hover:text-red-700">
//             <FaRegCircleXmark />
//           </button>
//         </div>

//         {/* Purpose Field */}
//         <div className="w-auto mt-6 mx-8 flex items-center justify-between">
//           <h1 className="text-black-500 font-medium">Purpose</h1>
//           <input
//             type="text"
//             className="w-4/5 mr-2 border border-gray-300 h-9 outline-none rounded-md"
//             value={form.purpose}
//             onChange={(e) => handleChange("purpose", e.target.value)}
//           />
//         </div>

//         {/* Priority Dropdown */}
//         <div className="priorityDropdown">
//           <div className="w-auto mt-6 mx-8 flex items-center justify-between">
//             <h1 className="text-black-500 font-medium">Priority</h1>
//             <div className="relative mr-2 w-4/5">
//               <select
//                 className="appearance-none w-full border border-gray-300 h-9 px-2 outline-none rounded-md"
//                 value={form.priority}
//                 onChange={(e) => handleChange("priority", e.target.value)}
//               >
//                 <option value="">Select</option>
//                 <option value="Low">Low</option>
//                 <option value="Medium">Medium</option>
//                 <option value="High">High</option>
//               </select>
//             </div>
//           </div>
//         </div>

//         {/* Item Details */}
//         <div className="mt-6">
//           <h3 className="font-semibold text-black-500 pb-2">Item Details</h3>
//           <div className="relative border border-gray-300 rounded-md p-2 w-[40rem]">
//             <table className="min-w-full">
//               <thead>
//                 <tr>
//                   <th className="text-left p-2 font-semibold">S.NO</th>
//                   <th className="text-left pl-6 pr-36 font-semibold">Item Name</th>
//                   <th className="text-left pl-6 pr-36 font-semibold">Number of Items (Nos)</th>
//                   <th className="text-right pr-10">
//                     <button onClick={handleAddItem} className="focus:outline-none">
//                       <FaSquarePlus className="text-blue-500 text-2xl" />
//                     </button>
//                   </th>
//                 </tr>
//               </thead>
//               <tbody>
//                 {form.items.map((item, index) => (
//                   <tr key={index} className="border border-gray-300">
//                     <td className="text-left p-2">{index + 1}</td>
//                     <td className="pl-4">
//                       <select
//                         className="w-full h-9 px-2 border border-gray-300 rounded-md focus:outline-none appearance-none"
//                         value={item.itemName}
//                         onChange={(e) => handleItemChange(index, "itemName", e.target.value)}
//                       >
//                         <option value="">Select Item</option>
//                         <option value="Pen">Pen</option>
//                         <option value="Pencil">Pencil</option>
//                         <option value="Stapler">Stapler</option>
//                         <option value="Marker">Marker</option>
//                         <option value="Highlighter">Highlighter</option>
//                       </select>
//                     </td>
//                     <td className="p-2">
//                       <input
//                         type="number"
//                         className="w-full ml-2 border border-gray-300 h-9 px-2 rounded-md focus:outline-none"
//                         value={item.numberOfItems}
//                         onChange={(e) => handleItemChange(index, "numberOfItems", e.target.value)}
//                       />
//                     </td>
//                     <td className="p-2">
//                       <button
//                         onClick={() => handleRemoveItem(index)}
//                         className="text-red-500 hover:text-red-700"
//                       >
//                         <BsTrash />
//                       </button>
//                     </td>
//                   </tr>
//                 ))}
//               </tbody>
//             </table>
//           </div>
//         </div>

//         {/* Action Buttons */}
//         <div className="mt-6 flex justify-end space-x-2">
//             <button
//                 onClick={() => handleSubmit("Draft")}
//                 className="px-4 py-2 bg-yellow-500 text-white rounded hover:bg-yellow-600"
//             >
//                 Save as Draft
//             </button>
//             <button
//                 onClick={() => handleSubmit("Submitted")}
//                 className="px-4 py-2 bg-green-500 text-white rounded hover:bg-green-600"
//             >
//                 Submit
//             </button>
//             <button onClick={onClose} className="px-4 py-2 bg-gray-300 rounded hover:bg-gray-400">
//                 Cancel
//             </button>
//         </div>


//       </div>
//     </div>
//   );
// };

// export default CreateRequestModal;



















