import React, { useState, useEffect } from "react";
import { FaRegCircleXmark, FaSquarePlus } from "react-icons/fa6";
import { BsTrash } from "react-icons/bs";

const EditRequestModal = ({ isOpen, onClose, record, onSubmit }) => {
  const [purpose, setPurpose] = useState("");
  const [priority, setPriority] = useState("");
  const [items, setItems] = useState([]);
  const [itemNames, setItemNames] = useState([]); // State to store item names fetched from the backend
  const [priorities, setPriorities] = useState([]); // State to store priorities fetched from the backend

  useEffect(() => {
    // Fetch item names and priorities when the modal is opened
    const fetchData = async () => {
      try {
        const [itemNamesResponse, prioritiesResponse] = await Promise.all([
          fetch("http://localhost:9031/api/itemnames"), // Replace with your backend API
          fetch("http://localhost:9031/api/priorities") // Replace with your backend API
        ]);

        if (!itemNamesResponse.ok || !prioritiesResponse.ok) {
          throw new Error("Error fetching data");
        }

        const itemNamesData = await itemNamesResponse.json();
        const prioritiesData = await prioritiesResponse.json();

        setItemNames(itemNamesData);
        setPriorities(prioritiesData);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    if (isOpen) {
      fetchData();
    }
  }, [isOpen]);

  useEffect(() => {
    if (record) {
      console.log("Loaded Record: ", record); 
      setPurpose(record.purpose || "");
      setPriority(record.priority || "");

      if (Array.isArray(record.items) && record.items.length > 0) {
        setItems(
          record.items.map((item) => ({
            itemName: item.itemName || "",
            numberOfItems: item.numberOfItems || 0
          }))
        );
      } else {
        setItems([]);
      }
    }
  }, [record]);

  const handleAddItem = () => {
    setItems([...items, { itemName: "", numberOfItems: "" }]);
  };

  const handleRemoveItem = (index) => {
    const updatedItems = items.filter((_, i) => i !== index);
    setItems(updatedItems);
  };

  const handleItemChange = (index, field, value) => {
    const updatedItems = [...items];
    updatedItems[index][field] = value;
    setItems(updatedItems);
  };

  const handleSave = () => {
    if (!purpose || !priority || items.some((item) => !item.itemName || !item.numberOfItems)) {
      alert("Please fill all required fields.");
      return;
    }

    const updatedData = { ...record, purpose, priority, items };
    onSubmit(updatedData);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-gray-600 bg-opacity-50 flex justify-center items-center z-50">
      <div className="bg-white rounded-lg w-2/4 p-6 shadow-lg">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-semibold">Edit Request</h2>
          <button onClick={onClose} className="text-red-500 hover:text-red-700">
            <FaRegCircleXmark />
          </button>
        </div>

        <div className="w-auto mt-6 mx-8 flex items-center justify-between">
          <h1 className="text-black-500 font-medium">Purpose</h1>
          <input
            type="text"
            value={purpose}
            onChange={(e) => setPurpose(e.target.value)}
            className="w-4/5 mr-2 border border-gray-300 h-9 outline-none rounded-md px-2"
          />
        </div>

        <div className="w-auto mt-6 mx-8 flex items-center justify-between">
          <h1 className="text-black-500 font-medium">Priority</h1>
          <select
            value={priority}
            onChange={(e) => setPriority(e.target.value)}
            className="w-4/5 mr-2 border border-gray-300 h-9 outline-none rounded-md px-2"
          >
            <option value="">Select</option>
            {priorities.map((priorityOption) => (
              <option key={priorityOption.id} value={priorityOption.name}>
                {priorityOption.name}
              </option>
            ))}
          </select>
        </div>

        <div className="mt-6">
          <h3 className="font-semibold text-black-500 pb-2">Item Details</h3>
          <div className="relative border border-gray-300 rounded-md p-2 w-[40rem]">
            <table className="min-w-full">
              <thead>
                <tr>
                  <th className="text-left p-2 font-semibold border-b border-gray-200">S.NO</th>
                  <th className="text-left pl-6 pr-20 font-semibold whitespace-nowrap border-b border-gray-200">Item Name</th>
                  <th className="text-left pl-6 pr-20 font-semibold whitespace-nowrap border-b border-gray-200">Number of Items</th>
                  <th className="text-right pr-4 border-b border-gray-200">
                    <button onClick={handleAddItem} className="focus:outline-none">
                      <FaSquarePlus className="text-blue-500 text-2xl" />
                    </button>
                  </th>
                </tr>
              </thead>
              <tbody>
                {items.map((item, index) => (
                  <tr key={index} className="border border-gray-300">
                    <td className="text-left p-2">{index + 1}</td>
                    <td className="pl-4">
                      <select
                        className="w-full h-9 px-2 border border-gray-300 rounded-md focus:outline-none appearance-none"
                        value={item.itemName}
                        onChange={(e) => handleItemChange(index, "itemName", e.target.value)}
                      >
                        <option value="">Select Item</option>
                        {itemNames.map((itemName) => (
                          <option key={itemName.id} value={itemName.name}>
                            {itemName.name}
                          </option>
                        ))}
                      </select>
                    </td>
                    <td className="p-2">
                      <input
                        type="number"
                        className="w-full ml-2 border border-gray-300 h-9 px-2 rounded-md focus:outline-none"
                        value={item.numberOfItems || ""}
                        onChange={(e) => handleItemChange(index, "numberOfItems", e.target.value)}
                      />
                    </td>
                    <td className="p-2">
                      <button onClick={() => handleRemoveItem(index)} className="text-red-500 hover:text-red-700">
                        <BsTrash />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="mt-6 flex justify-end space-x-2">
          <button onClick={handleSave} className="px-4 py-2 bg-green-500 text-white rounded hover:bg-green-600">
            Save
          </button>
          <button onClick={onClose} className="px-4 py-2 bg-gray-300 rounded hover:bg-gray-400">
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
};

export default EditRequestModal;










// import React, { useState, useEffect } from "react";
// import { FaRegCircleXmark, FaSquarePlus } from "react-icons/fa6";
// import { BsTrash } from "react-icons/bs";

// const EditRequestModal = ({ isOpen, onClose, record, onSubmit }) => {
//   const [purpose, setPurpose] = useState("");
//   const [priority, setPriority] = useState("");
//   const [items, setItems] = useState([]);

//   useEffect(() => {
//     if (record) {
//       console.log("Loaded record:", record); // Debugging log
//       setPurpose(record.purpose || "");
//       setPriority(record.priority || "");
  
//       // Check if items is an array and has objects
//       if (Array.isArray(record.items) && record.items.length > 0) {
//         setItems(
//           record.items.map(item => ({
//             itemName: item.itemName || "", // Ensure itemName exists
//             numberOfItems: item.numberOfItems || 0 // Ensure numberOfItems exists
//           }))
//         );
//       } else {
//         setItems([]); // Empty array if no items or invalid
//       }
//     }
//   }, [record]);
  
  
  
// const handleAddItem = () => {
//     setItems([...items, { itemName: "", numberOfItems: "" }]); // Add a new empty item
//   };

//   const handleRemoveItem = (index) => {
//     const updatedItems = items.filter((_, i) => i !== index);
//     setItems(updatedItems);
//   };

//   // const handleItemChange = (index, field, value) => {
//   //   setItems(prevItems => {
//   //     const updatedItems = [...prevItems];
//   //     updatedItems[index] = { ...updatedItems[index], [field]: value };
//   //     return updatedItems;
//   //   });
//   // };

//  // Handle changes in item name or number of items
// const handleItemChange = (index, field, value) => {
//   const updatedItems = [...items];
//   updatedItems[index][field] = value;
//   setItems(updatedItems);
// };
  

// const handleSave = () => {
//   // Validate if all fields are filled
//   if (!purpose || !priority || items.some(item => !item.itemName || !item.numberOfItems)) {
//     alert("Please fill all required fields.");
//     return;
//   }

//   // Prepare updated data
//   const updatedData = { ...record, purpose, priority, items };

//   // Pass the updated data to the parent component (if needed)
//   onSubmit(updatedData);

//   // Close the modal after saving
//   onClose();
// };



//   if (!isOpen) return null;

//   return (
//     <div className="fixed inset-0 bg-gray-600 bg-opacity-50 flex justify-center items-center z-50">
//       <div className="bg-white rounded-lg w-2/4 p-6 shadow-lg">
//         <div className="flex justify-between items-center mb-4">
//           <h2 className="text-xl font-semibold">Edit Request</h2>
//           <button onClick={onClose} className="text-red-500 hover:text-red-700">
//             <FaRegCircleXmark />
//           </button>
//         </div>
  
//         <div className="w-auto mt-6 mx-8 flex items-center justify-between">
//           <h1 className="text-black-500 font-medium">Purpose</h1>
//           <input
//             type="text"
//             value={purpose}
//             onChange={(e) => setPurpose(e.target.value)}
//             className="w-4/5 mr-2 border border-gray-300 h-9 outline-none rounded-md px-2"
//           />
//         </div>
  
//         <div className="w-auto mt-6 mx-8 flex items-center justify-between">
//           <h1 className="text-black-500 font-medium">Priority</h1>
//           <select
//             value={priority}
//             onChange={(e) => setPriority(e.target.value)}
//             className="w-4/5 mr-2 border border-gray-300 h-9 outline-none rounded-md px-2"
//           >
//             <option value="">Select</option>
//             <option value="Low">Low</option>
//             <option value="Medium">Medium</option>
//             <option value="High">High</option>
//           </select>
//         </div>
  
//         <div className="mt-6">
//           <h3 className="font-semibold text-black-500 pb-2">Item Details</h3>
//           <div className="relative border border-gray-300 rounded-md p-2 w-[40rem]">
//             <table className="min-w-full">
//               <thead>
//                 <tr>
//                   <th className="text-left p-2 font-semibold border-b border-gray-200">S.NO</th>
//                   <th className="text-left pl-6 pr-20 font-semibold whitespace-nowrap border-b border-gray-200">Item Name</th>
//                   <th className="text-left pl-6 pr-20 font-semibold whitespace-nowrap border-b border-gray-200">Number of Items</th>
//                   <th className="text-right pr-4 border-b border-gray-200">
//                     <button onClick={handleAddItem} className="focus:outline-none">
//                       <FaSquarePlus className="text-blue-500 text-2xl" />
//                     </button>
//                   </th>
//                 </tr>
//               </thead>
//               <tbody>
//                 {items.map((item, index) => (
//                   <tr key={index} className="border border-gray-300">
//                     <td className="text-left p-2">{index + 1}</td>
//                     <td className="pl-4">
//                       <select
//                         className="w-full h-9 px-2 border border-gray-300 rounded-md focus:outline-none appearance-none"
//                         value={item.itemName}
//                         onChange={(e) => handleItemChange(index, "itemName", e.target.value)}
//                       >
//                         <option value="">Select Item</option>
//                         <option value="Pen">Pen</option>
//                         <option value="Pencil">Pencil</option>
//                         <option value="Stapler">Stapler</option>
//                         <option value="Marker">Marker</option>
//                         <option value="Highlighter">Highlighter</option>
//                       </select>
//                     </td>
//                     <td className="p-2">
//                       <input
//                         type="number"
//                         className="w-full ml-2 border border-gray-300 h-9 px-2 rounded-md focus:outline-none"
//                         value={item.numberOfItems || ""}
//                         onChange={(e) => handleItemChange(index, "numberOfItems", e.target.value)}
//                       />
//                     </td>
//                     <td className="p-2">
//                       <button onClick={() => handleRemoveItem(index)} className="text-red-500 hover:text-red-700">
//                         <BsTrash />
//                       </button>
//                     </td>
//                   </tr>
//                 ))}
//               </tbody>
//             </table>
//           </div>
//         </div>
  
//          <div className="mt-6 flex justify-end space-x-2">
//           <button onClick={handleSave} className="px-4 py-2 bg-green-500 text-white rounded hover:bg-green-600">
//             Save
//           </button>
//           <button onClick={onClose} className="px-4 py-2 bg-gray-300 rounded hover:bg-gray-400">
//             Cancel
//           </button>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default EditRequestModal;






// import React, { useState, useEffect } from "react";
// import { FaRegCircleXmark, FaSquarePlus } from "react-icons/fa6";
// import { BsTrash } from "react-icons/bs";

// const EditRequestModal = ({ isOpen, onClose, record, onSubmit }) => {
//   const [purpose, setPurpose] = useState("");
//   const [priority, setPriority] = useState("");
//   const [items, setItems] = useState([]);

//   useEffect(() => {
//     if (record) {
//       setPurpose(record.purpose || "");
//       setPriority(record.priority || "");
//       setItems(Array.isArray(record.items) ? record.items : []);
//     }
//   }, [record]);

//   const handleAddItem = () => {
//     setItems([...items, { itemName: "", quantity: "" }]);
//   };

//   const handleRemoveItem = (index) => {
//     setItems(items.filter((_, i) => i !== index));
//   };

//   const handleItemChange = (index, field, value) => {
//     const updatedItems = [...items];
//     updatedItems[index][field] = value;
//     setItems(updatedItems);
//   };

//   const handleSave = () => {
//     if (!purpose || !priority || items.some((item) => !item.itemName || !item.quantity)) {
//       alert("Please fill all required fields.");
//       return;
//     }

//     const updatedData = { ...record, purpose, priority, items };
//     onSubmit(updatedData);
//     onClose();
//   };

//   if (!isOpen) return null;

//   return (
//     <div className="fixed inset-0 bg-gray-600 bg-opacity-50 flex justify-center items-center z-50">
//       <div className="bg-white rounded-lg w-2/4 p-6 shadow-lg">
//         <div className="flex justify-between items-center mb-4">
//           <h2 className="text-xl font-semibold">Edit Request</h2>
//           <button onClick={onClose} className="text-red-500 hover:text-red-700">
//             <FaRegCircleXmark />
//           </button>
//         </div>

//         <div className="w-auto mt-6 mx-8 flex items-center justify-between">
//           <h1 className="text-black-500 font-medium">Purpose</h1>
//           <input
//             type="text"
//             value={purpose}
//             onChange={(e) => setPurpose(e.target.value)}
//             className="w-4/5 mr-2 border border-gray-300 h-9 outline-none rounded-md px-2"
//           />
//         </div>

//         <div className="w-auto mt-6 mx-8 flex items-center justify-between">
//           <h1 className="text-black-500 font-medium">Priority</h1>
//           <select
//             value={priority}
//             onChange={(e) => setPriority(e.target.value)}
//             className="w-4/5 mr-2 border border-gray-300 h-9 outline-none rounded-md px-2"
//           >
//             <option value="">Select</option>
//             <option value="Low">Low</option>
//             <option value="Medium">Medium</option>
//             <option value="High">High</option>
//           </select>
//         </div>

//         <div className="mt-6">
//           <h3 className="font-semibold text-black-500 pb-2">Item Details</h3>
//           <div className="relative border border-gray-300 rounded-md p-2 w-[40rem]">
//             <table className="w-full">
//               <thead>
//                 <tr>
//                   <th className="text-left p-2 font-semibold">S.NO</th>
//                   <th className="text-left pl-6 pr-36 font-semibold">Item Name</th>
//                   <th className="text-left pl-6 pr-36 font-semibold">Quantity (Nos)</th>
//                   <th className="text-right pr-10">
//                     <button onClick={handleAddItem} className="focus:outline-none">
//                       <FaSquarePlus className="text-blue-500 text-2xl" />
//                     </button>
//                   </th>
//                 </tr>
//               </thead>
//               <tbody>
//                 {items.map((item, index) => (
//                   <tr key={index} className="border-t border-gray-300">
//                     <td className="text-left p-2">{index + 1}</td>
//                     <td className="pl-6">
//                       <input
//                         type="text"
//                         value={item.itemName}
//                         onChange={(e) => handleItemChange(index, "itemName", e.target.value)}
//                         className="w-[15rem] h-9 px-2 border border-gray-300 rounded-md"
//                       />
//                     </td>
//                     <td className="pl-6">
//                       <input
//                         type="number"
//                         value={item.quantity}
//                         onChange={(e) => handleItemChange(index, "quantity", e.target.value)}
//                         className="w-[15rem] h-9 px-2 border border-gray-300 rounded-md"
//                       />
//                     </td>
//                     <td className="text-right pr-10">
//                       <button
//                         onClick={() => handleRemoveItem(index)}
//                         className="text-red-500 hover:text-red-700"
//                       >
//                         <BsTrash />
//                       </button>
//                     </td>
//                   </tr>
//                 ))}
//               </tbody>
//             </table>
//           </div>
//         </div>

//         <div className="mt-6 flex justify-end space-x-2">
//           <button onClick={handleSave} className="px-4 py-2 bg-green-500 text-white rounded hover:bg-green-600">
//             Save
//           </button>
//           <button onClick={onClose} className="px-4 py-2 bg-gray-300 rounded hover:bg-gray-400">Cancel</button>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default EditRequestModal;











































// import React, { useState, useEffect } from "react";

// const EditRequestModal = ({ isOpen, onClose, record, onSubmit }) => {
//   const [formData, setFormData] = useState({
//     reqNo: "",
//     date: "",
//     items: "",
//     purpose: "",
//     priority: "",
//     status: "",
//     issueStatus: "",
//   });

//   useEffect(() => {
//     if (record) {
//       setFormData(record); // Pre-fill the form with the record data
//     }
//   }, [record]);

//   const handleChange = (e) => {
//     const { name, value } = e.target;
//     setFormData({ ...formData, [name]: value });
//   };

//   const handleSubmit = (e) => {
//     e.preventDefault();
//     onSubmit(formData); // Submit the updated data to the parent component
//     onClose(); // Close the modal after submitting
//   };

//   if (!isOpen) return null;

//   return (
//     <div className="fixed inset-0 bg-gray-600 bg-opacity-50 flex justify-center items-center">
//       <div className="bg-white p-6 rounded-md shadow-md w-[400px]">
//         <h2 className="text-2xl font-bold mb-4">Edit Request</h2>
//         <form onSubmit={handleSubmit}>
//           <div className="mb-4">
//             <label className="block mb-1">Request Date</label>
//             <input
//               type="date"
//               name="date"
//               className="w-full p-2 border border-gray-300 rounded"
//               value={formData.date}
//               onChange={handleChange}
//             />
//           </div>
//           <div className="mb-4">
//             <label className="block mb-1">No of Items</label>
//             <input
//               type="number"
//               name="items"
//               className="w-full p-2 border border-gray-300 rounded"
//               value={formData.items}
//               onChange={handleChange}
//             />
//           </div>
//           <div className="mb-4">
//             <label className="block mb-1">Purpose</label>
//             <input
//               type="text"
//               name="purpose"
//               className="w-full p-2 border border-gray-300 rounded"
//               value={formData.purpose}
//               onChange={handleChange}
//             />
//           </div>
//           <div className="mb-4">
//             <label className="block mb-1">Priority</label>
//             <select
//               name="priority"
//               className="w-full p-2 border border-gray-300 rounded"
//               value={formData.priority}
//               onChange={handleChange}
//             >
//               <option value="High">High</option>
//               <option value="Medium">Medium</option>
//               <option value="Low">Low</option>
//             </select>
//           </div>
//           <div className="mb-4">
//             <label className="block mb-1">Status</label>
//             <select
//               name="status"
//               className="w-full p-2 border border-gray-300 rounded"
//               value={formData.status}
//               onChange={handleChange}
//             >
//               <option value="Approved">Approved</option>
//               <option value="Rejected">Rejected</option>
//               <option value="Pending">Pending</option>
//               <option value="Draft">Draft</option>
//             </select>
//           </div>
//           <div className="mb-4">
//             <label className="block mb-1">Issue Status</label>
//             <select
//               name="issueStatus"
//               className="w-full p-2 border border-gray-300 rounded"
//               value={formData.issueStatus}
//               onChange={handleChange}
//             >
//               <option value="Issued">Issued</option>
//               <option value="Not issued">Not issued</option>
//             </select>
//           </div>
//           <div className="flex justify-between mt-6">
//             <button
//               type="button"
//               className="bg-gray-500 text-white px-4 py-2 rounded"
//               onClick={onClose}
//             >
//               Cancel
//             </button>
//             <button
//               type="submit"
//               className="bg-blue-500 text-white px-4 py-2 rounded"
//             >
//               Save
//             </button>
//           </div>
//         </form>
//       </div>
//     </div>
//   );
// };

// export default EditRequestModal;
