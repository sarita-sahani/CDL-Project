import React from "react";
import { FaRegCircleXmark } from "react-icons/fa6";

const ViewRequestModal = ({ isOpen, onClose, record }) => {
  if (!isOpen || !record) return null; // Don't render modal if not open or no record
  console.log("Record Data in Modal:", record); // Debugging

  return (
    <div className="fixed inset-0 bg-gray-600 bg-opacity-50 flex justify-center items-center z-50">
      <div className="bg-white rounded-lg w-2/4 p-6 shadow-lg">
        
        {/* Modal Header */}
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-semibold">Request Details</h2>
          <button onClick={onClose} className="text-red-500 hover:text-red-700">
            <FaRegCircleXmark />
          </button>
        </div>

        {/* Purpose */}
        <div className="w-auto mt-6 mx-8 flex items-center justify-between">
          <h3 className="font-medium">Purpose</h3>
          <span className="w-4/5 mr-2 border border-gray-300 h-9 flex items-center rounded-md px-2">
            {record.purpose || "N/A"}
          </span>
        </div>

        {/* Priority */}
        <div className="w-auto mt-6 mx-8 flex items-center justify-between">
          <h3 className="font-medium">Priority</h3>
          <span className="w-4/5 mr-2 border border-gray-300 h-9 flex items-center rounded-md px-2">
            {record.priority || "N/A"}
          </span>
        </div>

        {/* Items Table */}
        <div className="mt-6">
          <h3 className="font-semibold text-black-500 pb-2">Item Details</h3>
          <div className="relative border border-gray-300 rounded-md p-2 w-[40rem]">
            <table className="w-full">
              <thead>
                <tr>
                  <th className="text-left p-2 font-semibold border-b border-gray-200">S.NO</th>
                  <th className="text-left pl-6 pr-36 font-semibold border-b border-gray-200">Item Name</th>
                  <th className="text-left pl-6 pr-36 font-semibold border-b border-gray-200">Number of Items</th>
                </tr>
              </thead>
              <tbody>
                {Array.isArray(record.items) && record.items.length > 0 ? (
                  record.items.map((item, index) => (
                    <tr key={index} className="border-t border-gray-300">
                      <td className="text-left p-2">{index + 1}</td>
                      <td className="pl-6">{item.itemName || "N/A"}</td>
                      <td className="pl-6">{item.numberOfItems || "N/A"}</td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan="3" className="text-center p-2">No items found</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Close Button */}
        <div className="flex justify-end mt-4">
          <button className="bg-gray-500 text-white px-4 py-2 rounded" onClick={onClose}>
            Close
          </button>
        </div>

      </div>
    </div>
  );
};

export default ViewRequestModal;












//with API Calling
// import React, { useState, useEffect } from "react";
// import { FaRegCircleXmark } from "react-icons/fa6";

// const ViewRequestModal = ({ isOpen, onClose, requestId }) => {
//   const [record, setRecord] = useState(null);
//   const [loading, setLoading] = useState(true);
  
// useEffect(() => {
//   if (isOpen && requestId) {
//     const fetchData = async () => {
//       const response = await fetch(`http://localhost:9031/api/requests/${requestId}`);
//       const data = await response.json();
//       setRecord(data); 
//     };
//     fetchData();
//   }
// }, [isOpen, requestId]);


//   if (!isOpen) return null;  // Don't render if not open
//   if (!record) return <div>Loading...</div>; // Show loading if no data yet

//   return (
//     <div className="fixed inset-0 bg-gray-600 bg-opacity-50 flex justify-center items-center z-50">
//       <div className="bg-white rounded-lg w-2/4 p-6 shadow-lg">
//         <div className="flex justify-between items-center mb-4">
//           <h2 className="text-xl font-semibold">Request Details</h2>
//           <button onClick={onClose} className="text-red-500 hover:text-red-700">
//             <FaRegCircleXmark />
//           </button>
//         </div>

//         <div className="w-auto mt-6 mx-8 flex items-center justify-between">
//           <h1 className="text-black-500 font-medium">Purpose</h1>
//           <span className="w-4/5 mr-2 border border-gray-300 h-9 flex items-center rounded-md px-2">
//             {record?.purpose || "N/A"}
//           </span>
//         </div>

//         <div className="w-auto mt-6 mx-8 flex items-center justify-between">
//           <h1 className="text-black-500 font-medium">Priority</h1>
//           <span className="w-4/5 mr-2 border border-gray-300 h-9 flex items-center rounded-md px-2">
//             {record?.priority || "N/A"}
//           </span>
//         </div>

//         <div className="mt-6">
//           <h3 className="font-semibold text-black-500 pb-2">Item Details</h3>
//           <div className="relative border border-gray-300 rounded-md p-2 w-[40rem]">
//             <table className="w-full">
//               <thead>
//                 <tr>
//                   <th className="text-left p-2 font-semibold border-b border-gray-200">S.NO</th>
//                   <th className="text-left pl-6 pr-36 font-semibold border-b border-gray-200">Item Name</th>
//                   <th className="text-left pl-6 pr-36 font-semibold border-b border-gray-200">Number of Items</th>
//                 </tr>
//               </thead>
//               <tbody>
//                 {Array.isArray(record?.items) && record.items.length > 0 ? (
//                   record.items.map((item, index) => (
//                     <tr key={index} className="border-t border-gray-300">
//                       <td className="text-left p-2">{index + 1}</td>
//                       <td className="pl-6">{item.itemName || "N/A"}</td>
//                       <td className="pl-6">{item.numberOfItems || "N/A"}</td>
//                     </tr>
//                   ))
//                 ) : (
//                   <tr>
//                     <td colSpan="3" className="text-center p-2">No items found</td>
//                   </tr>
//                 )}
//               </tbody>
//             </table>
//           </div>
//         </div>

//         <div className="flex justify-end mt-4">
//           <button className="bg-gray-500 text-white px-4 py-2 rounded" onClick={onClose}>
//             Close
//           </button>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default ViewRequestModal;











// import React from "react";
// import { FaRegCircleXmark } from "react-icons/fa6";

// const ViewRequestModal = ({ isOpen, onClose, record }) => {
//   // Debugging: Log record to see if it has the expected data
//   console.log("Record data:", record);

//   if (!isOpen) return null;

//   return (
//     <div className="fixed inset-0 bg-gray-600 bg-opacity-50 flex justify-center items-center z-50">
//       <div className="bg-white rounded-lg w-2/4 p-6 shadow-lg">
//         {/* Modal Header */}
//         <div className="flex justify-between items-center mb-4">
//           <h2 className="text-xl font-semibold">Request Details</h2>
//           <button onClick={onClose} className="text-red-500 hover:text-red-700">
//             <FaRegCircleXmark />
//           </button>
//         </div>

//         {/* Display Purpose */}
//         <div className="w-auto mt-6 mx-8 flex items-center justify-between">
//           <h1 className="text-black-500 font-medium">Purpose</h1>
//           <span className="w-4/5 mr-2 border border-gray-300 h-9 flex items-center rounded-md px-2">
//             {record?.purpose || "N/A"}
//           </span>
//         </div>

//         {/* Display Priority */}
//         <div className="priorityDropdown">
//           <div className="w-auto mt-6 mx-8 flex items-center justify-between">
//             <h1 className="text-black-500 font-medium">Priority</h1>
//             <span className="w-4/5 mr-2 border border-gray-300 h-9 flex items-center rounded-md px-2">
//               {record?.priority || "N/A"}
//             </span>
//           </div>
//         </div>

//         {/* Item Details Section */}
//         <div className="mt-6">
//           <h3 className="font-semibold text-black-500 pb-2">Item Details</h3>
//           <div className="relative border border-gray-300 rounded-md p-2 w-[40rem]">
//             <table className="w-full">
//               <thead>
//                 <tr>
//                   <th className="text-left p-2 font-semibold">S.NO</th>
//                   <th className="text-left pl-6 pr-36 font-semibold">Item Name</th>
//                   <th className="text-left pl-6 pr-36 font-semibold">Quantity (Nos)</th>
//                 </tr>
//               </thead>
//               <tbody>
//                 {Array.isArray(record?.items) && record.items.length > 0 ? (
//                   record.items.map((item, index) => (
//                     <tr key={index} className="border-t border-gray-300">
//                       <td className="text-left p-2">{index + 1}</td>
//                       <td className="pl-6">{item.itemName || "N/A"}</td>
//                       <td className="pl-6">{item.quantity || "N/A"}</td>
//                     </tr>
//                   ))
//                 ) : (
//                   <tr>
//                     <td colSpan="3" className="text-center p-2">No items found</td>
//                   </tr>
//                 )}
//               </tbody>
//             </table>
//           </div>
//         </div>

//         {/* Close Button */}
//         <div className="flex justify-end mt-4">
//           <button
//             className="bg-gray-500 text-white px-4 py-2 rounded"
//             onClick={onClose}
//           >
//             Close
//           </button>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default ViewRequestModal;








