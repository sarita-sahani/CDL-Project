import React, { useState, useEffect } from "react";
import DataTable from "react-data-table-component";
import { CgSortAz } from "react-icons/cg";
import CreateRequestModal from "./CreateRequestModal";
import EditRequestModal from "./EditRequestModal";
import EditDraftRequestModal from "./EditDraftRequestModal";  // Import the new EditDraftRequestModal
import ViewRequestModal from "./ViewRequestModal";
import { MdOutlineEdit } from "react-icons/md";
import { RiDeleteBin5Line } from "react-icons/ri";
import { useNavigate } from "react-router-dom";

const StationaryRequest = () => {
  const [data, setData] = useState([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isViewModalOpen, setIsViewModalOpen] = useState(false);
  const [selectedRecord, setSelectedRecord] = useState(null);
  const [isEditDraftModalOpen, setIsEditDraftModalOpen] = useState(false);

  let navigate = useNavigate();
//  const empId=123;
  // Fetch data from both requests and drafts endpoints
  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [requestsResponse, draftsResponse] = await Promise.all([
        fetch("http://localhost:9031/api/requests"),
        fetch("http://localhost:9031/api/save-draft"),
      ]);

      if (!requestsResponse.ok || !draftsResponse.ok) {
        throw new Error("Failed to fetch data from the backend");
      }

      const requests = await requestsResponse.json();
      const drafts = await draftsResponse.json();

      console.log("Requests Data:", requests);
      console.log("Drafts Data:", drafts);
      const mergedData = [
        ...requests.map((item) => ({
          reqNo: item.id,
          date: item.requestDate ? item.requestDate : new Date().toLocaleDateString(), // Default to today's date if no requestDate
          items: Array.isArray(item.items) ? item.items : [],
          numberOfItems: item.items
            ? item.items.reduce((total, currentItem) => total + (currentItem.numberOfItems || 0), 0)
            : 0, // Calculate total number of items
          purpose: item.purpose || "N/A",
          priority: item.priority || "N/A",
          status: item.status || "Pending",
          itemIssueStatus: item.issueStatus ? item.issueStatus : "Not Issued", // Check if issueStatus is present, else "Not Issued"
        })),
        ...drafts.map((item) => ({
          reqNo: item.id,
          date: item.createdDate ? item.createdDate : new Date().toLocaleDateString(), // Default to today's date if no createdDate
          items: Array.isArray(item.items) ? item.items : [],
          numberOfItems: item.items
            ? item.items.reduce((total, currentItem) => total + (currentItem.numberOfItems || 0), 0)
            : 0, // Calculate total number of items
          purpose: item.purpose || "N/A",
          priority: item.priority || "N/A",
          status: "Draft",
          itemIssueStatus: item.issueStatus ? item.issueStatus : "Not Issued", // Ensure fallback value for drafts
        })),
      ];
      
      

      console.log("Merged Data:", mergedData);
      setData(mergedData);
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  const handleRowClick = (row) => {
    console.log("Selected Row Data:", row);
    console.log("Items Array in Selected Row:", row.items);

    setSelectedRecord({
      ...row,
      items: row.items ? row.items : [], // Ensure items is always an array
    });

    setIsViewModalOpen(true);
  };

  const handleEditClick = (record) => {
    setSelectedRecord(record); // Set the selected record for editing
    if (record.status === "Draft") {
      setIsEditDraftModalOpen(true); // Open Draft Edit Modal if it's a draft
    } else {
      setIsEditModalOpen(true); // Open Regular Edit Modal if it's not a draft
    }
  };

  const handleDeleteClick = async (record) => {
    try {
      const response = await fetch(`http://localhost:9031/api/requests/${record.reqNo}`, {
        method: "DELETE",
      });

      if (!response.ok) throw new Error("Failed to delete record");
      setData(data.filter((item) => item.reqNo !== record.reqNo)); // Remove the deleted record from the state
    } catch (error) {
      console.error("Error deleting record:", error);
    }
  };

  // Define getStatusStyle function
  const getStatusStyle = (status) => {
    switch (status) {
      case "Approved":
        return "bg-green-500 text-white p-2 rounded"; // Green background with white text
      case "Rejected":
        return "bg-red-500 text-white p-2 rounded"; // Red background with white text
      case "Pending":
        return "bg-blue-500 text-white p-2 rounded"; // Blue background with white text
      case "Draft":
        return "bg-gray-500 text-white p-2 rounded"; // Gray background with white text
      default:
        return "bg-gray-200 text-gray-700 p-2 rounded"; // Default case (in case status is not recognized)
    }
  };

  const columns = [
    {
      name: <>
        Req No <CgSortAz size="1.2em" />
      </>,
      selector: (row) => row.reqNo,
      sortable: true,
      center: true,
    },
    {
      name: <>Request Date <CgSortAz size="1.2em" /></>,
      selector: (row) => row.date,
      sortable: true,
      center: true,
    },
    {
      name: <>
        No of Items <CgSortAz size="1.2em" />
      </>,
      selector: (row) => row.numberOfItems, // Now using the formatted numberOfItems
      sortable: true,
      center: true,
      style: {
        whiteSpace: "nowrap", // Prevents wrapping
      },
    },
    {
      name: <>
        Purpose <CgSortAz size="1.2em" />
      </>,
      selector: (row) => row.purpose,
      sortable: true,
      center: true,
    },
    {
      name: <>
        Priority <CgSortAz size="1.2em" />
      </>,
      selector: (row) => row.priority,
      sortable: true,
      center: true,
    },
    {
      name: <>
        Status <CgSortAz size="1.2em" />
      </>,
      selector: (row) => row.status,
      sortable: true,
      center: true,
      cell: (row) => (
        <span className={getStatusStyle(row.status)}>{row.status}</span>
      ),
    },
    {
      name: <>
        Issue Status <CgSortAz size="1.2em" />
      </>,
      selector: (row) => row.itemIssueStatus || "Not Issued", // ✅ Fallback text
      sortable: true,
      center: true,
    },
    {
      name: "Actions",
      center: true,
      cell: (row) => (
        <div className="flex space-x-4 items-center">
          {row.status !== "Approved" && row.status !== "Rejected" && (
            <>
              <button
                onClick={() => handleEditClick(row)}
                className="text-gray-500 hover:text-gray-700"
                title="Edit"
              >
                <MdOutlineEdit size="1.2em" />
              </button>
              <button
                onClick={() => handleDeleteClick(row)}
                className="text-gray-500 hover:text-gray-700"
                title="Delete"
              >
                <RiDeleteBin5Line size="1.2em" />
              </button>
            </>
          )}
        </div>
      ),
    },
  ];

  return (
    <div className="container mx-auto p-4">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-2xl font-bold">Stationary Request</h2>
        <button
          className="bg-blue-500 text-white px-4 py-2 rounded"
          onClick={() => setIsModalOpen(true)}
        >
          Create New Request
        </button>
      </div>

      <div className="shadow border-transparent w-11/12 rounded-md ml-8 mt-4">
        <DataTable
          columns={columns}
          data={data}
          pagination
          highlightOnHover
          onRowClicked={handleRowClick}
          customStyles={{
            headCells: {
              style: {
                whiteSpace: "nowrap", // Ensures headers stay on one line
                fontSize: "14px", // Adjust the font size for all headers
                fontWeight: "bold", // Make headers bold
                textAlign: "center", // Center-align text in the headers
                color: "#374151", // Set a custom text color
                padding: "12px", // Add padding to the headers
              },
            },
            rows: {
              style: {
                color: "#9CA3AF", // Light gray text color
                fontSize: "13px", // Set row text size
                "&:hover": {
                  backgroundColor: "#f3f4f6", // Optional: Hover effect for rows
                },
              },
            },
          }}
        />
      </div>

      <CreateRequestModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onSubmit={async (newRequest) => {
          try {
            const response = await fetch("http://localhost:9031/api/requests", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify(newRequest),
            });
            if (!response.ok) throw new Error("Failed to create record");
            const result = await response.json();
            setData([...data, result]);
            setIsModalOpen(false);
          } catch (error) {
            console.error("Error creating record:", error);
          }
        }}
      />

      <EditRequestModal
        isOpen={isEditModalOpen}
        onClose={() => setIsEditModalOpen(false)}
        record={selectedRecord}
        onSubmit={async (editedRecord) => {
          try {
            const response = await fetch(`http://localhost:9031/api/requests/${editedRecord.reqNo}`, {
              method: "PUT",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify(editedRecord),
            });
            if (!response.ok) throw new Error("Failed to update record");
            const updatedRecord = await response.json();
            const updatedData = data.map((record) =>
              record.reqNo === updatedRecord.reqNo ? updatedRecord : record
            );
            setData(updatedData);
            setIsEditModalOpen(false);
          } catch (error) {
            console.error("Error updating record:", error);
          }
        }}
      />

      <EditDraftRequestModal
        isOpen={isEditDraftModalOpen}
        onClose={() => setIsEditDraftModalOpen(false)}
        record={selectedRecord}
        onSubmit={async (editedDraft) => {
          try {
            const response = await fetch(`http://localhost:9031/api/save-draft/${editedDraft.reqNo}`, {
              method: "PUT",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify(editedDraft),
            });
            if (!response.ok) throw new Error("Failed to update draft");
            const updatedDraft = await response.json();
            const updatedData = data.map((record) =>
              record.reqNo === updatedDraft.reqNo ? updatedDraft : record
            
            );
            setData(updatedData);
            setIsEditDraftModalOpen(false);
          } catch (error) {
            console.error("Error updating draft:", error);
          }
        }}
      />

      <ViewRequestModal
        isOpen={isViewModalOpen}
        onClose={() => setIsViewModalOpen(false)}
        record={selectedRecord}
      />
    </div>
  );
};

export default StationaryRequest;
