import React, { useState } from 'react';
import { IoReorderThreeOutline } from "react-icons/io5";
import DataTable from 'react-data-table-component';

const allColumns = [
  { name: 'A', selector: row => row.a, sortable: true, id: 'a' },
  { name: 'B', selector: row => row.b, sortable: true, id: 'b' },
  { name: 'C', selector: row => row.c, sortable: true, id: 'c' },
  { name: 'D', selector: row => row.d, sortable: true, id: 'd' },
  { name: 'E', selector: row => row.e, sortable: true, id: 'e' },
  { name: 'F', selector: row => row.f, sortable: true, id: 'f' },
];

const data = [
  { a: 'Apple', b: 'Ball', c: 'Cat', d: 'Dog', e: 'Elephant', f: 'Fish' },
  { a: 'Ant', b: 'Bat', c: 'Cow', d: 'Duck', e: 'Eagle', f: 'Frog' },
];

const Trial = () => {
  const [selectedColumns, setSelectedColumns] = useState(allColumns.map(col => col.id));
  const [showDropdown, setShowDropdown] = useState(false);

  const handleCheckboxChange = (columnId) => {
    setSelectedColumns((prev) =>
      prev.includes(columnId)
        ? prev.filter(id => id !== columnId)
        : [...prev, columnId]
    );
  };

  const handleSelectAll = () => {
    if (selectedColumns.length === allColumns.length) {
      setSelectedColumns([]);
    } else {
      setSelectedColumns(allColumns.map(col => col.id));
    }
  };

  const isAllSelected = selectedColumns.length === allColumns.length;
  const filteredColumns = allColumns.filter(col => selectedColumns.includes(col.id));

  return (
    <div className="p-4">
      <div className="relative inline-block text-left mb-4">
        <div className="flex items-center gap-x-2 border border-b mt-6 cursor-pointer w-fit px-2 py-1" onClick={() => setShowDropdown(prev => !prev)}  >
          <IoReorderThreeOutline /> Choose Columns
        </div>

        {showDropdown && (
          <div className="absolute z-10 mt-2 border rounded p-2 bg-white shadow-md w-48">
            <div className="flex items-center gap-x-2 font-semibold mb-1">
              <input
                type="checkbox"
                id="selectAll"
                checked={isAllSelected}
                onChange={handleSelectAll}
              />
              <label htmlFor="selectAll">Select All</label>
            </div>
            {allColumns.map((col) => (
              <div key={col.id} className="flex items-center gap-x-2">
                <input
                  type="checkbox"
                  id={col.id}
                  checked={selectedColumns.includes(col.id)}
                  onChange={() => handleCheckboxChange(col.id)}
                />
                <label htmlFor={col.id}>{col.name}</label>
              </div>
            ))}
          </div>
        )}
      </div>

      <DataTable
        title="Dynamic Columns Table"
        columns={filteredColumns}
        data={data}
        pagination
      />
    </div>
  );
};

export default Trial;
