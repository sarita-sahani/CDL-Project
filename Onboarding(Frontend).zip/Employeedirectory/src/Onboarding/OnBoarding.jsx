import React, { useState } from 'react';
import { IoIosArrowBack } from "react-icons/io";
import { PiIdentificationBadge } from "react-icons/pi";
import { BsBriefcase } from "react-icons/bs";
import { IoLocationOutline } from "react-icons/io5";
import { MdOutlineMailOutline, MdPhone } from "react-icons/md";
import { FaRegClock } from "react-icons/fa6";
import { useNavigate } from "react-router-dom";


const onboardingData = {
    Applied: [
        { name: "Alice Johnson", email: "alice@example.com", number: "9876543210", date: "2025-06-01" },
        { name: "Bob Smith", email: "bob@example.com", number: "9123456789", date: "2025-06-01" },
        { name: "Charlie Ray", email: "charlie@example.com", number: "9988776655", date: "2025-06-02" },
        { name: "Dana White", email: "dana@example.com", number: "9090909090", date: "2025-06-02" },
        { name: "Eva Green", email: "eva@example.com", number: "9012345678", date: "2025-06-03" },
    ],
    Screening: [
        { name: "Alice Johnson", email: "alice@example.com", number: "9876543210", date: "2025-06-04" },
        { name: "Bob Smith", email: "bob@example.com", number: "9123456789", date: "2025-06-04" },
    ],
    Interview: [
        { name: "Alice Johnson", email: "alice@example.com", number: "9876543210", date: "2025-06-05" },
        { name: "Bob Smith", email: "bob@example.com", number: "9123456789", date: "2025-06-05" },
        { name: "Charlie Ray", email: "charlie@example.com", number: "9988776655", date: "2025-06-06" },
        { name: "Eva Green", email: "eva@example.com", number: "9012345678", date: "2025-06-06" },
    ],
    Offer: [
        { name: "Alice Johnson", email: "alice@example.com", number: "9876543210", date: "2025-06-07" },
        { name: "Bob Smith", email: "bob@example.com", number: "9123456789", date: "2025-06-07" },
        { name: "Charlie Ray", email: "charlie@example.com", number: "9988776655", date: "2025-06-07" },
        { name: "Dana White", email: "dana@example.com", number: "9090909090", date: "2025-06-07" },
        { name: "Eva Green", email: "eva@example.com", number: "9012345678", date: "2025-06-07" },
    ],
    Hired: [
        { name: "Alice Johnson", email: "alice@example.com", number: "9876543210", date: "2025-06-08" },
        { name: "Eva Green", email: "eva@example.com", number: "9012345678", date: "2025-06-08" },
    ],
};
function OnBoarding() {
     const navigate = useNavigate();
    const [activeTab, setActiveTab] = useState('tab1');

    function getRelativeDate(dateString) {
        const givenDate = new Date(dateString);
        const now = new Date();
        const diffTime = now - givenDate;
        const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
        if (diffDays < 1) return 'Today';
        if (diffDays === 1) return '1 day ago';
        if (diffDays < 30) return `${diffDays} days ago`;
        const diffMonths = Math.floor(diffDays / 30);
        if (diffMonths < 12) {
            return diffMonths === 1 ? '1 month ago' : `${diffMonths} months ago`;
        }
        const diffYears = Math.floor(diffMonths / 12);
        return diffYears === 1 ? '1 year ago' : `${diffYears} years ago`;
    }

    return (
        <div className="pb-10">
            {/* Header */}
            <div className='flex items-center space-x-1 mx-4 mt-4' onClick={() => navigate("/")}>
                <button className='text-xl font-thin'><IoIosArrowBack /></button>
                <h1 className='text-base font-normal'>Back To Job openings</h1>
            </div>
            {/* Job Title */}
            <div className='flex items-center space-x-4 mt-6 mx-4 flex-wrap'>
                <h1 className='text-xl font-medium'>Junior UI | UX Designer</h1>
                <h1 className='text-sm font-medium text-[#2C8BE1]'>Open</h1>
            </div>
            {/* Job Details */}
            <div className='mt-2 flex items-center flex-wrap gap-4 text-[#A49B9B] mx-4'>
                <div className='flex items-center space-x-2 text-sm'>
                    <PiIdentificationBadge />
                    <span>Sales Department</span>
                </div>
                <div className='flex items-center space-x-2 text-sm'>
                    <BsBriefcase />
                    <span>Full Time</span>
                </div>
                <div className='flex items-center space-x-2 text-sm'>
                    <IoLocationOutline />
                    <span>Bangalore</span>
                </div>
            </div>
            {/* Tabs */}
            <div className="flex mx-4 mt-6">
                <button onClick={() => setActiveTab('tab1')} className={`px-4 py-2 text-base font-medium ${activeTab === 'tab1' ? 'border-b-2 border-blue-500 text-blue-600' : 'text-gray-500'}`}>
                    Job Applicants
                </button>
                <button onClick={() => setActiveTab('tab2')} className={`px-4 py-2 text-base font-medium ${activeTab === 'tab2' ? 'border-b-2 border-blue-500 text-blue-600' : 'text-gray-500'}`}>
                    Job Details
                </button>
            </div>
            {/* Applicants Section */}
            <div className='bg-[#F3F4F6] mt-4 mx-2 sm:mx-4 rounded-lg py-4'>
                <div className='flex items-center justify-between px-0 sm:px-4'>
                    <h1 className='font-medium'>Total Candidates Applied <span className='text-[#A49B9B]'>(10)</span></h1>
                    <select
                        className='border border-gray-300 rounded px-3 py-1 text-sm text-gray-700 bg-white outline-none'
                        defaultValue=""
                    >
                        <option value="" disabled hidden>Select</option>
                        <option value="all">Show All</option>
                        <option value="applied">Applied</option>
                        <option value="screening">Screening</option>
                    </select>
                </div>
                {/* Responsive Grid */}
                <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-1 sm:gap-4 px-0 sm:px-4 py-4">
                    {Object.entries(onboardingData).map(([stage, candidates]) => (
                        <div key={stage}>
                            <div className='flex items-center justify-between bg-white py-2 px-3 rounded-md mx-0 sm:mx-4'>
                                <h1 className='font-medium'>{stage}</h1>
                                <h1 className='text-[#A49B9B]'>{candidates.length}</h1>
                            </div>
                            <div className={`h-1 rounded-b-sm mt-1 mx-0 sm:mx-4 ${stage === "Applied" ? "bg-[#EA8C4B]" : stage === "Screening" ? "bg-[#EF7A6F]" : stage === "Interview" ? "bg-[#2B8AE0]" : stage === "Offer" ? "bg-[#7CBEE5]" : "bg-[#5DDB63]"}`}></div>
                            {candidates.map((c, index) => (
                                <div key={index} className='mt-4 bg-white rounded-lg shadow-sm border mx-0 sm:mx-4'>
                                    <div className='flex gap-2 p-3'>
                                        <img src='h3.jpg' alt='Profile' className='w-9 h-9 rounded-full object-cover' />
                                        <div className=''>
                                            <h1 className="text-sm font-medium">{c.name}</h1>
                                            <p className="text-xs flex items-center gap-1 text-[#A49B9B]"><MdOutlineMailOutline /><span className={c.email.length > 17 ? "break-words max-w-[140px]" : ""}>{c.email}</span></p>
                                            <p className="text-xs flex items-center gap-1 text-[#A49B9B]"><MdPhone /> {c.number}</p>
                                        </div>
                                    </div>
                                    <div className='border-t px-3 py-2'>
                                        <p className='text-xs flex items-center gap-1 text-[#A49B9B]'><FaRegClock /> <span className='text-gray-600'>{getRelativeDate(c.date)}</span></p>
                                    </div>
                                </div>
                            ))}
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
}
export default OnBoarding;