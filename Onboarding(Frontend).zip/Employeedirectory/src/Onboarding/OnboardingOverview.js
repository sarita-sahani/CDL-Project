import React, { useState } from 'react';
import DataTable from 'react-data-table-component';
import { IoPeopleSharp } from "react-icons/io5";
import { BsSpeedometer2 } from "react-icons/bs";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";
import { HiOutlinePrinter } from "react-icons/hi2";
import { HiDotsHorizontal } from "react-icons/hi";
import { SlPeople } from "react-icons/sl";
import Dropdown from 'react-dropdown';
import JobOverallDashboard from './JobOverallDashboard';
import Empdirectory from '../Empdirectory';
import OnboardedCandidates from './onboardedCandidates';
import ListOfOnboardingCandidates from './ListOfOnboardingCandidates';






function OnboardingOverview() {
    const [activeTab, setActiveTab] = useState("overview");
    const [selectedDue, setSelectedDue] = useState(30);

    const dueDays = [
        { value: 30, label: "Last 30 Days" },
        { value: 60, label: "Last 60 Days" },
        { value: 90, label: "Last 90 Days" }
    ];

    const handleDueDays = (selectedOption) => {
        setSelectedDue(selectedOption.value);
    };


    const dataa = [
        { name: "Apr 1", value: 2000 },
        { name: "may 2", value: 1350 },
        { name: "june 3", value: 1400 },
        { name: "jul 4", value: 1500 },
        { name: "Aug 5", value: 1600 },
        { name: "sep 6", value: 1660 },
        { name: "oct 6", value: 1100 },
        { name: "nov 6", value: 1500 },
        { name: "dec 6", value: 1760 },
        { name: "jan 6", value: 1890 },
        { name: "feb 6", value: 2020 },
        { name: "marc 6", value: 2340 },
    ];
    const columns = [
        {
            name: 'ERF Req No',
            selector: row => row.id,
            sortable: true,
            width: "160px"
        },
        {
            name: 'Position',
            selector: row => row.position,
            sortable: true,
            width: "160px"
        },
        {
            name: ' No Position',
            selector: row => row.noposition,
            width: "140px"
        },
        {
            name: 'Job id',
            selector: row => row.jobid,
            width: "100px"
        },
        {
            name: 'Interviewed',
            selector: row => row.interviewed,
            width: "120px"
        },
        {
            name: 'Offerd',
            selector: row => row.offered,
            width: "100px"
        },
        {
            name: 'Hired',
            selector: row => row.hired,
            width: "100px"
        },
        {
            name: 'ERF Status',
            selector: row => row.status,
            cell: row => {
                let color = 'text-gray-700';
                if (row.status === 'completed') color = 'text-green-600';
                else if (row.status === 'closed') color = 'text-red-600';
                else if (row.status === 'Hiring in process') color = 'text-yellow-600';

                return <span className={`font-medium ${color}`}>{row.status}</span>;
            },
        },
        {
            name: 'Hiring Ratio',
            selector: row => row.hired,
            cell: row => {
                const hired = parseInt(row.hired);
                const total = parseInt(row.noposition);
                const ratio = total === 0 ? 0 : Math.round((hired / total) * 100);

                // Bar color logic
                const getBarColor = () => {
                    if (ratio === 100) return 'bg-green-500';
                    if (ratio >= 50) return 'bg-yellow-400';
                    return 'bg-red-400';
                };

                return (
                    <div className="flex items-center space-x-2 w-full">
                        {/* Progress bar */}
                        <div className="w-24 bg-gray-200 rounded-full h-2 overflow-hidden">
                            <div
                                className={`h-2 ${getBarColor()} rounded-full`}
                                style={{ width: `${ratio}%` }}
                            />
                        </div>
                        {/* Text */}
                        <span className="text-xs font-medium text-gray-700">{ratio}% Hired</span>
                    </div>
                );
            },
        }
    ];


    const data = [
        { id: 'ERF101', position: 'Frontend Developer', noposition: '4', jobid: '102', offered: '4', interviewed: '5', hired: '4', status: "completed" },
        { id: 'ERF102', position: 'Backend Developer', noposition: '6', jobid: '103', offered: '5', interviewed: '6', hired: '3', status: "Hiring in process" },
        { id: 'ERF103', position: 'UI/UX Designer', noposition: '8', jobid: '104', offered: '8', interviewed: '4', hired: '2', status: "closed" },
        { id: 'ERF102', position: 'Backend Developer', noposition: '6', jobid: '103', offered: '5', interviewed: '6', hired: '3', status: "Hiring in process" },

    ];
    const customStyles = {
        headCells: {
            style: {
                borderTop: '1px solid #D1D5DB',
                borderBottom: '1px solid #D1D5DB',
                fontWeight: 'bold',
                fontSize: '14px',
            },
        },
    };
    const onboardedCandidatesList = [
        {
            name: "Ammu",
            empId: "21234555",
            department: "Software Development",
            joinedDaysAgo: 6,
        },
        {
            name: "Ravi",
            empId: "21234556",
            department: "Quality Assurance",
            joinedDaysAgo: 55,
        },
        {
            name: "Sneha",
            empId: "21234557",
            department: "UI/UX Design",
            joinedDaysAgo: 82,
        },
        {
            name: "Karan",
            empId: "21234558",
            department: "Data Analytics",
            joinedDaysAgo: 9,
        },
    ];
    const filteredCandidates = onboardedCandidatesList.filter(
        (candidate) => candidate.joinedDaysAgo <= selectedDue
    );

    return (
        <div>
            <div className="flex flex-col md:flex-row items-start md:items-center justify-between border py-4 px-4 border-gray-300 shadow-md mt-4 space-y-4 md:space-y-0">
                <div className="flex items-center space-x-3">
                    <div className="bg-green-400 p-2 rounded-md shadow-md">
                        <SlPeople className="text-white text-2xl" />
                    </div>
                    <div>
                        <h1 className="text-xl font-semibold">Onboarding</h1>
                        <p className="text-sm font-semibold text-gray-600">Manage your Candidates</p>
                    </div>
                </div>

            </div>
            <div className="flex flex-wrap gap-4 mt-4 px-4">
                <button
                    className={`py-2 flex items-center gap-2 border-b-4 ${activeTab === "overview"
                        ? "border-red-700 text-red-800 font-semibold"
                        : "border-transparent text-gray-600"
                        }`}
                    onClick={() => setActiveTab("overview")} >
                    <BsSpeedometer2 className="text-2xl" />
                    Overview
                </button>

                <button
                          className={`py-2 flex items-center gap-2 border-b-4 ${activeTab === "empDirectory"
                            ? "border-blue-400 text-blue-500 font-semibold"
                            : "border-transparent text-gray-600"
                            }`}
                          onClick={() => setActiveTab("empDirectory")}
                        >
                          <IoPeopleSharp className="text-2xl" />
                          Employee Directory
                        </button>
                

            
                  <button
                    className={`py-2 flex items-center gap-2 border-b-4 ${activeTab === "JobOverallDashboard"
                        ? "border-red-700 text-red-800 font-semibold"
                        : "border-transparent text-gray-600"
                        }`}
                    onClick={() => setActiveTab("JobOverallDashboard")}
                >
                    <IoPeopleSharp className="text-2xl" />
                    Job Overall Dashboard
                </button>

                
                 <button
                    className={`py-2 flex items-center gap-2 border-b-4 ${activeTab === "To Be Onboarded"
                        ? "border-red-700 text-red-800 font-semibold"
                        : "border-transparent text-gray-600"
                        }`}
                    onClick={() => setActiveTab("To Be Onboarded")}
                >
                    <IoPeopleSharp className="text-2xl" />
                    To Be Onboarded
                </button>

                 <button
                          className={`py-2 flex items-center gap-2 border-b-4 ${activeTab === "listOfOnboardedCandidates"
                            ? "border-blue-400 text-blue-500 font-semibold"
                            : "border-transparent text-gray-600"
                            }`}
                          onClick={() => setActiveTab("listOfOnboardedCandidates")}
                        >
                          <IoPeopleSharp className="text-2xl" />
                          Onboarding Candidates List
                        </button>
                

                <div className="">
                    {activeTab === "overview" && (
                        <>
                            <div className='w-full px-4'>
                                <h1 className='pt-4 font-semibold text-gray-800'>Onboarded Candidates</h1>

                                <div className='mt-4'>
                                    <ResponsiveContainer width="100%" height={240}>
                                        <LineChart data={dataa}>
                                            <XAxis dataKey="name" />
                                            <YAxis />
                                            <Tooltip />
                                            <Line type="natural" dataKey="value" stroke="#8884d8" />
                                        </LineChart>
                                    </ResponsiveContainer>
                                </div>

                                {/* First row of 3 cards */}
                                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-2 lg:grid-cols-3 gap-6 py-6">

                                    <div className="p-6 shadow-lg border border-gray-200 rounded-sm w-full">
                                        <h1 className="text-orange-500 text-2xl font-semibold flex justify-between items-center">
                                            {filteredCandidates.length}
                                            <Dropdown
                                                className='w-30 h-6 min-h-6 text-xs mb-6'
                                                options={dueDays}
                                                onChange={handleDueDays}
                                                value={dueDays.find(option => option.value === selectedDue)}
                                                placeholder="Select"
                                            />
                                            <button className="text-gray-600"><HiDotsHorizontal /></button>
                                        </h1>

                                        <h2 className="text-base font-semibold text-[#313335] pt-1">
                                            New Candidates Onboarded for last 1 Month
                                        </h2>

                                        <div className="pt-4 h-56 overflow-y-auto space-y-4">
                                            {filteredCandidates.map((candidate, index) => (
                                                <div key={index} className="flex items-center space-x-4 cursor-pointer">
                                                    <img src="/person1.jpg" className="rounded-full h-9 w-9" alt="Profile" />
                                                    <div className="w-full">
                                                        <div className="flex justify-between">
                                                            <h1 className="text-black">{candidate.name} - {candidate.empId}</h1>
                                                            <h2 className="text-gray-500 text-sm">{candidate.joinedDaysAgo} Days ago</h2>
                                                        </div>
                                                        <span className="block text-sm text-gray-500">{candidate.department}</span>
                                                    </div>
                                                </div>
                                            ))}
                                        </div>
                                    </div>


                                    <div className="bg-white shadow-lg rounded-sm p-4 border w-full">
                                        <h1 className="text-orange-500 text-2xl font-semibold flex justify-between items-center">
                                            {filteredCandidates.length}
                                            <Dropdown
                                                className='w-30 h-6 min-h-6 text-xs mb-6'
                                                options={dueDays}
                                                onChange={handleDueDays}
                                                value={dueDays.find(option => option.value === selectedDue)}
                                                placeholder="Select"
                                            />
                                            <button className="text-gray-600"><HiDotsHorizontal /></button>
                                        </h1>

                                        <h2 className="text-base font-semibold text-gray-800 pt-2">
                                            Candidates converted to employees for last 1 Month
                                        </h2>

                                        <div className="pt-4 h-56 overflow-y-auto space-y-4">
                                            {filteredCandidates.map((candidate, index) => (
                                                <div key={index} className="flex items-center space-x-4 cursor-pointer">
                                                    <img src="/person1.jpg" className="rounded-full h-9 w-9" alt="Profile" />
                                                    <div className="w-full">
                                                        <div className="flex justify-between">
                                                            <h1 className="text-black">{candidate.name} - {candidate.empId}</h1>
                                                            <h2 className="text-gray-500 text-sm">{candidate.joinedDaysAgo} Days ago</h2>
                                                        </div>
                                                        <span className="block text-sm text-gray-500">{candidate.department}</span>
                                                    </div>
                                                </div>
                                            ))}
                                        </div>
                                    </div>


                                    <div className="bg-white shadow-lg rounded-sm p-4 border w-full">
                                        <h1 className="text-orange-500 text-2xl font-semibold flex justify-between items-center">
                                            {filteredCandidates.length}
                                            <Dropdown
                                                className='w-30 h-6 min-h-6 text-xs mb-6'
                                                options={dueDays}
                                                onChange={handleDueDays}
                                                value={dueDays.find(option => option.value === selectedDue)}
                                                placeholder="Select"
                                            />
                                            <button className="text-gray-600"><HiDotsHorizontal /></button>
                                        </h1>

                                        <h2 className="text-base font-semibold text-gray-800 pt-2">
                                            Candidates due for Employee conversion
                                        </h2>

                                        <div className="pt-4 h-56 overflow-y-auto space-y-4">
                                            {filteredCandidates.map((candidate, index) => (
                                                <div key={index} className="flex items-center space-x-4 cursor-pointer">
                                                    <img src="/person4.jpg" className="rounded-full h-9 w-9" alt="Profile" />
                                                    <div className="w-full">
                                                        <div className="flex justify-between">
                                                            <h1 className="text-black">{candidate.name} - {candidate.empId}</h1>
                                                            <h2 className="text-gray-500 text-sm">{candidate.joinedDaysAgo} Days ago</h2>
                                                        </div>
                                                        <span className="block text-sm text-gray-500">{candidate.department}</span>
                                                    </div>
                                                </div>
                                            ))}
                                        </div>
                                    </div>

                                </div>
                            </div>

                            <div>
                                <div className="ml-4 border border-gray-300 shadow-md rounded p-4 mb-8">
                                    {/* Header row */}
                                    <div className="flex items-center space-x-4 justify-between mx-3">
                                        <div className='flex items-center space-x-4'>
                                            <h1 className="text-xl font-semibold ">Total ERF Created</h1>

                                        </div>
                                        <button className='text-xl text-blue-400 font-semibold'><HiOutlinePrinter /></button>
                                    </div>

                                    {/* Number 8 */}
                                    <div className="mt-2">
                                        <h1 className="text-orange-500 text-2xl font-semibold ml-6">{data.length}</h1>
                                    </div>

                                    {/* DataTable */}
                                    <div className="mt-4 h-56 overflow-y-auto space-y-4">
                                        <DataTable
                                            columns={columns}
                                            data={data}
                                            highlightOnHover
                                            striped
                                            customStyles={customStyles}
                                        />
                                    </div>
                                </div>
                            </div>
                        </>
                    )}
                  
                    {activeTab==="empDirectory" && <Empdirectory/>}
                    {activeTab ==="JobOverallDashboard" && <JobOverallDashboard/>}
                   {activeTab ==="To Be Onboarded" && <OnboardedCandidates/>}
                   {activeTab ==="listOfOnboardedCandidates" && <ListOfOnboardingCandidates/>}
                   
                </div>
            </div>
        </div>
    );
}

export default OnboardingOverview;
