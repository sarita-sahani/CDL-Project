import React, { useState, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ChevronLeft, Bell, UserCircle, Briefcase, LayoutDashboard, Search } from 'lucide-react';
import JobOpenings from './JobOpenings';
import JobApplicants from './JobApplicants';
import CandidateDetails from './CandidateDetails';
import { SlPeople } from "react-icons/sl";

const JobDashboard  = () => {
  const { intRefData } = useParams();
  const navigate = useNavigate();
  const [selectedJobId, setSelectedJobId] = useState(null);
  const [selectedCandidateId, setSelectedCandidateId] = useState(null);

  // Memoize callbacks to prevent unnecessary child re-renders and refetches
  const handleJobSelect = useCallback((jobId) => {
    setSelectedJobId(jobId);
    setSelectedCandidateId(null); 
  }, []);

  const handleCandidateSelect = useCallback((candidateId) => {
    setSelectedCandidateId(candidateId);
  }, []);

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col font-sans">
      {/* PROFESSIONAL STICKY HEADER */}
      <header className="sticky top-0 z-50 shadow-lg">

        {/* Main Header Action Area */}
        <div className="bg-gradient-to-r from-red-500 via-purple-600 via-blue-600 to-cyan-500 px-8 py-6 flex flex-col md:flex-row md:items-center justify-between gap-4 border-b-4 border-red-400 relative overflow-hidden">
          {/* Decorative background elements */}
          <div className="absolute top-0 right-0 w-40 h-40 bg-white/10 rounded-full -mr-20 -mt-10"></div>
          <div className="absolute bottom-0 left-0 w-32 h-32 bg-white/5 rounded-full -ml-16 -mb-8"></div>
          
          <div className="relative z-10">
            <div className="flex items-center space-x-4">
              <div className="bg-white p-3 rounded-full shadow-lg ring-2 ring-white/30 hover:shadow-xl hover:scale-110 transition-all duration-300">
                <SlPeople className="text-red-600 text-3xl" />
              </div>
              <div>
                <h1 className="text-3xl font-black text-white tracking-tight drop-shadow-lg">Job DashBoard</h1>
                {/* <p className="text-sm font-semibold text-white/90 drop-shadow-md">Manage your Candidates</p> */}
              </div>
            </div>
          </div>
          
          <div className="relative z-10 flex items-center gap-3">
            <button 
              onClick={() => navigate(-1)}
              className="px-4 py-2 bg-white/20 hover:bg-white/30 rounded-lg transition-all duration-300 text-white hover:text-white font-semibold flex items-center gap-2 backdrop-blur-sm border border-white/20 shadow-md hover:shadow-lg"
            >
              <ChevronLeft size={18} />
              Back
            </button>
          </div>
        </div>
      </header>

      {/* MAIN CONTENT AREA - Adjusted for visual matching */}
      <main className="flex-grow p-4 lg:p-6 overflow-hidden">
        <div className="max-w-[1600px] mx-auto grid grid-cols-1 lg:grid-cols-12 gap-6 h-full">
          
          {/* 1. Job Openings Column */}
          <div className="lg:col-span-3 h-full overflow-hidden flex flex-col bg-white rounded-xl shadow-sm border border-slate-200">
           <JobOpenings
  selectedJobId={selectedJobId}
  onJobSelect={handleJobSelect}
  intRefData={intRefData}
/>
          </div>
          
          {/* 2. Job Applicants Column */}
          <div className="lg:col-span-5 h-full overflow-hidden flex flex-col bg-white rounded-xl shadow-sm border border-slate-200">
            <JobApplicants 
              selectedJobId={selectedJobId} 
              onCandidateSelect={handleCandidateSelect} 
            />
          </div>
          
          {/* 3. Candidate Details Column */}
          <div className="lg:col-span-4 h-full overflow-hidden flex flex-col bg-white rounded-xl shadow-sm border border-slate-200">
            <CandidateDetails 
              candidateId={selectedCandidateId} 
            />
          </div>
        </div>
      </main>
    </div>
  );
};

export default JobDashboard ;

// // JobOverallDashboard.js
// import React, { useState } from 'react';
// import JobOpenings from './JobOpenings';
// import JobApplicants from './JobApplicants';
// import CandidateDetails from './CandidateDetails';

// const JobOverallDashboard = () => {
//   // State to manage the selected job and candidate across components
//   const [selectedJobId, setSelectedJobId] = useState(null);
//   const [selectedCandidateId, setSelectedCandidateId] = useState(null);

//   // CRITICAL HANDLER: Reset the candidate when the job changes
//   const handleJobSelect = (jobId) => {
//     setSelectedJobId(jobId);
//     // Explicitly reset the candidate ID to null when the job changes. 
//     // This forces JobApplicants to select and push the new default ID immediately.
//     setSelectedCandidateId(null); 
//   };

//   return (
//     <>
//       <main className="p-6">
//         <div className="grid grid-cols-3 gap-6">
          
//           {/* 1. Job Openings (left) - Controls selectedJobId */}
//           <JobOpenings 
//             selectedJobId={selectedJobId} 
//             onJobSelect={handleJobSelect} 
//           />
          
//           {/* 2. Job Applicants (middle) - Filters by selectedJobId and controls selectedCandidateId */}
//           <JobApplicants 
//             selectedJobId={selectedJobId} 
//             onCandidateSelect={setSelectedCandidateId} // This setter updates state for CandidateDetails
//           />
          
//           {/* 3. Candidate Details (right) - Displays data for selectedCandidateId */}
//           <CandidateDetails 
//             candidateId={selectedCandidateId} // This will be the JobAppID
//           />
//         </div>
//       </main>
//     </>
//   );
// };

// export default JobOverallDashboard;