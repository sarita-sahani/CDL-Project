import React, { useState, useEffect } from "react";
import { useLocation, useNavigate } from 'react-router-dom';
import axios from "axios";

// --- START: Transformation Helper Functions ---

// 1. Helper function to ensure dates are in YYYY-MM-DD format
const formatDate = (dateString) => {
  if (!dateString) return null;
  try {
    // If date is already in YYYY-MM-DD format, return it
    if (dateString.match(/^\d{4}-\d{2}-\d{2}$/)) {
      return dateString;
    }

    // Convert to Date object and format to YYYY-MM-DD
    const date = new Date(dateString);
    if (isNaN(date)) {
      console.warn("Invalid date string encountered:", dateString);
      return null;
    }
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  } catch (e) {
    console.error("Date parsing failed for:", dateString, e);
    return null;
  }
};

// 2. Helper to safely split comma-separated strings
const safeSplit = (str) => {
  if (!str || typeof str !== 'string') return [];
  // Handle the specific issue of trailing/leading commas or multiple spaces
  return str.split(',').map(s => s.trim()).filter(s => s.length > 0);
};

/**
 * Transforms flat form data into the required nested DTO structure for the backend API.
 * This is crucial for PUT/POST operations on the complex DTO.
 * @param {object} flatData - The flat state object from the form (formData).
 * @param {object} existingIds - Object containing existing 'id' fields for nested entities (needed for PUT).
 * @returns {object} The structured DTO payload.
 */
const transformDataForBackend = (flatData, existingIds) => {
  // Process comma-separated skill/level strings
  const primarySkills = safeSplit(flatData.primarySkillName);
  const primaryLevels = safeSplit(flatData.primarySkillLevel);
  const secondarySkills = safeSplit(flatData.secondarySkillName);
  const secondaryLevels = safeSplit(flatData.secondarySkillLevel);

  // --- Build the DTO Structure ---
  const payload = {
    candId: flatData.candID,

    // 1. EONPersonal (Mandatory)
    personal: {
      // Include existing ID for PUT request
      id: existingIds.personalId || null,
      candID: flatData.candID,
      firstName: flatData.firstName,
      middleName: flatData.middleName || null,
      lastName: flatData.lastName,
      emailAddr: flatData.personalEmail,
      dob: formatDate(flatData.dateOfBirth), // ✅ Date formatted
      maritalStatus: flatData.maritalStatus,
      bloodGroup: flatData.bloodGroup,
      emrContactNum: flatData.emergencyContact,
      curContactNum: flatData.secondaryContactNo,
      permContactNum: flatData.primaryContactNo,
      aadharNum: flatData.aadharNumber,
      panNum: flatData.panNumber,
      gender: flatData.gender,
      passportNumber: flatData.passportNumber,
      fullNameAsPerAadhar: flatData.fullNameAsPerAadhar,

      // NOTE: Filling mandatory/dummy fields required by your backend DTO
      noOfDependents: 3, // Dummy
      curAddress: "om nilaya bangalore", curCity: "Bangalore", curState: "Karnataka", curPinCode: "580301", // Dummy
      permAddress: "om nilaya bangalore", permCity: "bangalore", permState: "Karnataka", permPinCode: "580301", // Dummy
    },

    // 2. EONGeneral (Mandatory)
    general: {
      id: existingIds.generalId || null,
      candID: flatData.candID,
      dateOfJoin: formatDate(flatData.dateOfJoining), // ✅ Date formatted
      locationId: flatData.selectedLocationId || null, // Assuming you track location ID
    },

    // 3. EONPF (Mandatory)
    pf: {
      id: existingIds.pfId || null,
      candID: flatData.candID,
      uan: flatData.uanNumber,
      prevPFNum: flatData.currentPfNumber,
      prevESICNum: flatData.currentESICNumber,
      memberEPS: 'YES', // Dummy/Default
    },

    // 4. EONDOCUMENTPROOF (Mandatory)
    documentProof: {
      id: existingIds.documentProofId || null,
      candID: flatData.candID,
      aadharCard: flatData.aadharNumber,
      panCard: flatData.panNumber,
      addrProofType1: "Aadhar", // Dummy/Default
    },

    // 5. EONSkill (Mandatory) - Splitting comma-separated values
    skill: {
      id: existingIds.skillId || null,
      candID: flatData.candID,
      primarySkill1Name: primarySkills[0] || null,
      primarySkill1Level: primaryLevels[0] || null,
      primarySkill2Name: primarySkills[1] || null,
      primarySkill2Level: primaryLevels[1] || null,
      primarySkill3Name: primarySkills[2] || null,
      primarySkill3Level: primaryLevels[2] || null,
      secondarySkill1Name: secondarySkills[0] || null,
      secondarySkill1Level: secondaryLevels[0] || null,
      secondarySkill2Name: secondarySkills[1] || null,
      secondarySkill2Level: secondaryLevels[1] || null,
      secondarySkill3Name: secondarySkills[2] || null,
      secondarySkill3Level: secondaryLevels[2] || null,
    },

    // 6. EONProfressionalExperience (Mandatory)
    profExp: {
      id: existingIds.profExpId || null,
      candID: flatData.candID,
      company1: flatData.previousCompany,
      fromDate1: formatDate(flatData.previousCompanyFrom), // ✅ Date formatted
      toDate1: formatDate(flatData.previousCompanyTo),     // ✅ Date formatted
      // NOTE: Filling mandatory/dummy fields required by your backend DTO
      totalExp: flatData.totalExp || null,
      location1: "bangalore", desGrad1: "softwear developer", annualCTC1: "3.5", jobRole1: "developer", leaveReason1: "career growth",
    },


    // 7. EONEmployeeOnboardingInfo (Mandatory)
    employeeOnboardingInfo: {
      id: existingIds.onboardingId || null,
      candID: flatData.candID,
      empOnboardingRefNum: flatData.empOnboardingRefNum || "",
      isProbationApplicable: flatData.isProbationApplicable,
      rptManagerName: flatData.rptManagerName || null,
      rptMgrEmployeeCode: flatData.rptMgrEmployeeCode || "",
      rptManagerEmailId: flatData.rptManagerEmailId || "",
      hiringHr: flatData.hiringHr || null,
      employmentStatus: flatData.employmentStatus || null,
      grade: flatData.grade || "",
      payrollAreaType: flatData.payrollAreaType || "",
      buHead: flatData.buHead || "",
      mainDepartment: flatData.mainDepartment || null,
      subDepartment: flatData.subDepartment || null,
      project: flatData.project || "",
      organisationCode: flatData.organisationCode || "",
      designation: flatData.designation || null,
      organisationHierarchy: flatData.organisationHierarchy || "",
      fullNameAsPerPAN: flatData.fullNameAsPerPAN || null,
      currentPfNumber: flatData.currentPfNumber,
      currentESICNumber: flatData.currentESICNumber,
      status: flatData.status,
      confirmationDate: formatDate(flatData.confirmationDate), // ✅ Date formatted
      probationPeriod: formatDate(flatData.probationPeriod), // ✅ Date formatted (assuming this is the start date)
      maxProbationExtension: flatData.maxProbationExtension || "",
      companyCode: flatData.companyCode,
      officialEmailId: flatData.officialEmailId,
      orgUnit: flatData.orgUnit,
      wbsElement: flatData.wbsElement,
      buHeadECode: flatData.buHeadECode,
      category: flatData.category,
      qualification: flatData.qualification
    },

    // 8. Other Entities (Sent as empty objects or minimal required data to satisfy backend @NotNull or not-null constraints)
    family: {
      id: existingIds.familyId || null,
      candID: flatData.candID,
      nomineeName: flatData.nomineeName1,
      dependentName: flatData.dependentName,
      dependentRelation: flatData.dependentRelationship,
      dependentDob: formatDate(flatData.dependentDOB)
    },
   bank: { 
      id: existingIds.bankId || null, 
      candID: flatData.candID,
      bankName: flatData.bankName,
      accountNum: flatData.salaryAccountNumber,
      ifscCode: flatData.ifscCode,
      nameAsPerBank: flatData.nameOnSalaryAccount
    },
    education: { id: existingIds.educationId || null, candID: flatData.candID },
    // Candidate declaration requires date/place/signature to avoid backend validation errors
    candidateDeclaration: { id: existingIds.candDeclId || null, candID: flatData.candID, declDate: formatDate("2025-05-19"), declPlace: "Bangalore", candSignature: flatData.firstName || "" },
    declQuestionnaire: { id: existingIds.quesId || null, candID: flatData.candID },
    hrDeclaration: { id: existingIds.hrDeclId || null, candID: flatData.candID },
    interest: { id: existingIds.interestId || null, candID: flatData.candID },
    language: { id: existingIds.languageId || null, candID: flatData.candID },
    overallStatus: { id: existingIds.statusId || null, candID: flatData.candID },
    profReference: { id: existingIds.refId || null, candID: flatData.candID },

  };

  return payload;
};

// --- END: Transformation Helper Functions ---


const AddEmployee = ({ initialCandidateData, onClose }) => {
  const [locations, setLocations] = useState([]);
  const location = useLocation();
  // Use initialCandidateData for modal/edit mode, fallback to location.state for page/add mode
  const candidateData = initialCandidateData || location.state?.candidate;
  const [roles, setRoles] = useState([]);
  const [selectedLocation, setSelectedLocation] = useState('');
  const [selectedRole, setSelectedRole] = useState('');
  const navigate = useNavigate();

  // Determine if candidate data is present & if it's an edit operation
  const isDataPresent = !!candidateData;
  const isEditMode = !!initialCandidateData;

  // All form fields are now managed in formData
  const [formData, setFormData] = useState({
    // Fields that are always editable for both new and existing candidates
    empOnboardingRefNum: '',
    isProbationApplicable: false,
    rptManagerName: '',
    rptMgrEmployeeCode: '',
    rptManagerEmailId: '',
    hiringHr: '',
    employmentStatus: '', // ADDED to new card
    grade: '',
    payrollAreaType: '', // ADDED to new card
    buHead: '', // ADDED to new card
    mainDepartment: '',
    subDepartment: '',
    project: '', // ADDED to new card
    organisationCode: '', // ADDED to new card
    designation: '',
    organisationHierarchy: '', // ADDED to new card
    fullNameAsPerPAN: '',
    currentPfNumber: '',
    currentESICNumber: '',
    status: 'Probation',
    confirmationDate: '',
    probationPeriod: '',
    maxProbationExtension: '',

    companyCode: '',
    fullNameAsPerAadhar: '',
    emergencyContactName: '',
    relationWithEmergencyContact: '',
    passportNumber: '',

    // Nominee Info
    nomineeName1: '',

    // Fields that will be filled from candidateData or entered by user
    candID: '',
    firstName: '',
    middleName: '',
    lastName: '',
    fullName: '',
    dateOfJoining: '',
    gender: '',
    dateOfBirth: '',
    primaryContactNo: '',
    secondaryContactNo: '',
    emergencyContact: '',
    personalEmail: '',
    maritalStatus: '',
    bloodGroup: '',
    totalExp: '',
    previousCompany: '',
    previousCompanyFrom: '',
    previousCompanyTo: '',
    primarySkillName: '',
    primarySkillLevel: '',
    secondarySkillName: '',
    secondarySkillLevel: '',
    aadharNumber: '',
    panNumber: '',
    uanNumber: '',
    // Dependent Info
    dependentName: '',
    dependentRelationship: '',
    dependentDOB: '',
    
    // Bank Info
    bankName: '',
    salaryAccountNumber: '',
    nameOnSalaryAccount: '',
    ifscCode: '',
    officialEmailId: '',
    
    // Org/Structure
    orgUnit: '',
    orgUnitDescription: '',
    departmentDescription: '',
    subDepartmentDescription: '',
    wbsElement: '',
    wbsElementText: '',
    projectDescription: '',
    classification: '',
    category: '',
    buHeadECode: '',
    buHeadEmail: '',
    eeSubGrpName: '',
    segment: '',
    
    // Skills/Education
    qualification: '',
    certification1: '',
    certification2: '',
    tertiarySkills: '',
    
    // Exit Info
    resignationStatus: 'NO',
    dateOfResignation: '',
    dateOfLeaving: '',
    exitStatus: ''
  
  });

  // Use a single effect to handle form data initialization
  useEffect(() => {
    if (isDataPresent) {
      // Use existing onboarding info if available (for edit mode)
      const onboardingInfo = candidateData.employeeOnboardingInfo || {};
      const personal = candidateData.personal || {};
      const general = candidateData.general || {};
      const profExp = candidateData.profExp || {};
      const skill = candidateData.skill || {};
      const documentProof = candidateData.documentProof || {};
      const pf = candidateData.pf || {};

      // Helper function to concatenate skills/levels
      const getSkillsString = (s1, s2, s3) => [s1, s2, s3].filter(Boolean).join(', ');

      setFormData(prevFormData => ({
        ...prevFormData,
        // Fields from nested entities
        candID: personal.candID || general.candID || '',
        firstName: personal.firstName || '',
        middleName: personal.middleName || '',
        lastName: personal.lastName || '',
        fullName: [personal.firstName, personal.middleName, personal.lastName].filter(Boolean).join(' ') || '',
        dateOfJoining: general.dateOfJoin || '',
        gender: onboardingInfo.gender || '',
        dateOfBirth: personal.dob || '',
        primaryContactNo: personal.permContactNum || '',
        secondaryContactNo: personal.curContactNum || '',
        emergencyContact: personal.emrContactNum || '',
        personalEmail: personal.emailAddr || '',
        maritalStatus: personal.maritalStatus || '',
        bloodGroup: personal.bloodGroup || '',
        totalExp: profExp.totalExp || '',
        previousCompany: profExp.company1 || '',
        previousCompanyFrom: profExp.fromDate1 || '',
        previousCompanyTo: profExp.toDate1 || '',
        primarySkillName: getSkillsString(skill.primarySkill1Name, skill.primarySkill2Name, skill.primarySkill3Name),
        primarySkillLevel: getSkillsString(skill.primarySkill1Level, skill.primarySkill2Level, skill.primarySkill3Level),
        secondarySkillName: getSkillsString(skill.secondarySkill1Name, skill.secondarySkill2Name, skill.secondarySkill3Name),
        secondarySkillLevel: getSkillsString(skill.secondarySkill1Level, skill.secondarySkill2Level, skill.secondarySkill3Level),
        aadharNumber: documentProof.aadharCard || '',
        panNumber: documentProof.panCard || '',
        uanNumber: pf.uan || '',

        // Fields from employeeOnboardingInfo (for edit mode)
        empOnboardingRefNum: onboardingInfo.empOnboardingRefNum || '',
        isProbationApplicable: onboardingInfo.isProbationApplicable || false,
        rptManagerName: onboardingInfo.rptManagerName || '',
        rptMgrEmployeeCode: onboardingInfo.rptMgrEmployeeCode || '',
        rptManagerEmailId: onboardingInfo.rptManagerEmailId || '',
        hiringHr: onboardingInfo.hiringHr || '',
        employmentStatus: onboardingInfo.employmentStatus || '',
        grade: onboardingInfo.grade || '',
        payrollAreaType: onboardingInfo.payrollAreaType || '',
        buHead: onboardingInfo.buHead || '',
        mainDepartment: onboardingInfo.mainDepartment || '',
        subDepartment: onboardingInfo.subDepartment || '',
        project: onboardingInfo.project || '',
        organisationCode: onboardingInfo.organisationCode || '',
        designation: onboardingInfo.designation || '',
        organisationHierarchy: onboardingInfo.organisationHierarchy || '',
        fullNameAsPerPAN: onboardingInfo.fullNameAsPerPAN || '',
        currentPfNumber: onboardingInfo.currentPfNumber || '',
        currentESICNumber: onboardingInfo.currentESICNumber || '',
        status: onboardingInfo.status || 'Probation',
        confirmationDate: onboardingInfo.confirmationDate || '',
        probationPeriod: onboardingInfo.probationPeriod || '',
        maxProbationExtension: onboardingInfo.maxProbationExtension || '',
      }));

      if (candidateData.general?.locationId) {
        setSelectedLocation(candidateData.general.locationId);
      }
      if (candidateData.userRoles && candidateData.userRoles.length > 0) {
        setSelectedRole(candidateData.userRoles[0].roleId);
      }
    }
  }, [isDataPresent, candidateData]);

  const handleProbationChange = (e) => {
    handleChange({
      target: {
        name: "isProbationApplicable",
        type: "checkbox",
        checked: e.target.checked
      }
    });
  };

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData((prev) => {
      let newFormData = {
        ...prev,
        [name]: type === "checkbox" ? checked : value,
      };

      // When name/middle/last name changes, update fullName
      if (name === 'firstName' || name === 'middleName' || name === 'lastName') {
        const personalData = candidateData?.personal || {};
        const fName = name === 'firstName' ? value : personalData.firstName || newFormData.firstName;
        const mName = name === 'middleName' ? value : personalData.middleName || newFormData.middleName;
        const lName = name === 'lastName' ? value : personalData.lastName || newFormData.lastName;
        newFormData.fullName = [fName, mName, lName].filter(Boolean).join(' ').trim();
      }

      return newFormData;
    });
  };

  const fetchOptions = async (url, setter) => {
    try {
      const res = await fetch(url);
      if (!res.ok) throw new Error("Network response was not ok");
      const data = await res.json();
      setter(data);
    } catch (error) {
      console.error("Failed to fetch:", error);
      setter([]);
    }
  };

  useEffect(() => {
    fetchOptions("http://43.205.24.208:9021/location/getAll", setLocations);
    fetchOptions("http://43.205.24.208:9021/role/getAllRoleNames", setRoles);
  }, []);

  const handleSaveAndContinue = async () => {
    console.log("Save button clicked — starting request...");
    // Future logic for multi-step form handling
  };

  // UPDATED onSubmit function to handle both POST (Add) and PUT (Edit) with DTO transformation
  const onSubmit = async () => {
    const candidateId = formData.candID;

    if (isEditMode && !candidateId) {
      alert("Candidate ID is missing. Cannot update.");
      return;
    }

    // --- 1. Collect Existing IDs (Crucial for PUT/Update operations) ---
    // These IDs ensure that existing nested records are updated instead of creating new ones.
    const existingIds = {
      personalId: candidateData?.personal?.id || null,
      generalId: candidateData?.general?.id || null,
      pfId: candidateData?.pf?.id || null,
      skillId: candidateData?.skill?.id || null,
      profExpId: candidateData?.profExp?.id || null,
      onboardingId: candidateData?.employeeOnboardingInfo?.id || null,
      documentProofId: candidateData?.documentProof?.id || null,
      familyId: candidateData?.family?.id || null,
      bankId: candidateData?.bank?.id || null,
      educationId: candidateData?.education?.id || null,
      candDeclId: candidateData?.candidateDeclaration?.id || null,
      quesId: candidateData?.declQuestionnaire?.id || null,
      hrDeclId: candidateData?.hrDeclaration?.id || null,
      interestId: candidateData?.interest?.id || null,
      languageId: candidateData?.language?.id || null,
      statusId: candidateData?.overallStatus?.id || null,
      refId: candidateData?.profReference?.id || null,
    };

    // --- 2. Transform the flat form data into the required nested DTO payload ---
    const payload = transformDataForBackend(formData, existingIds);

    // --- 3. Determine Endpoint and Method ---
    const method = isEditMode ? 'put' : 'post';
    const url = isEditMode
      ? `http://localhost:9034/onboarding/updateEmployeeDataInOnboardingTable/${candidateId}` // **PUT Endpoint**
      : 'http://localhost:9034/onboarding/saveEmployeeDataInOnboardingTable'; // **POST Endpoint**

    console.log(`Sending payload via ${method.toUpperCase()} to ${url}:`, payload);


    try {
      // --- 4. Send the STRUCTURED PAYLOAD ---
      const response = await axios[method](url, payload); // <--- FIX: Sending the structured payload
      alert(`Data ${isEditMode ? 'updated' : 'saved'} successfully!`);
      console.log(response.data);
      navigate(-1);
      // If in modal mode, close the modal, otherwise navigate back
      if (isEditMode && onClose) {
        onClose();
      } else {
        navigate(-1);
      }
    } catch (error) {
      console.error(`Error ${isEditMode ? 'updating' : 'submitting'} form:`, error.response || error);
      const errorMsg = error.response?.data?.message || error.message || 'Unknown error occurred.';
      alert(`Failed to ${isEditMode ? 'update' : 'save'} data: ${errorMsg}`);
    }
  };

  // Helper functions used in JSX (Select, FormRow) are provided below the main component.
  // ...

  return (
    <div className="bg-white min-h-screen">
      <div className="max-w-6xl mx-auto p-4 sm:p-6 lg:p-8 text-xs">
        <div className="space-y-6">

          <div>
            <h1 className="text-2xl font-bold text-gray-800">{isEditMode ? "Edit Employee Onboarding Form" : "Employee Onboarding Form"}</h1>
            <p className="mt-1 text-gray-600">Please fill in the details below to {isEditMode ? "update employee details" : "add a new employee"}.</p>
          </div>

          {/* Card 1: Basic Information */}
          <div className="bg-gray-50 p-5 rounded-lg border border-gray-200">
            <h2 className="text-lg font-semibold text-red-800 border-b border-gray-300 pb-3 mb-5">Basic Information</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-6 gap-y-5">
              <FormRow label="Emp Onboarding Ref number" required>
                <input type="text" name="empOnboardingRefNum" className="input-field" value={formData.empOnboardingRefNum} onChange={handleChange} />
              </FormRow>
              <FormRow label="Date of Joining" required>
                <input
                  type="date"
                  name="dateOfJoining"
                  className="input-field" // <-- REMOVED conditional class
                  value={formData.dateOfJoining} // <-- ALWAYS use formData for the value
                  // REMOVED: disabled={!!candidateData?.general?.dateOfJoin} 
                  onChange={handleChange}
                />
              </FormRow>
              <FormRow label="Status" required>
                <select name="status" className="input-field" value={formData.status} onChange={handleChange}>
                  <option value="Probation">Probation</option>
                  <option value="Confirmed">Confirmed</option>
                  <option value="Contract">Contract</option>
                </select>
              </FormRow>
              <FormRow label="Employee Full Name" required>
                <input
                  type="text"
                  name="fullName"
                  className={candidateData?.personal?.firstName ? "input-field-disabled" : "input-field"}
                  value={candidateData?.personal?.firstName ? [candidateData.personal.firstName, candidateData.personal.middleName, candidateData.personal.lastName].filter(Boolean).join(' ') : formData.fullName}
                  disabled={!!candidateData?.personal?.firstName}
                  onChange={handleChange}
                />
              </FormRow>
              <FormRow label="Date of Birth" required>
                <input
                  type="date"
                  name="dateOfBirth"
                  className={candidateData?.personal?.dob ? "input-field-disabled" : "input-field"}
                  value={candidateData?.personal?.dob || formData.dateOfBirth}
                  disabled={!!candidateData?.personal?.dob}
                  onChange={handleChange}
                />
              </FormRow>
              <FormRow label="Gender" required>
                <select
                  name="gender"
                  value={candidateData?.personal?.gender || formData.gender}
                  onChange={handleChange}
                  className={candidateData?.personal?.gender ? "input-field-disabled" : "input-field"}
                  disabled={!!candidateData?.personal?.gender}
                >
                  <option value="">Select Gender</option>
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                  <option value="Other">Other</option>
                </select>
              </FormRow>
              <FormRow label="Reporting Manager Name" required>
                <input type="text" name="rptManagerName" className="input-field" value={formData.rptManagerName} onChange={handleChange} />
              </FormRow>
              <FormRow label="Reporting Manager Code" required>
                <input type="text" name="rptMgrEmployeeCode" className="input-field" value={formData.rptMgrEmployeeCode} onChange={handleChange} />
              </FormRow>
              <FormRow label="Reporting Manager Email" required>
                <input type="email" name="rptManagerEmailId" className="input-field" value={formData.rptManagerEmailId} onChange={handleChange} />
              </FormRow>

              <div className="md:col-span-2 lg:col-span-3 pt-3">
                <label className="flex items-center gap-3">
                  <input type="checkbox" name="isProbationApplicable" className="h-4 w-4 rounded border-gray-300 text-red-600 focus:ring-red-500" checked={formData.isProbationApplicable} onChange={handleProbationChange} />
                  <span>Is probation Applicable? <span className="font-semibold text-red-600">{formData.isProbationApplicable ? "Yes" : "No"}</span></span>
                </label>
              </div>

              {formData.isProbationApplicable && (
                <>
                  <FormRow label="Probation Start Date" required>
                    <input type="date" name="probationPeriod" className="input-field" value={formData.probationPeriod} onChange={handleChange} />
                  </FormRow>
                  <FormRow label="Confirmation End Date" required>
                    <input type="date" name="confirmationDate" className="input-field" value={formData.confirmationDate} onChange={handleChange} />
                  </FormRow>
                  <FormRow label="Max Probation Extension" required>
                    <input type="number" name="maxProbationExtension" placeholder="e.g., 2 times" className="input-field" value={formData.maxProbationExtension} onChange={handleChange} />
                  </FormRow>
                </>
              )}
            </div>
          </div>


          {/* Card 3: Personal Details */}
          <div className="bg-gray-50 p-5 rounded-lg border border-gray-200">
            <h2 className="text-lg font-semibold text-red-800 border-b border-gray-300 pb-3 mb-5">Personal Details</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-6 gap-y-5">
              <FormRow label="Primary Contact">
                <input
                  type="text"
                  name="primaryContactNo"
                  className={candidateData?.personal?.permContactNum ? "input-field-disabled" : "input-field"}
                  value={candidateData?.personal?.permContactNum || formData.primaryContactNo}
                  disabled={!!candidateData?.personal?.permContactNum}
                  onChange={handleChange}
                />
              </FormRow>
              <FormRow label="Secondary Contact">
                <input
                  type="text"
                  name="secondaryContactNo"
                  className={candidateData?.personal?.curContactNum ? "input-field-disabled" : "input-field"}
                  value={candidateData?.personal?.curContactNum || formData.secondaryContactNo}
                  disabled={!!candidateData?.personal?.curContactNum}
                  onChange={handleChange}
                />
              </FormRow>
              <FormRow label="Emergency Contact">
                <input
                  type="text"
                  name="emergencyContact"
                  className={candidateData?.personal?.emrContactNum ? "input-field-disabled" : "input-field"}
                  value={candidateData?.personal?.emrContactNum || formData.emergencyContact}
                  disabled={!!candidateData?.personal?.emrContactNum}
                  onChange={handleChange}
                />
              </FormRow>
              <FormRow label="Personal Email">
                <input
                  type="email"
                  name="personalEmail"
                  className={candidateData?.personal?.emailAddr ? "input-field-disabled" : "input-field"}
                  value={candidateData?.personal?.emailAddr || formData.personalEmail}
                  disabled={!!candidateData?.personal?.emailAddr}
                  onChange={handleChange}
                />
              </FormRow>
              <FormRow label="Marital Status">
                <input
                  type="text"
                  name="maritalStatus"
                  className={candidateData?.personal?.maritalStatus ? "input-field-disabled" : "input-field"}
                  value={candidateData?.personal?.maritalStatus || formData.maritalStatus}
                  disabled={!!candidateData?.personal?.maritalStatus}
                  onChange={handleChange}
                />
              </FormRow>
              <FormRow label="Blood Group">
                <input
                  type="text"
                  name="bloodGroup"
                  className={candidateData?.personal?.bloodGroup ? "input-field-disabled" : "input-field"}
                  value={candidateData?.personal?.bloodGroup || formData.bloodGroup}
                  disabled={!!candidateData?.personal?.bloodGroup}
                  onChange={handleChange}
                />
              </FormRow>
            </div>
          </div>


          {/* Card 4: Statutory & Financial Details */}
          <div className="bg-gray-50 p-5 rounded-lg border border-gray-200">
            <h2 className="text-lg font-semibold text-red-800 border-b border-gray-300 pb-3 mb-5">Statutory & Financial Details</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-6 gap-y-5">
              <FormRow label="Aadhar No">
                <input
                  type="text"
                  name="aadharNumber"
                  className={candidateData?.documentProof?.aadharCard ? "input-field-disabled" : "input-field"}
                  value={candidateData?.documentProof?.aadharCard || formData.aadharNumber}
                  disabled={!!candidateData?.documentProof?.aadharCard}
                  onChange={handleChange}
                />
              </FormRow>
              <FormRow label="PAN No">
                <input
                  type="text"
                  name="panNumber"
                  className={candidateData?.documentProof?.panCard ? "input-field-disabled" : "input-field"}
                  value={candidateData?.documentProof?.panCard || formData.panNumber}
                  disabled={!!candidateData?.documentProof?.panCard}
                  onChange={handleChange}
                />
              </FormRow>
              <FormRow label="Full Name as per PAN" required><input type="text" name="fullNameAsPerPAN" className="input-field" value={formData.fullNameAsPerPAN} onChange={handleChange} /></FormRow>
              <FormRow label="UAN Number">
                <input
                  type="text"
                  name="uanNumber"
                  className={candidateData?.pf?.uan ? "input-field-disabled" : "input-field"}
                  value={candidateData?.pf?.uan || formData.uanNumber}
                  disabled={!!candidateData?.pf?.uan}
                  onChange={handleChange}
                />
              </FormRow>
              <FormRow label="Current PF Number" required><input type="text" name="currentPfNumber" className="input-field" value={formData.currentPfNumber} onChange={handleChange} /></FormRow>
              <FormRow label="Current ESIC Number" required><input type="text" name="currentESICNumber" className="input-field" value={formData.currentESICNumber} onChange={handleChange} /></FormRow>
            </div>
          </div>

          {/* Card 5: Organization & Structure Details - NEW CARD */}
          <div className="bg-gray-50 p-5 rounded-lg border border-gray-200">
            <h2 className="text-lg font-semibold text-red-800 border-b border-gray-300 pb-3 mb-5">Organization & Structure Details</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-6 gap-y-5">
              <FormRow label="Employment Status" required>
                <input type="text" name="employmentStatus" className="input-field" value={formData.employmentStatus} onChange={handleChange} />
              </FormRow>
              <FormRow label="Payroll Area Type" required>
                <input type="text" name="payrollAreaType" className="input-field" value={formData.payrollAreaType} onChange={handleChange} />
              </FormRow>
              <FormRow label="BU Head" required>
                <input type="text" name="buHead" className="input-field" value={formData.buHead} onChange={handleChange} />
              </FormRow>
              <FormRow label="Project" required>
                <input type="text" name="project" className="input-field" value={formData.project} onChange={handleChange} />
              </FormRow>
              <FormRow label="Organisation Code" required>
                <input type="text" name="organisationCode" className="input-field" value={formData.organisationCode} onChange={handleChange} />
              </FormRow>
              <FormRow label="Organisation Hierarchy" required>
                <input type="text" name="organisationHierarchy" className="input-field" value={formData.organisationHierarchy} onChange={handleChange} />
              </FormRow>
            </div>
          </div>
          {/* END NEW CARD */}

          {/* Card 6: Work Details (Originally Card 4) */}
          <div className="bg-gray-50 p-5 rounded-lg border border-gray-200">
            <h2 className="text-lg font-semibold text-red-800 border-b border-gray-300 pb-3 mb-5">Work Details</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-6 gap-y-5">
              {/* --- Existing Editable Fields --- */}
              <FormRow label="Designation" required><input type="text" name="designation" className="input-field" value={formData.designation} onChange={handleChange} /></FormRow>
              <FormRow label="Role" required><Select options={["Select a role", ...roles]} value={selectedRole} onChange={(e) => setSelectedRole(e.target.value)} /></FormRow>
              <FormRow label="Location" required><Select options={locations.map(loc => loc.locationName)} value={selectedLocation} onChange={(e) => setSelectedLocation(e.target.value)} /></FormRow>
              <FormRow label="Main Department" required><input type="text" name="mainDepartment" className="input-field" value={formData.mainDepartment} onChange={handleChange} /></FormRow>
              <FormRow label="Sub Department" required><input type="text" name="subDepartment" className="input-field" value={formData.subDepartment} onChange={handleChange} /></FormRow>
              <FormRow label="Grade" required><input type="text" name="grade" className="input-field" value={formData.grade} onChange={handleChange} /></FormRow>
              <FormRow label="Hiring HR" required><input type="text" name="hiringHr" className="input-field" value={formData.hiringHr} onChange={handleChange} /></FormRow>

              {/* --- Conditionally Enabled Fields --- */}
              <FormRow label="Total Experience">
                <input
                  type="text"
                  name="totalExp"
                  className={candidateData?.profExp?.totalExp ? "input-field-disabled" : "input-field"}
                  value={candidateData?.profExp?.totalExp || formData.totalExp}
                  disabled={!!candidateData?.profExp?.totalExp}
                  onChange={handleChange}
                />
              </FormRow>
              <FormRow label="Previous Company">
                <input
                  type="text"
                  name="previousCompany"
                  className={candidateData?.profExp?.company1 ? "input-field-disabled" : "input-field"}
                  value={candidateData?.profExp?.company1 || formData.previousCompany}
                  disabled={!!candidateData?.profExp?.company1}
                  onChange={handleChange}
                />
              </FormRow>
              <FormRow label="From Date">
                <input
                  type="date"
                  name="previousCompanyFrom"
                  className={candidateData?.profExp?.fromDate1 ? "input-field-disabled" : "input-field"}
                  value={candidateData?.profExp?.fromDate1 || formData.previousCompanyFrom}
                  disabled={!!candidateData?.profExp?.fromDate1}
                  onChange={handleChange}
                />
              </FormRow>
              <FormRow label="To Date">
                <input
                  type="date"
                  name="previousCompanyTo"
                  className={candidateData?.profExp?.toDate1 ? "input-field-disabled" : "input-field"}
                  value={candidateData?.profExp?.toDate1 || formData.previousCompanyTo}
                  disabled={!!candidateData?.profExp?.toDate1}
                  onChange={handleChange}
                />
              </FormRow>

              <FormRow label="Primary Skill Name" >
                <input
                  type="text"
                  name="primarySkillName"
                  className={candidateData?.skill?.primarySkill1Name ? "input-field-disabled" : "input-field"}
                  value={candidateData?.skill?.primarySkill1Name ? ([candidateData.skill.primarySkill1Name, candidateData.skill.primarySkill2Name, candidateData.skill.primarySkill3Name].filter(Boolean).join(', ')) : formData.primarySkillName}
                  disabled={!!candidateData?.skill?.primarySkill1Name}
                  onChange={handleChange}
                />
              </FormRow>
              <FormRow label="Primary Skills level" >
                <input
                  type="text"
                  name="primarySkillLevel"
                  className={candidateData?.skill?.primarySkill1Level ? "input-field-disabled" : "input-field"}
                  value={candidateData?.skill?.primarySkill1Level ? ([candidateData.skill.primarySkill1Level, candidateData.skill.primarySkill2Level, candidateData.skill.primarySkill3Level].filter(Boolean).join(', ')) : formData.primarySkillLevel}
                  disabled={!!candidateData?.skill?.primarySkill1Level}
                  onChange={handleChange}
                />
              </FormRow>
              <FormRow label="Secondary Skill Name">
                <input
                  type="text"
                  name="secondarySkillName"
                  className={candidateData?.skill?.secondarySkill1Name ? "input-field-disabled" : "input-field"}
                  value={candidateData?.skill?.secondarySkill1Name ? ([candidateData.skill.secondarySkill1Name, candidateData.skill.secondarySkill2Name, candidateData.skill.secondarySkill3Name].filter(Boolean).join(', ')) : formData.secondarySkillName}
                  disabled={!!candidateData?.skill?.secondarySkill1Name}
                  onChange={handleChange}
                />
              </FormRow>
              <FormRow label="Secondary Skill Level">
                <input
                  type="text"
                  name="secondarySkillLevel"
                  className={candidateData?.skill?.secondarySkill1Level ? "input-field-disabled" : "input-field"}
                  value={candidateData?.skill?.secondarySkill1Level ? ([candidateData.skill.secondarySkill1Level, candidateData.skill.secondarySkill2Level, candidateData.skill.secondarySkill3Level].filter(Boolean).join(', ')) : formData.secondarySkillLevel}
                  disabled={!!candidateData?.skill?.secondarySkill1Level}
                  onChange={handleChange}
                />
              </FormRow>
            </div>
          </div>

      <div className="bg-gray-50 p-5 rounded-lg border border-gray-200">
  <h2 className="text-lg font-semibold text-red-800 border-b border-gray-300 pb-3 mb-5">Bank & Official Details</h2>
  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-6 gap-y-5">
    <FormRow label="Official Email ID"><input type="email" name="officialEmailId" className="input-field" value={formData.officialEmailId} onChange={handleChange} /></FormRow>
    <FormRow label="Bank Name"><input type="text" name="bankName" className="input-field" value={formData.bankName} onChange={handleChange} /></FormRow>
    <FormRow label="Salary Account Number"><input type="text" name="salaryAccountNumber" className="input-field" value={formData.salaryAccountNumber} onChange={handleChange} /></FormRow>
    <FormRow label="IFSC Code"><input type="text" name="ifscCode" className="input-field" value={formData.ifscCode} onChange={handleChange} /></FormRow>
  </div>
</div>

<div className="bg-gray-50 p-5 rounded-lg border border-gray-200">
  <h2 className="text-lg font-semibold text-red-800 border-b border-gray-300 pb-3 mb-5">Family & Nominee</h2>
  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-6 gap-y-5">
    <FormRow label="Nominee Name 1 (Mandatory)" required><input type="text" name="nomineeName1" className="input-field" value={formData.nomineeName1} onChange={handleChange} /></FormRow>
    <FormRow label="Dependent Name"><input type="text" name="dependentName" className="input-field" value={formData.dependentName} onChange={handleChange} /></FormRow>
    <FormRow label="Dependent Relation"><input type="text" name="dependentRelationship" className="input-field" value={formData.dependentRelationship} onChange={handleChange} /></FormRow>
    <FormRow label="Dependent DOB"><input type="date" name="dependentDOB" className="input-field" value={formData.dependentDOB} onChange={handleChange} /></FormRow>
  </div>
</div>


          {/* Action Buttons */}
          <div className="flex flex-wrap items-center justify-end gap-3 pt-5 border-t border-gray-200">
            {/* Conditional Close/Back button */}
            <button
              type="button"
              className="px-4 py-2 rounded-md bg-gray-300 text-gray-800 hover:bg-gray-400 transition"
              onClick={isEditMode ? onClose : () => navigate(-1)}
            >
              ← {isEditMode ? "Cancel" : "Back"}
            </button>
            <button type="button" className="px-4 py-2 rounded-md bg-blue-600 text-white hover:bg-blue-700 transition" onClick={onSubmit}>{isEditMode ? "Update" : "Save"}</button>
          </div>
        </div>
      </div>
    </div>
  );
};

// Helper components
const FormRow = ({ label, required, children, className }) => (
  <div className={`flex flex-col gap-1 ${className}`}>
    <label className="font-medium text-gray-800">
      {label}
      {required && <span className="text-red-600 ml-1">*</span>}
    </label>
    <div className="w-full">{children}</div>
  </div>
);

const Select = ({ options = [], value, onChange }) => (
  <select className="input-field" value={value} onChange={onChange}>
    {options.map((opt, i) =>
      typeof opt === "string" ? (
        <option key={i} value={opt}>{opt}</option>
      ) : (
        <option key={opt.id} value={opt.id}>{opt.name}</option>
      )
    )}
  </select>
);

export default AddEmployee;