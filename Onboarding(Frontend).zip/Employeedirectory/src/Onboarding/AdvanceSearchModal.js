import React, { useState } from "react";

const AdvanceSearchModal = ({ isOpen, onClose, onSearch }) => {
    // New state to manage form inputs
    const [formState, setFormState] = useState({
        candidateName: '',
        status: '',
        fromDate: '',
        toDate: '',
        r1Status: '',
        hrStatus: '',
        overdueDays: ''
    });

    if (!isOpen) return null;

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormState(prevState => ({ ...prevState, [name]: value }));
    };

    const handleSearchClick = () => {
        onSearch(formState); // Pass the form state to the parent component
        onClose(); // Close the modal after searching
    };

    const handleClearAll = () => {
        setFormState({
            candidateName: '',
            status: '',
            fromDate: '',
            toDate: '',
            r1Status: '',
            hrStatus: '',
            overdueDays: ''
        });
        onSearch({}); // Reset the search in the parent component
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-30 flex justify-center items-center z-50">
            <div className="bg-white w-[700px] rounded-lg shadow-lg relative p-8">
                <button
                    onClick={onClose}
                    className="absolute top-4 right-4 text-red-500 hover:text-red-700 text-xl font-bold"
                >
                    ✕
                </button>

                <h2 className="text-xl font-semibold text-gray-800 mb-6">
                    Advance Search
                </h2>

                <div className="grid grid-cols-2 gap-6">
                    {/* Candidate Name */}
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                            Candidate Name
                        </label>
                        <input
                            type="text"
                            name="candidateName"
                            placeholder="Enter a Candidate Name.."
                            className="w-full border border-gray-300 rounded-md px-3 py-2 focus:ring focus:ring-blue-200"
                            value={formState.candidateName}
                            onChange={handleInputChange}
                        />
                    </div>

                    {/* Status */}
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                            Status
                        </label>
                        <select
                            name="status"
                            className="w-full border border-gray-300 rounded-md px-3 py-2 focus:ring focus:ring-blue-200"
                            value={formState.status}
                            onChange={handleInputChange}
                        >
                            <option value="">Select a status</option>
                            <option value="Active">Active</option>
                            <option value="Completed">Completed</option>
                            <option value="Extended">Extended</option>
                        </select>
                    </div>

                    {/* Probation End Date */}
                    <div className="col-span-2 flex gap-4">
                        <div className="flex-1">
                            <label className="block text-sm font-medium text-gray-700 mb-2">
                                From Date
                            </label>
                            <input
                                type="date"
                                name="fromDate"
                                className="w-full border border-gray-300 rounded-md px-3 py-2"
                                value={formState.fromDate}
                                onChange={handleInputChange}
                            />
                        </div>
                        <div className="flex-1">
                            <label className="block text-sm font-medium text-gray-700 mb-2">
                                To Date
                            </label>
                            <input
                                type="date"
                                name="toDate"
                                className="w-full border border-gray-300 rounded-md px-3 py-2"
                                value={formState.toDate}
                                onChange={handleInputChange}
                            />
                        </div>
                    </div>

                    {/* R1 Approval Status */}
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                            R1 Approval Status
                        </label>
                        <select
                            name="r1Status"
                            className="w-full border border-gray-300 rounded-md px-3 py-2"
                            value={formState.r1Status}
                            onChange={handleInputChange}
                        >
                            <option value="">Select a status</option>
                            <option value="Approved">Approved</option>
                            <option value="Pending">Pending</option>
                            <option value="Rejected">Rejected</option>
                        </select>
                    </div>

                    {/* HR Status */}
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                            HR Status
                        </label>
                        <select
                            name="hrStatus"
                            className="w-full border border-gray-300 rounded-md px-3 py-2"
                            value={formState.hrStatus}
                            onChange={handleInputChange}
                        >
                            <option value="">Select a status</option>
                            <option value="Approved">Approved</option>
                            <option value="Pending">Pending</option>
                            <option value="Rejected">Rejected</option>
                        </select>
                    </div>

                    {/* Confirmation Overdue Days */}
                    <div className="col-span-2">
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                            Confirmation Overdue (in Days)
                        </label>
                        <input
                            type="number"
                            name="overdueDays"
                            placeholder="Enter overdue days"
                            className="w-full border border-gray-300 rounded-md px-3 py-2"
                            value={formState.overdueDays}
                            onChange={handleInputChange}
                        />
                    </div>
                </div>

                {/* Buttons */}
                <div className="mt-8 flex justify-end gap-4">
                    <button
                        onClick={handleClearAll}
                        className="px-5 py-2 border border-gray-400 rounded-md text-gray-600 hover:bg-gray-100"
                    >
                        Clear All
                    </button>
                    <button
                        onClick={handleSearchClick}
                        className="px-5 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600"
                    >
                        Search
                    </button>
                </div>
            </div>
        </div>
    );
};

export default AdvanceSearchModal;