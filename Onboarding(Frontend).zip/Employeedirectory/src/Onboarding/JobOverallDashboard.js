

// JobOverallDashboard.js
import React, { useState } from 'react';
import JobOpenings from './JobOpenings';
import JobApplicants from './JobApplicants';
import CandidateDetails from './CandidateDetails';

const JobOverallDashboard = () => {
  // State to manage the selected job and candidate across components
  const [selectedJobId, setSelectedJobId] = useState(null);
  const [selectedCandidateId, setSelectedCandidateId] = useState(null);

  // CRITICAL HANDLER: Reset the candidate when the job changes
  const handleJobSelect = (jobId) => {
    setSelectedJobId(jobId);
    // Explicitly reset the candidate ID to null when the job changes. 
    // This forces JobApplicants to select and push the new default ID immediately.
    setSelectedCandidateId(null); 
  };

  return (
    <>
      <main className="p-6">
        <div className="grid grid-cols-3 gap-6">
          
          {/* 1. Job Openings (left) - Controls selectedJobId */}
          <JobOpenings 
            selectedJobId={selectedJobId} 
            onJobSelect={handleJobSelect} 
          />
          
          {/* 2. Job Applicants (middle) - Filters by selectedJobId and controls selectedCandidateId */}
          <JobApplicants 
            selectedJobId={selectedJobId} 
            onCandidateSelect={setSelectedCandidateId} // This setter updates state for CandidateDetails
          />
          
          {/* 3. Candidate Details (right) - Displays data for selectedCandidateId */}
          <CandidateDetails 
            candidateId={selectedCandidateId} // This will be the JobAppID
          />
        </div>
      </main>
    </>
  );
};

export default JobOverallDashboard;