import React, { useEffect, useState, useRef, useCallback } from "react";
import axios from "axios";
import * as XLSX from "xlsx";
import { saveAs } from "file-saver";
import { useNavigate, useLocation } from "react-router-dom";
import { FaDownload, FaSearch, FaPlus, FaCheck } from "react-icons/fa"; // Added FaCheck for the modal
import { IoEyeSharp } from "react-icons/io5";
import { FaEdit, FaTrashAlt } from "react-icons/fa";

// Import AddEmployee to use it as a modal
import AddEmployee from "./AddEmployee";

// Helper component for the modal overlay and positioning
const EditModalWrapper = ({ children, onClose }) => {
  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-gray-900 bg-opacity-75 flex items-center justify-center">
      {/* Increased max-w-7xl for a large form, and adjusted max-h for scrolling */}
      <div className="relative bg-white rounded-lg shadow-xl w-full max-w-7xl mx-4 my-8 max-h-[95vh] overflow-y-auto">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-600 hover:text-gray-900 z-10 p-2 text-3xl font-bold"
        >
          &times;
        </button>
        {children}
      </div>
    </div>
  );
};


const ListOfOnboardingCandidates = () => {
  const [employees, setEmployees] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [locationFilter, setLocationFilter] = useState("All Locations");
  const [departmentFilter, setDepartmentFilter] = useState("All Departments");
  const [statusFilter, setStatusFilter] = useState("All Status"); // excel export status filter
  const [showColumnsDropdown, setShowColumnsDropdown] = useState(false);
  const [selectedCandidateIds, setSelectedCandidateIds] = useState([]); // State for selected candidate IDs
  const dropdownRef = useRef(null); // Ref for the Choose Columns dropdown
  const navigate = useNavigate();
  const [exported, setExported] = useState(false);
  
  // State for Active/Inactive Tabs (Default to Active)
  const [activeTab, setActiveTab] = useState('Active'); 

  // State for Edit Modal
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [candidateToEdit, setCandidateToEdit] = useState(null); // Holds data of the candidate being edited

  // State for Activation Confirmation Modal (NEW)
  const [showActivateConfirmation, setShowActivateConfirmation] = useState(false);
  const [candidateToActivate, setCandidateToActivate] = useState(null); // Holds data of the candidate being activated

  // Define all available columns and their default visibility
  const allColumns = [
    { key: "select", label: "Select", visible: true }, 
    { key: "name", label: "Candidate Name", visible: true },
    { key: "email", label: "Email ID", visible: true },
    { key: "contact", label: "Contact No", visible: true },
    { key: "department", label: "Department", visible: true },
    { key: "designation", label: "Designation", visible: true },
    { key: "manager", label: "Manager", visible: true },
    { key: "overallStatus", label: "Status", visible: true },
    { key: "employeeStatus", label: "Candidate Status", visible: true },
    { key: "exportStatus", label: "Excel Export Status", visible: true },
    { key: "actions", label: "Actions", visible: true },
  ];
  const [visibleColumns, setVisibleColumns] = useState(allColumns);

  // Function to fetch data - Refactored to be callable
  const fetchData = useCallback(async () => {
    setLoading(true);
    try {
      // Fetch data from API
      const res = await axios.get("http://localhost:9034/onboarding/get/allCandidates");
      const candidatesWithStatus = res.data.map(candidate => ({
          ...candidate,
          // Ensure default/existing status fields are populated
          excelExportStatus: candidate.employeeOnboardingInfo?.excelExportStatus || "Pending",
          // The employeeOnboardingInfo.status is used for the table column display, 
          // but overallStatus.overallStatus will be used for the Active/Inactive tab filtering.
          employeeOnboardingInfo: {
            ...candidate.employeeOnboardingInfo,
            status: candidate.employeeOnboardingInfo?.status || "Active" 
          }
      }));
      setEmployees(candidatesWithStatus);
    } catch (err) {
      console.error("Error fetching employee data:", err);
    } finally {
      setLoading(false);
    }
  }, []);

  // Fetch all onboarding candidates from API on mount
  useEffect(() => {
    fetchData();
  }, [fetchData]);

  // Close the columns dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setShowColumnsDropdown(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  const handleColumnToggle = (key) => {
    setVisibleColumns(
      visibleColumns.map((col) =>
        col.key === key ? { ...col, visible: !col.visible } : col
      )
    );
  };

  const handleSelectAllColumns = (e) => {
    const isChecked = e.target.checked;
    setVisibleColumns(
      visibleColumns.map((col) => ({ ...col, visible: isChecked }))
    );
  };

  // Function to handle individual candidate selection
  const handleCandidateSelection = (candidateId, isChecked) => {
    setSelectedCandidateIds(prevIds =>
      isChecked
        ? [...prevIds, candidateId] 
        : prevIds.filter(id => id !== candidateId)
    );
  };
  
  const handleEdit = (candidateData) => {
    setCandidateToEdit(candidateData);
    setIsEditModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsEditModalOpen(false);
    setCandidateToEdit(null);
    fetchData(); 
  };


  // Step 1: Filter employees based on the selected tab (Active/Inactive)
  // MODIFIED LOGIC: Use emp.overallStatus?.overallStatus for tab filtering.
  const tabFilteredEmployees = employees.filter((emp) => {
      // Use overallStatus.overallStatus for determining Active/Inactive tab placement
      const overallStatus = emp.overallStatus?.overallStatus; 
      
      if (activeTab === 'Active') {
          // Active tab: Show all candidates whose overallStatus is NOT 'InActive'
          return overallStatus !== 'InActive';
      } else { // activeTab === 'Inactive'
          // Inactive tab: Show only candidates whose overallStatus IS 'InActive'
          return overallStatus === 'InActive';
      }
  });


  // Step 2: Apply Search, Location, Department, and Export Status filters on the tab-filtered list
  const filteredEmployees = tabFilteredEmployees.filter((emp) => {
    const fullName = `${emp.personal?.firstName} ${emp.personal?.lastName}`.toLowerCase();
    const matchesSearch = fullName.includes(searchTerm.toLowerCase());
    const matchesLocation =
      locationFilter === "All Locations" || emp.employeeOnboardingInfo?.location === locationFilter;
    const matchesDepartment =
      departmentFilter === "All Departments" || emp.employeeOnboardingInfo?.mainDepartment === departmentFilter;
    const matchesStatus =
      statusFilter === "All Status" || emp.excelExportStatus === statusFilter;

    return matchesSearch && matchesLocation && matchesDepartment && matchesStatus;
  });

  // Get IDs of candidates that are filtered AND NOT 'Exported'
  const allSelectableFilteredIds = filteredEmployees
    .filter(emp => emp.excelExportStatus !== 'Exported')
    .map(emp => emp.personal?.candID)
    .filter(Boolean);

  // Check if all *selectable* filtered candidates are currently selected
  const allFilteredSelected = allSelectableFilteredIds.length > 0 &&
    allSelectableFilteredIds.every(id => selectedCandidateIds.includes(id));


  // Function to handle select all visible *selectable* candidates
  const handleSelectAllCandidates = (e) => {
    const isChecked = e.target.checked;
    
    setSelectedCandidateIds(prevIds => {
      if (isChecked) {
        // Add all selectable filtered IDs that are not already in the selection
        const newIds = [...new Set([...prevIds, ...allSelectableFilteredIds])];
        return newIds;
      } else {
        // Remove only the selectable IDs visible in the current filter
        return prevIds.filter(id => !allSelectableFilteredIds.includes(id));
      }
    });
  };

  const uniqueLocations = [...new Set(employees.map(emp => emp.employeeOnboardingInfo?.location).filter(Boolean))];
  const uniqueDepartments = [...new Set(employees.map(emp => emp.employeeOnboardingInfo?.mainDepartment).filter(Boolean))];
  const uniqueExportStatuses = [...new Set(employees.map(emp => emp.excelExportStatus).filter(Boolean))];

  // Calculate the total number of candidates pending export (only from Active Candidates)
  // MODIFIED LOGIC: Use overallStatus?.overallStatus !== 'InActive' for Active check
  const pendingExportCount = employees.filter(
      (emp) => emp.excelExportStatus === "Pending" && emp.overallStatus?.overallStatus !== 'InActive'
  ).length;

  // ------------------------- API CALL FUNCTIONS -------------------------
  
  // Helper to update Excel Export Status
  const updateCandidateImportStatus = async (candidateId, newStatus) => {
    const url = `http://localhost:9034/onboarding/updateCandidatesDetails/${candidateId}`; 
    try {
      await axios.put(url, { excelExportStatus: newStatus });
    } catch (err) {
      console.error(`Failed to update status for candidate ${candidateId}:`, err);
    }
  };

  // Handler for Deactivate (Trash Icon)
  const handleDelete = async (candID) => {
  try {
    // This API call likely updates the overallStatus to 'InActive' on the backend.
    await axios.put(`http://localhost:9034/onboarding/candidates/${candID}/deactivate`);
    alert("Candidate marked as InActive successfully");
    fetchData(); // refresh list to move the candidate to the Inactive tab
  } catch (error) {
    console.error(error);
    alert("Failed to deactivate candidate");
  }
};

  // Activation Logic (NEW)
  const handleActivateClick = (candidateData) => {
    setCandidateToActivate(candidateData);
    setShowActivateConfirmation(true);
  };

  const confirmActivate = async () => {
    if (!candidateToActivate) return;
    const candID = candidateToActivate.personal?.candID;
    setShowActivateConfirmation(false);

    try {
      // API call to set status to 'Active'. Assumes an endpoint similar to the previous turn's suggestion.
      // If the backend only uses '/deactivate', you will need a separate '/activate' endpoint.
      // Using a generic status endpoint for better practice:
     // const url = `http://localhost:9034/onboarding/candidates/${candID}/status?status=Active`; 
      const url = `http://localhost:9034/onboarding/candidates/${candID}/activate`;
      await axios.put(url);
      
      alert(`Candidate ${candID} marked as Active successfully.`);
      fetchData(); // Re-fetch data to move the candidate to the Active tab and update the table
    } catch (error) {
      console.error("Error activating candidate:", error);
      alert("Failed to activate candidate. Please ensure the backend API (/candidates/{candID}/status?status=Active) is available.");
    } finally {
      setCandidateToActivate(null);
    }
  };

  const cancelActivateConfirmation = () => {
    setShowActivateConfirmation(false);
    setCandidateToActivate(null);
  };
  // --------------------------------------------------------------------------


  // Export to Excel for **Selected** candidates
  const exportSelectedToExcel = async () => {
    // CRITICAL: Prevent export if the Inactive tab is selected
    if (activeTab === 'Inactive') {
        alert("Only candidates from the 'Active' list can be exported.");
        setSelectedCandidateIds([]); // Clear selection
        return;
    }
    
    if (selectedCandidateIds.length === 0) {
      alert("Please select at least one candidate to download.");
      return;
    }

    // Filter the full employee list to get only the selected ones
    const selectedEmployees = employees.filter(emp => selectedCandidateIds.includes(emp.personal?.candID));

    // Map the selected employee data to a flattened format suitable for a single Excel sheet
    const formattedData = selectedEmployees.map((emp) => ({
      // === Basic Information ===
      "Candidate ID": emp.personal?.candID || "",
      "Emp Onboarding Ref Number": emp.employeeOnboardingInfo?.empOnboardingRefNum || "",
      "Date of Joining": emp.employeeOnboardingInfo?.joiningDate || "",
      "Status": emp.employeeOnboardingInfo?.status || "",
      "Full Name": [emp.personal?.firstName, emp.personal?.middleName, emp.personal?.lastName].filter(Boolean).join(" "),
      "Date of Birth (DD-MM-YYYY)": emp.personal?.dob || "",
      "Gender": emp.employeeOnboardingInfo?.gender || "",
      "Is Probation Applicable": emp.employeeOnboardingInfo?.isProbationApplicable ? "Yes" : "No",
      "Probation Start Date": emp.employeeOnboardingInfo?.probationPeriod || "",
      "Confirmation End Date": emp.employeeOnboardingInfo?.confirmationDate || "",
      "Max Probation Extension": emp.employeeOnboardingInfo?.maxProbationExtension || "",

      // === Personal Details ===
      "Primary Contact No": emp.personal?.permContactNum || "",
      "Secondary Contact No": emp.personal?.curContactNum || "",
      "Emergency Contact No": emp.personal?.emrContactNum || "",
      "Personal Email": emp.personal?.emailAddr || "",
      "Marital Status": emp.personal?.maritalStatus || "",
      "Blood Group": emp.personal?.bloodGroup || "",

      // === Statutory & Financial Details ===
      "Aadhar No": emp.documentProof?.aadharCard || "",
      "PAN No": emp.documentProof?.panCard || "",
      "Full Name as per PAN": emp.employeeOnboardingInfo?.fullNameAsPerPAN || "",
      "UAN Number": emp.pf?.uan || "",
      "Current PF Number": emp.employeeOnboardingInfo?.currentPfNumber || "",
      "Current ESIC Number": emp.employeeOnboardingInfo?.currentESICNumber || "",

      // === Organization & Structure Details ===
      "Employment Status": emp.employeeOnboardingInfo?.employmentStatus || "",
      "Payroll Area Type": emp.employeeOnboardingInfo?.payrollAreaType || "",
      "BU Head": emp.employeeOnboardingInfo?.buHead || "",
      "Project": emp.employeeOnboardingInfo?.project || "",
      "Organisation Code": emp.employeeOnboardingInfo?.organisationCode || "",
      "Organisation Hierarchy": emp.employeeOnboardingInfo?.organisationHierarchy || "",

      // === Work Details ===
      "Designation": emp.employeeOnboardingInfo?.designation || "",
      "Location": emp.employeeOnboardingInfo?.jobLocation || "",
      "Main Department": emp.employeeOnboardingInfo?.mainDepartment || "",
      "Sub Department": emp.employeeOnboardingInfo?.subDepartment || "",
      "Grade": emp.employeeOnboardingInfo?.grade || "",
      "Hiring HR": emp.employeeOnboardingInfo?.hiringHr || "",
      "Total Experience": emp.profExp?.totalExp || "",
      "Previous Company": emp.profExp?.company1 || "",
      "Previous Company From Date": emp.profExp?.fromDate1 || "",
      "Previous Company To Date": emp.profExp?.toDate1 || "",

      // === Skills ===
      "Primary Skills": [
        emp.skill?.primarySkill1Name,
        emp.skill?.primarySkill2Name,
        emp.skill?.primarySkill3Name
      ].filter(Boolean).join(", "),
      "Primary Skills Level": [
        emp.skill?.primarySkill1Level,
        emp.skill?.primarySkill2Level,
        emp.skill?.primarySkill3Level
      ].filter(Boolean).join(", "),
      "Secondary Skills": [
        emp.skill?.secondarySkill1Name,
        emp.skill?.secondarySkill2Name,
        emp.skill?.secondarySkill3Name
      ].filter(Boolean).join(", "),
      "Secondary Skills Level": [
        emp.skill?.secondarySkill1Level,
        emp.skill?.secondarySkill2Level,
        emp.skill?.secondarySkill3Level
      ].filter(Boolean).join(", "),

      // === Bank & Official Details ===
      "Official Email ID": emp.employeeOnboardingInfo?.officialEmailId || "",
      "Bank Name": emp.bank?.bankName || "",
      "Salary Account Number": emp.bank?.accountNum || "",
      "Name on Salary Account": emp.bank?.nameAsPerBank || "",
      "IFSC Code": emp.bank?.ifscCode || "",

      // === Family & Nominee ===
      "Nominee Name 1": emp.family?.nomineeName || "",
      "Dependent Name": emp.family?.dependentName || "",
      "Dependent Relation": emp.family?.dependentRelation || "",
      "Dependent DOB": emp.family?.dependentDob || "",

      // === Reporting Manager Details ===
      "Reporting Manager Name": emp.employeeOnboardingInfo?.rptManagerName || "",
      "Reporting Manager Code": emp.employeeOnboardingInfo?.rptMgrEmployeeCode || "",
      "Reporting Manager Email": emp.employeeOnboardingInfo?.rptManagerEmailId || "",

      // === Additional Details ===
      "Org Unit": emp.employeeOnboardingInfo?.orgUnit || "",
      "Company Code": emp.employeeOnboardingInfo?.companyCode || "",
      "Category": emp.employeeOnboardingInfo?.category || "",
      "Qualification": emp.education?.highestQualification || "",

      // === Status ===
      "Excel Export Status": emp.excelExportStatus || "Pending",
      "Overall Status": emp.overallStatus?.overallStatus || "Initiated",
    }));

    // Create a new worksheet and workbook
    const ws = XLSX.utils.json_to_sheet(formattedData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Selected Active Candidates");

    // Write and save the Excel file
    XLSX.writeFile(wb, "SelectedActiveOnboardingCandidates.xlsx");
    
    // Update Status After Export 
    try {
      await Promise.all(
        selectedCandidateIds.map(id => updateCandidateImportStatus(id, 'Exported'))
      );
      setEmployees(prevEmployees => 
          prevEmployees.map(emp => 
              selectedCandidateIds.includes(emp.personal?.candID)
                ? { ...emp, excelExportStatus: 'Exported' } 
                : emp
          )
      );
      
      setSelectedCandidateIds([]); 
      setExported(true);
      setTimeout(() => setExported(false), 3000);
      alert(`Successfully exported ${selectedCandidateIds.length} candidates and updated their status to 'Exported'.`);

    } catch (error) {
      console.error("Error during status update after export:", error);
      alert("Export successful, but there was an error updating candidate statuses on the server.");
    }
  };

// ...existing code...

  const handleClearFilters = () => {
    setSearchTerm("");
    setLocationFilter("All Locations");
    setDepartmentFilter("All Departments");
    setStatusFilter("All Status");
    setVisibleColumns(allColumns);
    setSelectedCandidateIds([]); 
  };


  // Helper function to render a status badge for Excel Import Status
  const renderStatusBadge = (status) => {
    let bgColor, textColor;
    switch (status) {
        case "Exported":
            bgColor = "bg-green-100";
            textColor = "text-green-800";
            break;
        case "Pending":
            bgColor = "bg-yellow-100";
            textColor = "text-yellow-800";
            break;
        case "Failed":
            bgColor = "bg-red-100";
            textColor = "text-red-800";
            break;
        default:
            bgColor = "bg-gray-100";
            textColor = "text-gray-800";
    }

    return (
        <span className={`px-2 py-1 rounded-full text-xs font-semibold ${bgColor} ${textColor}`}>
            {status || "N/A"}
        </span>
    );
  };
  // ---------------------------------------------

  return (
    <div className="p-6 bg-gray-100 min-h-screen">
      <div className="bg-white rounded-lg shadow-lg p-6">
        <h2 className="text-2xl font-bold mb-4">Onboarding Candidates List</h2>
        
        {/* Simple Tab Navigation */}
        <div className="flex border-b border-gray-200 mb-6">
            {['Active', 'Inactive'].map((tab) => (
                <button
                    key={tab}
                    onClick={() => {
                        setActiveTab(tab);
                        setSelectedCandidateIds([]); // Clear selection when switching tabs
                        // Reset all filters for a clean tab switch
                        setSearchTerm("");
                        setLocationFilter("All Locations");
                        setDepartmentFilter("All Departments");
                        setStatusFilter("All Status");
                    }}
                    className={`
                        py-2 px-4 text-lg font-medium transition-colors duration-200 
                        ${activeTab === tab 
                            ? 'text-blue-600 border-b-4 border-blue-600' 
                            : 'text-gray-500 hover:text-gray-700'
                        }
                    `}
                >
                    {tab}
                </button>
            ))}
        </div>
        
        {/* Top bar with total employee count, Pending count, and Export button */}
        <div className="flex justify-between items-center mb-6 border-b pb-4">
          
          {/* LEFT SIDE: Total Candidate Count */}
          <p className="text-lg font-semibold text-gray-700">
            {activeTab} Candidates: <b className="text-2xl text-blue-600 ml-1">{tabFilteredEmployees.length}</b>
            {tabFilteredEmployees.length !== filteredEmployees.length && (
              <span className="text-sm text-gray-500 ml-4">
                ({filteredEmployees.length} currently filtered)
              </span>
            )}
          </p>
          
          {/* RIGHT SIDE: Pending Count (Attractive Badge) and Export Button (Conditional) */}
          <div className="flex items-center space-x-4">
            
            {/* Conditional Rendering: Only show export tools on the Active tab */}
            {activeTab === 'Active' && (
              <>
                {/* Attractive Pending Export Display (Badge/Card) */}
                <div className="flex items-center space-x-2 p-3 bg-yellow-50 border border-yellow-300 rounded-lg shadow-md">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-yellow-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                        <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                    </svg>
                    <span className="text-sm font-semibold text-yellow-800 uppercase">
                      Pending Export:
                    </span>
                    <span className="text-xl font-bold text-yellow-600">
                      {pendingExportCount}
                    </span>
                </div>

                {/* Export Button */}
                <button
                  onClick={exportSelectedToExcel} 
                  className="px-6 py-3 flex items-center bg-blue-600 text-white font-semibold rounded-xl shadow-lg hover:bg-blue-700 hover:shadow-xl transition duration-200 disabled:opacity-50 disabled:shadow-none"
                  disabled={selectedCandidateIds.length === 0}
                >
                  <FaDownload className="mr-2 text-lg" /> 
                  Export Selected ({selectedCandidateIds.length})
                </button>
              </>
            )}
          </div>
        </div>
        
        {/* Filter and Search Bar */}
        <div className="flex justify-between items-center mb-6 p-4 bg-gray-50 border rounded-lg shadow-sm">
          <div className="flex items-center space-x-4 flex-1">
            <div className="relative flex-1">
              <FaSearch className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                placeholder="Search Candidates..."
                className="w-full pl-10 pr-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>

            <select
              className="px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              value={locationFilter}
              onChange={(e) => setLocationFilter(e.target.value)}
            >
              <option>All Locations</option>
              {uniqueLocations.map((loc) => (
                <option key={loc} value={loc}>
                  {loc}
                </option>
              ))}
            </select>

            <select
              className="px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              value={departmentFilter}
              onChange={(e) => setDepartmentFilter(e.target.value)}
            >
              <option>All Departments</option>
              {uniqueDepartments.map((dept) => (
                <option key={dept} value={dept}>
                  {dept}
                </option>
              ))}
            </select>

            {/* Status filter (Excel Export Status) */}
            <select
              className="px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
            >
              <option>All Status</option>
              {uniqueExportStatuses.map((excelExportStatus) => (
                <option key={excelExportStatus} value={excelExportStatus}>
                  {excelExportStatus}
                </option>
              ))}
            </select>
          </div>

          <div className="flex items-center space-x-2 ml-4">
            {/* Choose Columns button */}
            <div className="relative" ref={dropdownRef}>
              <button
                onClick={() => setShowColumnsDropdown(!showColumnsDropdown)}
                className="px-4 py-2 bg-gray-300 text-gray-700 rounded-lg hover:bg-gray-400"
              >
                Choose Columns
              </button>
              {showColumnsDropdown && (
                <div className="absolute right-0 mt-2 w-64 p-4 bg-white rounded-lg shadow-lg z-10">
                  <h4 className="font-semibold mb-2">Select Columns to display</h4>
                  <div className="border-b pb-2 mb-2">
                    <label className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        className="form-checkbox"
                        checked={visibleColumns.every((col) => col.visible)}
                        onChange={handleSelectAllColumns} 
                      />
                      <span>Select All</span>
                    </label>
                  </div>
                  {allColumns.map((col) => (
                    <div key={col.key} className="mb-1">
                      <label className="flex items-center space-x-2">
                        <input
                          type="checkbox"
                          className="form-checkbox"
                          checked={visibleColumns.find(c => c.key === col.key)?.visible || false}
                          onChange={() => handleColumnToggle(col.key)}
                        />
                        <span>{col.label}</span>
                      </label>
                    </div>
                  ))}
                  <button
                    onClick={() => setShowColumnsDropdown(false)}
                    className="mt-4 w-full py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                  >
                    Submit
                  </button>
                </div>
              )}
            </div>
            <button
              onClick={handleClearFilters}
              className="px-4 py-2 text-gray-700 border border-gray-300 rounded-lg hover:bg-gray-200"
            >
              Clear Filters
            </button>
          </div>
        </div>

        {loading ? (
          <p>Loading candidates...</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="min-w-full bg-white border border-gray-200 rounded-lg shadow-sm">
              <thead className="bg-gray-100">
                <tr className="text-left text-sm text-gray-600 uppercase tracking-wider">
                  {visibleColumns.filter(col => col.visible).map((col) => (
                    <th key={col.key} className="px-4 py-3 border-b-2 border-gray-200 font-semibold">
                      {/* Logic for the 'Select All' checkbox in the header */}
                      {col.key === 'select' ? (
                        <input
                          type="checkbox"
                          className="form-checkbox h-4 w-4 text-blue-600 rounded"
                          checked={allFilteredSelected}
                          onChange={handleSelectAllCandidates}
                          disabled={allSelectableFilteredIds.length === 0 || activeTab === 'Inactive'}
                        />
                      ) : (
                        col.label
                      )}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filteredEmployees.map((emp, index) => {
                  const candidateId = emp.personal?.candID;
                  const isSelected = selectedCandidateIds.includes(candidateId);
                  const isExported = emp.excelExportStatus === 'Exported'; 
                  // Check if the candidate is in the Inactive tab based on the new logic
                  const isInactive = emp.overallStatus?.overallStatus === 'InActive'; 

                  return (
                    <tr key={candidateId} className="border-b border-gray-200 hover:bg-gray-50 transition-colors duration-200">
                      {visibleColumns.filter(col => col.visible).map((col) => (
                        <td key={col.key} className="p-4 text-sm text-gray-600">
                          {/* Checkbox Column (Select) */}
                          {col.key === "select" && (
                            <input
                              type="checkbox"
                              className="form-checkbox h-4 w-4 text-blue-600 rounded"
                              checked={isSelected}
                              onChange={(e) => handleCandidateSelection(candidateId, e.target.checked)}
                              // Disabled logic remains based on 'isExported' and if it's the 'Inactive' tab
                              disabled={isExported || activeTab === 'Inactive'} 
                              title={isExported ? "Already exported" : activeTab === 'Inactive' ? "Cannot select inactive candidates for export" : "Select for export"}
                            />
                          )}

                          {col.key === "name" && (
                            <div className="flex items-center">
                              <img
                                src="https://via.placeholder.com/40"
                                alt="Profile"
                                className="w-8 h-8 rounded-full mr-3 border border-gray-300"
                              />
                              <span className="font-medium text-gray-900">
                                {emp.personal?.firstName} {emp.personal?.lastName}
                              </span>
                            </div>
                          )}
                          
                          {col.key === "email" && (emp.personal?.emailAddr || "N/A")}
                          {col.key === "contact" && (emp.personal?.curContactNum || "N/A")}
                          {col.key === "department" && (emp.employeeOnboardingInfo?.mainDepartment || "N/A")}
                          {col.key === "designation" && (emp.employeeOnboardingInfo?.designation || "N/A")}
                          {col.key === "manager" && (emp.employeeOnboardingInfo?.rptManagerName || "N/A")}

                          {col.key === "overallStatus" && (
                            <span
                              className={`px-2 py-1 rounded-full text-xs font-semibold ${emp.overallStatus?.overallStatus === "Initiated"
                                  ? "bg-yellow-100 text-yellow-800"
                                  : emp.overallStatus?.overallStatus === "HR-completed"
                                    ? "bg-green-100 text-green-800"
                                    : emp.overallStatus?.overallStatus === "InActive"
                                      ? "bg-red-100 text-red-800" // Added InActive style
                                      : "bg-gray-100 text-gray-800"
                                }`}
                            >
                              {emp.overallStatus?.overallStatus || "N/A"}
                            </span>
                          )}

                          {col.key === "employeeStatus" && (
                            // This column currently uses employeeOnboardingInfo?.status 
                            // which might be different from overallStatus?.overallStatus
                            <span
                              className={`px-2 py-1 rounded-full text-xs font-semibold ${emp.employeeOnboardingInfo?.status === "Active"
                                  ? "bg-green-100 text-green-800"
                                  : "bg-red-100 text-red-800"
                                }`}
                            >
                              {emp.employeeOnboardingInfo?.status || "N/A"}
                            </span>
                          )}

                          {/* Excel Export Status */}
                          {col.key === "exportStatus" && ( 
                            renderStatusBadge(emp.excelExportStatus)
                          )}
                          
                         {col.key === "actions" && (
                            <div className="flex space-x-2 items-center">
                              {isInactive ? (
                                // Show Activate button only when the candidate is InActive
                                <button
                                    onClick={() => handleActivateClick(emp)}
                                    className="px-3 py-1 text-sm font-semibold text-white bg-green-500 rounded-lg shadow-md hover:bg-green-600 transition duration-150"
                                    title="Activate Candidate"
                                >
                                    Activate
                                </button>
                              ) : (
                                // Show View, Edit, and Deactivate button when the candidate is NOT InActive
                                <>
                                    {/* View Icon */}
                                    <button
                                        onClick={() => {
                                            navigate(`/employee/${candidateId}`, { state: { employee: emp } });
                                        }}
                                        className="text-gray-500 hover:text-blue-600"
                                        title="View Candidate Details"
                                    >
                                        <IoEyeSharp size={20} className="text-blue-600" />
                                    </button>

                                    {/* Edit Icon */}
                                    <button
                                        onClick={() => handleEdit(emp)} 
                                        className="text-gray-500 hover:text-yellow-500"
                                        title="Edit Candidate Details"
                                    >
                                        <FaEdit size={20} className="text-green-600" />
                                    </button>

                                    {/* Delete/Deactivate Icon */}
                                    <button
                                        onClick={() => handleDelete(candidateId)}
                                        className="text-gray-500 hover:text-red-600"
                                        title="Deactivate Candidate (Move to Inactive list)"
                                    >
                                        <FaTrashAlt size={20} className="text-red-600" />
                                    </button>
                                </>
                              )}
                            </div>
                          )}
						  
                        </td>
                      ))}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
      
      {/* RENDER THE MODAL COMPONENT CONDITIONALLY */}
      {isEditModalOpen && candidateToEdit && (
        <EditModalWrapper onClose={handleCloseModal}>
          <AddEmployee 
             initialCandidateData={candidateToEdit}
             onClose={handleCloseModal}
          />
        </EditModalWrapper>
      )}

      {/* Confirmation Modal for Activation (NEW) */}
      {showActivateConfirmation && candidateToActivate && (
          <div className="fixed inset-0 bg-gray-600 bg-opacity-50 flex justify-center items-center z-50">
              <div className="bg-white p-6 rounded-lg shadow-xl max-w-sm w-full">
                  <div className="flex items-center text-green-600 mb-4">
                      <FaCheck className="h-6 w-6 mr-3" />
                      <h3 className="text-lg font-semibold text-gray-800">Confirm Activation</h3>
                  </div>
                  <p className="text-gray-700 mb-6">
                      Are you sure you want to "activate" this candidate  to "Active".
                  </p>
                  <div className="flex justify-end space-x-4">
                      <button
                          onClick={cancelActivateConfirmation}
                          className="px-4 py-2 bg-gray-300 text-gray-800 rounded-md hover:bg-gray-400 transition duration-150"
                      >
                          Cancel
                      </button>
                      <button
                          onClick={confirmActivate}
                          className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition duration-150"
                      >
                          Activate
                      </button>
                  </div>
              </div>
          </div>
      )}

    </div>
  );
};

export default ListOfOnboardingCandidates;