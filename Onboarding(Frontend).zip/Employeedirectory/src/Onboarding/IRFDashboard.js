import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom'; // Import useNavigate for routing
import { Search, ChevronRight, FileText } from 'lucide-react';

const IRFDashboard = () => {
  const [intRefData, setIntRefData] = useState('');
  const navigate = useNavigate();

  const handleSearch = (e) => {
    e.preventDefault();
    if (intRefData.trim()) {
      // Route to the dashboard page and pass the IRF number as a URL parameter
      navigate(`/jobdashboard/${intRefData}`);
    }
  };

  return (
    <div className="flex min-h-screen bg-slate-50 font-sans text-slate-900">
      {/* Sidebar remains same */}
      <aside className="w-64 bg-[#0A192F] text-white flex flex-col">
        <div className="p-6 border-b border-slate-700/50">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-red-600 rounded flex items-center justify-center font-bold">H</div>
            <span className="text-xl font-bold tracking-tight">HR.PORTAL</span>
          </div>
        </div>
      </aside>

      <div className="flex-grow flex flex-col items-center justify-center p-8">
        <div className="max-w-2xl w-full">
          <div className="text-center mb-10">
            <h1 className="text-4xl font-bold text-blue-900 mb-4">Internal Resource Lookup</h1>
            <p className="text-slate-500">Enter the Reference Data to generate the job analysis report.</p>
          </div>

          <section className="bg-white p-2 rounded-2xl shadow-2xl border border-slate-200 overflow-hidden">
            <form onSubmit={handleSearch} className="flex">
              <div className="flex-grow flex items-center px-6 py-4">
                <Search className="text-blue-900 mr-4" size={24} />
                <input 
                  type="text" 
                  value={intRefData}
                  onChange={(e) => setIntRefData(e.target.value)}
                  placeholder="Enter INT_REF_NUMBER here..." 
                  className="w-full outline-none text-xl font-medium"
                />
              </div>
              <button type="submit" className="bg-blue-900 hover:bg-blue-800 text-white px-10 py-4 font-bold transition-all flex items-center gap-2">
                Search <ChevronRight size={18} />
              </button>
            </form>
          </section>
        </div>
      </div>
    </div>
  );
};

export default IRFDashboard;