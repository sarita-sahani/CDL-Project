import React, { useEffect, useState } from "react";
import { FaSearch, FaFilter, FaEye } from 'react-icons/fa';
import { MdPerson, MdOutlineMail, MdLocationOn, MdClose } from 'react-icons/md';

// Helper function for date sorting
const getDateForSorting = (dateString) => {
    if (!dateString) return new Date(0);
    const date = new Date(dateString);
    return isNaN(date.getTime()) ? new Date(0) : date; 
};

const JobOpenings = ({ selectedJobId, onJobSelect,intRefData}) => { 
//const intRefData = 1234;
    const [jobs, setJobs] = useState([]);
    const [loading, setLoading] = useState(false);
    const [searchTerm, setSearchTerm] = useState("");
    const [selectedJob, setSelectedJob] = useState(null);

    useEffect(() => {
        const fetchJobs = async () => {
            setLoading(true);
            try {
                let url = "http://localhost:9034/display/fetch/jobPost/data";

                if (intRefData) {
                    url += `/${encodeURIComponent(intRefData)}`;
                }

                const response = await fetch(url);
                const data = await response.json();

                const fetchedJobs = Array.isArray(data) ? data : [];
                setJobs(fetchedJobs);

                if (fetchedJobs.length > 0 && onJobSelect) {
                    onJobSelect(fetchedJobs[0].JOB_ID);
                }

            } catch (error) {
                console.error("Error fetching job posts", error);
            } finally {
                setLoading(false);
            }
        };

        fetchJobs();
    }, [intRefData, onJobSelect]);

    const filteredJobs = jobs.filter(job => {
        const term = searchTerm.toLowerCase();
        return (
            job.JOB_ROLE?.toLowerCase().includes(term) ||
            job.JOB_ID?.toString().includes(term)
        );
    });

    if (loading) {
        return <div className="p-6 text-center">Loading jobs...</div>;
    }

    const openJobCount = filteredJobs.filter(job => job.JOB_STATUS === 'Open').length;

    const handleJobClick = (jobId) => {
        if (onJobSelect) {
            onJobSelect(jobId);
        }
    };

    const handleViewJob = (e, job) => {
        e.stopPropagation();
        setSelectedJob(job);
    };

    const closeModal = () => {
        setSelectedJob(null);
    };
    return (
        <div className="bg-white rounded-lg shadow w-full font-sans">
            <div className="p-3 sm:p-4 border-b border-gray-100">
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 sm:gap-0">
                    <h2 className="text-base sm:text-lg font-semibold text-red-800">
                        {intRefData ? "Search Result" : "Job Openings"}
                    </h2>
                    <span className="text-lg sm:text-xl md:text-2xl font-bold text-red-600 bg-red-50 px-3 py-1 rounded-full">{openJobCount}</span>
                </div>
            </div>

            <div className="p-3 sm:p-4 space-y-4 max-h-[700px] overflow-y-auto">
                {/* Only show search bar if we aren't already filtered by IRF */}
                {!intRefData && (
                    <div className="relative mb-3 sm:mb-4">
                        <FaSearch className="absolute left-3 top-1/2 transform -translate-y-1/2 w-3 h-3 sm:w-4 sm:h-4 text-gray-400" />
                        <input
                            type="text"
                            placeholder="Search jobs..."
                            className="w-full pl-10 pr-10 py-2.5 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-red-500"
                            value={searchTerm} 
                            onChange={(e) => setSearchTerm(e.target.value)} 
                        />
                    </div>
                )}

                {filteredJobs.length > 0 ? filteredJobs.map((job) => { 
                    const jobId = job.JOB_ID;
                    const isActive = jobId === selectedJobId;
                    return (
                        <div key={jobId} 
                             className={`border rounded-xl p-4 transition-all duration-200 cursor-pointer shadow-sm
                                 ${isActive ? 'border-red-600 bg-red-50 ring-2 ring-red-300' : 'border-gray-200 hover:border-red-400'}`}
                             onClick={() => handleJobClick(jobId)}
                        >
                            <div className="flex justify-between items-start mb-3 gap-3">
                                <h3 className="font-bold text-gray-900 text-base leading-tight">
                                    {job.JOB_ROLE}
                                </h3>
                                <div className="flex items-center gap-2">
                                    <button
                                        onClick={(e) => handleViewJob(e, job)}
                                        className="p-2 hover:bg-red-100 rounded-lg transition-colors"
                                        title="View Details"
                                    >
                                        <FaEye className="text-red-600 w-4 h-4" />
                                    </button>
                                    <span 
                                        className="px-3 py-1 text-white text-xs font-semibold rounded-full"
                                        style={{ backgroundColor: job.JOB_STATUS === 'Open' ? '#ef4444' : '#6b7280' }}
                                    >
                                        {job.JOB_STATUS}
                                    </span>
                                </div>
                            </div>

                            <div className="grid grid-cols-2 gap-2 text-xs text-gray-600">
                                <div className="flex items-center gap-1.5 truncate">
                                   <MdPerson className="text-gray-400" />
                                    <span>{job.HIRING_DEPT}</span>
                                </div>
                                <div className="flex items-center gap-1.5 truncate">
                                    <MdLocationOn className="text-gray-400" />
                                    <span>{job.OTH_JOB_LOCATIONS}</span>
                                </div>
                            </div>
                            
                            <div className="flex justify-between text-[10px] mt-3 pt-2 border-t border-gray-100">
                                <span className="text-gray-500">Ref: {job.INT_REF_DATA || 'N/A'}</span>
                                <span className="text-gray-500">ID: {job.JOB_ID}</span>
                            </div>
                        </div>
                    );
                }) : (
                    <div className="text-center text-gray-500 p-8 border border-dashed border-gray-300 rounded-lg">
                        <p>No job postings found for IRF: {intRefData}</p>
                    </div>
                )}
            </div>

            {/* Job Details Modal */}
            {selectedJob && (
                <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
                    <div className="bg-white rounded-lg shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
                        {/* Modal Header */}
                        <div className="sticky top-0 bg-red-600 text-white p-4 flex justify-between items-center">
                            {/* <h2 className="text-xl font-bold">{selectedJob.JOB_ROLE} - Details</h2> */}
                            <h2 className="text-xl font-bold">JobPost Details</h2>
                            <button
                                onClick={closeModal}
                                className="hover:bg-red-700 p-2 rounded-lg transition-colors"
                            >
                                <MdClose className="w-6 h-6" />
                            </button>
                        </div>

                        {/* Modal Body */}
                        <div className="p-6 space-y-6">
                            {/* Job Basic Info */}
                            <div>
                                <h3 className="text-lg font-semibold text-gray-900 mb-3 pb-2 border-b border-gray-200">Job Information</h3>
                                <div className="grid grid-cols-2 gap-4">
                                    <div>
                                        <p className="text-xs text-gray-500 font-semibold uppercase">Job ID</p>
                                        <p className="text-sm text-gray-900 font-medium">{selectedJob.JOB_ID}</p>
                                    </div>
                                    <div>
                                        <p className="text-xs text-gray-500 font-semibold uppercase">Status</p>
                                        <p className="text-sm text-gray-900 font-medium">{selectedJob.JOB_STATUS}</p>
                                    </div>
                                    <div>
                                        <p className="text-xs text-gray-500 font-semibold uppercase">Job Type</p>
                                        <p className="text-sm text-gray-900 font-medium">{selectedJob.JOB_TYPE}</p>
                                    </div>
                                    <div>
                                        <p className="text-xs text-gray-500 font-semibold uppercase">Priority</p>
                                        <p className="text-sm text-gray-900 font-medium">{selectedJob.JOB_PRIORITY || 'N/A'}</p>
                                    </div>
                                </div>
                            </div>

                            {/* Location & Department */}
                            <div>
                                <h3 className="text-lg font-semibold text-gray-900 mb-3 pb-2 border-b border-gray-200">Location & Department</h3>
                                <div className="grid grid-cols-2 gap-4">
                                    <div>
                                        <p className="text-xs text-gray-500 font-semibold uppercase">Location</p>
                                        <p className="text-sm text-gray-900 font-medium">{selectedJob.OTH_JOB_LOCATIONS || 'N/A'}</p>
                                    </div>
                                    <div>
                                        <p className="text-xs text-gray-500 font-semibold uppercase">Hiring Department</p>
                                        <p className="text-sm text-gray-900 font-medium">{selectedJob.HIRING_DEPT || 'N/A'}</p>
                                    </div>
                                    <div>
                                        <p className="text-xs text-gray-500 font-semibold uppercase">Hiring Manager</p>
                                        <p className="text-sm text-gray-900 font-medium">{selectedJob.HIRING_MGR || 'N/A'}</p>
                                    </div>
                                </div>
                            </div>

                            {/* Experience & Salary */}
                            <div>
                                <h3 className="text-lg font-semibold text-gray-900 mb-3 pb-2 border-b border-gray-200">Experience & Salary</h3>
                                <div className="grid grid-cols-2 gap-4">
                                    <div>
                                        <p className="text-xs text-gray-500 font-semibold uppercase">Experience Range</p>
                                        <p className="text-sm text-gray-900 font-medium">{selectedJob.EXP_MIN}-{selectedJob.EXP_MAX} years</p>
                                    </div>
                                    <div>
                                        <p className="text-xs text-gray-500 font-semibold uppercase">Salary Range</p>
                                        <p className="text-sm text-gray-900 font-medium">₹{selectedJob.SALARY_MIN}L - ₹{selectedJob.SALARY_MAX}L</p>
                                    </div>
                                </div>
                            </div>

                            {/* Project Details */}
                            <div>
                                <h3 className="text-lg font-semibold text-gray-900 mb-3 pb-2 border-b border-gray-200">Project Details</h3>
                                <div className="grid grid-cols-2 gap-4">
                                    <div>
                                        <p className="text-xs text-gray-500 font-semibold uppercase">Project Name</p>
                                        <p className="text-sm text-gray-900 font-medium">{selectedJob.PROJ_NAME || 'N/A'}</p>
                                    </div>
                                    <div>
                                        <p className="text-xs text-gray-500 font-semibold uppercase">Project Code</p>
                                        <p className="text-sm text-gray-900 font-medium">{selectedJob.PROJ_CODE || 'N/A'}</p>
                                    </div>
                                    <div>
                                        <p className="text-xs text-gray-500 font-semibold uppercase">Customer Name</p>
                                        <p className="text-sm text-gray-900 font-medium">{selectedJob.CUST_NAME || 'N/A'}</p>
                                    </div>
                                    <div>
                                        <p className="text-xs text-gray-500 font-semibold uppercase">Internal Ref Data</p>
                                        <p className="text-sm text-gray-900 font-medium">{selectedJob.INT_REF_DATA || 'N/A'}</p>
                                    </div>
                                </div>
                            </div>

                            {/* Recruitment Stats */}
                            <div>
                                <h3 className="text-lg font-semibold text-gray-900 mb-3 pb-2 border-b border-gray-200">Recruitment Stats</h3>
                                <div className="grid grid-cols-2 gap-4">
                                    <div className="bg-blue-50 p-3 rounded-lg">
                                        <p className="text-xs text-gray-500 font-semibold uppercase">Total Count</p>
                                        <p className="text-lg font-bold text-blue-600">{selectedJob.TOTAL_COUNT || 0}</p>
                                    </div>
                                    <div className="bg-green-50 p-3 rounded-lg">
                                        <p className="text-xs text-gray-500 font-semibold uppercase">Fulfilled</p>
                                        <p className="text-lg font-bold text-green-600">{selectedJob.FULFILLED_COUNT || 0}</p>
                                    </div>
                                    <div className="bg-yellow-50 p-3 rounded-lg">
                                        <p className="text-xs text-gray-500 font-semibold uppercase">Selected</p>
                                        <p className="text-lg font-bold text-yellow-600">{selectedJob.SELECTED_COUNT || 0}</p>
                                    </div>
                                    <div className="bg-purple-50 p-3 rounded-lg">
                                        <p className="text-xs text-gray-500 font-semibold uppercase">Offered</p>
                                        <p className="text-lg font-bold text-purple-600">{selectedJob.OFFERED_COUNT || 0}</p>
                                    </div>
                                    <div className="bg-indigo-50 p-3 rounded-lg">
                                        <p className="text-xs text-gray-500 font-semibold uppercase">Joined</p>
                                        <p className="text-lg font-bold text-indigo-600">{selectedJob.JOINED_COUNT || 0}</p>
                                    </div>
                                    <div className="bg-red-50 p-3 rounded-lg">
                                        <p className="text-xs text-gray-500 font-semibold uppercase">Rejected</p>
                                        <p className="text-lg font-bold text-red-600">{selectedJob.REJECTED_COUNT || 0}</p>
                                    </div>
                                </div>
                            </div>

                            {/* Application Stats */}
                            <div>
                                <h3 className="text-lg font-semibold text-gray-900 mb-3 pb-2 border-b border-gray-200">Application Stats</h3>
                                <div className="grid grid-cols-2 gap-4">
                                    <div>
                                        <p className="text-xs text-gray-500 font-semibold uppercase">Total Applications</p>
                                        <p className="text-sm text-gray-900 font-medium">{selectedJob.APP_TOTAL_COUNT || 0}</p>
                                    </div>
                                    <div>
                                        <p className="text-xs text-gray-500 font-semibold uppercase">Pending</p>
                                        <p className="text-sm text-gray-900 font-medium">{selectedJob.APP_PENDING_COUNT || 0}</p>
                                    </div>
                                    <div>
                                        <p className="text-xs text-gray-500 font-semibold uppercase">In Progress</p>
                                        <p className="text-sm text-gray-900 font-medium">{selectedJob.APP_INPROGRESS_COUNT || 0}</p>
                                    </div>
                                    <div>
                                        <p className="text-xs text-gray-500 font-semibold uppercase">Processed</p>
                                        <p className="text-sm text-gray-900 font-medium">{selectedJob.APP_PROCESSED_COUNT || 0}</p>
                                    </div>
                                    <div>
                                        <p className="text-xs text-gray-500 font-semibold uppercase">Selection Ratio</p>
                                        <p className="text-sm text-gray-900 font-medium">{(selectedJob.APP_SELECTION_RATIO * 100).toFixed(1)}%</p>
                                    </div>
                                    <div>
                                        <p className="text-xs text-gray-500 font-semibold uppercase">Rejection Ratio</p>
                                        <p className="text-sm text-gray-900 font-medium">{(selectedJob.APP_REJECTION_RATIO * 100).toFixed(1)}%</p>
                                    </div>
                                </div>
                            </div>

                            {/* Other Details */}
                            <div>
                                <h3 className="text-lg font-semibold text-gray-900 mb-3 pb-2 border-b border-gray-200">Other Details</h3>
                                <div className="grid grid-cols-2 gap-4">
                                    <div>
                                        <p className="text-xs text-gray-500 font-semibold uppercase">Post Date</p>
                                        <p className="text-sm text-gray-900 font-medium">{new Date(selectedJob.JOB_POST_DATE).toLocaleDateString()}</p>
                                    </div>
                                    <div>
                                        <p className="text-xs text-gray-500 font-semibold uppercase">Post By</p>
                                        <p className="text-sm text-gray-900 font-medium">{selectedJob.JOB_POST_USERID || 'N/A'}</p>
                                    </div>
                                    <div>
                                        <p className="text-xs text-gray-500 font-semibold uppercase">Owner</p>
                                        <p className="text-sm text-gray-900 font-medium">{selectedJob.OWNER_USERID || 'N/A'}</p>
                                    </div>
                                    <div>
                                        <p className="text-xs text-gray-500 font-semibold uppercase">Owner Org</p>
                                        <p className="text-sm text-gray-900 font-medium">{selectedJob.OWNER_USERORG || 'N/A'}</p>
                                    </div>
                                    <div>
                                        <p className="text-xs text-gray-500 font-semibold uppercase">Lead Time</p>
                                        <p className="text-sm text-gray-900 font-medium">{selectedJob.LEAD_TIME || 'N/A'} days</p>
                                    </div>
                                    <div>
                                        <p className="text-xs text-gray-500 font-semibold uppercase">Publish Type</p>
                                        <p className="text-sm text-gray-900 font-medium">{selectedJob.PUBLISH_TYPE || 'N/A'}</p>
                                    </div>
                                </div>
                            </div>

                            {/* Job Description */}
                            {selectedJob.JOB_DESC && (
                                <div>
                                    <h3 className="text-lg font-semibold text-gray-900 mb-3 pb-2 border-b border-gray-200">Job Description</h3>
                                    <p className="text-sm text-gray-700 whitespace-pre-wrap">{selectedJob.JOB_DESC}</p>
                                </div>
                            )}

                            {/* Job Document */}
                            {selectedJob.JOB_DOC && selectedJob.JOB_DOC.length > 0 && (
                                <div>
                                    <h3 className="text-lg font-semibold text-gray-900 mb-3 pb-2 border-b border-gray-200">Job Document</h3>
                                    <a
                                        href={selectedJob.JOB_DOC[0]}
                                        className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                                    >
                                        <FaEye className="w-4 h-4" />
                                        {selectedJob.JOB_DOC[1] || 'Download Document'}
                                    </a>
                                </div>
                            )}
                        </div>

                        {/* Modal Footer */}
                        <div className="sticky bottom-0 bg-gray-50 p-4 border-t border-gray-200 flex justify-end">
                            <button
                                onClick={closeModal}
                                className="px-6 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors font-medium"
                            >
                                Close
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default JobOpenings;