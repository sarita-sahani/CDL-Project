import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import AdvanceSearchModal from './AdvanceSearchModal';

const OnboardedCandidates = () => {

  const [mergedData, setMergedData] = useState([]);
  const navigate = useNavigate();
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [selectedCandidate, setSelectedCandidate] = useState(null);
  const [openMenuIdx, setOpenMenuIdx] = useState(null);
  const [initiatedIds, setInitiatedIds] = useState([]);
  const [abottedIds, setAbottedIds] = useState([]);
  const [showPopup, setShowPopup] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [advSearchCriteria, setAdvSearchCriteria] = useState({});
  // === NEW STATE: To track the active tab ('New' or 'Initiated') ===
  const [activeTab, setActiveTab] = useState('New');

  // Fetch backend status for each candidate in mergedData
  useEffect(() => {
    const fetchInitiatedStatuses = async () => {
      try {
        const statuses = await Promise.all(
          mergedData.map(async (candidate) => {
            const candId = candidate.candId || candidate.eonGeneralReqDTO?.CandID;
            if (!candId) return { candId, initiated: false };

            try {
              const response = await fetch(`http://localhost:9034/onboarding/get/eonOverallStatus/data/${candId}`);
              if (!response.ok) return { candId, initiated: false };

              const text = await response.text();
              if (!text) return { candId, initiated: false };

              let data;
              try {
                data = JSON.parse(text);
              } catch (err) {
                console.warn(`Invalid JSON for ${candId}:`, text);
                return { candId, initiated: false };
              }

              return {
                candId,
                initiated: typeof data?.overallStatus === 'string' &&
                  data.overallStatus.toLowerCase() === 'initiated'
              };
            } catch (err) {
              console.error(`Error fetching status for ${candId}:`, err);
              return { candId, initiated: false };
            }
          })
        );

        const initiated = statuses
          .filter((status) => status.initiated)
          .map((status) => status.candId);

        setInitiatedIds(initiated);
      } catch (error) {
        console.error('Error fetching onboarding statuses:', error);
      }
    };

    if (mergedData.length > 0) fetchInitiatedStatuses();
  }, [mergedData]);


  // Onboarding submit handler
  const initiateOnboardingSubmit = async (candidate, idx) => {
    const candId = candidate.candId || candidate.eonGeneralReqDTO?.CandID;
    console.log('Initiating onboarding for candidate:', candId);

    try {
      // Step 1: Fetch full candidates list
      const allRes = await fetch(`http://localhost:9034/onboarding/fetchAllHRCompletedCandidatesDetails`);
      if (!allRes.ok) throw new Error('Failed to fetch full onboarding candidates');
      const fullData = await allRes.json();

      // Step 2: Find current candidate from full data by CandID
      const fullCandidate = (fullData || []).find(item =>
        (item.candId || item.eonGeneralReqDTO?.CandID) === candId
      );

      if (!fullCandidate) {
        alert(`❌ Candidate data not found for ID: ${candId}`);
        return;
      }

      // Step 3: Save the full candidate data
      const res = await fetch('http://localhost:9034/onboarding/saveOnBoardingCandidatesDetails', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(fullCandidate),
      });

      if (res.ok) {
        const updatedIds = [...initiatedIds, candId];
        setInitiatedIds(updatedIds);
        // localStorage.setItem('initiatedCandidates', JSON.stringify(updatedIds)); // Removed localStorage update to keep it focused on state
        alert(`✅ Onboarding initiated for ${candId}`);
        // Optionally switch to the 'Initiated' tab after successful initiation
        // setActiveTab('Initiated');
      } else {
        alert('❌ Failed to initiate onboarding');
      }
    } catch (err) {
      console.error('Error during onboarding:', err);
      alert('❌ Error initiating onboarding');
    }
  };

  const handleAbortEmployee = async (candidate) => {
    const candidateId = candidate.candId || candidate.eonGeneralReqDTO?.CandID || '';
    const jobId = parseInt(candidate.eonGeneralReqDTO?.JOB_ID) || 0;
    const applicationId = parseInt(candidate.eonGeneralReqDTO?.JOB_APP_ID) || 0;
    const status = 'HR-Abort';
    const url = `http://localhost:9034/onboarding/update-overall-status?candId=${candidateId}&jobId=${jobId}&applicationId=${applicationId}&status=${status}`;

    try {
      const res = await fetch(url, { method: 'PUT' });

      if (!res.ok) {
        const errorText = await res.text();
        console.error('Abott failed:', errorText);
        alert('Failed to abott employee: ' + errorText);
        return;
      }

      const data = await res.text(); // since Mono<String>, not JSON
      console.log('Abott success:', data);

      setAbottedIds((prev) => [...prev, candidateId]);
      alert(data || 'Employee abotted and status updated.');
      window.location.reload();
    } catch (err) {
      console.error('Network error:', err);
      alert('Error aborting employee: ' + err.message);
    }
  };



  // Function to fetch all candidate data and move to employee
  const handleMoveToEmployee = async (candidate) => {
    const cid = candidate.candId || candidate.eonGeneralReqDTO?.CandID;
    if (!cid) {
      alert('Candidate ID not found');
      return;
    }
    try {
      const endpoints = {
        personal: `eonPersonal`,
        family: `eonFamily`,
        bank: `eonBank`,
        candidateDeclaration: `eonCandidateDeclaration`,
        declQuestionnaire: `eonDeclQuestionnaire`,
        documentProof: `eonDocumentProof`,
        education: `eonEducation`,
        general: `eonGeneral`,
        hrDeclaration: `eonHRDeclaration`,
        interest: `eonInterest`,
        language: `eonLanguage`,
        overallStatus: `eonOverallStatus`,
        pf: `eonPF`,
        profReference: `eonProfessionalReference`,
        profExp: `eonProfressionalExperience`,
        skill: `eonSkill`
      };
      //http://localhost:9034/onboarding/get/general/data/cid7
      const results = await Promise.all(
        Object.entries(endpoints).map(async ([key, endpoint]) => {
          const res = await fetch(`http://localhost:9034/onboarding/get/${endpoint}/data/${cid}`);
          if (!res.ok) {
            return { [key]: {} };
          }
          try {
            const data = await res.json();
            return { [key]: data };
          } catch {
            return { [key]: {} };
          }
        })
      );
      const merged = results.reduce((acc, item) => ({ ...acc, ...item }), {});
      navigate('/addEmployee', { state: { candidate: merged } });
    } catch (err) {
      alert('Failed to fetch all candidate data');
    }
  };

  const fetchAllGenealCandidates = async (params = {}) => {
    try {
      // Use Axios params for clean URL query strings
      const response = await axios.get("http://localhost:9034/onboarding/fetchAllHRCompletedGeneralCandidatesDetails", { params });

      const data = response.data;
      setMergedData(Array.isArray(data) ? data : []);
      console.log("Merged Data:", data);
    } catch (error) {
      console.error("Failed to load candidates", error);
    }
  };

  useEffect(() => {
    fetchAllGenealCandidates();
  }, []);


  const handleProbationEvaluation = (candidate) => {
    navigate('/probation-status-card', { state: { candidate } });
  };

  // New function to handle the search from the modal
  const handleAdvancedSearch = (criteria) => {
    setAdvSearchCriteria(criteria);
    // Option 2: Fetch new data from the backend (RECOMMENDED)
    // You would need a new backend endpoint that accepts these parameters.
    // For now, this is just a conceptual function call.
    // fetchAllGenealCandidates(criteria);
  };

  const filteredCandidates = mergedData.filter((candidate) => {
    const candidateId = candidate.candId || candidate.eonGeneralReqDTO?.CandID; // Get candidate ID
    const isInitiated = initiatedIds.includes(candidateId); // Check initiated status

    // === NEW FILTER LOGIC: Filter by activeTab ('New' or 'Initiated') ===
    if (activeTab === 'New' && isInitiated) return false; // Hide initiated candidates from 'New' tab
    if (activeTab === 'Initiated' && !isInitiated) return false; // Hide non-initiated candidates from 'Initiated' tab
    // Skip abotted candidates regardless of tab, as they have their own tab
    if (abottedIds.includes(candidateId)) return false; 
    // =================================================================

    const name = candidate.eonGeneralReqDTO?.CandName?.toLowerCase() || '';
    const email = candidate.eonGeneralReqDTO?.email_id?.toLowerCase() || '';
    const position = candidate.eonGeneralReqDTO?.PosApplied?.toLowerCase() || '';
    const id = candidate.candId?.toLowerCase() || '';
    const overallStatus = candidate.eonOverallStatusReqDTO?.OverallStatus?.toLowerCase() || '';

    const query = searchQuery.toLowerCase();

    // Simple search filter logic
    const simpleSearchMatch =
      name.includes(query) ||
      email.includes(query) ||
      position.includes(query) ||
      id.includes(query);

    // Advanced search filter logic
    const advSearchMatch =
      (!advSearchCriteria.candidateName || name.includes(advSearchCriteria.candidateName.toLowerCase())) &&
      (!advSearchCriteria.status || overallStatus.includes(advSearchCriteria.status.toLowerCase()));
    // Add more checks for other advanced search fields here

    return simpleSearchMatch && advSearchMatch;
  });
  
  return (
    <div className="w-full">
      <h2 className="text-xl font-semibold mb-4">To be Onboarded Candidates</h2>

      {/* Search & Filter */}
      <div className="flex flex-wrap gap-4 mb-6">

        <input
          type="text"
          placeholder="Search Employees"
          className="border px-4 py-2 rounded-md w-64"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />

        <button
          onClick={() => setShowPopup(true)}
          className="border px-4 py-2 rounded-md text-gray-600 hover:bg-gray-100"
        >
          🛠 AdvanceFilter
        </button>
        <AdvanceSearchModal
          isOpen={showPopup}
          onClose={() => setShowPopup(false)}
          onSearch={handleAdvancedSearch} // Pass the new search handler
        />
      </div>
      
      {/* Tabs - MODIFIED */}
      <div className="flex gap-4 mb-6">
        {/* 'New' Tab (Default) */}
        <button
          onClick={() => setActiveTab('New')}
          className={
            activeTab === 'New'
              ? 'bg-green-400 text-white px-6 py-2 rounded-full font-semibold'
              : 'border px-6 py-2 rounded-full font-semibold text-gray-600 hover:bg-gray-100'
          }
        >
          New
        </button>
        {/* 'Initiated' Tab - NEW */}
        <button
          onClick={() => setActiveTab('Initiated')}
          className={
            activeTab === 'Initiated'
              ? 'bg-blue-400 text-white px-6 py-2 rounded-full font-semibold' // Changed color for distinction
              : 'border px-6 py-2 rounded-full font-semibold text-gray-600 hover:bg-gray-100'
          }
        >
          Initiated
        </button>
        {/* 'Abotted Candidates' Tab (Unchanged) */}
        <button className="border px-6 py-2 rounded-full font-semibold text-gray-600 hover:bg-gray-100">
          Aborted Candidates
        </button>
      </div>

      {/* Cards */}
      {filteredCandidates.map((candidate, idx) => {
        // debugger
        const candidateId = candidate.candId || candidate.eonGeneralReqDTO?.CandID;
        const isInitiated = initiatedIds.includes(candidateId);
        return (
          <div
            key={candidateId || idx}
            className="bg-[#f9f9fb] shadow-md rounded-2xl mb-8 px-6 py-4"
          >
            {/* Top Section */}
            <div className="flex items-center justify-between">
              <div className="flex gap-4">
                <img
                  src={`https://i.pravatar.cc/60?img=${idx + 10}`}
                  alt="avatar"
                  className="w-14 h-14 rounded-full"
                />
                <div>
                  <p className="text-base font-semibold">
                    {candidate.eonGeneralReqDTO?.CandName || 'N/A'}</p>
                  <p className="text-sm text-gray-500">{candidate.eonGeneralReqDTO?.PosApplied || 'N/A'}</p>
                  <div className="flex items-center gap-2 text-sm text-blue-600">
                    <a href={`mailto:${candidate.eonGeneralReqDTO?.email_id}`} className="underline">
                      {candidate.eonGeneralReqDTO?.email_id || 'N/A'}
                    </a> | {candidate.eonGeneralReqDTO?.CurContactNum || 'N/A'}
                  </div>
                </div>
              </div>
              <div className="relative">
                <p className="text-sm text-gray-500">HR Declaration</p><br />
                <span className="text-green-600 bg-green-100 px-3 py-1 rounded-full text-sm font-medium">
                  ✔ {candidate.eonOverallStatusReqDTO?.OverallStatus || 'Pending'}
                </span>
              </div>
              {/* Three-dot Menu */}
              <div className="relative">
                <button
                  onClick={() => setOpenMenuIdx(openMenuIdx === idx ? null : idx)}
                  className="p-2 rounded-full hover:bg-gray-100 text-xl"
                  title="Actions"
                >
                  &#8942;
                </button>

                {openMenuIdx === idx && (
                  <div className="absolute right-0 mt-2 w-52 bg-white border border-gray-200 rounded-lg shadow-lg z-10">
                    <div className="px-4 py-2 text-xs text-gray-500 border-b font-semibold cursor-default">Actions</div>
                    {/* If abotted, show only Abott button */}
                    {abottedIds.includes(candidateId) ? (
                      <button
                        className="w-full px-4 py-2 text-left text-sm bg-red-100 text-red-600 rounded hover:bg-red-200 transition-colors"
                        onClick={() => {
                          // Remove from abottedIds to allow menu again if needed
                          setAbottedIds(abottedIds.filter(id => id !== candidateId));
                        }}
                      >
                        Abotted
                      </button>
                    ) : (
                      <>
                        {/* Initiate Onboarding button: now only visible in 'New' tab/not initiated state */}
                        {!isInitiated && (
                            <button
                              className={`w-full px-4 py-2 text-left text-sm transition-colors rounded
                                hover:bg-blue-100 hover:text-blue-600 bg-white text-black border cursor-pointer
                            `}
                              onClick={() => {
                                initiateOnboardingSubmit(candidate, idx);
                                setOpenMenuIdx(null); // Close menu after action
                              }}
                            >
                              🚀 Initiate Employee
                            </button>
                        )}


                        {/* Move to Employee: enabled only after initiated */}
                        <button
                          className={`w-full px-4 py-2 text-left text-sm transition-colors rounded
                  ${isInitiated
                              ? 'hover:bg-blue-100 hover:text-blue-600 bg-white text-black border cursor-pointer'
                              : 'bg-gray-200 text-gray-500 cursor-not-allowed'}
                `}
                          disabled={!isInitiated}
                          style={!isInitiated ? { pointerEvents: 'none', opacity: 1 } : {}}
                          onClick={() => {
                            isInitiated && handleMoveToEmployee(candidate);
                            setOpenMenuIdx(null); // Close menu after action
                          }}
                        >
                          Move to OnboardEmployee
                        </button>

                        {/* Abott Employee: only visible before initiated and not abotted */}
                        {!isInitiated && (
                          <button
                            className="w-full px-4 py-2 text-left text-sm hover:bg-red-100 hover:text-red-600 transition-colors"
                            onClick={() => {
                              handleAbortEmployee(candidate);
                              setOpenMenuIdx(null); // Close menu after action
                            }}
                          >
                            Abott Employee
                          </button>
                        )}
                      </>
                    )}
                  </div>
                )}

              </div>

            </div>

            {/* Divider */}
            <div className="border-b border-gray-200 my-4" />

            {/* Bottom Grid */}
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-y-3 text-sm text-gray-700">
              <div><strong>Candidate ID</strong><br />{candidate.candId || 'N/A'}</div>
              <div><strong>Job ID</strong><br />{candidate.eonGeneralReqDTO?.JOB_ID || 'N/A'}</div>
              <div><strong>Offer Date</strong><br />{candidate.eonGeneralReqDTO?.DateOfJoin
                ? new Date(candidate.eonGeneralReqDTO.DateOfJoin).toDateString() : 'N/A'}</div>
              <div><strong>Expected joining Date</strong><br />{candidate.eonGeneralReqDTO?.DateOfJoin
                ? new Date(candidate.eonGeneralReqDTO.DateOfJoin).toDateString() : 'N/A'}</div>
              <div><strong>HR (TA)</strong><br />{candidate.eonGeneralReqDTO?.INIT_USERID || 'N/A'}</div>
              <div><strong>HR Manager</strong><br />{candidate.eonGeneralReqDTO?.INIT_USERID || 'N/A'}</div>
              <div><strong>Current Status</strong><br />{candidate.eonOverallStatusReqDTO?.OverallStatus}</div>
            </div>

            {/* Divider after Current Status */}
            <div className="border-b border-gray-200 my-4" />

            {/* Extra Info Row */}
            <div className="grid grid-cols-3 md:grid-cols-6 gap-y-3 text-sm text-gray-700">
              <div><strong>Total Year of Experience</strong><br />
                <span className="text-blue-600 font-bold">{candidate.eonGeneralReqDTO?.TotalExp || 0}</span>
              </div>
              <div><strong>HR Declaration Date</strong><br />{candidate.eonhrDeclReqDTO?.VerifiedDate
                ? new Date(candidate.eonhrDeclReqDTO.VerifiedDate).toDateString() : 'N/A'}</div>
              <div><strong>Due in Days</strong><br />
                <span className="text-red-500 font-bold">{candidate.eonOverallStatusReqDTO?.dueInDays || 'N/A'}</span>
              </div>
            </div>

            {/* Footer */}
            <div className="mt-4 text-right">
              {/* <button type="button"
                className="text-red-600 font-semibold hover:underline"
                onClick={() => handleProbationEvaluation(candidate)}
              >
                View Candidate Details →
              </button> */}
            </div>
          </div>
        )
      })}
      {showConfirmModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-lg shadow-lg w-full max-w-md relative">
            <button
              className="absolute top-2 right-2 text-red-500 text-lg"
              onClick={() => setShowConfirmModal(false)}
            >
              ✕
            </button>
            <h3 className="text-lg font-semibold mb-4 text-center">Moving to Employee Directory</h3>
            <p className="text-sm text-center mb-6">
              Do you want to move the selected Candidate to Employee Directory?<br />
              <span className="text-gray-500">The Candidate will be saved as an Employee</span>
            </p>
            <div className="flex justify-center gap-4">
              <button
                onClick={() => setShowConfirmModal(false)}
                className="px-4 py-2 bg-gray-200 rounded-md hover:bg-gray-300"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  navigate('/addEmployee', { state: { candidate: selectedCandidate } });
                  setShowConfirmModal(false);
                }}
                className="px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600"
              >
                Move
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};

export default OnboardedCandidates;