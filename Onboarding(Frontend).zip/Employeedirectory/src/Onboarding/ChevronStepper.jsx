import React from "react";

const ChevronStepper = ({ stages }) => {
  return (
    <div className="flex overflow-x-auto mt-4">
      {stages.map((stage, index) => {
        const clipPath =
          index === 0
            ? "polygon(0% 0%, 92% 0%, 100% 50%, 92% 100%, 0% 100%, 0% 50%)" // flat start
            : "polygon(0% 0%, 92% 0%, 100% 50%, 92% 100%, 0% 100%, 8% 50%)"; // arrow

        return (
          <div
            key={index}
            className={`relative px-10 py-3 text-white text-sm font-semibold flex items-center ${stage.color} min-w-[120px]`}
            style={{
              clipPath: clipPath,
              marginRight: index !== stages.length - 1 ? "-8px" : "0px",
              zIndex: index + 1,
            }}
          >
            <span className="whitespace-nowrap">
              {stage.count} {stage.label}
            </span>
          </div>
        );
      })}
    </div>
  );
};

export default ChevronStepper;
