
import React from "react";
import { X } from "lucide-react";

const Field = ({ label, value }) => (
  <div className="flex text-sm">
    <div className="min-w-[200px] flex text-slate-500 font-semibold">{label}</div>
    <div className="font-semibold text-black">{value || "-"}</div>
  </div>
);

const ViewRequisitionModal = ({ requisition, onClose }) => {
  if (!requisition) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black bg-opacity-40 flex justify-center items-start pt-10">
      <div className="bg-white w-[90%] max-w-6xl rounded-xl p-6 relative shadow-xl border border-gray-300 max-h-[90vh] overflow-y-auto">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-red-500 border border-red-500 rounded-full p-1 hover:bg-red-100"
          title="Close"
        >
          <X size={20} />
        </button>

        {/* Request No */}
        <div className="mb-1">
          <h2 className="text-xl font-semibold text-gray-800">
            Request No:{" "}
            <span className="text-green-600">
              ERF{requisition.requisitionNumber?.toString().padStart(4, "0")}
            </span>
          </h2>
        </div>

        {/* Approval & Overall Status */}
        <div className="flex justify-between items-center mb-4">
          <div className="w-1/3" />
          <div className="w-1/3 text-center text-base font-medium text-gray-700">
            Approval Status:{" "}
            <span className="text-red-500 ">{requisition.approvalStatus}</span>
          </div>
          <div className="w-1/3 text-right text-base font-medium text-gray-700 mr-[5rem]">
            Overall Status:{" "}
            <span className="text-blue-600">{requisition.overallStatus}</span>
          </div>
        </div>
        
        <div className="border border-gray-300 rounded px-6 py-4 mb-6">

              <div className="flex justify-between items-center mb-4">
                <div className="text-slate-500 font-semibold flex">
                  <div className="min-w-[200px]">Requisition Type</div>
                  <div className="font-semibold text-black">
                    {requisition.requisitionType || "-"}
                  </div>
                </div>
                <select className="border text-sm border-gray-300 rounded px-2 py-1 text-blue-500 bg-white">
                  <option>Action</option>
                  <option>Edit</option>
                  <option>Withdraw</option>
                </select>
              </div>

              <div className="w-[50%] h-px bg-gray-200 mt-1 mb-4" />

              <div className="flex text-slate-500 font-semibold mb-2">
                <div className="min-w-[200px]">Date</div>
                <div className="font-semibold text-black">{requisition.appliedOn || "-"}</div>
              </div>

              <div className="w-[50%] h-px bg-gray-200 mt-2 mb-4" />

              <div className="flex text-slate-500 font-semibold mb-2">
                <div className="min-w-[200px]">Employment Type</div>
                <div className="font-semibold text-black">{requisition.employmentType || "-"}</div>
              </div>

              <div className="w-[50%] h-px bg-gray-200 mt-2 mb-4" />

              <div className="flex text-slate-500 font-semibold mb-2">
                <div className="min-w-[200px]">Billing Type</div>
                <div className="font-semibold text-black">{requisition.billingType || "-"}</div>
              </div>
              
              {/* Grid Columns for Details */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-6 pb-6 text-semibold">

                  {/* Replacement */}
                  <div>
                    <h3 className="text-md font-semibold text-gray-700 mb-4">Replacement</h3>
                    <div className="space-y-4">
                      <Field label="Name of Replacement" value={requisition.replacementType} />
                      <Field label="Employee Code" value={requisition.employeeCode} />
                      <Field label="Project" value={requisition.replacementProject} />
                      <Field label="Department" value={requisition.replacementDepartment} />
                      <Field label="Location" value={requisition.replacementLocation} />
                      <Field label="CTC" value={requisition.ctc} />
                    </div>
                  </div>

                  {/* Position Details */}
                  <div>
                    <h3 className="text-md font-semibold text-gray-700 mb-4">Position Details</h3>
                    <div className="space-y-4">
                      <Field label="Department" value={requisition.department} />
                      <Field label="Position" value={requisition.position} />
                      <Field label="No of Positions" value={requisition.noOfPositions} />
                      <Field label="Experience Range" value={`${requisition.minimumExperienceRange} to ${requisition.maximumExperienceRange}`} />
                      <Field label="Education" value={requisition.education} />
                      <Field label="Certification(s)" value={requisition.certifications} />
                      <Field label="Location" value={requisition.location} />
                      <Field label="Reporting To" value={requisition.reportingTo} />
                      <Field label="Budget" value={requisition.budget} />
                    </div>
                  </div>

                  {/* Timeline Section */}
                  <div className="border-l-[1px] border-gray-300 pl-6 mt-6">
                    <h3 className="text-md font-semibold text-gray-700 mb-4 -mt-6">Timeline</h3>

                    {/* Pending + Withdraw */}
                    <div className="flex items-center justify-between w-80">
                      <div className="space-y-1">
                        <div className="text-sm text-red-500 font-semibold">Pending</div>
                        <div className="text-[13px] text-gray-700">
                          With <span className="font-bold">Manager</span>
                        </div>
                      </div>
                      <button className="bg-[#f26c6c] text-white text-xs px-4 py-[6px] rounded">Withdraw</button>
                    </div>

                    {/* Comment Box */}
                    <div className="mt-4 mb-4">
                      <input type="text" placeholder="Add a comment....." className="w-80 border border-gray-300 text-sm px-3 py-2 outline-none" />
                    </div>

                    {/* Comment Entry */}
                    <div className="text-[13px] text-black mb-3">
                      <p className="font-semibold">Harish Kumar <span className="font-normal">added a Comment</span></p>
                      <p className="text-gray-500 text-sm mt-1">If document is required let me know</p>
                      <p className="text-gray-500 text-sm mt-[2px]">03 June, 2024 <span className="ml-6">11:30 AM</span></p>
                    </div>

                    {/* Submission Entry */}
                    <div className="text-[13px] text-black">
                      <p className="font-semibold">Harish Kumar Submitted</p>
                      <p className="text-gray-500 text-sm mt-[2px]">02 June, 2024 <span className="ml-6">05:30 PM</span></p>
                    </div>
                  </div>
                </div>

                {/* IT & Initiator Section */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-6 pb-6 text-semibold">

                  {/* IT Asset Requirements */}
                  <div>
                    <h3 className="text-md font-semibold text-gray-700 mb-4">IT Asset Requirements</h3>
                    <div className="space-y-4">
                      <Field label="IT Asset" value={requisition.itAsset} />
                      <Field label="Configurations" value={requisition.configuartions} />
                      <Field label="Additional Informations" value={requisition.additionalInformations} />
                      <Field label="Initiated by (Hiring manager)" value={requisition.initiatorName} />
                      <Field label="First Level Approver" value={requisition.firstLevelApprover} />
                      <Field label="Second Level Approver" value={requisition.secondLevelApprover} />
                    </div>
                  </div>

                  {/* Initiator Details */}
                  <div>
                    <h3 className="text-md font-semibold text-gray-700 mb-4">Initiator Details</h3>
                    <div className="space-y-4">
                      <Field label="Name" value={requisition.initiatorName} />
                      <Field label="Employee Code" value={requisition.initiatorEmployeeCode} />
                      <Field label="BU Head" value={requisition.buHead} />
                      <Field label="Location" value={requisition.initiatorLocation} />
                    </div>
                  </div>


                  

                  {/* Column 3: Open Dropdown only */}
                  <div className="flex items-center justify-center">
                    {/* <select className="border border-gray-300 rounded px-4 py-2 text-green-600 text-sm"> */}
                    <select
                      className="w-48 border border-gray-400 rounded-md px-4 py-2 text-left text-[#0ddd1a] text-sm focus:outline-none">
                      <option>Open</option>
                    </select>
                    </div>
                </div>
                
                
              {/* Selected JD */}
                <div className="mb-6">
                  <h3 className="text-md font-semibold mb-2 ">Selected JD</h3>
                  <div className="flex text-slate-700 font-semibold  pl-2">{requisition.selectedJD || "Sr.Executive-Accounts"}</div>
                </div>

                {/* Job Description */}
                {/* <div className="mb-6">
                  <h3 className="text-md font-medium mb-2">Job Description</h3>
                  <div className="text-sm text-black whitespace-pre-line pl-2">{requisition.jobDescription || "-"}</div>
                </div> */}

                <div className="mb-6">
                    <h3 className="text-md font-semibold mb-2">Job Description</h3>
                    <div className="text-slate-500 font-semibold text-black whitespace-pre-line pl-2">
                      {requisition.jobDescription
                        ? requisition.jobDescription
                            .split('\n')
                            .map((line, index) => (
                              <div key={index}>
                                {line.trim() !== '' ? `• ${line}` : ''}
                              </div>
                            ))
                        : "-"}
                    </div>
                  </div>

                  {/* Required Skills */}
                  <div className="mb-6">
                    <h3 className="text-md font-semibold mb-2">Required Skills</h3>
                    <div className="text-slate-500 font-semibold text-black pl-2">
                      {requisition.requiredSkills
                        ? requisition.requiredSkills.split('\n').map((line, index) => (
                            <div key={index}>{line.trim() ? `• ${line}` : ''}</div>
                          ))
                        : "-"}
                    </div>
                  </div>

                  {/* Additional Skills */}
                  <div className="mb-6">
                    <h3 className="text-md font-semibold mb-2">Additional Skills</h3>
                    <div className="text-slate-500 font-semibold text-black pl-2">
                      {requisition.additionalSkills
                        ? requisition.additionalSkills.split('\n').map((line, index) => (
                            <div key={index}>{line.trim() ? `• ${line}` : ''}</div>
                          ))
                        : "-"}
                    </div>
                  </div>
                 </div>
               </div>
              </div>
  );
};

export default ViewRequisitionModal;






// import React from "react";
// import { X } from "lucide-react";

// const Field = ({ label, value }) => (
//   <div className="flex justify-between py-1">
//     <div className="font-medium text-sm text-gray-600">{label}</div>
//     <div className="text-sm text-gray-800">{value || "-"}</div>
//   </div>
// );

// const ViewRequisitionModal = ({ requisition, onClose }) => {
//   if (!requisition) return null;

//   return (
//     <div className="fixed inset-0 z-50 bg-black bg-opacity-40 flex justify-center items-start pt-10">
//       <div className="bg-white w-[90%] max-w-6xl rounded-xl p-6 relative shadow-xl border border-gray-300 max-h-[90vh] overflow-y-auto">

//         {/* Close Button (Top Right Corner) */}
//         <button
//           onClick={onClose}
//           className="absolute top-4 right-4 text-red-500 border border-red-500 rounded-full p-1 hover:bg-red-100"
//           title="Close"
//         >
//           <X size={20} />
//         </button>

//         {/* Row 1: Request No */}
//         <div className="flex justify-start items-start mb-1">
//           <h2 className="text-xl font-semibold text-gray-800">
//             Request No:{" "}
//             <span className="text-green-600">
//               ERF{requisition.requisitionNumber?.toString().padStart(4, "0")}
//             </span>
//           </h2>
//         </div>

//         {/* Row 2: Approval & Overall Status */}
//         <div className="flex justify-between items-center  mb-4">
//           <div className="w-1/3" />
//           <div className="w-1/3 text-center text-base font-medium text-gray-700">
//             Approval Status:{" "}
//             <span className="text-red-500">{requisition.approvalStatus}</span>
//           </div>
//           <div className="w-1/3 text-right text-base font-medium text-gray-700">
//             Overall Status:{" "}
//             <span className="text-blue-600">{requisition.overallStatus}</span>
//           </div>
//         </div>

//      <div className="border border-gray-300 rounded px-6 py-4 mb-6">
//           {/* Top row: Requisition Type and Action */}
//           <div className="flex justify-between items-center mb-4">
//             <div className="text-sm text-gray-600 flex">
//               <div className="min-w-[200px]">Requisition Type</div>
//               <span className="font text-sm text-black">
//                 {requisition.requisitionType || "-"}
//               </span>
//             </div>
//             <div className="relative inline-block text-left">
//               <select className="border text-sm border-gray-300 rounded px-2 py-1 text-blue-500 pr-6 appearance-none bg-white">
//                 <option>Action</option>
//                 <option>Edit</option>
//                 <option>Withdraw</option>
//               </select>
//             </div>
//           </div>

//           <div className="w-[50%] h-px bg-gray-200 mt-1 mb-2" />

//           {/* Date */}
//           <div className="text-sm text-gray-600 flex ">
//             <div className="min-w-[200px]">Date</div>
//             <span className="font text-black">
//               {requisition.appliedOn || "-"}
//             </span>
//           </div>

//           <div className="w-[50%] h-px bg-gray-200 mt-2 mb-4" />

//           {/* Employment Type */}
//           <div className="text-sm text-gray-600 flex ">
//             <div className="min-w-[200px]">Employment Type</div>
//             <span className="font text-black">
//               {requisition.employmentType || "-"}
//             </span>
//           </div>

//           <div className="w-[50%] h-px bg-gray-200 mt-2 mb-4" />

//           {/* Billing Type */}
//           <div className="text-sm text-gray-600 flex ">
//             <div className="min-w-[200px]">Billing Type</div>
//             <span className="font text-black">
//               {requisition.billingType || "-"}
//             </span>
//           </div>

//           <div className="w-[50%] h-px bg-gray-200 my-2" />
        

        


        
//       </div>
//     </div>
//     </div>
//   );
// };

// export default ViewRequisitionModal;


























// import React from "react";
// import { X } from "lucide-react";

// const ViewRequisitionModal = ({ requisition, onClose }) => {
//   return (
//     <div className="fixed inset-0 z-50 bg-black bg-opacity-40 flex justify-center items-start pt-10">
//       <div className="bg-white w-[90%] max-w-6xl rounded-xl p-6 relative shadow-lg border border-gray-300 max-h-[90vh] overflow-y-auto">
//         {/* Close */}
//         <button onClick={onClose} className="absolute top-4 right-4 text-gray-500 hover:text-red-500">
//           <X size={24} />
//         </button>

//         {/* Request Header */}
//         <div className="text-center mb-6 border-b pb-4">
//           <h2 className="text-base font-semibold">Request No : <span className="text-green-600">ERF00{requisition.requisitionNumber}</span></h2>
//           <p className="text-sm text-gray-500 mt-1">
//             Approval Status: <span className="text-red-500">{requisition.approvalStatus}</span> | 
//             Overall Status: <span className="text-blue-500">{requisition.overallStatus}</span>
//           </p>
//         </div>

//         {/* Requisition Details - Top Row */}
//         <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-sm text-gray-600 border-b pb-4">
//           <Field label="Requisition Type" value={requisition.requisitionType} />
//           <Field label="Date" value={requisition.appliedOn} />
//           <Field label="Employment Type" value={requisition.employmentType} />
//           <Field label="Billing Type" value={requisition.billingType} />
//         </div>

//         {/* Middle Sections: Replacement | Position | Timeline */}
//         <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-6 border-b pb-6 text-sm">
//           {/* Replacement */}
//           <div>
//             <h3 className="text-xs font-semibold text-gray-700 mb-2">Replacement</h3>
//             <Field label="Name of Replacement" value={requisition.replacementType} />
//             <Field label="Employee Code" value={requisition.employeeCode} />
//             <Field label="Project" value={requisition.replacementProject} />
//             <Field label="Department" value={requisition.replacementDepartment} />
//             <Field label="Location" value={requisition.replacementLocation} />
//             <Field label="CTC" value={requisition.ctc} />
//           </div>

//           {/* Position Details */}
//           <div>
//             <h3 className="text-xs font-semibold text-gray-700 mb-2">Position Details</h3>
//             <Field label="Department" value={requisition.department} />
//             <Field label="Position" value={requisition.position} />
//             <Field label="No of Positions" value={requisition.noOfPositions} />
//             <Field label="Experience Range" value={`${requisition.minimumExperienceRange} to ${requisition.maximumExperienceRange}`} />
//             <Field label="Education" value={requisition.education} />
//             <Field label="Certification(s)" value={requisition.certifications} />
//             <Field label="Location" value={requisition.location} />
//             <Field label="Reporting To" value={requisition.reportingTo} />
//             <Field label="Budget" value={requisition.budget} />
//           </div>

//           {/* Timeline */}
//           <div className="border-l pl-4">
//             <h3 className="text-xs font-semibold text-gray-700 mb-2">Timeline</h3>
//             <div className="text-xs text-red-500 font-semibold">Pending</div>
//             <button className="mt-2 bg-red-500 text-white text-xs px-2 py-1 rounded">Withdraw</button>
//             <div className="text-xs text-gray-500 mt-4 leading-tight">
//               Harish Kumar added a comment<br />
//               03 June, 2022 - 11:36 AM
//             </div>
//             <div className="text-xs text-gray-500 mt-2 leading-tight">
//               Harish Kumar submitted<br />
//               02 June, 2022 - 05:30 PM
//             </div>
//             <select className="mt-4 border text-sm border-gray-300 rounded px-2 py-1 text-blue-500">
//               <option>Open</option>
//             </select>
//           </div>
//         </div>

//         {/* IT Asset & Initiator */}
//         <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6 border-b pb-6 text-sm">
//           {/* IT Asset */}
//           <div>
//             <h3 className="text-xs font-semibold text-gray-700 mb-2">IT Asset</h3>
//             <Field label="Asset Required" value={requisition.itAsset} />
//             <Field label="Configuration" value={requisition.configuartions} />
//             <Field label="Additional Info" value={requisition.additionalInformations} />
//           </div>
//           {/* Initiator */}
//           <div>
//             <h3 className="text-xs font-semibold text-gray-700 mb-2">Initiator Details</h3>
//             <Field label="Name" value={requisition.initiatorName} />
//             <Field label="Employee Code" value={requisition.initiatorEmployeeCode} />
//             <Field label="BU Head" value={requisition.buHead} />
//             <Field label="Location" value={requisition.initiatorLocation} />
//             <Field label="First Level Approver" value={requisition.firstLevelApprover} />
//             <Field label="Second Level Approver" value={requisition.secondLevelApprover} />
//           </div>
//         </div>

//         {/* JD and Skills */}
//         <div className="mt-6 text-sm">
//           <Field label="Selected JD" value={requisition.selectedJob} />
//           <Field label="Job Description" value={requisition.jobDescription} />
//           <Field label="Required Skills" value={requisition.requiredSkills} />
//           <Field label="Additional Skills" value={requisition.additionalSkills} />
//         </div>
//       </div>
//     </div>
//   );
// };

// const Field = ({ label, value }) => (
//   <div className="mb-2">
//     <span className="block text-[12px] text-gray-500">{label}</span>
//     <span className="text-[13px] text-gray-800">{value || "-"}</span>
//   </div>
// );

// export default ViewRequisitionModal;
