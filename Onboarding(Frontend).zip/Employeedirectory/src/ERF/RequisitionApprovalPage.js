import React, { useState, useEffect } from 'react';
import axios from 'axios';

const RequisitionApprovalPage = ({ requisitionId }) => {
    const [requisition, setRequisition] = useState(null);
    const [comments, setComments] = useState("");
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState("");
    const [submitting, setSubmitting] = useState(false);

    // 1. Fetch data from the backend on component load
    useEffect(() => {
        const fetchData = async () => {
            try {
                const response = await axios.get(`http:localhost:9024/employeeRequisition/getSingleEmployeeRequistionData/${requisitionId}`);
                setRequisition(response.data);
                setLoading(false);
            } catch (err) {
                setError("Failed to load requisition details.");
                setLoading(false);
            }
        };
        fetchData();
    }, [requisitionId]);

    // 2. Handle Approval/Rejection Logic
    const handleAction = async (action) => {
        setError("");
        
        // Frontend validation: Logic mirroring the backend service
        if (action === 'REJECT' && !comments.trim()) {
            setError("Comments are mandatory when rejecting a requisition.");
            return;
        }

        setSubmitting(true);
        try {
            await axios.post(`http:localhost:9024/employeeRequisition/requisitionStatus/${requisitionId}`, {
                action: action,
                comments: comments
            });
            alert(`Requisition ${action === 'APPROVE' ? 'Approved' : 'Rejected'} successfully!`);
            // Optional: Redirect to dashboard
            // window.location.href = "/dashboard";
        } catch (err) {
            setError(err.response?.data || "An error occurred while processing the request.");
        } finally {
            setSubmitting(false);
        }
    };

    if (loading) return <div className="p-10 text-center">Loading Requisition Data...</div>;
    if (!requisition) return <div className="p-10 text-red-500 text-center">{error}</div>;

    return (
        <div className="min-h-screen bg-gray-50 p-6">
            <div className="max-w-5xl mx-auto bg-white shadow-lg rounded-lg overflow-hidden">
                
                {/* Header */}
                <div className="bg-slate-800 text-white p-6 flex justify-between items-center">
                    <div>
                        <h1 className="text-2xl font-bold">Requisition Approval</h1>
                        <p className="text-sm opacity-80">ID: {requisition.requisitionNumber} | Applied On: {requisition.appliedOn}</p>
                    </div>
                    <div className="text-right">
                        <span className="px-3 py-1 bg-yellow-500 text-black text-xs font-bold rounded-full uppercase">
                            {requisition.overallStatus || "Pending Review"}
                        </span>
                    </div>
                </div>

                <div className="p-8">
                    {/* Initiator Details Section */}
                    <SectionTitle title="Initiator Information" />
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8 bg-gray-50 p-4 rounded border">
                        <DetailField label="Initiator Name" value={requisition.initiatorName} />
                        <DetailField label="Employee Code" value={requisition.initiatorEmployeeCode} />
                        <DetailField label="Location" value={requisition.initiatorLocation} />
                    </div>

                    {/* Position Details Section (Blue Section in your screenshot) */}
                    <SectionTitle title="Position Details" />
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8 bg-cyan-50 p-4 rounded border border-cyan-100">
                        <DetailField label="Department" value={requisition.department} />
                        <DetailField label="Position" value={requisition.position} />
                        <DetailField label="Exp Range" value={`${requisition.minimumExperienceRange} - ${requisition.maximumExperienceRange} Years`} />
                        <DetailField label="Education" value={requisition.education} />
                        <DetailField label="Location" value={requisition.location} />
                        <DetailField label="Budget" value={requisition.budget} />
                        <DetailField label="Positions" value={requisition.noOfPositions} />
                        <DetailField label="Employment Type" value={requisition.employmentType} />
                    </div>

                    {/* Requirements Section */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
                        <div>
                            <SectionTitle title="Job Description" />
                            <div className="p-3 border rounded text-sm text-gray-700 bg-white min-h-[100px]">
                                {requisition.jobDescription}
                            </div>
                        </div>
                        <div>
                            <SectionTitle title="Required Skills" />
                            <div className="p-3 border rounded text-sm text-gray-700 bg-white min-h-[100px]">
                                {requisition.requiredSkills}
                            </div>
                        </div>
                    </div>

                    {/* Approval Form Section */}
                    <div className="mt-10 border-t pt-8">
                        <h3 className="text-xl font-semibold mb-4 text-gray-800">Review Decision</h3>
                        
                        <div className="mb-6">
                            <label className="block text-sm font-medium text-gray-700 mb-2">
                                Approver Comments <span className="text-red-500">* (Required for rejection)</span>
                            </label>
                            <textarea 
                                className={`w-full p-3 border rounded-md focus:ring-2 focus:ring-blue-500 outline-none transition-all ${error ? 'border-red-500' : 'border-gray-300'}`}
                                rows="4"
                                placeholder="Enter your remarks here..."
                                value={comments}
                                onChange={(e) => setComments(e.target.value)}
                            ></textarea>
                            {error && <p className="mt-2 text-sm text-red-600 font-medium">{error}</p>}
                        </div>

                        <div className="flex gap-4">
                            <button 
                                onClick={() => handleAction('APPROVE')}
                                disabled={submitting}
                                className="px-8 py-3 bg-green-600 hover:bg-green-700 text-white font-bold rounded-md transition-colors disabled:opacity-50"
                            >
                                {submitting ? "Processing..." : "Approve Requisition"}
                            </button>
                            <button 
                                onClick={() => handleAction('REJECT')}
                                disabled={submitting}
                                className="px-8 py-3 bg-red-600 hover:bg-red-700 text-white font-bold rounded-md transition-colors disabled:opacity-50"
                            >
                                {submitting ? "Processing..." : "Reject"}
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

// Small Helper Components for layout consistency
const SectionTitle = ({ title }) => (
    <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-3">{title}</h3>
);

const DetailField = ({ label, value }) => (
    <div>
        <p className="text-xs text-gray-500 mb-1">{label}</p>
        <p className="text-sm font-semibold text-gray-900">{value || "N/A"}</p>
    </div>
);

export default RequisitionApprovalPage;