import React, { useEffect, useState } from "react";

const API_BASE_URL = "http://localhost:8080/api/erf";

// Years & months
const years = ["All", "2025", "2024", "2023", "2022", "2021"];

const months = [
  { label: "All", value: "All" },
  { label: "January", value: "1" },
  { label: "February", value: "2" },
  { label: "March", value: "3" },
  { label: "April", value: "4" },
  { label: "May", value: "5" },
  { label: "June", value: "6" },
  { label: "July", value: "7" },
  { label: "August", value: "8" },
  { label: "September", value: "9" },
  { label: "October", value: "10" },
  { label: "November", value: "11" },
  { label: "December", value: "12" },
];

function StatusBadge({ status }) {
  let colorClasses = "text-gray-600";
  if (status === "Completed") colorClasses = "text-green-600";
  if (status === "Hiring in Process") colorClasses = "text-yellow-500";
  if (status === "Closed") colorClasses = "text-red-500";

  return <span className={`text-xs font-medium ${colorClasses}`}>{status}</span>;
}

function HiringRatioBar({ ratio }) {
  let barColor = "bg-green-500";
  if (ratio < 100 && ratio >= 50) barColor = "bg-yellow-400";
  if (ratio < 50) barColor = "bg-red-400";

  return (
    <div className="flex items-center gap-2">
      <div className="flex-1 h-2 bg-gray-200 rounded-full overflow-hidden">
        <div className={`h-full ${barColor}`} style={{ width: `${ratio}%` }} />
      </div>
      <span className="text-xs text-gray-500 whitespace-nowrap">{ratio}% Hired</span>
    </div>
  );
}

export default function ErfOverviewPage() {
  const [activeTab, setActiveTab] = useState("overview");
  const [selectedYear, setSelectedYear] = useState("All");
  const [selectedMonth, setSelectedMonth] = useState("All");

  const [overview, setOverview] = useState({
    createdRequestsLast30Days: 0,
    hiringInProcessLast30Days: 0,
    hiredLast30Days: 0,
    totalErfCreatedLast30Days: 0,
  });

  const [rows, setRows] = useState([]);

  const fallbackRows = [
    {
      erfReqNo: "ERF101",
      position: "Java Developer",
      noOfPosition: 4,
      jobId: "12301",
      interviewed: 4,
      offered: 4,
      hired: 4,
      status: "Completed",
      hiringRatioPercent: 100,
    },
  ];

  const finalRows = rows.length > 0 ? rows : fallbackRows;

  useEffect(() => {
    const fetchData = async () => {
      const params = new URLSearchParams();

      if (selectedYear !== "All") params.append("year", selectedYear);
      if (selectedMonth !== "All") params.append("month", selectedMonth);

      const url =
        params.toString().length > 0
          ? `${API_BASE_URL}/overview?${params.toString()}`
          : `${API_BASE_URL}/overview`;

      try {
        const res = await fetch(url);
        const data = await res.json();
        setOverview(data.overview || {});
        setRows(data.rows || []);
      } catch (e) {
        console.error(e);
      }
    };

    fetchData();
  }, [selectedYear, selectedMonth]);

  const handlePrint = () => window.print();

  return (
    <div className="min-h-screen bg-gray-50 text-gray-800">
      
      {/* ============ TOP TABS ============ */}
      <div className="w-full bg-white border-b border-gray-200">
        <div className="max-w-6xl mx-auto px-6 flex items-center justify-between h-12">
          <div className="flex items-center gap-6 text-sm">
            <button
              className={`pb-2 ${
                activeTab === "overview"
                  ? "text-sky-600 border-b-2 border-sky-600"
                  : "text-gray-500"
              }`}
              onClick={() => setActiveTab("overview")}
            >
              Overview
            </button>

            <button
              className={`pb-2 ${
                activeTab === "myerf"
                  ? "text-sky-600 border-b-2 border-sky-600"
                  : "text-gray-500"
              }`}
              onClick={() => setActiveTab("myerf")}
            >
              MY ERF
            </button>
          </div>
        </div>
      </div>

      {/* ============ CONTENT AREA ============ */}
      <div className="max-w-6xl mx-auto px-6 py-4">

        {/* Filters */}
        <div className="flex justify-center mt-2">
          <div className="flex justify-center items-center gap-12 mb-6">

            {/* Year Filter */}
            <div className="flex items-center gap-2 relative">
             <span className="text-[#4B5563] font-medium text-base">Choose Year :</span>


              <select
                className="custom-select text-base font-semibold cursor-pointer pr-6 py-1 border border-gray-300 rounded-md bg-white appearance-none"
                value={selectedYear}
                onChange={(e) => setSelectedYear(e.target.value)}
              >
                {years.map((y) => (
                  <option key={y} value={y}>
                    {y}
                  </option>
                ))}
              </select>

              <span className="absolute right-1 top-1/2 -translate-y-1/2 text-black pointer-events-none">▼</span>
            </div>

            {/* Month Filter */}
            <div className="flex items-center gap-2 relative">
             <span className="text-[#4B5563] font-medium text-base">Choose Month :</span>


              <select
                className="custom-select text-base font-semibold cursor-pointer pr-6 py-1 border border-gray-300 rounded-md bg-white appearance-none"
                value={selectedMonth}
                onChange={(e) => setSelectedMonth(e.target.value)}
              >
                {months.map((m) => (
                  <option key={m.value} value={m.value}>
                    {m.label}
                  </option>
                ))}
              </select>

              <span className="absolute right-1 top-1/2 -translate-y-1/2 text-black pointer-events-none">▼</span>
            </div>
          </div>
        </div>

        {/* Overview Heading */}
        <div className="flex items-center justify-between mb-2">
          <h2 className="text-base font-semibold text-gray-700">Overview</h2>

          <div className="min-w-[200px]" />
        </div>

        {/* ================= OVERVIEW CARDS ================= */}
        <div className="grid grid-cols-3 gap-4 mb-6">

          {/* Created Requests */}
       <div className="bg-white shadow rounded-xl px-4 py-2 h-24">
  
  {/* Title + Last 30 Days */}
  <div className="flex items-start justify-between">
    <h3 className="text-lg font-semibold text-gray-700 leading-tight">
      Created Requests
    </h3>

    <div className="flex items-center gap-1">
      <span className="text-[11px] text-gray-500">Last 30 Days</span>
      <span className="text-gray-600 text-[10px] font-bold -mt-[2px]">▼</span>
    </div>
  </div>

  {/* Number - left middle */}
  <div className="text-4xl font-extrabold text-[#3B82F6] mt-3 ml-1">
    {overview.createdRequestsLast30Days || 0}
  </div>

</div>






          {/* Hiring in Process */}
          <div className="bg-white shadow-md rounded-xl px-6 py-4">
            <h3 className="text-sm font-bold text-gray-700">Hiring in process</h3>
            <div className="text-3xl font-extrabold mt-1" style={{ color: "#16A34A" }}>
              {overview.hiringInProcessLast30Days || 0}
            </div>
            <div className="flex items-center gap-1 mt-1">
              <span className="text-xs text-gray-500">Last 30 Days</span>
              <span className="text-gray-600 text-[10px] font-bold">▼</span>
            </div>
          </div>

          {/* Hired */}
          <div className="bg-white shadow-md rounded-xl px-6 py-4">
            <h3 className="text-sm font-bold text-gray-700">Hired</h3>
            <div className="text-3xl font-extrabold mt-1" style={{ color: "#F472B6" }}>
              {overview.hiredLast30Days || 0}
            </div>
            <div className="flex items-center gap-1 mt-1">
              <span className="text-xs text-gray-500">Last 30 Days</span>
              <span className="text-gray-600 text-[10px] font-bold">▼</span>
            </div>
          </div>
        </div>

        {/* ========== PRINT BUTTON (placed correctly) ========== */}
        <div className="flex justify-end mb-4">
          <button
            onClick={handlePrint}
            className="p-2 rounded-full border border-gray-300 hover:bg-gray-100"
            title="Print"
          >
            <div className="w-4 h-3 border border-gray-600 border-b-0 mx-auto" />
            <div className="w-4 h-2 border border-gray-600 mx-auto mt-0.5" />
          </button>
        </div>

        {/* ========== TABLE ========== */}
        <div className="px-6 py-3">
          <div className="overflow-y-auto max-h-72 pr-2">
            <table className="w-full text-xs">
              <thead className="border-b border-gray-200 text-gray-500">
                <tr className="text-left">
                  <th className="py-2 pr-4">ERF Req No</th>
                  <th className="py-2 pr-4">Position</th>
                  <th className="py-2 pr-4">No of Position</th>
                  <th className="py-2 pr-4">Job ID</th>
                  <th className="py-2 pr-4">Interviewed</th>
                  <th className="py-2 pr-4">Offered</th>
                  <th className="py-2 pr-4">Hired</th>
                  <th className="py-2 pr-4">ERF Status</th>
                  <th className="py-2">Hiring Ratio</th>
                </tr>
              </thead>

              <tbody className="text-gray-700">
                {finalRows.map((row, idx) => (
                  <tr key={idx} className="border-b border-gray-100 last:border-b-0">
                    <td className="py-2 pr-4">{row.erfReqNo}</td>
                    <td className="py-2 pr-4">{row.position}</td>
                    <td className="py-2 pr-4 text-center">{row.noOfPosition}</td>
                    <td className="py-2 pr-4">{row.jobId}</td>
                    <td className="py-2 pr-4 text-center">{row.interviewed}</td>
                    <td className="py-2 pr-4 text-center">{row.offered}</td>
                    <td className="py-2 pr-4 text-center">
                      <span className="text-sky-600 cursor-pointer">{row.hired}</span>
                    </td>
                    <td className="py-2 pr-4">
                      <StatusBadge status={row.status} />
                    </td>
                    <td className="py-2">
                      <HiringRatioBar ratio={row.hiringRatioPercent || 0} />
                    </td>
                  </tr>
                ))}
              </tbody>

            </table>
          </div>
        </div>

      </div>
    </div>
  );
}
