import React from 'react';
import Trial from './Trial';
import Empdirectory from './Empdirectory';
import Bulkadd from './Bulkadd';
import AddEmp from './AddEmp';
import OnboardingOverview from './Onboarding/OnboardingOverview';
import { BrowserRouter as Router,Routes, Route } from 'react-router-dom';
import DashBoard from './Onboarding/JobOverallDashboard';
import AddEmployee from './Onboarding/AddEmployee';
import ListOfOnboardingCandidates from './Onboarding/ListOfOnboardingCandidates';
import EmployeeDetailsPage from './Onboarding/EmployeeDetailsPage';
import IRFDashboard from './Onboarding/IRFDashboard';
import JobOverallDashboard from './Onboarding/JobOverallDashboard';
import JobDashboard from './Onboarding/JobDashboard ';
import ErfOverviewPage from './ERF/ErfOverviewPage';
import EmployeeRequisition from './ERF/EmployeeRequisition';
import RequisitionApprovalPage from './ERF/RequisitionApprovalPage';





function App() {
  return (
    <Router>
    <div>
       <Routes>
        <Route path="/" element={<OnboardingOverview/>}/>
            <Route path="/empDirectory" element={<Empdirectory />} />
            <Route path="/addEmployee" element={<AddEmployee />} />
             {/* <Route path="/listOfOnbcandidates" element={<ListOfOnboardingCandidates />} /> */}
             {/* The new route for VIEWING a candidate's details */}
        {/* The URL path matches the one used by the View button in the list: /employee/:candidateId */}
        <Route path="/employee/:candidateId" element={<EmployeeDetailsPage />} />
        <Route path="/irfdashboard" element={<IRFDashboard />} />
         <Route path="/jobdashboard/:intRefData" element={<JobDashboard />} />

         <Route path="/erf" element={<EmployeeRequisition />} />
            <Route path="/overviewErf" element={<ErfOverviewPage />} />
            <Route path="requisitionApproval/:requisitionId" element={<RequisitionApprovalPage />} />
      {/* <Empdirectory/> */}
      
    {/* <DashBoard/> */}
      {/* <Excelcreation/> */}
      {/* <Bulkadd/> */}
      {/* <AddEmp/> */}
      {/* <Trial /> */}
       </Routes>
    </div>
  </Router>
);
}

export default App;
