const config = {
 // empolyeeRequisitionUrl: "http://43.205.24.208:9024/employeeRequisition",
   empolyeeRequisitionUrl: "http://localhost:9024/employeeRequisition",
};

export default config;