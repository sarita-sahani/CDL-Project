package com.cms.cdl.dto.request_dto.wrapperDTO;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class GenericRetDataWrapper<T> {

    @JsonProperty("retcode")
    private int retcode;

    @JsonProperty("retdata")
    private List<T> retdata;
}
